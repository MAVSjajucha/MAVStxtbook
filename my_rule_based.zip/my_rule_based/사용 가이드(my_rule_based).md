z
**이 파일은 my_rule_based의 사용 가이드입니다.**
**디렉터리 구조는 `디렉터리 구조(my_rule_based).md`에서 확인할 수 있습니다.**
**실습 관련 자료는 `https://github.com/MAVSjajucha/MAVStxtbook`에서 다운로드할 수 있습니다.**
**SSH 관련 설명은 VS Code 기준입니다. 관련 설명은 'MAVS(Yahboom ROSMASTER A1) 사용 가이드'를 참고하세요.**


`========================================================================================================================================================`

# [패키지 다운로드 후 빌드]

## 1. my_rule_based.zip을 다운로드한 후 모형 자주차 시스템(MAVS, Yahboom ROSMASTER A1)에 복사/붙여 넣습니다.

### A. 로컬 접속하여 파일 옮기기
(1) 개인 PC를 통해 파일을 USB에 저장한 후 MAVS에 옮깁니다.
(2) MAVS 화면을 모니터로 확인하기 위해서는 DP 케이블이 필요힙니다(모니터 포트에 따라 DP to DP, DP to HDMI 등 케이블 준비).

### B. 원격 접속하여 파일 옮기기
(1) Windows PC에 파일을 다운로드합니다.
(2) Windows 터미널을 엽니다.
(3) scp "**my_rule_based.zip이 저장된 Windows PC의 절대 경로**" "jetson@**차량 IP 주소**:/home/jetson/"
scp "C:\Users\user\Downloads\my_rule_based.zip" "jetson@10.96.160.8:/home/jetson/"
(4) 차량 비밀번호를 요구하면 "yahboom"을 입력합니다.

## 2. my_rule_based 패키지를 빌드합니다.

(1) MAVS 터미널에서 다음 명령을 차례대로 실행해 빌드합니다.(```bash를 제외하고 복사해서 붙여넣으세요.)

```bash
python3 -m zipfile -e /home/jetson/my_rule_based.zip /home/jetson
```

```bash
cd /home/jetson/my_rule_based
colcon build --symlink-install --packages-select \
  my_rule_based_interfaces \
  my_rule_based_learning
```

(2) 빌드가 완료되면 다음 명령으로 소싱(sourcing)합니다. 이후 새 MAVS 터미널을 열 때마다 위 소싱 명령을 실행합니다. 환경만 불러오는 명령이므로 노드가 실행되지는 않습니다.

```bash
source /home/jetson/my_rule_based/install/setup.bash
```

`install/setup.bash`는 빌드 후 생성됩니다. 빌드할 때 불러온 ROS 2와 Yahboom 환경 경로도 이 파일에 기록됩니다. 

`========================================================================================================================================================`


# [실습1. 센서 정보 확인하기]

## 1. 센서 확인용으로 drive.launch.py를 실행합니다.

(1) 소싱을 사용해 환경을 불러온 MAVS 터미널에서 다음 명령을 실행합니다.

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=depth enable_motion:=false
```

(2) 실행한 터미널은 그대로 둡니다. `drive.launch.py`는 기본적으로 차량 제어부, 카메라, 라이다, 격자 처리, 웹 시각화, 주행 판단 노드를 함께 실행합니다.

`enable_motion:=false`에서는 `/cmd_vel`을 발행하지 않고 실습용 판단 함수도 실행하지 않습니다. 웹의 "주행 시작" 버튼을 눌러도 주행 명령 출력은 허용되지 않습니다.

## 2. 웹 화면에 접속합니다.

(1) 차량 앞쪽 디스플레이에서 IP 주소를 확인합니다. 별도의 MAVS 터미널에서 다음 명령으로 확인할 수도 있습니다.

```bash
hostname -I
```

주소가 여러 개 나오면 PC와 연결된 네트워크의 IP 주소를 사용합니다.

(2) 같은 네트워크에 연결된 PC의 브라우저 주소창에 다음 주소를 입력합니다.

http://**차량 IP 주소**:8080

차량 자체의 브라우저에서는 `http://localhost:8080`으로 접속할 수 있습니다. PC에서 `localhost`를 입력하면 PC 자신에게 접속하므로 차량 IP 주소를 입력해야 합니다.

## 3. 화면을 선택하여 센서 정보를 확인합니다.

(1) 웹 화면에서 확인할 항목을 선택합니다.

- RGB: 카메라의 컬러 영상을 확인합니다.
- 격자: 윤곽선과 격자, V·L·R 특징값의 미리보기를 확인합니다.
- Depth: 깊이 영상과 커서 좌표, 관심 영역별 거리 통계를 확인합니다.
- LiDAR: 라이다 측정점과 지정한 각도 구간의 거리 통계를 확인합니다.

(2) 화면 선택은 표시 내용만 바꿉니다. Depth 화면을 열어도 실행 미션은 바뀌지 않습니다. 미션을 바꾸려면 런치를 종료하고 `mission_mode`를 변경하여 다시 실행합니다.

## 4. Depth 영상에서 관심 영역(ROI)을 지정하는 방법

### 4-1. 커서 좌표 확인하기

(1) Depth 영상 위에 마우스 커서를 올립니다. 영상 오른쪽 위에 `X: 320, Y: 240 px`와 같이 좌표가 표시됩니다.

- 왼쪽 위는 `(0, 0)`, 오른쪽 아래는 `(639, 479)`입니다.
- X는 오른쪽으로, Y는 아래쪽으로 증가합니다.
- 화면 크기를 100%·75%·50%로 바꿔도 좌표는 640×480 기준입니다.
- 커서를 영상 밖으로 옮기면 좌표 표시가 사라집니다.

(2) 커서 좌표로 확인할 영역의 위치를 정합니다. 이 표시는 영상의 픽셀 위치이며, 해당 위치의 거리나 실제 공간의 X·Y 좌표는 아닙니다.

### 4-2. 관심 영역의 거리 확인하기

(1) "+ ROI 추가"를 누르고 `y1, y2, x1, x2`를 입력합니다.

(2) "ROI 적용·저장"을 누릅니다. 최대 16개 영역을 지정할 수 있으며, 각 영역에서 유효한 거리의 최솟값·평균값·최댓값을 mm 단위로 확인합니다.

(3) 웹에서는 양 끝 픽셀을 포함합니다. 예를 들어 `y1=200, y2=259, x1=300, x2=359`인 영역을 주행 코드에 사용할 때는 다음과 같이 작성합니다.

```Python
ROI_DISTANCE = DEPTH_IMAGE[200:260, 300:360]
VALID_DISTANCE = ROI_DISTANCE[ROI_DISTANCE > 0]
```

웹 ROI는 화면 표시와 통계 확인에 사용합니다. 저장해도 판단 함수의 ROI나 장애물 회피 조건이 바뀌지는 않습니다. 주행에 사용할 영역과 조건은 `decision_node.py`에 직접 작성합니다.

기본 원본 영상은 640×480이므로 웹 좌표와 배열 좌표가 일치합니다. 카메라 원본 해상도를 바꾸었다면 배열 좌표도 그에 맞게 수정합니다.

격자의 "미리보기 적용"과 LiDAR 표시 설정도 웹 확인용입니다. 실제 차선 처리 설정은 `grid_node`의 설정에서, 장애물 회피 조건은 실습용 판단 함수에서 수정합니다.


`========================================================================================================================================================`


# [실습2. 규칙 기반 주행]

## 1. 실습할 미션의 판단 함수를 작성합니다.

(1) 별도의 MAVS 터미널에서 다음 파일을 엽니다.

```bash
nano /home/jetson/my_rule_based/src/my_rule_based_learning/my_rule_based_learning/decision_node.py
```

(2) 실습할 미션에 해당하는 함수를 수정합니다.

a. 차선 주행 미션
수정할 함수: `decide_lane(V, L, R)` 
받아오는 값: 차선 특징값 V, L, R

b. 깊이 정보 기반 장애물 회피 미션
수정할 함수: `decide_depth(DEPTH_IMAGE)` 
받아오는 값: 픽셀별 깊이 거리가 담긴 NumPy 배열. 단위 mm

c. 라이다 기반 장애물 회피 미션
수정할 함수: `decide_lidar(SCAN)` 
받아오는 값: LaserScan 메시지. 거리 m, 각도 rad

d. 통합 주행 미션
수정할 함수: `decide_integrated(V, L, R, DEPTH_IMAGE, SCAN)` 
받아오는 값: 차선 특징값, 깊이 영상, 라이다 정보

(3) 예제를 사용할 때는 기존 함수 전체를 예제 함수로 교체합니다. 기존 함수 안에 같은 이름의 함수를 다시 정의하지 않습니다.

## 2. 주행할 미션을 실행합니다.

(1) 센서 확인용 런치를 실행한 터미널에서 `Ctrl+C`를 눌러 종료합니다.

(2) 다음 중 실습할 미션의 명령 하나를 실행합니다.

### A. 차선 주행

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=lane enable_motion:=true
```

### B. 깊이 정보를 이용한 장애물 회피

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=depth enable_motion:=true
```

### C. 라이다를 이용한 장애물 회피

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=lidar enable_motion:=true
```

### D. 통합 주행

```bash
ros2 launch my_rule_based_learning drive.launch.py mission_mode:=integrated enable_motion:=true
```

미션을 지정하는 실행 인자는 `mission_mode`입니다. `enable_motion:=true`는 주행 명령 출력을 허용하는 설정입니다.

## 3. 웹 화면에서 주행을 시작합니다.

(1) 웹 화면의 "▶ 주행 시작" 버튼을 누릅니다. `enable_motion:=true`로 실행했더라도 이 버튼을 눌러야 주행이 시작됩니다.

(2) 주행을 멈추려면 "Ⅱ 일시정지" 버튼을 누릅니다.

(3) 선택한 미션에 필요한 센서 입력이 들어오는지 확인합니다.

센서 입력이 없거나 시간이 초과되면 정지합니다. 입력이 복구되면 주행 허용 상태에 따라 다시 판단합니다. 함수 오류나 함수 실행 시간 초과로 멈췄다면 원인을 해결한 뒤 "주행 시작"을 다시 눌러야 합니다.

## 4. 코드를 수정하고 다시 실행합니다.

(1) 웹 화면에서 "Ⅱ 일시정지"를 누릅니다.

(2) 런치를 실행한 터미널에서 `Ctrl+C`를 눌러 종료합니다.

(3) 판단 함수나 설정을 수정합니다. `--symlink-install`로 빌드한 뒤 기존 Python 파일의 함수 내용만 수정했다면 보통 노드를 다시 실행하면 반영됩니다.

(4) YAML 설정, 런치, 웹 파일, 메시지 정의, 패키지 구성을 수정하거나 버전을 교체했다면 다시 빌드하고 소싱합니다.

```bash
cd /home/jetson/my_rule_based
colcon build --symlink-install --packages-select my_rule_based_interfaces my_rule_based_learning
source /home/jetson/my_rule_based/install/setup.bash
```

(5) 원하는 미션의 런치를 실행하고 웹에서 "주행 시작"을 누릅니다. 웹 파일을 수정했다면 브라우저도 새로고침합니다. 이전 화면이 남아 있으면 `Ctrl+F5`를 누릅니다.

`========================================================================================================================================================`

# [실행 중 문제가 생겼을 때]

## 1. 환경 파일이나 패키지를 찾지 못하는 경우

(1) `install/setup.bash`가 없으면 빌드 완료 여부와 폴더 경로를 확인합니다. 이 가이드에서는 `/home/jetson/my_rule_based`를 사용합니다.

(2) `Package ... not found`가 나오면 다음 명령을 실행했는지 확인합니다.

```bash
source /home/jetson/my_rule_based/install/setup.bash
```

(3) 기본 Yahboom 경로에 환경 파일이 없다면 실제 설치 위치를 확인합니다.

```bash
ls /opt/ros
find /home/jetson/yahboomcar_ros2_ws -type f -path '*/install/setup.bash'
```

(4) 새 터미널을 열 때마다 잘못된 경로 오류가 나오면 `.bashrc`에 남은 이전 `source` 명령을 확인합니다.

```bash
nano /home/jetson/.bashrc
```

## 2. 웹 화면이나 주행이 정상적으로 동작하지 않는 경우

# a. 웹은 열리지만 차량이 움직이지 않는 경우

 `enable_motion:=true`, `mission_mode`, 주행 시작 여부, 센서 입력과 함수의 이동 명령을 확인합니다. 정지 사유는 `/decision_status`에서 확인합니다.

# b. 웹 화면이 열리지 않는 경우

 `vis_node` 실행 여부와 네트워크 연결을 확인하고, 차량 IP와 포트 `8080`으로 접속합니다.

포트 `8080` 사용 중 오류가 나오면 기존 웹 서버를 종료합니다. `drive.launch.py`와 `vis.launch.py`는 중복 실행하지 않습니다.

## 3. 빌드 중 '파일의 변경 시각이 미래입니다' 경고가 나오는 경우

(1) 파일의 수정 시각보다 차량 시간이 과거이면 이 경고가 나올 수 있습니다. 차량 시간을 확인합니다.

```bash
date
timedatectl status
```

(2) 시간이 맞지 않으면 차량을 인터넷에 연결하고 자동 시간 동기화를 켭니다.

```bash
sudo timedatectl set-ntp true
```

(3) 잠시 뒤 `timedatectl status`로 실제 시각과 `System clock synchronized: yes`를 확인한 다음 다시 빌드합니다. 명령을 입력한 직후에는 아직 동기화되지 않았을 수 있습니다.

`2 packages finished`와 함께 `had stderr output`이 표시되면 로그를 읽고 경고인지 빌드 실패인지 확인합니다.


`========================================================================================================================================================`

## 패키지의 노드, 토픽, 메시지 타입 확인 명령어 모음

(1) 런치를 실행한 터미널을 그대로 두고 새 MAVS 터미널을 엽니다. 먼저 환경을 불러옵니다.

```bash
source /home/jetson/my_rule_based/install/setup.bash
```

(2) 필요한 확인 명령을 하나씩 실행합니다. 아래 명령은 상태 확인용이며 주행 명령을 새로 보내지 않습니다. 연속 출력되는 명령은 `Ctrl+C`로 종료합니다.

### A. 패키지와 실행 중인 노드 확인

```bash
ros2 pkg prefix my_rule_based_learning
ros2 node list
ros2 node info /decision_node
```

### B. 토픽 이름·타입·연결 확인

```bash
ros2 topic list -t
ros2 topic info /lane_features
ros2 topic info /scan
ros2 topic info /cmd_vel
```

### C. 메시지 구조 확인

```bash
ros2 interface show my_rule_based_interfaces/msg/LaneFeatures
ros2 interface show sensor_msgs/msg/Image
ros2 interface show sensor_msgs/msg/LaserScan
ros2 interface show geometry_msgs/msg/Twist
```

### D. 차선 특징값·주행 명령·정지 사유 확인

```bash
ros2 topic echo /lane_features
```

```bash
ros2 topic echo /cmd_vel
```

```bash
ros2 topic echo /decision_status --qos-durability transient_local
```

`enable_motion:=false`에서는 판단 노드가 `/cmd_vel`을 발행하지 않으므로 출력이 없을 수 있습니다. `/decision_status`는 상태가 바뀔 때 발행합니다. 나중에 연 터미널에서도 최근 상태를 받도록 `--qos-durability transient_local`을 지정합니다.

### E. 센서 수신 주기 확인

```bash
ros2 topic hz /ascamera_hp60c/camera_publisher/depth0/image_raw
```

```bash
ros2 topic hz /scan
```

### F. 현재 실행 설정 확인

```bash
ros2 param get /decision_node mode
ros2 param get /decision_node publish_cmd_vel
ros2 param get /decision_node timer_hz
ros2 param get /vis_node web_port
```


`========================================================================================================================================================`

