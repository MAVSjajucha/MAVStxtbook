**이 파일은 my_rule_based의 디렉터리 구조입니다.**
**패키지 사용 설명은 `사용 가이드(my_rule_based).md`에서 확인할 수 있습니다.**
**실습 관련 자료는 `https://github.com/MAVSjajucha/MAVStxtbook`에서 다운로드할 수 있습니다.**
**SSH 관련 설명은 VS Code 기준입니다. 관련 설명은 'MAVS(Yahboom ROSMASTER A1) 사용 가이드'를 참고하세요.**


`========================================================================================================================================================`


**주요 실습과 관련된 파일/폴더는 `** 문자로 강조` 표시되어 있습니다.**

my_rule_based/                              # 작업 공간: /home/jetson/my_rule_based
├── src/
│   ├── my_rule_based_interfaces/           # 차선 특징값 메시지를 정의하는 ROS 2 패키지
│   │   ├── msg/
│   │   │   └── LaneFeatures.msg            # V·L·R 특징값과 영상·격자 정보
│   │   ├── CMakeLists.txt                  # 메시지 빌드 설정
│   │   └── package.xml                     # 패키지 정보 및 의존성
│   └── my_rule_based_learning/              # 규칙 기반 주행 실습용 ROS 2 패키지
│       ├── package.xml                     # 패키지 정보 및 의존성
│       ├── setup.py                        # Python 패키지 설치 및 실행 항목 설정
│       ├── setup.cfg                       # 설치 경로 설정
│       ├── launch/
│       │   ├── drive.launch.py             # 차량·센서·실습 노드 통합 실행 및 미션 선택
│       │   ├── camera_15fps.launch.py      # HP60C 카메라 실행(현재 요청 설정: 640×480, 25fps)
│       │   ├── grid.launch.py              # 차선 격자 처리 노드 실행
│       │   └── vis.launch.py               # 웹 시각화 노드 실행
│       ├── config/
│       │   ├── **decision.yaml**           # 판단 주기·시간 초과·속도 제한·깊이 정보 처리 설정
│       │   ├── **grid.yaml**               # RGB·특징값 토픽 및 차선 처리 설정
│       │   └── vis.yaml                    # 웹 포트·센서 토픽·깊이 및 라이다 표시 설정
│       ├── my_rule_based_learning/         # Python 소스 코드
│       │   ├── **decision_node.py**        # 실습용 판단 함수와 주행 명령·정지·반복 실행 처리
│       │   ├── grid_node.py                # RGB 영상 수신·차선 특징값 계산·/lane_features 발행
│       │   ├── grid_core.py                # 회색조 변환·블러링·캐니 윤곽선 검출·격자 특징값 계산
│       │   └── vis_node.py                 # 웹 서버·센서 시각화·ROI 통계 및 저장·주행 버튼 처리
│       ├── web/
│       │   └── index.html                  # 브라우저
│
├── **사용 가이드(my_rule_based).md**
├── **디렉터리 구조(my_rule_based).md**
├── build/                                  # 빌드 중간 결과
├── install/                                # 설치 결과 및 환경 설정(setup.bash)
└── log/                                    # 빌드 로그