"""학생이 주행 코드를 작성하는 파일입니다. 선택한 모드의 함수만 사용합니다."""

from geometry_msgs.msg import Twist
from my_supervised._internal.drive_runtime import run_decision_node


# ========================== 학생 작성 영역 ==========================
def lane_decision(V, L, R, prediction):
    """학습한 방향 또는 회전 속도로 차선을 따라갑니다.

    V, L, R: 수집 때와 같은 격자에서 계산한 차선 특징값 목록입니다.
    prediction["angular_z"]: 회전 속도 (rad/s). 좌회전은 +, 우회전은 -입니다.
    분류 모델은 direction으로 회전 방향을 정합니다.
    전진 속도와 분류 모델의 회전 속도는 아래에서 직접 지정합니다.
    """
    command = Twist()
    command.linear.x = 0.1
    angular_speed = 0.5
    if "direction" in prediction:
        if prediction["direction"] == "left":
            command.angular.z = angular_speed
        elif prediction["direction"] == "right":
            command.angular.z = -angular_speed
        else:
            command.angular.z = 0.0
    else:
        # 회귀 모델은 학습한 연속 회전 속도를 그대로 사용합니다.
        command.angular.z = float(prediction["angular_z"])
    return command


def obstacle_decision(image_bgr, boxes):
    """장애물이 가까우면 반대쪽으로 회전하고, 그 외에는 직진한다."""
    command = Twist()
    command.linear.x = 0.2
    angular_speed = 0.5

    image_height, image_width = image_bgr.shape[:2]

    # 화면 아래쪽까지 내려온 박스만 가까운 장애물로 판단한다.
    close_obstacles = []
    for box in boxes:
        if box["y2"] >= image_height * 0.70:
            close_obstacles.append(box)

    # 가까운 장애물이 없으면 직진한다.
    if not close_obstacles:
        return command

    # 여러 개라면 하단 좌표가 가장 아래에 있는 장애물을 선택한다.
    obstacle = max(close_obstacles, key=lambda box: box["y2"])

    if obstacle["center_x"] < image_width / 2:
        # 장애물이 왼쪽에 있으므로 오른쪽으로 회전한다.
        command.angular.z = -angular_speed
    else:
        # 장애물이 오른쪽 또는 정중앙에 있으면 왼쪽으로 회전한다.
        command.angular.z = angular_speed

    return command
# ======================== 학생 작성 영역 끝 ========================


def main(args=None):
    """존재하는 판단 함수를 등록합니다. 이 부분은 수정할 필요가 없습니다."""
    del args
    candidates = {
        "lane": globals().get("lane_decision"),
        "obstacle": globals().get("obstacle_decision"),
    }
    functions = {name: function for name, function in candidates.items() if callable(function)}
    run_decision_node(functions)


if __name__ == "__main__":
    main()
