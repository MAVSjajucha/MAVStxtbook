"""YOLO or CSV lane learning: classification tree, regression tree and linear regression."""

from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo, OpaqueFunction, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

from my_supervised._internal.camera import resolve_camera_selection
from my_supervised._internal.environment import detect_vehicle_ros_environment


def generate_launch_description():
    share = Path(get_package_share_directory("my_supervised"))

    def configure(context):
        def value(name):
            return LaunchConfiguration(name).perform(context)

        environment = detect_vehicle_ros_environment(require_driver=False)
        mode = value("training_mode")
        actions = [
            SetEnvironmentVariable("ROS_DOMAIN_ID", environment.domain_id),
            SetEnvironmentVariable("RMW_IMPLEMENTATION", environment.rmw_implementation),
            LogInfo(msg=f"[my_supervised] training={mode}, domain={environment.domain_id}, source={environment.source}"),
        ]
        camera_enabled = value("start_camera").lower() == "true"
        selected = resolve_camera_selection(value("camera_mode"), environment) if camera_enabled else None
        if selected is not None:
            actions.append(LogInfo(msg=f"[my_supervised] RGB={selected.topic}, camera={selected.source}"))
            if selected.should_start:
                actions.append(IncludeLaunchDescription(PythonLaunchDescriptionSource(str(selected.launch_path))))
        if mode == "lane" and camera_enabled:
            actions.append(Node(
                package="my_supervised", executable="lane_processor",
                name="supervised_lane_processor", output="screen",
                parameters=[value("grid_config"), {
                    "rgb_topic": selected.topic, "lane_model": "", "show_grid": True,
                    "inference_hz": float(value("inference_hz")),
                    "preview_hz": float(value("preview_hz")),
                }],
            ))
        parameters = {
            "server_port": int(value("server_port")),
            "open_local_browser": value("open_local_browser").lower() == "true",
        }
        if mode == "lane":
            parameters.update(command_topic=value("command_topic"), max_delta_ms=float(value("max_delta_ms")))
        else:
            parameters.update(camera_mode=selected.mode if selected else "offline",
                              rgb_topic=selected.topic if selected else "/supervised/offline_rgb")
        actions.append(Node(
            package="my_supervised", executable="training_app",
            name="supervised_training_app", output="screen",
            arguments=["--lane"] if mode == "lane" else [], parameters=[parameters],
        ))
        return actions

    arguments = [
        DeclareLaunchArgument("training_mode", default_value="yolo", choices=["yolo", "lane"], description="yolo: YOLO workspace; lane: CSV lane-learning workspace with classification tree, regression tree and linear regression."),
        DeclareLaunchArgument("server_port", default_value="8081", description="Training web port."),
        DeclareLaunchArgument("open_local_browser", default_value="false", choices=["true", "false"], description="Optional local browser launch; default is manual URL entry."),
        DeclareLaunchArgument("start_camera", default_value="true", choices=["true", "false"], description="false: train saved data without starting camera/grid."),
        DeclareLaunchArgument("camera_mode", default_value="auto", choices=["auto", "existing", "nuwa", "usb"], description="Reuse or start an existing supported vendor camera."),
        DeclareLaunchArgument("command_topic", default_value="/cmd_vel", description="Manual joystick Twist topic to record; not published by this app."),
        DeclareLaunchArgument("max_delta_ms", default_value="200.0", description="Maximum causal feature/command receipt-time difference for recording."),
        DeclareLaunchArgument("grid_config", default_value=str(share / "config" / "grid.yaml"), description="Initial grid parameters. Editable on the lane web page."),
        DeclareLaunchArgument("inference_hz", default_value="25.0", description="Maximum grid feature processing rate; latest frames only."),
        DeclareLaunchArgument("preview_hz", default_value="25.0", description="Maximum grid preview JPEG rate."),
    ]
    return LaunchDescription(arguments + [OpaqueFunction(function=configure)])
