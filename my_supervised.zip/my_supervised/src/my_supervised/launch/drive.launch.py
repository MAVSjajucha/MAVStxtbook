"""YOLO 장애물 회피 또는 분류·회귀 모델 차선 주행을 실행합니다."""

from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo, OpaqueFunction, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

from my_supervised._internal.camera import resolve_camera_selection
from my_supervised._internal.environment import detect_vehicle_ros_environment


def generate_launch_description():
    """Keep two public missions and start only the selected inference path."""
    def configure(context):
        def value(name):
            return LaunchConfiguration(name).perform(context)

        def typed(name, kind):
            return ParameterValue(LaunchConfiguration(name), value_type=kind)

        mode = value('mission_mode')
        if mode not in ('obstacle', 'lane'):
            raise ValueError('mission_mode는 obstacle 또는 lane이어야 합니다.')
        motion = value('enable_motion').strip().lower()
        if motion not in ('true', 'false'):
            raise ValueError('enable_motion must be true or false')
        if mode == 'lane' and not value('lane_model').strip():
            raise ValueError('lane 모드는 lane_model:=학습한_JSON_모델_전체경로가 필요합니다.')
        if mode == 'lane' and not Path(value('lane_model')).expanduser().is_file():
            raise FileNotFoundError(f'차선 모델 파일을 찾을 수 없습니다: {value("lane_model")}')
        environment = detect_vehicle_ros_environment(require_driver=motion == 'true')
        selected = resolve_camera_selection(value('camera_mode'), environment)
        grid_config = Path(value('grid_config')).expanduser()
        if not grid_config.is_file():
            raise FileNotFoundError(f'격자 설정 파일을 찾을 수 없습니다: {grid_config}')
        actions = [
            SetEnvironmentVariable('ROS_DOMAIN_ID', environment.domain_id),
            SetEnvironmentVariable('RMW_IMPLEMENTATION', environment.rmw_implementation),
            LogInfo(msg=f'[my_supervised] mission={mode}, domain={environment.domain_id}, '
                    f'camera={selected.mode}, topic={selected.topic}, enable_motion={motion}'),
        ]
        if selected.should_start:
            actions.append(IncludeLaunchDescription(
                PythonLaunchDescriptionSource(str(selected.launch_path))))
        if mode == 'lane':
            actions.append(Node(
                package='my_supervised', executable='lane_processor',
                name='supervised_lane_processor', output='screen',
                parameters=[str(grid_config), {
                    'rgb_topic': selected.topic,
                    'lane_model': value('lane_model'),
                    'show_grid': typed('show_grid', bool),
                    'inference_hz': typed('inference_hz', float),
                    'preview_hz': typed('preview_hz', float),
                }],
            ))
        actions.append(Node(
            package='my_supervised', executable='decision_node',
            name='supervised_decision_node', output='screen',
            parameters=[str(grid_config), {
                'mission_mode': mode, 'rgb_topic': selected.topic,
                'enable_motion': typed('enable_motion', bool),
                'box_model': value('box_model'), 'lane_model': value('lane_model'),
                'show_grid': typed('show_grid', bool),
                'max_linear_speed': typed('max_linear_speed', float),
                'max_angular_speed': typed('max_angular_speed', float),
                'inference_hz': typed('inference_hz', float),
                'preview_hz': typed('preview_hz', float),
                'web_port': typed('web_port', int),
            }],
        ))
        return actions

    default_grid = str(Path(get_package_share_directory(
        'my_supervised')) / 'config' / 'grid.yaml')
    return LaunchDescription([
        DeclareLaunchArgument('mission_mode', default_value='obstacle', choices=['obstacle', 'lane'],
                              description='obstacle: YOLO 장애물 회피, lane: 분류·회귀 차선 주행'),
        DeclareLaunchArgument('enable_motion', default_value='true', choices=['true', 'false'],
                              description='모터 출력 허용 여부. true도 리모컨 연결 해제와 웹 Start 전에는 정지'),
        DeclareLaunchArgument('camera_mode', default_value='auto',
                              choices=['auto', 'existing', 'nuwa', 'usb']),
        DeclareLaunchArgument('box_model', default_value='', description='객체 탐지 .pt 파일 전체 경로'),
        DeclareLaunchArgument('lane_model', default_value='', description='학습한 분류나무·회귀나무·선형회귀 .json 파일 전체 경로'),
        DeclareLaunchArgument('grid_config', default_value=default_grid,
                              description='obstacle 표시 격자 설정. lane은 모델에 저장된 격자 사용'),
        DeclareLaunchArgument('show_grid', default_value='true', choices=['true', 'false'],
                              description='웹 영상에 격자 표시. 특징 추출과 추론은 계속 실행'),
        DeclareLaunchArgument('max_linear_speed', default_value='0.5',
                              description='학생 함수가 반환한 전진 속도의 상한 (m/s). 주행 속도는 함수 안에서 지정'),
        DeclareLaunchArgument('max_angular_speed', default_value='0.5',
                              description='학생 함수가 반환한 회전 속도의 상한 (rad/s). 주행 속도는 함수 안에서 지정'),
        DeclareLaunchArgument('inference_hz', default_value='25.0',
                              description='처리 상한. 실제 속도는 카메라·장치 성능에 따름'),
        DeclareLaunchArgument('preview_hz', default_value='25.0', description='웹 영상 생성 상한'),
        DeclareLaunchArgument('web_port', default_value='8082'),
        OpaqueFunction(function=configure),
    ])
