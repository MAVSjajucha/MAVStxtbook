"""주행 알고리즘을 작성하는 부분입니다."""

from geometry_msgs.msg import Twist
from my_supervised._internal.drive_runtime import run_decision_node


# ========================== 알고리즘 작성 영역 ==========================


def lane_decision(V, L, R, prediction):

    command = Twist()

    return command



def obstacle_decision(image_bgr, boxes):

    command = Twist()

    return command



# ======================== 알고리즘 작성 영역 끝 ========================


def main(args=None):

    del args
    candidates = {
        "lane": globals().get("lane_decision"),
        "obstacle": globals().get("obstacle_decision"),
    }
    functions = {name: function for name, function in candidates.items() if callable(function)}
    run_decision_node(functions)


if __name__ == "__main__":
    main()
