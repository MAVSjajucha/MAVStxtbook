"""
Persist project identity without keeping browser selections.

A project is resumable only when the canonical photo and result directory
paths exactly match the pair recorded in its manifest.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional


_SCHEMA_VERSION = 1
_STATE_ROOT = ".my_supervised"
_PROJECTS_DIRECTORY = "projects"
_MANIFEST_FILE = "project.json"


class ProjectStoreError(ValueError):
    """Report an invalid directory selection or project state."""


class ProjectStatus(str, Enum):
    """Describe whether a selected directory pair can be resumed."""

    NEW = "new"
    RESUMABLE = "resumable"


@dataclass(frozen=True)
class ProjectPaths:
    """Contain every path derived from one exact directory pair."""

    photo_directory: Path
    result_directory: Path
    project_key: str
    project_directory: Path
    manifest_path: Path
    annotations_directory: Path
    dataset_directory: Path
    checkpoints_directory: Path

    def as_dict(self) -> Dict[str, str]:
        """Return browser-safe string paths."""
        return {
            "photo_directory": str(self.photo_directory),
            "result_directory": str(self.result_directory),
            "project_key": self.project_key,
            "project_directory": str(self.project_directory),
            "manifest_path": str(self.manifest_path),
            "annotations_directory": str(self.annotations_directory),
            "dataset_directory": str(self.dataset_directory),
            "checkpoints_directory": str(self.checkpoints_directory),
        }


@dataclass(frozen=True)
class ProjectInspection:
    """Return the result of inspecting a photo/result directory pair."""

    status: ProjectStatus
    paths: ProjectPaths
    manifest: Optional[Dict[str, Any]]

    @property
    def resume_available(self) -> bool:
        """Return true only for an exact, valid manifest match."""
        return self.status is ProjectStatus.RESUMABLE


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_directory(value: str, label: str) -> Path:
    if value is None or not str(value).strip():
        raise ProjectStoreError(f"{label} directory is not selected.")

    candidate = Path(str(value).strip()).expanduser()
    if not candidate.is_absolute():
        raise ProjectStoreError(f"{label} directory must be an absolute path.")

    try:
        resolved = candidate.resolve(strict=True)
    except FileNotFoundError as error:
        raise ProjectStoreError(
            f"{label} directory does not exist: {candidate}"
        ) from error

    if not resolved.is_dir():
        raise ProjectStoreError(f"{label} path is not a directory: {resolved}")

    required = os.R_OK | os.W_OK | os.X_OK
    if not os.access(resolved, required):
        raise ProjectStoreError(
            f"{label} directory must be readable and writable: {resolved}"
        )
    return resolved


def _project_key(photo_directory: Path, result_directory: Path) -> str:
    identity = (
        str(photo_directory).encode("utf-8")
        + b"\0"
        + str(result_directory).encode("utf-8")
    )
    return hashlib.sha256(identity).hexdigest()


def _derive_paths(photo_value: str, result_value: str) -> ProjectPaths:
    photo_directory = _canonical_directory(photo_value, "Photo")
    result_directory = _canonical_directory(result_value, "Result")
    key = _project_key(photo_directory, result_directory)
    project_directory = (
        result_directory / _STATE_ROOT / _PROJECTS_DIRECTORY / key
    )
    return ProjectPaths(
        photo_directory=photo_directory,
        result_directory=result_directory,
        project_key=key,
        project_directory=project_directory,
        manifest_path=project_directory / _MANIFEST_FILE,
        annotations_directory=project_directory / "annotations",
        dataset_directory=project_directory / "dataset",
        checkpoints_directory=project_directory / "checkpoints",
    )


def _read_manifest(paths: ProjectPaths) -> Dict[str, Any]:
    try:
        manifest = json.loads(paths.manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ProjectStoreError(
            f"Project manifest cannot be read: {paths.manifest_path}"
        ) from error

    if manifest.get("schema_version") != _SCHEMA_VERSION:
        raise ProjectStoreError("Project manifest schema is not supported.")
    if manifest.get("project_key") != paths.project_key:
        raise ProjectStoreError("Project manifest key does not match.")
    if manifest.get("photo_directory") != str(paths.photo_directory):
        raise ProjectStoreError("Project photo directory does not match.")
    if manifest.get("result_directory") != str(paths.result_directory):
        raise ProjectStoreError("Project result directory does not match.")
    return manifest


def _write_manifest(paths: ProjectPaths, manifest: Dict[str, Any]) -> None:
    paths.project_directory.mkdir(parents=True, exist_ok=True)
    temporary = paths.manifest_path.with_name(
        f".{_MANIFEST_FILE}.tmp-{os.getpid()}"
    )
    try:
        temporary.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temporary.replace(paths.manifest_path)
    finally:
        if temporary.exists():
            temporary.unlink()


class ProjectStore:
    """Inspect, create, and resume path-paired training projects."""

    def inspect(
        self,
        photo_directory: str,
        result_directory: str,
    ) -> ProjectInspection:
        """Inspect without creating files or retaining browser state."""
        paths = _derive_paths(photo_directory, result_directory)
        if not paths.manifest_path.exists():
            return ProjectInspection(ProjectStatus.NEW, paths, None)

        manifest = _read_manifest(paths)
        return ProjectInspection(ProjectStatus.RESUMABLE, paths, manifest)

    def create_new(
        self,
        photo_directory: str,
        result_directory: str,
    ) -> ProjectInspection:
        """Create a new project after both directories are selected."""
        inspection = self.inspect(photo_directory, result_directory)
        if inspection.resume_available:
            raise ProjectStoreError(
                "The exact directory pair already has a project. "
                "Choose Resume instead of creating over it."
            )

        paths = inspection.paths
        paths.annotations_directory.mkdir(parents=True, exist_ok=False)
        paths.dataset_directory.mkdir()
        paths.checkpoints_directory.mkdir()

        timestamp = _now_utc()
        manifest: Dict[str, Any] = {
            "schema_version": _SCHEMA_VERSION,
            "project_key": paths.project_key,
            "photo_directory": str(paths.photo_directory),
            "result_directory": str(paths.result_directory),
            "created_at": timestamp,
            "updated_at": timestamp,
            "workflow_step": "class_setup",
            "task_type": None,
            "model_family": None,
            "classes": [],
        }
        _write_manifest(paths, manifest)
        return ProjectInspection(ProjectStatus.RESUMABLE, paths, manifest)

    def resume(
        self,
        photo_directory: str,
        result_directory: str,
    ) -> ProjectInspection:
        """Resume only when both canonical paths exactly match."""
        inspection = self.inspect(photo_directory, result_directory)
        if not inspection.resume_available:
            raise ProjectStoreError(
                "No resumable project exists for this exact directory pair."
            )
        return inspection

    def update(
        self,
        paths: ProjectPaths,
        changes: Dict[str, Any],
    ) -> ProjectInspection:
        """Atomically update an existing project manifest."""
        manifest = _read_manifest(paths)
        protected = {
            "schema_version",
            "project_key",
            "photo_directory",
            "result_directory",
            "created_at",
        }
        if protected.intersection(changes):
            raise ProjectStoreError("Project identity fields cannot be changed.")

        manifest.update(changes)
        manifest["updated_at"] = _now_utc()
        _write_manifest(paths, manifest)
        return ProjectInspection(ProjectStatus.RESUMABLE, paths, manifest)
