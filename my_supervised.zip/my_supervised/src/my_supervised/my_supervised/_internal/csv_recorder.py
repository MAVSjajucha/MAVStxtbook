"""Record causal feature/joystick pairs without removing student data."""

from bisect import bisect_right
import csv
from datetime import datetime
import math
import os
from pathlib import Path
from threading import RLock
import time
from uuid import uuid4

from my_supervised._internal.grid_features import DEFAULT_GRID, validate_grid


class CsvRecorder:
    """Pair a fresh feature frame with the latest preceding command receipt."""

    def __init__(self, max_delta_ms=200):
        self.max_delta_ms = float(max_delta_ms)
        if not math.isfinite(self.max_delta_ms) or not 0 < self.max_delta_ms <= 10000:
            raise ValueError("max_delta_ms는 0보다 크고 10000 이하여야 합니다.")
        self._lock = RLock()
        self._commands = []
        self._file = None
        self._writer = None
        self._last_sequence = -1
        self._last_flush = 0.0
        self._state = {"recording": False, "path": None, "session_id": None,
                       "rows_written": 0, "skipped_unmatched": 0,
                       "skipped_duplicate": 0, "error": "", "grid": None,
                       "last_delta_ms": None, "max_delta_ms": self.max_delta_ms}

    def status(self):
        """Return current recording details, including the download path."""
        with self._lock:
            state = dict(self._state)
            if state["grid"] is not None:
                state["grid"] = dict(state["grid"])
            return state

    def start(self, directory, grid):
        """Create a unique CSV only after an explicit folder was selected."""
        config = validate_grid(grid)
        if not isinstance(directory, (str, Path)) or not str(directory).strip():
            raise ValueError("CSV 저장 폴더를 먼저 지정하세요.")
        folder = Path(directory).expanduser()
        if not folder.is_absolute():
            raise ValueError("CSV 저장 폴더는 차량의 절대경로로 지정하세요.")
        folder = folder.resolve()
        with self._lock:
            if self._file is not None:
                raise ValueError("이미 수집 중입니다. 먼저 기록을 중지하세요.")
            # REQUIRE_EXISTING_USER_DIRECTORY
            if not folder.is_dir():
                raise ValueError(
                    f"CSV 저장 폴더가 없거나 폴더가 아닙니다: {folder}"
                )
            session = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid4().hex[:8]
            path = folder / f"lane_{session}.csv"
            columns = ["session_id", "timestamp_ns", "feature_received_ns",
                       "cmd_received_ns", "delta_ms"] + list(DEFAULT_GRID)
            columns += [f"v_{i}" for i in range(config["cols"])]
            columns += [f"l_{i}" for i in range(config["rows"])]
            columns += [f"r_{i}" for i in range(config["rows"])]
            columns += ["linear_x", "angular_z", "direction"]
            stream = path.open("x", encoding="utf-8", newline="")
            try:
                writer = csv.DictWriter(stream, fieldnames=columns)
                writer.writeheader()
                stream.flush()
            except Exception:
                stream.close()
                raise
            self._file, self._writer = stream, writer
            self._last_sequence = -1
            self._last_flush = time.monotonic()
            self._started_ns = time.time_ns()
            self._state.update(recording=True, path=str(path), session_id=session,
                               rows_written=0, skipped_unmatched=0, skipped_duplicate=0,
                               error="", grid=config, last_delta_ms=None)
            return self.status()

    def stop(self):
        """Flush and close the CSV without deleting any recorded rows."""
        with self._lock:
            if self._file is not None:
                try:
                    self._file.flush()
                    os.fsync(self._file.fileno())
                except OSError as error:
                    self._state["error"] = f"CSV 저장 실패: {error}"
                finally:
                    self._file.close()
                    self._file = self._writer = None
            self._state["recording"] = False
            return self.status()

    def on_command(self, linear_x, angular_z, received_ns=None):
        """Remember received Twist values; zero commands remain valid targets."""
        linear, angular = float(linear_x), float(angular_z)
        if not math.isfinite(linear) or not math.isfinite(angular):
            raise ValueError("조이스틱 명령은 유한한 숫자여야 합니다.")
        stamp = time.time_ns() if received_ns is None else int(received_ns)
        with self._lock:
            index = bisect_right([item[0] for item in self._commands], stamp)
            self._commands.insert(index, (stamp, linear, angular))
            cutoff = self._commands[-1][0] - 10_000_000_000
            first = bisect_right([item[0] for item in self._commands], cutoff)
            self._commands = self._commands[first:][-10000:]

    def on_features(self, result):
        """Write one row per new RGB feature event, only for a causal pair."""
        with self._lock:
            if self._file is None:
                return
            try:
                if result.get("error"):
                    self._state["skipped_unmatched"] += 1
                    return
                config = validate_grid(result["grid"])
                if config != self._state["grid"]:
                    raise ValueError("수집 중 격자 설정이 변경되어 기록을 중지했습니다.")
                sequence = int(result["sequence"])
                if sequence <= self._last_sequence:
                    self._state["skipped_duplicate"] += 1
                    return
                self._last_sequence = sequence
                received = int(result["received_ns"])
                # A queued result from before the record button is not a sample.
                if received < self._started_ns:
                    self._state["skipped_unmatched"] += 1
                    return
                index = bisect_right([item[0] for item in self._commands], received) - 1
                if index < 0:
                    self._state["skipped_unmatched"] += 1
                    return
                command_stamp, linear, angular = self._commands[index]
                delta = (received - command_stamp) / 1_000_000.0
                if delta > self.max_delta_ms:
                    self._state["skipped_unmatched"] += 1
                    return
                features = result["features"]
                row = {"session_id": self._state["session_id"],
                       "timestamp_ns": received, "feature_received_ns": received,
                       "cmd_received_ns": command_stamp, "delta_ms": delta,
                       **config, "linear_x": linear, "angular_z": angular,
                       # ROS yaw: left is positive, right is negative.
                       # Keep the original continuous command for regression.
                       "direction": ("left" if angular > 0 else
                                     "right" if angular < 0 else "straight")}
                for name, expected in (("V", config["cols"]), ("L", config["rows"]),
                                       ("R", config["rows"])):
                    values = features[name]
                    if len(values) != expected:
                        raise ValueError(f"{name} 특징값 개수가 격자 설정과 다릅니다.")
                    for i, value in enumerate(values):
                        if isinstance(value, bool) or not math.isfinite(float(value)):
                            raise ValueError(f"{name}[{i}] 특징값이 유한한 숫자가 아닙니다.")
                        row[f"{name.lower()}_{i}"] = value
                self._writer.writerow(row)
                self._state["rows_written"] += 1
                self._state["last_delta_ms"] = delta
                now = time.monotonic()
                if self._state["rows_written"] % 10 == 0 or now - self._last_flush >= .5:
                    self._file.flush()
                    self._last_flush = now
            except (ValueError, KeyError, TypeError, OSError) as error:
                self._state["error"] = str(error)
                self.stop()
