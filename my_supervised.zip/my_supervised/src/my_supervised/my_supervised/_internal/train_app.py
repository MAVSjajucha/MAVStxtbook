"""Receive RGB images and provide the YOLO training preparation web UI."""

from pathlib import Path
from typing import Optional
import threading
import cv2

from cv_bridge import CvBridge
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image

from my_supervised._internal.camera import CameraFrameBuffer
from my_supervised._internal.web_server import TrainingWebServer
from my_supervised._internal.live_video import LatestJpeg


class TrainingApp(Node):
    """Receive RGB frames for the YOLO data-collection workflow."""

    def __init__(self):
        super().__init__("supervised_training_app")
        self.declare_parameter("server_port", 8081)
        self.declare_parameter("open_local_browser", False)
        self.declare_parameter("camera_mode", "auto")
        self.declare_parameter("rgb_topic", "")
        self.server_port = int(self.get_parameter("server_port").value)
        self.camera_mode = str(self.get_parameter("camera_mode").value)
        self.rgb_topic = str(self.get_parameter("rgb_topic").value)
        if not self.rgb_topic:
            raise RuntimeError("rgb_topic must be resolved by train.launch.py.")
        self._bridge = CvBridge()
        self.frames = CameraFrameBuffer()
        self.preview = LatestJpeg()
        self._pending = None
        self._pending_event = threading.Event()
        self._pending_lock = threading.Lock()
        self._stopping = threading.Event()
        self._first_frame_logged = False
        self._selected_photo_directory: Optional[str] = None
        self._rgb_subscription = self.create_subscription(
            Image, self.rgb_topic, self._rgb_callback,
            QoSProfile(history=HistoryPolicy.KEEP_LAST, depth=1,
                       reliability=ReliabilityPolicy.BEST_EFFORT)
        )
        self.web_server = TrainingWebServer(self, self.server_port)
        self.web_server.start()
        self._frame_worker = threading.Thread(target=self._process_latest, daemon=True)
        self._frame_worker.start()
        self.get_logger().info(
            "YOLO training UI ready: "
            f"http://<vehicle-ip>:{self.web_server.port} "
            f"(camera={self.camera_mode}, topic={self.rgb_topic})"
        )

    def _rgb_callback(self, message: Image) -> None:
        # The ROS callback never waits for JPEG encoding or an HTTP client.
        with self._pending_lock:
            self._pending = message
        self._pending_event.set()

    def _process_latest(self):
        while not self._stopping.is_set():
            self._pending_event.wait(0.5)
            self._pending_event.clear()
            with self._pending_lock:
                message, self._pending = self._pending, None
            if message is not None:
                self._convert_frame(message)

    def _convert_frame(self, message):
        try:
            image_bgr = self._bridge.imgmsg_to_cv2(message, desired_encoding="bgr8")
            self.frames.update(image_bgr)
            if self.preview.viewers:
                ok, encoded = cv2.imencode(".jpg", image_bgr, [cv2.IMWRITE_JPEG_QUALITY, 80])
                if ok:
                    self.preview.update(encoded.tobytes())
        except Exception as error:
            self.get_logger().error(
                f"RGB conversion failed: {error}", throttle_duration_sec=2.0
            )
            return
        if not self._first_frame_logged:
            status = self.frames.status()
            self.get_logger().info(
                "RGB stream active: "
                f"{status.width}x{status.height}, encoding={message.encoding}"
            )
            self._first_frame_logged = True

    def clear_browser_selection(self) -> None:
        """Forget the browser-selected photo directory."""
        self._selected_photo_directory = None

    def select_photo_directory(self, directory: Optional[str]) -> None:
        """Store only the active browser selection, never a default."""
        self._selected_photo_directory = (
            None if directory is None else str(directory).strip() or None
        )

    def capture_selected_frame(self) -> Path:
        """Capture one frame or raise when no project has been selected."""
        return self.frames.capture(self._selected_photo_directory)

    def destroy_node(self):
        """Stop HTTP serving before the ROS resources disappear."""
        self._stopping.set()
        self._pending_event.set()
        self.preview.close()
        if hasattr(self, "_frame_worker"):
            self._frame_worker.join(timeout=2.0)
        if hasattr(self, "web_server"):
            self.web_server.stop()
        return super().destroy_node()


def main(args=None):
    """Run the training camera node and browser UI."""
    rclpy.init(args=args)
    # The launch chooses one app; students still have only two launch files.
    from rclpy.utilities import remove_ros_args
    import sys
    plain_args = remove_ros_args(args=sys.argv if args is None else args)
    if "--lane" in plain_args:
        from my_supervised._internal.tree_app import TreeTrainingApp
        node = TreeTrainingApp()
    else:
        node = TrainingApp()
    if bool(node.get_parameter("open_local_browser").value):
        from my_supervised._internal.browser import open_training_browser
        open_training_browser(node.web_server.port)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
