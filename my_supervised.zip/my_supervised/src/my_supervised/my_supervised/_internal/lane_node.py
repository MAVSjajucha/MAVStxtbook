"""Latest-frame grid extraction and optional lane-model prediction, with no motion output."""

import json
import math
from threading import Condition, Event, RLock, Thread
import time

import cv2
from cv_bridge import CvBridge
import rclpy
from rcl_interfaces.msg import SetParametersResult
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import CompressedImage, Image
from std_msgs.msg import String

from my_supervised._internal.grid_features import (
    DEFAULT_GRID, process_grid, validate_grid,
)


def image_qos():
    """Keep only the freshest image; never queue old video frames."""
    return QoSProfile(history=HistoryPolicy.KEEP_LAST, depth=1,
                      reliability=ReliabilityPolicy.BEST_EFFORT,
                      durability=DurabilityPolicy.VOLATILE)


class LaneNode(Node):
    """Use identical features for collection and all three lane learning models."""

    def __init__(self):
        super().__init__("supervised_lane_processor")
        for name, value in DEFAULT_GRID.items():
            self.declare_parameter(name, value)
        self.declare_parameter("rgb_topic", "")
        self.declare_parameter("lane_model", "")
        self.declare_parameter("show_grid", True)
        self.declare_parameter("inference_hz", 25.0)
        self.declare_parameter("preview_hz", 25.0)
        self._state_lock = RLock()
        self._config_generation = 0
        self._grid = validate_grid({name: self.get_parameter(name).value
                                    for name in DEFAULT_GRID})
        self._show_grid = bool(self.get_parameter("show_grid").value)
        self._inference_hz = self._rate(self.get_parameter("inference_hz").value)
        self._preview_hz = self._rate(self.get_parameter("preview_hz").value)
        topic = str(self.get_parameter("rgb_topic").value).strip()
        if not topic:
            raise ValueError("rgb_topic must be resolved by the launch file.")
        self._model = None
        self._predict = None
        model_path = str(self.get_parameter("lane_model").value).strip()
        if model_path:
            from my_supervised._internal.tree_learning import load_model, predict_model
            self._model = load_model(model_path)
            self._predict = predict_model
            self._grid = validate_grid(self._model["grid"])
            # Report the artifact's actual processing settings through ROS too.
            self.set_parameters([rclpy.parameter.Parameter(name, value=value)
                                 for name, value in self._grid.items()])
        self.add_on_set_parameters_callback(self._on_grid_parameters)
        self._bridge = CvBridge()
        self._condition = Condition()
        self._stopping = Event()
        self._latest = None
        self._sequence = 0
        self._results = self.create_publisher(String, "/supervised/lane_result", 10)
        self._preview = self.create_publisher(
            CompressedImage, "/supervised/lane_preview", image_qos())
        self._subscription = self.create_subscription(Image, topic, self._on_rgb, image_qos())
        self._worker = Thread(target=self._run, name="lane-latest-frame", daemon=True)
        self._worker.start()
        self.get_logger().info(
            f"Lane processor ready: camera={topic}, model={model_path or 'CSV collection'}, "
            f"grid={json.dumps(self._grid)}, show_grid={self._show_grid}")

    @staticmethod
    def _rate(value):
        rate = float(value)
        if not math.isfinite(rate) or not 0 < rate <= 120:
            raise ValueError("영상 처리 및 표시 빈도는 0 초과 120 이하이어야 합니다.")
        return rate

    def _on_grid_parameters(self, parameters):
        with self._state_lock:
            settings = dict(self._grid)
            show = self._show_grid
            inference, preview = self._inference_hz, self._preview_hz
            try:
                for parameter in parameters:
                    if parameter.name in DEFAULT_GRID:
                        if self._model is not None and parameter.value != settings[parameter.name]:
                            raise ValueError("주행 시 격자 설정은 학습 모델에 저장된 값을 사용합니다.")
                        settings[parameter.name] = parameter.value
                    elif parameter.name == "show_grid":
                        if not isinstance(parameter.value, bool):
                            raise ValueError("show_grid는 true 또는 false이어야 합니다.")
                        show = parameter.value
                    elif parameter.name == "inference_hz":
                        inference = self._rate(parameter.value)
                    elif parameter.name == "preview_hz":
                        preview = self._rate(parameter.value)
                    elif parameter.name in ("rgb_topic", "lane_model"):
                        raise ValueError("카메라 토픽과 모델 경로 변경은 노드를 다시 실행하세요.")
                settings = validate_grid(settings)
            except (ValueError, TypeError) as error:
                return SetParametersResult(successful=False, reason=str(error))
            if (settings != self._grid or show != self._show_grid
                    or inference != self._inference_hz or preview != self._preview_hz):
                self._config_generation += 1
            self._grid, self._show_grid = settings, show
            self._inference_hz, self._preview_hz = inference, preview
            return SetParametersResult(successful=True)

    def _on_rgb(self, message):
        # Conversion, Canny, prediction and JPEG encoding never block this callback.
        received_ns = time.time_ns()
        with self._condition:
            self._sequence += 1
            self._latest = (self._sequence, message, received_ns)
            self._condition.notify()

    def _run(self):
        processed = 0
        next_process = 0.0
        next_preview = 0.0
        while not self._stopping.is_set():
            with self._condition:
                self._condition.wait_for(
                    lambda: self._stopping.is_set()
                    or (self._latest is not None and self._latest[0] > processed), timeout=.5)
            if self._stopping.wait(max(0.0, next_process - time.monotonic())):
                break
            with self._condition:
                if self._latest is None or self._latest[0] <= processed:
                    continue
                sequence, message, received_ns = self._latest
            processed = sequence
            with self._state_lock:
                grid, show = dict(self._grid), self._show_grid
                inference_hz, preview_hz = self._inference_hz, self._preview_hz
                generation = self._config_generation
            started = time.monotonic()
            next_process = started + 1.0 / inference_hz
            emit_preview = started >= next_preview and self._preview.get_subscription_count() > 0
            result = {
                "sequence": sequence,
                "stamp_ns": int(message.header.stamp.sec) * 1_000_000_000
                + int(message.header.stamp.nanosec),
                "received_ns": received_ns, "grid": grid, "features": None,
                "prediction": None, "error": "", "config_generation": generation,
            }
            result_published = False
            try:
                image = self._bridge.imgmsg_to_cv2(message, desired_encoding="bgr8")
                rendered, features = process_grid(image, grid, draw=show and emit_preview)
                result["features"] = features
                if self._model is not None:
                    result["prediction"] = self._predict(self._model, features, grid)
                result["processed_ns"] = time.time_ns()
                result["processing_ms"] = (time.monotonic() - started) * 1000
                # Deliver features/predictions before JPEG work can delay driving.
                # Parameter acknowledgement cannot precede an old-config publish.
                with self._state_lock:
                    if generation != self._config_generation:
                        continue
                    self._results.publish(String(data=json.dumps(result, allow_nan=False)))
                    result_published = True
                if emit_preview:
                    encoded_ok, data = cv2.imencode(
                        ".jpg", rendered, [cv2.IMWRITE_JPEG_QUALITY, 80])
                    if not encoded_ok:
                        raise ValueError("격자 미리보기 JPEG 변환에 실패했습니다.")
                    compressed = CompressedImage()
                    compressed.header = message.header
                    compressed.format = "jpeg"
                    compressed.data = data.tobytes()
                    # Settings may also change while the JPEG is being encoded.
                    with self._state_lock:
                        if generation != self._config_generation:
                            continue
                        self._preview.publish(compressed)
                        next_preview = started + 1.0 / preview_hz
            except Exception as error:
                if self._stopping.is_set() or not rclpy.ok():
                    break
                if result_published:
                    # A display failure does not invalidate the valid prediction
                    # already published for this frame, or publish a duplicate ID.
                    self.get_logger().error(
                        f"Lane preview failed: {error}", throttle_duration_sec=2.0)
                    continue
                result["error"] = str(error)
                result["prediction"] = None
                result["processed_ns"] = time.time_ns()
                result["processing_ms"] = (time.monotonic() - started) * 1000
                with self._state_lock:
                    if generation != self._config_generation:
                        continue
                    self._results.publish(String(data=json.dumps(result, allow_nan=False)))
                self.get_logger().error(f"Lane processing failed: {error}", throttle_duration_sec=2.0)

    def destroy_node(self):
        """Finish worker use of publishers before destroying ROS resources."""
        self._stopping.set()
        with self._condition:
            self._condition.notify_all()
        self._worker.join(timeout=3.0)
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = LaneNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
