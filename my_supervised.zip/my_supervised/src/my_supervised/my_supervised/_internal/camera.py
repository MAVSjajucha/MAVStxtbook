"""
Select an existing Yahboom RGB source and store captured camera frames.

Vendor files are only inspected and launched. They are never modified.
"""

from dataclasses import dataclass
from datetime import datetime
import os
from pathlib import Path
from threading import Lock
import time
from typing import Dict, Iterator, List, Optional, Tuple

import cv2
import numpy as np


AUTO_MODE = "auto"
EXISTING_MODE = "existing"
NUWA_MODE = "nuwa"
USB_MODE = "usb"

NUWA_TOPIC = "/ascamera_hp60c/camera_publisher/rgb0/image"
USB_TOPIC = "/usb_cam/image_raw"

NUWA_LAUNCH = Path(
    "/home/jetson/yahboomcar_ros2_ws/software/library_ws/"
    "src/ascamera/launch/hp60c.launch.py"
)
USB_LAUNCH = Path(
    "/home/jetson/yahboomcar_ros2_ws/software/library_ws/"
    "src/usb_cam/launch/camera.launch.py"
)


class CameraError(RuntimeError):
    """Report a camera selection or frame-capture failure."""


@dataclass(frozen=True)
class RunningCamera:
    """Describe one supported camera driver process."""

    mode: str
    pid: int
    domain_id: str
    rmw_implementation: str


@dataclass(frozen=True)
class CameraSelection:
    """Describe the camera source chosen for a launch."""

    mode: str
    topic: str
    launch_path: Path
    existing_pid: Optional[int]
    source: str

    @property
    def should_start(self) -> bool:
        """Return true only when the vendor launch must be included."""
        return self.existing_pid is None


@dataclass(frozen=True)
class FrameStatus:
    """Summarize the current in-memory camera frame."""

    available: bool
    width: int
    height: int
    age_seconds: Optional[float]


def normalize_camera_mode(value: str) -> str:
    """Normalize and validate a public camera-mode value."""
    aliases = {
        "auto": AUTO_MODE,
        "existing": EXISTING_MODE,
        "nuwa": NUWA_MODE,
        "hp60c": NUWA_MODE,
        "ascamera": NUWA_MODE,
        "usb": USB_MODE,
        "usb_cam": USB_MODE,
    }
    normalized = str(value or "").strip().lower()
    try:
        return aliases[normalized]
    except KeyError as error:
        raise CameraError(
            "camera_mode must be auto, existing, nuwa, or usb."
        ) from error


def choose_camera_mode(requested: str, configured: str) -> str:
    """Choose a physical camera when no supported source is running."""
    mode = normalize_camera_mode(requested)
    if mode == EXISTING_MODE:
        raise CameraError(
            "camera_mode=existing requires a supported running camera."
        )
    if mode in (NUWA_MODE, USB_MODE):
        return mode

    configured_mode = str(configured or "").strip().lower()
    if configured_mode in ("usb", "usb_cam"):
        return USB_MODE
    return NUWA_MODE


def _processes() -> Iterator[Tuple[int, str]]:
    """Yield PID and decoded command line for visible Linux processes."""
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            raw = (entry / "cmdline").read_bytes()
        except (OSError, PermissionError):
            continue
        tokens = [
            token.decode(errors="replace")
            for token in raw.split(b"\0")
            if token
        ]
        if not tokens:
            continue
        yield int(entry.name), " ".join(tokens)


def _process_environment(pid: int) -> Dict[str, str]:
    """Read the small ROS-related environment subset for one process."""
    try:
        raw = Path(f"/proc/{pid}/environ").read_bytes()
    except (OSError, PermissionError):
        return {}

    environment: Dict[str, str] = {}
    for item in raw.split(b"\0"):
        if b"=" not in item:
            continue
        key_bytes, value_bytes = item.split(b"=", 1)
        key = key_bytes.decode(errors="replace")
        if key in ("ROS_DOMAIN_ID", "RMW_IMPLEMENTATION"):
            environment[key] = value_bytes.decode(errors="replace")
    return environment


def _infer_rmw(pid: int) -> str:
    """Infer the loaded ROS middleware when its env variable is absent."""
    try:
        maps = Path(f"/proc/{pid}/maps").read_text(errors="replace")
    except (OSError, PermissionError):
        return ""

    for name in (
        "rmw_cyclonedds_cpp",
        "rmw_fastrtps_cpp",
    ):
        if name in maps:
            return name
    return ""


def detect_running_cameras() -> List[RunningCamera]:
    """Find supported RGB camera driver processes."""
    cameras: List[RunningCamera] = []
    for pid, command in _processes():
        command_tokens = command.split()
        if not command_tokens:
            continue
        executable_name = Path(command_tokens[0]).name
        if executable_name == "ascamera_node":
            mode = NUWA_MODE
        elif executable_name == "usb_cam_node_exe":
            mode = USB_MODE
        else:
            continue

        environment = _process_environment(pid)
        cameras.append(
            RunningCamera(
                mode=mode,
                pid=pid,
                domain_id=environment.get("ROS_DOMAIN_ID", "0"),
                rmw_implementation=(
                    environment.get("RMW_IMPLEMENTATION")
                    or _infer_rmw(pid)
                    or os.environ.get(
                        "RMW_IMPLEMENTATION",
                        "rmw_fastrtps_cpp",
                    )
                ),
            )
        )
    return cameras


def _topic_for(mode: str) -> str:
    """Return the RGB topic for a physical camera mode."""
    return USB_TOPIC if mode == USB_MODE else NUWA_TOPIC


def _launch_for(mode: str) -> Path:
    """Return the unmodified vendor launch path."""
    return USB_LAUNCH if mode == USB_MODE else NUWA_LAUNCH


def resolve_camera_selection(
    requested: str,
    ros_environment,
    configured: Optional[str] = None,
) -> CameraSelection:
    """Reuse one compatible camera or select one vendor launch."""
    requested_mode = normalize_camera_mode(requested)
    running = detect_running_cameras()

    if len(running) > 1:
        details = ", ".join(
            f"{camera.mode}:pid={camera.pid}" for camera in running
        )
        raise CameraError(
            f"Multiple supported camera processes are running: {details}"
        )

    if running:
        camera = running[0]
        if (
            requested_mode in (NUWA_MODE, USB_MODE)
            and requested_mode != camera.mode
        ):
            raise CameraError(
                f"Requested {requested_mode}, but {camera.mode} is running."
            )
        if camera.domain_id != str(ros_environment.domain_id):
            raise CameraError(
                "Running camera ROS_DOMAIN_ID does not match the vehicle."
            )
        if (
            camera.rmw_implementation
            != str(ros_environment.rmw_implementation)
        ):
            raise CameraError(
                "Running camera RMW implementation does not match the vehicle."
            )
        return CameraSelection(
            mode=camera.mode,
            topic=_topic_for(camera.mode),
            launch_path=_launch_for(camera.mode),
            existing_pid=camera.pid,
            source="running_camera",
        )

    configured_value = (
        configured
        or os.environ.get("CAMERA_TYPE")
        or os.environ.get("MY_CAMERA")
        or NUWA_MODE
    )
    mode = choose_camera_mode(requested_mode, configured_value)
    launch_path = _launch_for(mode)
    if not launch_path.is_file():
        raise CameraError(
            f"Vendor camera launch file is missing: {launch_path}"
        )
    return CameraSelection(
        mode=mode,
        topic=_topic_for(mode),
        launch_path=launch_path,
        existing_pid=None,
        source="vendor_launch",
    )


class CameraFrameBuffer:
    """Keep only the latest RGB frame and capture it on explicit request."""

    def __init__(self) -> None:
        self._lock = Lock()
        self._frame: Optional[np.ndarray] = None
        self._received_at: Optional[float] = None
        self._sequence = 0

    def update(self, image_bgr: np.ndarray) -> None:
        """Validate and replace the in-memory BGR frame."""
        if not isinstance(image_bgr, np.ndarray):
            raise CameraError("Camera frame must be a NumPy array.")
        if image_bgr.dtype != np.uint8:
            raise CameraError("Camera frame dtype must be uint8.")
        if (
            image_bgr.ndim != 3
            or image_bgr.shape[2] != 3
            or image_bgr.shape[0] < 1
            or image_bgr.shape[1] < 1
        ):
            raise CameraError("Camera frame must have BGR shape HxWx3.")

        with self._lock:
            self._frame = image_bgr.copy()
            self._received_at = time.monotonic()

    def latest(self) -> Optional[np.ndarray]:
        """Return an isolated copy of the latest frame."""
        with self._lock:
            if self._frame is None:
                return None
            return self._frame.copy()

    def status(self) -> FrameStatus:
        """Return availability, dimensions, and current frame age."""
        with self._lock:
            if self._frame is None or self._received_at is None:
                return FrameStatus(False, 0, 0, None)
            height, width = self._frame.shape[:2]
            age = max(0.0, time.monotonic() - self._received_at)
            return FrameStatus(True, width, height, age)

    def capture(
        self,
        photo_directory: Optional[str],
        jpeg_quality: int = 95,
    ) -> Path:
        """Atomically save one original-size JPEG to a selected directory."""
        if photo_directory is None or not str(photo_directory).strip():
            raise CameraError(
                "Select a photo directory before taking a picture."
            )

        directory = Path(str(photo_directory)).expanduser()
        if not directory.is_absolute():
            raise CameraError("Photo directory must be an absolute path.")
        try:
            directory = directory.resolve(strict=True)
        except FileNotFoundError as error:
            raise CameraError(
                f"Photo directory does not exist: {directory}"
            ) from error
        if not directory.is_dir():
            raise CameraError(f"Photo path is not a directory: {directory}")
        if not os.access(directory, os.R_OK | os.W_OK | os.X_OK):
            raise CameraError(
                f"Photo directory is not readable and writable: {directory}"
            )

        quality = int(jpeg_quality)
        if quality < 1 or quality > 100:
            raise CameraError("JPEG quality must be between 1 and 100.")

        frame = self.latest()
        if frame is None:
            raise CameraError(
                "No RGB image has been received. Check the camera first."
            )

        encoded_ok, encoded = cv2.imencode(
            ".jpg",
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), quality],
        )
        if not encoded_ok:
            raise CameraError("OpenCV could not encode the RGB image.")

        with self._lock:
            self._sequence += 1
            sequence = self._sequence

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        destination = directory / f"image_{stamp}_{sequence:04d}.jpg"
        temporary = directory / f".{destination.name}.tmp"
        try:
            with temporary.open("xb") as file_handle:
                file_handle.write(encoded.tobytes())
                file_handle.flush()
                os.fsync(file_handle.fileno())
            os.replace(temporary, destination)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return destination
