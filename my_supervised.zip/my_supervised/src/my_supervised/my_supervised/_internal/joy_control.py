"""Manage only the local vendor joystick translator, never its launch or driver."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time


class JoyControl:
    """Explicit, fail-closed handover; construction never kills or starts a process."""

    def __init__(self, pause, enabled, directory=None):
        self.pause = pause
        self.enabled = enabled
        self.allowed = threading.Event()
        self.closed = threading.Event()
        self.lock = threading.RLock()
        self.mode = 'unselected'
        self.message = '정지 상태에서 리모컨 연결 해제 또는 리모컨 연결을 선택하세요.'
        self.busy = False
        self.child = None
        self.worker = None
        self.guard = None
        self.executable = str(Path.home() / 'yahboomcar_ros2_ws/yahboomcar_ws/install/'
                              'yahboomcar_ctrl/lib/yahboomcar_ctrl/yahboom_joy_A1')
        self.directory = Path(directory or Path.home() / '.local/state/my_supervised_joy')
        self.monitor = threading.Thread(target=self._monitor, daemon=True)
        self.monitor.start()

    def status(self):
        with self.lock:
            return dict(mode=self.mode, busy=self.busy, message=self.message,
                        auto_ready=self.allowed.is_set())

    def _scan(self):
        found = []
        for item in Path('/proc').iterdir():
            if not item.name.isdigit():
                continue
            try:
                args = (item / 'cmdline').read_bytes().split(b'\0')
                args = [a.decode() for a in args if a]
                if self.executable not in args:
                    continue
                if item.stat().st_uid != os.getuid():
                    raise RuntimeError('다른 사용자 소유의 joy_ctrl: 리모컨 연결 상태 전환을 중단합니다.')
                # A shell command containing the path is not a matching argument.
                if args[:2] != ['/usr/bin/python3', self.executable]:
                    raise RuntimeError('예상과 다른 리모컨 제어 프로그램 실행 형식입니다.')
                stat = (item / 'stat').read_text().rsplit(')', 1)[1].split()
                if stat[0] != 'Z':
                    found.append((int(item.name), stat[19], args))
            except (FileNotFoundError, ProcessLookupError):
                continue
        if len(found) > 1:
            raise RuntimeError('joy_ctrl이 여러 개입니다. 리모컨 연결 상태를 전환하지 않습니다.')
        return found

    def _acquire(self):
        if self.guard is not None:
            return
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        handle = (self.directory / 'manager.lock').open('a')
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            handle.close()
            raise RuntimeError('다른 주행 앱이 리모컨 연결 상태를 관리 중입니다.')
        self.guard = handle

    def _save(self, process):
        pid, _, args = process
        raw = (Path('/proc') / str(pid) / 'environ').read_bytes()
        environment = dict(v.decode().split('=', 1) for v in raw.split(b'\0') if b'=' in v)
        # Retain runtime paths and ROS configuration, not arbitrary credentials.
        keys = {'PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'PYTHONPATH',
                'LD_LIBRARY_PATH', 'AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH',
                'CMAKE_PREFIX_PATH', 'INIT_SERVO_S1', 'INIT_SERVO_S2',
                'CYCLONEDDS_URI', 'FASTRTPS_DEFAULT_PROFILES_FILE',
                'FASTDDS_DEFAULT_PROFILES_FILE', 'RMW_IMPLEMENTATION'}
        env = {k: v for k, v in environment.items() if k in keys or k.startswith('ROS_')}
        if not all(k in env for k in ('INIT_SERVO_S1', 'INIT_SERVO_S2')):
            raise RuntimeError('서보 초기값을 읽지 못했습니다. 리모컨 연결을 해제하지 않습니다.')
        recipe = dict(args=args, cwd=os.readlink(f'/proc/{pid}/cwd'), env=env)
        temporary = self.directory / 'restart.tmp'
        fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as stream:
            json.dump(recipe, stream)
        temporary.replace(self.directory / 'restart.json')

    def _recipe(self):
        path = self.directory / 'restart.json'
        if not path.is_file():
            raise RuntimeError('리모컨 연결 정보가 없습니다. 기존 조이스틱 런치를 먼저 실행하세요.')
        data = json.loads(path.read_text())
        if data['args'] != ['/usr/bin/python3', self.executable, '--ros-args']:
            raise RuntimeError('저장된 리모컨 연결 명령이 확인된 실행 구성과 다릅니다.')
        if not Path(self.executable).is_file():
            raise RuntimeError('기존 리모컨 제어 프로그램의 실행 파일이 없습니다.')
        return data

    def request(self, mode):
        if mode not in ('auto', 'manual'):
            raise ValueError('mode는 auto 또는 manual이어야 합니다.')
        with self.lock:
            if not self.enabled or self.closed.is_set():
                raise RuntimeError('모터 출력이 꺼져 있거나 앱이 종료 중입니다.')
            if self.busy:
                raise RuntimeError('리모컨 연결 상태 전환 중입니다. 완료될 때까지 기다리세요.')
            self._acquire()
            self.allowed.clear()
            self.busy = True
            self.mode = 'switching'
            self.message = '정지 후 리모컨 연결 상태를 전환하고 있습니다.'
        # Do not hold the manager lock while acquiring the runtime motion lock.
        self.pause(force=True)
        self.worker = threading.Thread(target=self._switch, args=(mode,), daemon=True)
        self.worker.start()

    def _switch(self, target):
        try:
            processes = self._scan()
            if processes:
                self._save(processes[0])
            self._recipe()  # Validate recovery before terminating anything.
            if target == 'auto':
                if processes:
                    process = processes[0]
                    # pidfd prevents PID reuse from targeting another process.
                    fd = os.pidfd_open(process[0])
                    try:
                        if self._scan() != [process]:
                            raise RuntimeError('리모컨 제어 프로세스가 변경됐습니다. 다시 확인하세요.')
                        signal.pidfd_send_signal(fd, signal.SIGTERM)
                    finally:
                        os.close(fd)
                deadline = time.monotonic() + 5
                while self._scan():
                    if time.monotonic() > deadline:
                        raise RuntimeError('리모컨 연결 해제 확인 실패 (joy_ctrl): Start를 차단합니다.')
                    if self.closed.wait(.1):
                        raise RuntimeError('앱이 종료 중입니다.')
                    if self.child is not None:
                        self.child.poll()
                if self.closed.wait(.7) or self._scan():
                    raise RuntimeError('앱이 종료 중이거나 리모컨 제어 프로세스가 재시작됐습니다.')
                self.pause(force=True)
                with self.lock:
                    if self.closed.is_set():
                        raise RuntimeError('앱이 종료 중입니다.')
                    self.mode = 'auto'
                    self.message = '리모컨 연결 해제 완료. 주변 확인 후 Start를 누르세요.'
                    self.allowed.set()
            else:
                if not processes:
                    if self.closed.wait(.3):
                        raise RuntimeError('앱이 종료 중입니다.')
                    recipe = self._recipe()
                    with self.lock:
                        if self.closed.is_set():
                            raise RuntimeError('앱이 종료 중입니다.')
                        with (self.directory / 'joy_ctrl.log').open('ab') as log:
                            self.child = subprocess.Popen(
                                recipe['args'], cwd=recipe['cwd'], env=recipe['env'],
                                stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                start_new_session=True)
                    if self.closed.wait(1) or self.child.poll() is not None:
                        raise RuntimeError('리모컨 연결 실패 또는 앱 종료: 로그를 확인하세요.')
                if not self._scan():
                    raise RuntimeError('리모컨 연결을 확인하지 못했습니다 (joy_ctrl).')
                with self.lock:
                    self.mode = 'manual'
                    self.message = '리모컨 연결 완료. 리모컨에서 수동 제어를 활성화하세요.'
        except Exception as error:
            with self.lock:
                self.allowed.clear()
                self.mode = 'error'
                self.message = str(error)
        finally:
            with self.lock:
                self.busy = False

    def _monitor(self):
        while not self.closed.wait(.2):
            try:
                if self.child is not None:
                    self.child.poll()
                if self.allowed.is_set() and self._scan():
                    # Recheck under lock: a manual transition may have started.
                    with self.lock:
                        if not self.allowed.is_set():
                            continue
                        self.allowed.clear()
                        self.mode = 'error'
                        self.message = '리모컨 제어 프로세스 재등장: 자동 주행 중단. 리모컨 연결 해제를 다시 확인하세요.'
                    self.pause(force=True)
            except Exception as error:
                if self.allowed.is_set():
                    self.allowed.clear()
                    with self.lock:
                        self.mode, self.message = 'error', str(error)
                    self.pause(force=True)

    def close(self):
        self.closed.set()
        self.allowed.clear()
        if self.worker is not None:
            self.worker.join(timeout=7)
        self.monitor.join(timeout=1)
        if self.guard is not None:
            self.guard.close()
        # Never restart/kill joystick on app shutdown; leave explicit selected state.
