"""Detect the ROS environment used by the running Yahboom vehicle driver."""

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Dict, Iterator, Optional, Tuple


_DRIVER_TOKEN = "Ackman_driver_A1"


@dataclass(frozen=True)
class RosEnvironment:
    domain_id: str
    rmw_implementation: str
    driver_pid: Optional[int]
    driver_running: bool
    source: str

    def child_environment(self) -> Dict[str, str]:
        return {
            "ROS_DOMAIN_ID": self.domain_id,
            "RMW_IMPLEMENTATION": self.rmw_implementation,
        }


def _processes() -> Iterator[Tuple[int, str]]:
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            command = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(
                errors="replace"
            )
        except (OSError, PermissionError):
            continue
        yield int(entry.name), command


def _process_environment(pid: int) -> Dict[str, str]:
    values: Dict[str, str] = {}
    try:
        raw = Path(f"/proc/{pid}/environ").read_bytes()
    except (OSError, PermissionError):
        return values

    for item in raw.split(b"\0"):
        if b"=" not in item:
            continue
        key, value = item.split(b"=", 1)
        values[key.decode(errors="replace")] = value.decode(errors="replace")
    return values


def _infer_rmw(pid: int) -> str:
    try:
        maps = Path(f"/proc/{pid}/maps").read_text(errors="replace")
    except (OSError, PermissionError):
        maps = ""

    if "librmw_cyclonedds_cpp" in maps:
        return "rmw_cyclonedds_cpp"
    if "librmw_fastrtps_cpp" in maps:
        return "rmw_fastrtps_cpp"
    return "rmw_fastrtps_cpp"


def detect_vehicle_ros_environment(require_driver: bool = False) -> RosEnvironment:
    """Return the active vehicle driver's ROS domain and middleware."""

    for pid, command in _processes():
        if _DRIVER_TOKEN not in command:
            continue
        process_env = _process_environment(pid)
        return RosEnvironment(
            domain_id=process_env.get("ROS_DOMAIN_ID", "0"),
            rmw_implementation=process_env.get(
                "RMW_IMPLEMENTATION", _infer_rmw(pid)
            ),
            driver_pid=pid,
            driver_running=True,
            source="running_vehicle_driver",
        )

    if require_driver:
        raise RuntimeError(
            "Yahboom vehicle driver is not running. Start the vehicle's normal "
            "base/remote-control service, then run drive.launch.py again."
        )

    return RosEnvironment(
        domain_id=os.environ.get("ROS_DOMAIN_ID", "0"),
        rmw_implementation=os.environ.get(
            "RMW_IMPLEMENTATION", "rmw_fastrtps_cpp"
        ),
        driver_pid=None,
        driver_running=False,
        source="current_shell",
    )
