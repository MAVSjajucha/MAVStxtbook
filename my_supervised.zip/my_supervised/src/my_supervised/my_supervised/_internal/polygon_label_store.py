"""YOLO segmentation polygon label storage."""

from math import isfinite
from pathlib import Path
from typing import Dict, List, Sequence

from my_supervised._internal.box_label_store import (
    BoxLabelStore,
)


MAX_POLYGONS_PER_IMAGE = 2000
MAX_POINTS_PER_POLYGON = 5000


class PolygonLabelError(RuntimeError):
    """Raised for an invalid segmentation polygon."""


class PolygonLabelStore(BoxLabelStore):
    """Read external polygons and save edits separately."""

    @staticmethod
    def _project_label(
        photo_root: Path,
        annotation_root: Path,
        image: Path,
    ) -> Path:
        relative = image.relative_to(photo_root)
        return (
            Path(annotation_root)
            / "segment"
            / relative
        ).with_suffix(".txt")

    @staticmethod
    def _polygon_area(points: Sequence[Sequence[float]]) -> float:
        area = 0.0

        for index, point in enumerate(points):
            next_point = points[(index + 1) % len(points)]
            area += (
                point[0] * next_point[1]
                - next_point[0] * point[1]
            )

        return abs(area) / 2.0

    @classmethod
    def _validate_polygon(
        cls,
        polygon,
        class_count: int,
        polygon_number: int,
    ) -> Dict[str, object]:
        if not isinstance(polygon, dict):
            raise PolygonLabelError(
                f"{polygon_number}번 다각형 형식이 올바르지 않습니다."
            )

        try:
            class_id = int(polygon["class_id"])
            raw_points = polygon["points"]
        except (KeyError, TypeError, ValueError) as error:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형 값이 올바르지 않습니다."
            ) from error

        if not 0 <= class_id < class_count:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형의 클래스가 등록되지 않았습니다."
            )

        if not isinstance(raw_points, list):
            raise PolygonLabelError(
                f"{polygon_number}번 다각형 점 목록이 올바르지 않습니다."
            )

        if len(raw_points) < 3:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형에는 최소 3개 점이 필요합니다."
            )

        if len(raw_points) > MAX_POINTS_PER_POLYGON:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형 점이 5000개를 초과합니다."
            )

        points: List[List[float]] = []

        for point_number, raw_point in enumerate(
            raw_points,
            start=1,
        ):
            if (
                not isinstance(raw_point, (list, tuple))
                or len(raw_point) != 2
            ):
                raise PolygonLabelError(
                    f"{polygon_number}번 다각형의 "
                    f"{point_number}번 점 형식이 올바르지 않습니다."
                )

            try:
                x = float(raw_point[0])
                y = float(raw_point[1])
            except (TypeError, ValueError) as error:
                raise PolygonLabelError(
                    f"{polygon_number}번 다각형의 "
                    f"{point_number}번 점이 숫자가 아닙니다."
                ) from error

            if (
                not isfinite(x)
                or not isfinite(y)
                or x < 0.0
                or x > 1.0
                or y < 0.0
                or y > 1.0
            ):
                raise PolygonLabelError(
                    f"{polygon_number}번 다각형의 "
                    f"{point_number}번 점이 0~1 범위를 벗어났습니다."
                )

            points.append([x, y])

        unique_points = {
            (round(point[0], 10), round(point[1], 10))
            for point in points
        }
        if len(unique_points) < 3:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형에는 "
                "서로 다른 점이 최소 3개 필요합니다."
            )

        if cls._polygon_area(points) <= 0.000001:
            raise PolygonLabelError(
                f"{polygon_number}번 다각형의 면적이 너무 작습니다."
            )

        return {
            "class_id": class_id,
            "points": points,
        }

    @classmethod
    def _parse_polygon_label(
        cls,
        label_path: Path,
        class_count: int,
    ) -> List[Dict[str, object]]:
        polygons = []

        try:
            lines = label_path.read_text(
                encoding="utf-8"
            ).splitlines()
        except (OSError, UnicodeDecodeError) as error:
            raise PolygonLabelError(
                f"레이블을 읽을 수 없습니다: {label_path}"
            ) from error

        for line_number, raw_line in enumerate(
            lines,
            start=1,
        ):
            line = raw_line.strip()
            if not line:
                continue

            tokens = line.split()

            if len(tokens) < 7 or len(tokens) % 2 != 1:
                raise PolygonLabelError(
                    f"{label_path}:{line_number}: "
                    "세그멘테이션 레이블은 클래스 번호와 "
                    "최소 3개 좌표점이 필요합니다."
                )

            try:
                class_id = int(tokens[0])
                coordinates = [
                    float(value)
                    for value in tokens[1:]
                ]
            except ValueError as error:
                raise PolygonLabelError(
                    f"{label_path}:{line_number}: "
                    "레이블 값 형식이 올바르지 않습니다."
                ) from error

            points = [
                [coordinates[index], coordinates[index + 1]]
                for index in range(0, len(coordinates), 2)
            ]

            polygons.append(
                cls._validate_polygon(
                    {
                        "class_id": class_id,
                        "points": points,
                    },
                    class_count,
                    line_number,
                )
            )

        return polygons

    def load(
        self,
        photo_root: Path,
        annotation_root: Path,
        relative_path: str,
        class_count: int,
    ) -> Dict[str, object]:
        root, image = self._safe_image(
            photo_root,
            relative_path,
        )
        project_label = self._project_label(
            root,
            annotation_root,
            image,
        )

        if project_label.is_file():
            label_path = project_label
            source = "project"
        else:
            label_path = self._external_label(
                root,
                image,
            )
            source = (
                "external"
                if label_path is not None
                else "none"
            )

        polygons = (
            self._parse_polygon_label(
                label_path,
                class_count,
            )
            if label_path is not None
            else []
        )

        return {
            "image_path": image.relative_to(root).as_posix(),
            "label_source": source,
            "polygons": polygons,
        }

    def save(
        self,
        photo_root: Path,
        annotation_root: Path,
        relative_path: str,
        polygons,
        class_count: int,
    ) -> Dict[str, object]:
        root, image = self._safe_image(
            photo_root,
            relative_path,
        )

        if not isinstance(polygons, list):
            raise PolygonLabelError(
                "다각형 목록 형식이 올바르지 않습니다."
            )

        if len(polygons) > MAX_POLYGONS_PER_IMAGE:
            raise PolygonLabelError(
                "한 이미지에는 최대 2000개 다각형을 저장할 수 있습니다."
            )

        normalized = [
            self._validate_polygon(
                polygon,
                class_count,
                index,
            )
            for index, polygon in enumerate(
                polygons,
                start=1,
            )
        ]

        lines = []

        for polygon in normalized:
            values = [str(polygon["class_id"])]

            for x, y in polygon["points"]:
                values.extend(
                    [f"{x:.8f}", f"{y:.8f}"]
                )

            lines.append(" ".join(values))

        target = self._project_label(
            root,
            annotation_root,
            image,
        )
        target.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        temporary = target.with_suffix(
            target.suffix + ".tmp"
        )
        content = (
            "\n".join(lines) + "\n"
            if lines
            else ""
        )

        temporary.write_text(
            content,
            encoding="utf-8",
        )
        temporary.replace(target)

        return {
            "ok": True,
            "image_path": image.relative_to(root).as_posix(),
            "label_path": str(target),
            "label_source": "project",
            "polygon_count": len(normalized),
            "polygons": normalized,
        }
