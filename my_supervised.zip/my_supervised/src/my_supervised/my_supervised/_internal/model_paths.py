"""Find bundled YOLO weights without depending on a particular home folder."""

from pathlib import Path


def resolve_yolo_model(raw="", task="detect"):
    """An explicit path must exist; only an empty path selects defaults."""
    if task not in ("detect", "segment"):
        raise ValueError("YOLO task must be detect or segment.")
    if str(raw).strip():
        selected = Path(str(raw).strip()).expanduser()
        if not selected.is_file():
            raise FileNotFoundError(f"지정한 YOLO 모델 파일이 없습니다: {selected}")
        return selected.resolve()
    filename = "yolo11n.pt" if task == "detect" else "yolo11n-seg.pt"
    candidates = []
    try:
        from ament_index_python.packages import get_package_share_directory
        candidates.append(Path(get_package_share_directory("my_supervised")) / "models" / filename)
    except (ImportError, LookupError):
        pass
    # Source-tree execution is useful for tests and for inspecting the package.
    candidates.append(Path(__file__).resolve().parents[2] / "models" / filename)
    candidates.append(Path("/home/jetson/ultralytics/ultralytics") / filename)
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise FileNotFoundError(f"기본 YOLO 모델이 없습니다: {filename}. 패키지의 models 폴더를 확인하세요.")
