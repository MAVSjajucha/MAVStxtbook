"""ROS subscriptions for the lane-learning web workspace; never publish motion."""

import json
import math
import threading

from geometry_msgs.msg import Twist
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String
from rclpy.node import Node
from rclpy.parameter import Parameter
from rcl_interfaces.srv import SetParametersAtomically
from rclpy.qos import QoSProfile, ReliabilityPolicy

from .tree_web import TreeWebServer, TreeWorkspace
from .web_server import _vehicle_identity


class TreeTrainingApp(Node):
    """Keep data collection active and request JPEGs only for connected viewers."""

    def __init__(self):
        """Start subscriptions and the tree workspace web server."""
        super().__init__("supervised_training_app")
        self._lifecycle_lock = threading.RLock()
        self._closed = False
        self._preview_subscription = None
        self.declare_parameter("server_port", 8081)
        self.declare_parameter("open_local_browser", False)
        self.declare_parameter("command_topic", "/cmd_vel")
        self.declare_parameter("max_delta_ms", 200.0)
        self._grid_client = self.create_client(
            SetParametersAtomically,
            "/supervised_lane_processor/set_parameters_atomically",
        )
        self.workspace = TreeWorkspace(
            command_topic=str(self.get_parameter("command_topic").value),
            max_delta_ms=float(self.get_parameter("max_delta_ms").value),
            apply_grid=self._apply_grid,
        )
        self.workspace.vehicle = _vehicle_identity()
        latest = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.create_subscription(String, "/supervised/lane_result", self._result, latest)
        self.create_subscription(Twist, self.workspace.command_topic, self._command,
                                 QoSProfile(depth=50, reliability=ReliabilityPolicy.BEST_EFFORT))
        # Subscription creation/destruction happens on the ROS executor's timer callback.
        self._preview_timer = self.create_timer(0.2, self._update_preview_subscription)
        self.web_server = TreeWebServer(self.workspace, self.get_parameter("server_port").value)
        self.web_server.start()
        self.get_logger().info(
            f"Lane learning UI ready: http://<vehicle-ip>:{self.web_server.port}")

    def _result(self, message):
        with self._lifecycle_lock:
            if self._closed:
                return
            try:
                self.workspace.receive_result(json.loads(message.data))
            except (ValueError, TypeError, KeyError, OSError) as error:
                self.get_logger().error(f"CSV/grid: {error}", throttle_duration_sec=2.0)

    def _update_preview_subscription(self):
        with self._lifecycle_lock:
            if self._closed:
                return
            with self.workspace.preview.condition:
                wanted = self.workspace.preview.viewers > 0 and not self.workspace.preview.closed
            if wanted and self._preview_subscription is None:
                self._preview_subscription = self.create_subscription(
                    CompressedImage, "/supervised/lane_preview", self._preview,
                    QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT))
            elif not wanted and self._preview_subscription is not None:
                self.destroy_subscription(self._preview_subscription)
                self._preview_subscription = None

    def _preview(self, message):
        with self._lifecycle_lock:
            if not self._closed:
                self.workspace.preview.update(message.data)

    def _command(self, message):
        with self._lifecycle_lock:
            if self._closed:
                return
            try:
                linear_x, angular_z = float(message.linear.x), float(message.angular.z)
                if not (math.isfinite(linear_x) and math.isfinite(angular_z)):
                    raise ValueError("조이스틱 명령에 NaN 또는 무한대가 있습니다.")
                self.workspace.receive_command(linear_x, angular_z)
            except (ValueError, TypeError, OverflowError, OSError) as error:
                self.get_logger().error(f"CSV/command: {error}", throttle_duration_sec=2.0)

    def _apply_grid(self, config):
        with self._lifecycle_lock:
            if self._closed:
                raise RuntimeError("학습 화면이 종료되고 있습니다.")
        if not self._grid_client.wait_for_service(timeout_sec=2.0):
            raise RuntimeError("격자 노드에 연결할 수 없습니다.")
        request = SetParametersAtomically.Request()
        request.parameters = [
            Parameter(name, value=value).to_parameter_msg()
            for name, value in config.items()
        ]
        future = self._grid_client.call_async(request)
        done = threading.Event()
        future.add_done_callback(lambda _: done.set())
        if not done.wait(3.0):
            raise RuntimeError("격자 설정 응답 시간이 초과되었습니다.")
        result = future.result().result
        if not result.successful:
            raise ValueError(result.reason)

    def destroy_node(self):
        """Prevent timer/callback activity before closing the workspace and HTTP server."""
        with self._lifecycle_lock:
            if self._closed:
                return None
            self._closed = True
            self._preview_timer.cancel()
            if self._preview_subscription is not None:
                self.destroy_subscription(self._preview_subscription)
                self._preview_subscription = None
        self.workspace.close()
        self.web_server.stop()
        return super().destroy_node()
