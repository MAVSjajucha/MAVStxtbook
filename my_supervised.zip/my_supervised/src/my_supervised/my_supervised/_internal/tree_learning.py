"""CSV learning and portable lane-model prediction, without ROS dependencies.

Students clean CSV rows themselves. This module checks their data; it never drops
stops, outliers, or otherwise valid examples. Only training requires scikit-learn.
Saved models are plain JSON, and prediction does not execute serialized code.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import json
import math
from pathlib import Path
import struct
import tempfile
from typing import Any, Dict, Mapping
import uuid

from my_supervised._internal.grid_features import validate_grid


GRID_FIELDS = (
    "processing_width", "processing_height", "rows", "cols", "roi_b", "roi_t",
    "ths1", "ths2", "ker_size",
)
RECORD_FIELDS = (
    "session_id", "timestamp_ns", "feature_received_ns", "cmd_received_ns", "delta_ms",
)
# Steering is the only learned output. Older recordings may retain linear_x as
# audit metadata, but it is never an input feature or a regression target.
TARGET_COLUMNS = ["angular_z"]
MODEL_FORMAT_VERSION = 3
MODEL_TYPES = ("decision_tree_classification", "decision_tree_regression", "linear_regression")
DIRECTION_COMMANDS = {"left": 0.5, "straight": 0.0, "right": -0.5}
CLASS_LABELS = list(DIRECTION_COMMANDS)
DEFAULT_TRAINING_SETTINGS = {
    "model_type": "decision_tree_classification",
    "max_depth": 6,
    "min_samples_leaf": 5,
    "min_samples_split": 10,
    "max_leaf_nodes": None,
    "ccp_alpha": 0.0,
    "criterion": "gini",
    "fit_intercept": True,
    "train_percent": 80,
    "split_mode": "row",
    "train_sessions": [],
    "validation_sessions": [],
    "random_state": 0,
    "feature_groups": ["V", "L", "R"],
}


class TreeLearningError(ValueError):
    """An actionable dataset, training, or model error."""


def _number(value: Any, label: str) -> float:
    if isinstance(value, bool):
        raise TreeLearningError(f"{label}: 숫자를 입력하세요.")
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError):
        raise TreeLearningError(f"{label}: 숫자가 아닙니다: {value!r}") from None
    if not math.isfinite(result):
        raise TreeLearningError(f"{label}: NaN 또는 무한대는 사용할 수 없습니다.")
    return result


def _integer(value: Any, label: str, minimum: int = 0) -> int:
    if isinstance(value, bool):
        raise TreeLearningError(f"{label}: 정수를 입력하세요.")
    try:
        decimal = Decimal(str(value))
        if not decimal.is_finite() or decimal != decimal.to_integral_value():
            raise ValueError
        result = int(decimal)
    except (ValueError, TypeError, InvalidOperation, OverflowError):
        raise TreeLearningError(f"{label}: 정수를 입력하세요.") from None
    if result < minimum:
        raise TreeLearningError(f"{label}: {minimum} 이상이어야 합니다.")
    return result


def normalize_grid(raw: Mapping[str, Any]) -> Dict[str, int]:
    """Return the exact preprocessing metadata shared by collection and driving."""
    if not isinstance(raw, Mapping):
        raise TreeLearningError("격자 설정은 객체여야 합니다.")
    missing = [key for key in GRID_FIELDS if key not in raw]
    if missing:
        raise TreeLearningError("격자 설정 누락: " + ", ".join(missing))
    grid = {key: _integer(raw[key], key) for key in GRID_FIELDS}
    try:
        return validate_grid(grid)
    except ValueError as error:
        raise TreeLearningError(str(error)) from None


def _columns(grid: Mapping[str, int], groups=("V", "L", "R")):
    return [
        f"{group.lower()}_{index}"
        for group in ("V", "L", "R") if group in groups
        for index in range(grid["cols"] if group == "V" else grid["rows"])
    ]


def _float32(value: Any, label: str) -> float:
    number = _number(value, label)
    try:
        result = struct.unpack("f", struct.pack("f", number))[0]
    except (OverflowError, struct.error):
        raise TreeLearningError(f"{label}: 모델 입력 범위를 벗어난 숫자입니다.") from None
    if not math.isfinite(result):
        raise TreeLearningError(f"{label}: 모델 입력 범위를 벗어난 숫자입니다.")
    return result


def direction_from_angular(angular_z):
    """ROS convention: positive yaw is left; exact zero is straight."""
    value = _number(angular_z, "angular_z")
    return "left" if value > 0 else "right" if value < 0 else "straight"


def _model_type(value):
    if value not in MODEL_TYPES:
        raise TreeLearningError("지원하지 않는 모델 종류입니다: " + str(value))
    return value


def _read_csv(path, model_type="decision_tree_classification"):
    model_type = _model_type(model_type)
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise TreeLearningError(f"CSV 파일이 없습니다: {source}")
    records = []
    grid = None
    feature_columns = None
    try:
        with source.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            header = reader.fieldnames
            if not header or len(header) != len(set(header)) or any(not key for key in header):
                raise TreeLearningError("CSV 열 이름이 없거나 중복되어 있습니다.")
            missing = [key for key in (*RECORD_FIELDS, *GRID_FIELDS) if key not in header]
            if model_type != "decision_tree_classification" and "angular_z" not in header:
                missing.append("angular_z")
            elif "direction" not in header and "angular_z" not in header:
                missing.append("direction (또는 이전 CSV의 angular_z)")
            if missing:
                raise TreeLearningError("CSV 필수 열 누락: " + ", ".join(missing))
            for row in reader:
                line = reader.line_num
                try:
                    if None in row or any(value is None for value in row.values()):
                        raise TreeLearningError("헤더와 데이터의 열 개수가 다릅니다.")
                    row_grid = normalize_grid(row)
                    if grid is None:
                        grid = row_grid
                        feature_columns = _columns(grid)
                        missing_features = [key for key in feature_columns if key not in header]
                        if missing_features:
                            raise TreeLearningError("특징값 열 누락: " + ", ".join(missing_features))
                        extra_features = [key for key in header if key.startswith(("v_", "l_", "r_")) and key not in feature_columns]
                        if extra_features:
                            raise TreeLearningError("격자와 맞지 않는 특징값 열: " + ", ".join(extra_features))
                    elif row_grid != grid:
                        raise TreeLearningError("한 CSV에서 영상 크기·격자·ROI·영상 처리 설정을 섞을 수 없습니다.")
                    session_id = row["session_id"].strip()
                    if not session_id:
                        raise TreeLearningError("session_id가 비어 있습니다.")
                    record = {"session_id": session_id}
                    for key in ("timestamp_ns", "feature_received_ns", "cmd_received_ns"):
                        record[key] = _integer(row[key], key)
                    record["delta_ms"] = _number(row["delta_ms"], "delta_ms")
                    for key in feature_columns:
                        record[key] = _float32(row[key], key)
                    if "angular_z" in header:
                        record["angular_z"] = _number(row["angular_z"], "angular_z")
                    if "direction" in header:
                        direction = row["direction"].strip().lower()
                        if direction not in DIRECTION_COMMANDS:
                            raise TreeLearningError("direction은 left, straight, right 중 하나여야 합니다.")
                        record["direction"] = direction
                        record["_direction_derived"] = False
                    else:
                        record["direction"] = direction_from_angular(record["angular_z"])
                        record["_direction_derived"] = True
                    if "linear_x" in header:
                        record["linear_x"] = _number(row["linear_x"], "linear_x")
                    records.append(record)
                except TreeLearningError as error:
                    raise TreeLearningError(f"CSV {line}행: {error}") from None
    except (OSError, UnicodeError, csv.Error) as error:
        raise TreeLearningError(f"CSV를 읽을 수 없습니다: {error}") from error
    if not records:
        raise TreeLearningError("CSV에 데이터 행이 없습니다.")
    return source, grid, feature_columns, records


def _summary(source, grid, feature_columns, records, model_type="decision_tree_classification"):
    sessions = {}
    for row in records:
        sessions[row["session_id"]] = sessions.get(row["session_id"], 0) + 1
    warnings = []
    if any(row["_direction_derived"] for row in records):
        warnings.append("이전 CSV에 direction 열이 없어 angular_z 부호로 방향을 해석했습니다 (좌회전 +, 우회전 −). 원본은 변경하지 않았습니다.")
    mismatch = sum("angular_z" in row and row["direction"] != direction_from_angular(row["angular_z"]) for row in records)
    if mismatch:
        warnings.append(f"direction과 angular_z 부호가 다른 행이 {mismatch}개입니다. 분류는 direction, 회귀는 angular_z를 각각 그대로 학습합니다.")
    if len({row["timestamp_ns"] for row in records}) == 1:
        warnings.append("timestamp_ns가 모두 같습니다. 시간 정보가 반올림되었을 수 있습니다. CSV 행 순서 분리는 사용할 수 있고, 서로 다른 session_id가 2개 이상이면 수집 회차 직접 지정 분리도 가능합니다.")
    if len({row["direction"] for row in records}) < 2:
        warnings.append("방향 종류가 한 가지뿐입니다. 분류 학습에는 두 종류 이상의 방향 예시가 필요합니다.")
    return {
        "model_type": model_type,
        "csv_path": str(source),
        "row_count": len(records),
        "session_count": len(sessions),
        "sessions": [{"session_id": key, "row_count": count} for key, count in sessions.items()],
        "grid": grid,
        "feature_columns": feature_columns,
        "target_columns": ["direction"] if model_type == "decision_tree_classification" else list(TARGET_COLUMNS),
        "regression_target_columns": list(TARGET_COLUMNS),
        "target_options": {"classification": ["direction"], "regression": list(TARGET_COLUMNS)},
        "direction_counts": {label: sum(row["direction"] == label for row in records) for label in CLASS_LABELS},
        "direction_commands": dict(DIRECTION_COMMANDS),
        "warnings": warnings,
        "straight_row_count": sum(row["direction"] == "straight" for row in records),
        "audit_columns": ["linear_x"] if "linear_x" in records[0] else [],
        # Zero steering also includes straight driving; it does not mean stopped.
        "stopped_row_count": (
            sum(row["linear_x"] == 0 and row["angular_z"] == 0 for row in records)
            if "linear_x" in records[0] and "angular_z" in records[0] else None
        ),
        "first_timestamp_ns": min(row["timestamp_ns"] for row in records),
        "last_timestamp_ns": max(row["timestamp_ns"] for row in records),
        "source_files_modified": False,
    }


def inspect_csv(path, model_type="decision_tree_classification") -> Dict[str, Any]:
    """Validate every row and report its layout. Does not change the CSV."""
    return _summary(*_read_csv(path, model_type), model_type=model_type)


def _selected_session_ids(selected, label):
    if not isinstance(selected, (list, tuple)) or any(
            not isinstance(value, str) or not value.strip() for value in selected):
        raise TreeLearningError(f"{label}: session_id 문자열 목록을 지정하세요.")
    if len(selected) != len(set(selected)):
        raise TreeLearningError(f"{label}에 중복된 session_id가 있습니다. 각 회차는 한 번만 선택하세요.")
    return list(selected)


def validate_session_selection(session_ids, settings):
    """Validate explicit assignment against inspected or freshly read CSV IDs.

    Kept separate from normalization so previously exported models with legacy
    automatic session-split metadata remain loadable for inference.
    """
    sessions = set(session_ids)
    if len(sessions) < 2:
        raise TreeLearningError("수집 회차별 분리에는 session_id가 서로 다른 기록이 최소 2개 필요합니다.")
    training_sessions = set(_selected_session_ids(settings.get("train_sessions", []), "훈련용 회차"))
    validation_sessions = set(_selected_session_ids(settings.get("validation_sessions", []), "검증용 회차"))
    if not training_sessions:
        raise TreeLearningError("훈련용 회차를 최소 1개 선택하세요.")
    if not validation_sessions:
        raise TreeLearningError("검증용 회차를 최소 1개 선택하세요.")
    overlap = training_sessions & validation_sessions
    if overlap:
        raise TreeLearningError("같은 회차를 훈련용·검증용에 동시에 지정할 수 없습니다: " + ", ".join(sorted(overlap)))
    selected = training_sessions | validation_sessions
    unknown = selected - sessions
    if unknown:
        raise TreeLearningError("현재 CSV에 없는 회차가 선택되었습니다. CSV를 다시 검사하고 회차를 선택하세요: " + ", ".join(sorted(unknown)))
    unassigned = sessions - selected
    if unassigned:
        raise TreeLearningError("모든 회차를 훈련용 또는 검증용으로 지정하세요. 미지정 회차: " + ", ".join(sorted(unassigned)))
    return training_sessions, validation_sessions


def normalize_settings(raw: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise TreeLearningError("학습 설정은 객체여야 합니다.")
    unknown = set(raw) - set(DEFAULT_TRAINING_SETTINGS)
    if unknown:
        raise TreeLearningError("지원하지 않는 학습 설정: " + ", ".join(sorted(unknown)))
    settings = dict(DEFAULT_TRAINING_SETTINGS)
    settings.update(raw)
    settings["model_type"] = _model_type(settings["model_type"])
    if "criterion" not in raw:
        settings["criterion"] = "gini" if settings["model_type"] == "decision_tree_classification" else "squared_error"
    if type(settings["fit_intercept"]) is not bool:
        raise TreeLearningError("fit_intercept는 true 또는 false여야 합니다.")
    for key in ("max_depth", "max_leaf_nodes"):
        if settings[key] in (None, "", "None", "null"):
            settings[key] = None
        else:
            settings[key] = _integer(settings[key], key, 1 if key == "max_depth" else 2)
    for key, minimum in (("min_samples_leaf", 1), ("min_samples_split", 2), ("random_state", 0)):
        settings[key] = _integer(settings[key], key, minimum)
    if settings["random_state"] > 2**32 - 1:
        raise TreeLearningError("random_state는 0~4294967295여야 합니다.")
    settings["ccp_alpha"] = _number(settings["ccp_alpha"], "ccp_alpha")
    if settings["ccp_alpha"] < 0:
        raise TreeLearningError("ccp_alpha는 0 이상이어야 합니다.")
    if settings["split_mode"] not in ("time", "session", "row"):
        raise TreeLearningError("split_mode는 time, session 또는 row여야 합니다.")
    if settings["split_mode"] == "session":
        # Session assignment is explicit; a stale hidden ratio has no effect.
        settings["train_percent"] = None
    else:
        settings["train_percent"] = _number(settings["train_percent"], "train_percent")
        if not 0 < settings["train_percent"] < 100:
            raise TreeLearningError("훈련 비율은 0% 초과, 100% 미만이어야 합니다.")
    for key, label in (("train_sessions", "훈련용 회차"), ("validation_sessions", "검증용 회차")):
        settings[key] = _selected_session_ids(settings[key], label)
    criteria = ("gini", "entropy") if settings["model_type"] == "decision_tree_classification" else ("squared_error", "friedman_mse", "absolute_error")
    if settings["criterion"] not in criteria:
        raise TreeLearningError("선택한 모델에서 지원하는 criterion: " + ", ".join(criteria))
    groups = settings["feature_groups"]
    if not isinstance(groups, (list, tuple)) or not groups or any(group not in ("V", "L", "R") for group in groups):
        raise TreeLearningError("입력 특징은 V, L, R 중 하나 이상을 선택하세요.")
    if len(groups) != len(set(groups)):
        raise TreeLearningError("입력 특징 그룹이 중복되었습니다.")
    settings["feature_groups"] = [group for group in ("V", "L", "R") if group in groups]
    return settings


def _split(records, settings):
    if len(records) < 2:
        raise TreeLearningError("훈련·검증을 나누려면 데이터 행이 최소 2개 필요합니다.")
    ordered = sorted(range(len(records)), key=lambda index: records[index]["timestamp_ns"])
    if settings["split_mode"] == "session":
        training_sessions, validation_sessions = validate_session_selection(
            (row["session_id"] for row in records), settings)
        # Membership is explicit; timestamps only retain the existing order
        # within each partition. Equal timestamps keep their CSV row order.
        train = [index for index in ordered if records[index]["session_id"] in training_sessions]
        validation = [index for index in ordered if records[index]["session_id"] in validation_sessions]
        return train, validation
    fraction = settings["train_percent"] / 100.0
    if settings["split_mode"] == "row":
        ordered = list(range(len(records)))
        cut = max(1, min(len(ordered) - 1, int(len(ordered) * fraction)))
        train, validation = ordered[:cut], ordered[cut:]
    elif settings["split_mode"] == "time":
        # Keep equal timestamps together rather than placing duplicate observations
        # on both sides of the split. No random per-row shuffling is performed.
        boundaries = [index for index in range(1, len(ordered)) if records[ordered[index - 1]]["timestamp_ns"] < records[ordered[index]]["timestamp_ns"]]
        if not boundaries:
            raise TreeLearningError("시간 분리에는 서로 다른 timestamp_ns가 최소 2개 필요합니다.")
        cut = min(boundaries, key=lambda index: abs(index - len(ordered) * fraction))
        train, validation = ordered[:cut], ordered[cut:]
    return train, validation


def _metrics(actual, predicted):
    values = [float(value) for value in actual]
    errors = [float(predicted[index]) - value for index, value in enumerate(values)]
    total = len(values)
    mse = sum(error * error for error in errors) / total
    mean = sum(values) / total
    variance_sum = sum((value - mean) ** 2 for value in values)
    return {"angular_z": {
        "mae": sum(abs(error) for error in errors) / total,
        "rmse": math.sqrt(mse),
        "r2": None if total < 2 or variance_sum == 0 else 1 - sum(error * error for error in errors) / variance_sum,
    }}


def _classification_metrics(actual, predicted):
    matrix = [[0 for _ in CLASS_LABELS] for _ in CLASS_LABELS]
    for expected, output in zip(actual, predicted):
        matrix[CLASS_LABELS.index(str(expected))][CLASS_LABELS.index(str(output))] += 1
    precision_values = []
    recall_values = []
    for index in range(len(CLASS_LABELS)):
        true_positive = matrix[index][index]
        predicted_count = sum(row[index] for row in matrix)
        actual_count = sum(matrix[index])
        precision_values.append(true_positive / predicted_count if predicted_count else 0.0)
        recall_values.append(true_positive / actual_count if actual_count else 0.0)
    return {
        "accuracy": (
            sum(matrix[index][index] for index in range(len(CLASS_LABELS))) / len(actual)
            if len(actual) else 0.0
        ),
        # All three directions have equal weight, including absent classes.
        "macro_precision": sum(precision_values) / len(CLASS_LABELS),
        "macro_recall": sum(recall_values) / len(CLASS_LABELS),
        "confusion_matrix": matrix,
        "class_labels": list(CLASS_LABELS),
    }


def _write_json(path: Path, value):
    """Atomic publication prevents readers observing a partly written result."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, prefix=".tree_", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        temporary.replace(path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def train_csv(csv_path, output_directory, settings: dict) -> Dict[str, Any]:
    """Learn direction or angular_z, evaluate held-out rows, then publish JSON."""
    settings = normalize_settings(settings)
    if not str(output_directory).strip():
        raise TreeLearningError("모델 결과 저장 폴더를 선택하세요.")
    output = Path(output_directory).expanduser().resolve()
    if not output.is_dir():
        raise TreeLearningError(f"모델 결과 저장 폴더가 없거나 폴더가 아닙니다: {output}")
    model_type = settings["model_type"]
    classification = model_type == "decision_tree_classification"
    source, grid, all_columns, records = _read_csv(csv_path, model_type)
    columns = _columns(grid, settings["feature_groups"])
    train_indices, validation_indices = _split(records, settings)
    try:
        import numpy as np
        from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
        from sklearn.linear_model import LinearRegression
    except ImportError as error:
        raise TreeLearningError("학습에는 numpy와 scikit-learn이 필요합니다. 차량의 Python 환경을 확인하세요.") from error
    # CSV values are quantized to float32 for a consistent camera/tree contract.
    # Linear regression fits those exact values in float64 for portable dot products.
    x = np.asarray([[row[key] for key in columns] for row in records], dtype=np.float64 if model_type == "linear_regression" else np.float32)
    y = np.asarray([row["direction"] if classification else row["angular_z"] for row in records], dtype=str if classification else np.float64)
    if classification and len(set(y[train_indices])) < 2:
        adjustment = "훈련용 회차 선택" if settings["split_mode"] == "session" else "분리 비율"
        raise TreeLearningError(f"훈련 구간에 방향이 한 종류뿐입니다. 두 종류 이상의 방향 데이터를 수집하거나 {adjustment}을 조정하세요.")
    if model_type == "linear_regression":
        estimator = LinearRegression(fit_intercept=settings["fit_intercept"])
    else:
        estimator_class = DecisionTreeClassifier if classification else DecisionTreeRegressor
        estimator = estimator_class(**{key: settings[key] for key in (
            "max_depth", "min_samples_leaf", "min_samples_split", "max_leaf_nodes",
            "ccp_alpha", "criterion", "random_state",
        )})
    estimator.fit(x[train_indices], y[train_indices])
    predicted_train = estimator.predict(x[train_indices])
    predicted_validation = estimator.predict(x[validation_indices])
    metric_function = _classification_metrics if classification else _metrics
    metrics = {
        "training": metric_function(y[train_indices], predicted_train),
        "validation": metric_function(y[validation_indices], predicted_validation),
        "train_row_count": len(train_indices),
        "validation_row_count": len(validation_indices),
        "actual_train_percent": 100.0 * len(train_indices) / len(records),
        "train_sessions": sorted({records[index]["session_id"] for index in train_indices}),
        "validation_sessions": sorted({records[index]["session_id"] for index in validation_indices}),
    }
    if model_type == "linear_regression":
        model = {"coefficients": estimator.coef_.tolist(), "intercept": float(estimator.intercept_)}
    else:
        metrics.update(tree_depth=int(estimator.get_depth()), leaf_count=int(estimator.get_n_leaves()))
        tree = estimator.tree_
        model = {
            "children_left": tree.children_left.tolist(),
            "children_right": tree.children_right.tolist(),
            "feature": tree.feature.tolist(),
            "threshold": tree.threshold.tolist(),
            "value": tree.value[:, 0, :].tolist() if classification else tree.value[:, :, 0].tolist(),
        }
        if classification:
            model["classes"] = estimator.classes_.tolist()
            model["direction_commands"] = dict(DIRECTION_COMMANDS)
    targets = ["direction"] if classification else list(TARGET_COLUMNS)
    artifact = {
        "format_version": MODEL_FORMAT_VERSION,
        "model_type": model_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "grid": grid,
        "feature_columns": columns,
        "target_columns": targets,
        "hyperparameters": settings,
        "metrics": metrics,
        "model": model,
    }
    validate_model(artifact)
    # Check exported traversal against the library before publishing any model.
    for index, expected in zip(validation_indices, predicted_validation):
        actual = _predict_vector(artifact, [records[index][key] for key in columns])
        matches = actual == str(expected) if classification else np.allclose(actual, expected, rtol=1e-9, atol=1e-9)
        if not matches:
            raise TreeLearningError("JSON 모델 변환 검증에 실패했습니다.")
    positions = sorted({round(index * (len(validation_indices) - 1) / max(1, min(120, len(validation_indices)) - 1)) for index in range(min(120, len(validation_indices)))})
    curve = [
        {
            "timestamp_ns": records[validation_indices[position]]["timestamp_ns"],
            "session_id": records[validation_indices[position]]["session_id"],
            "actual_angular_z": DIRECTION_COMMANDS[str(y[validation_indices[position]])] if classification else float(y[validation_indices[position]]),
            "predicted_angular_z": DIRECTION_COMMANDS[str(predicted_validation[position])] if classification else float(predicted_validation[position]),
            **({"actual_direction": str(y[validation_indices[position]]), "predicted_direction": str(predicted_validation[position])} if classification else {}),
        }
        for position in positions
    ]
    run = output / (("linear_" if model_type == "linear_regression" else "tree_") + datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8])
    run.mkdir(exist_ok=False)
    result = {
        "ok": True,
        "model_type": model_type,
        "run_directory": str(run),
        "model_path": str(run / "model.json"),
        "report_path": str(run / "report.json"),
        "csv": _summary(source, grid, all_columns, records, model_type),
        "settings": settings,
        "feature_columns": columns,
        "target_columns": targets,
        "metrics": metrics,
        "curve_sample": curve,
        "source_files_modified": False,
    }
    _write_json(run / "model.json", artifact)
    _write_json(run / "report.json", result)
    return result


def _validate_output_contract(artifact):
    """Never reinterpret old two-output leaves as steering-only predictions."""
    if not isinstance(artifact, dict):
        raise TreeLearningError("학습 모델은 JSON 객체여야 합니다.")
    if artifact.get("format_version") == 1 or artifact.get("target_columns") == ["linear_x", "angular_z"]:
        raise TreeLearningError(
            "기존 전진·회전 2출력 모델은 사용할 수 없습니다. "
            "CSV를 다시 선택하고 angular_z 전용 모델로 재학습하세요."
        )
    if type(artifact.get("format_version")) is not int or artifact["format_version"] not in (2, MODEL_FORMAT_VERSION):
        raise TreeLearningError("지원하지 않는 모델 형식입니다. format_version=3 또는 이전 angular_z 회귀나무 version=2가 필요합니다.")
    model_type = _model_type(artifact.get("model_type"))
    if artifact["format_version"] == 2 and model_type != "decision_tree_regression":
        raise TreeLearningError("이전 version=2는 angular_z 의사결정회귀나무만 지원합니다.")
    expected = ["direction"] if model_type == "decision_tree_classification" else TARGET_COLUMNS
    if artifact.get("target_columns") != expected:
        raise TreeLearningError("선택한 모델의 출력 열이 잘못되었습니다. 필요한 출력: " + ", ".join(expected))


def validate_model(artifact: dict) -> dict:
    """Reject malformed trees, invalid values, cycles and unreachable nodes."""
    _validate_output_contract(artifact)
    model_type = artifact["model_type"]
    grid = normalize_grid(artifact.get("grid"))
    raw_settings = artifact.get("hyperparameters", {})
    if not isinstance(raw_settings, dict):
        raise TreeLearningError("모델 hyperparameters는 JSON 객체여야 합니다.")
    if artifact["format_version"] == 2:
        raw_settings = {**raw_settings, "model_type": "decision_tree_regression"}
    settings = normalize_settings(raw_settings)
    if settings["model_type"] != model_type:
        raise TreeLearningError("모델 종류와 학습 설정의 model_type이 다릅니다.")
    if artifact.get("feature_columns") != _columns(grid, settings["feature_groups"]):
        raise TreeLearningError("모델 특징값 열 순서와 격자 설정이 일치하지 않습니다.")
    model = artifact.get("model")
    if model_type == "linear_regression":
        if not isinstance(model, dict):
            raise TreeLearningError("선형회귀 모델 계수가 없습니다.")
        coefficients = model.get("coefficients")
        if not isinstance(coefficients, list) or len(coefficients) != len(artifact["feature_columns"]):
            raise TreeLearningError("선형회귀 계수 개수가 입력 특징 열 개수와 다릅니다.")
        for value in [*coefficients, model.get("intercept")]:
            if type(value) not in (int, float):
                raise TreeLearningError("선형회귀 계수와 절편은 JSON 숫자여야 합니다.")
            _number(value, "선형회귀 계수/절편")
        if not settings["fit_intercept"] and model["intercept"] != 0:
            raise TreeLearningError("절편을 사용하지 않는 모델의 intercept는 0이어야 합니다.")
        artifact["grid"] = grid
        artifact["hyperparameters"] = settings
        return artifact
    classification = model_type == "decision_tree_classification"
    if classification:
        classes = model.get("classes") if isinstance(model, dict) else None
        if not isinstance(classes, list) or not 2 <= len(classes) <= len(CLASS_LABELS) or any(label not in CLASS_LABELS for label in classes) or len(set(classes)) != len(classes):
            raise TreeLearningError("분류나무 classes는 중복 없는 left/straight/right 중 2개 이상이어야 합니다.")
        mapping = model.get("direction_commands")
        if not isinstance(mapping, dict) or set(mapping) != set(DIRECTION_COMMANDS) or any(type(mapping[key]) not in (int, float) or mapping[key] != value for key, value in DIRECTION_COMMANDS.items()):
            raise TreeLearningError("분류 방향 명령은 left=+0.5, right=-0.5, straight=0이어야 합니다.")
    keys = ("children_left", "children_right", "feature", "threshold", "value")
    if not isinstance(model, dict) or any(not isinstance(model.get(key), list) for key in keys):
        raise TreeLearningError("모델 트리 배열이 없거나 형식이 잘못되었습니다.")
    count = len(model["children_left"])
    if not 1 <= count <= 1000000 or any(len(model[key]) != count for key in keys):
        raise TreeLearningError("모델 트리 배열 길이가 일치하지 않습니다.")
    feature_count = len(artifact["feature_columns"])
    parents = [0] * count
    for node in range(count):
        left, right, feature = (model[key][node] for key in keys[:3])
        if any(type(value) is not int for value in (left, right, feature)):
            raise TreeLearningError("트리 자식 번호와 특징 번호는 정수여야 합니다.")
        threshold = model["threshold"][node]
        if type(threshold) not in (int, float):
            raise TreeLearningError("트리 임곗값은 JSON 숫자여야 합니다.")
        _number(threshold, "threshold")
        value = model["value"][node]
        if not isinstance(value, list) or len(value) != (len(model["classes"]) if classification else 1):
            raise TreeLearningError("트리 예측값 개수가 출력 형식과 다릅니다.")
        for prediction in value:
            if type(prediction) not in (int, float):
                raise TreeLearningError("트리 예측값은 JSON 숫자여야 합니다.")
            _number(prediction, "value")
        if classification and (any(prediction < 0 for prediction in value) or sum(value) <= 0):
            raise TreeLearningError("분류나무 클래스 가중치는 음수가 아니고 합이 양수여야 합니다.")
        if left == right == -1:
            if feature != -2:
                raise TreeLearningError("리프 노드의 feature는 -2여야 합니다.")
        else:
            if not (0 <= left < count and 0 <= right < count and left != right):
                raise TreeLearningError("트리 자식 노드 번호가 잘못되었습니다.")
            if not 0 <= feature < feature_count:
                raise TreeLearningError("트리 특징 번호가 입력 열 범위를 벗어났습니다.")
            parents[left] += 1
            parents[right] += 1
    if parents[0] != 0 or any(parent != 1 for parent in parents[1:]):
        raise TreeLearningError("트리의 루트 또는 부모 연결이 잘못되었습니다.")
    seen = set()
    stack = [0]
    while stack:
        node = stack.pop()
        if node in seen:
            raise TreeLearningError("트리에 순환 연결이 있습니다.")
        seen.add(node)
        if model["children_left"][node] != -1:
            stack.extend((model["children_left"][node], model["children_right"][node]))
    if len(seen) != count:
        raise TreeLearningError("트리에 접근할 수 없는 노드 또는 순환 연결이 있습니다.")
    artifact["grid"] = grid
    artifact["hyperparameters"] = settings
    return artifact


def load_model(path) -> Dict[str, Any]:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise TreeLearningError(f"모델 파일이 없습니다: {source}")
    if source.stat().st_size > 64 * 1024 * 1024:
        raise TreeLearningError("트리 JSON 모델은 64 MiB 이하여야 합니다.")
    try:
        with source.open("r", encoding="utf-8") as stream:
            artifact = json.load(stream)
    except (OSError, ValueError, UnicodeError) as error:
        raise TreeLearningError(f"모델 JSON을 읽을 수 없습니다: {error}") from error
    return validate_model(artifact)


def _predict_vector(artifact, values):
    model = artifact["model"]
    if artifact["model_type"] == "linear_regression":
        predicted = model["intercept"] + math.fsum(coefficient * value for coefficient, value in zip(model["coefficients"], values))
        return (_number(predicted, "선형회귀 예측값"),)
    node = 0
    # load_model validates all links once. The traversal guard also prevents an
    # accidental mutation after loading from turning inference into an infinite loop.
    for _ in range(len(model["children_left"])):
        left = model["children_left"][node]
        if left == -1:
            if artifact["model_type"] == "decision_tree_classification":
                # max returns the first maximum, matching sklearn's class order.
                index = max(range(len(model["classes"])), key=lambda item: model["value"][node][item])
                return model["classes"][index]
            return tuple(float(value) for value in model["value"][node])
        node = left if values[model["feature"][node]] <= model["threshold"][node] else model["children_right"][node]
    raise TreeLearningError("트리 예측 중 순환 연결이 발견되었습니다.")


def predict_model(artifact, features: dict, grid: dict) -> Dict[str, Any]:
    """Predict from an artifact returned by load_model; grid must match training."""
    _validate_output_contract(artifact)
    normalized = normalize_grid(grid)
    if normalized != artifact.get("grid"):
        raise TreeLearningError("현재 격자/ROI/영상 처리 설정이 학습 모델의 설정과 다릅니다.")
    if not isinstance(features, Mapping):
        raise TreeLearningError("V/L/R 특징값은 객체여야 합니다.")
    values = {}
    for group in ("V", "L", "R"):
        length = normalized["cols"] if group == "V" else normalized["rows"]
        vector = features.get(group)
        if vector is None or isinstance(vector, (str, bytes)):
            raise TreeLearningError(f"{group} 특징값 배열이 없습니다.")
        try:
            if len(vector) != length:
                raise TreeLearningError(f"{group} 특징값 개수가 격자와 다릅니다. 기대값: {length}")
            for index, value in enumerate(vector):
                values[f"{group.lower()}_{index}"] = _float32(value, f"{group}[{index}]")
        except TypeError:
            raise TreeLearningError(f"{group} 특징값은 배열이어야 합니다.") from None
    predicted = _predict_vector(artifact, [values[key] for key in artifact["feature_columns"]])
    if artifact["model_type"] == "decision_tree_classification":
        return {"angular_z": DIRECTION_COMMANDS[predicted], "direction": predicted}
    return dict(zip(TARGET_COLUMNS, predicted))


def main(argv=None):
    parser = argparse.ArgumentParser(description="Train a lane classification tree, regression tree or linear model from a CSV job.")
    parser.add_argument("--job", required=True, help="JSON containing csv_path, output_directory, settings, status_path")
    args = parser.parse_args(argv)
    status_path = None
    try:
        job = json.loads(Path(args.job).read_text(encoding="utf-8"))
        status_path = Path(job["status_path"]).expanduser().resolve()
        _write_json(status_path, {"status": "running"})
        result = train_csv(job["csv_path"], job["output_directory"], job.get("settings", {}))
        _write_json(status_path, {"status": "completed", "result": result})
        return 0
    except Exception as error:
        if status_path is not None:
            _write_json(status_path, {"status": "failed", "error": str(error)})
        print(f"트리 학습 실패: {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
