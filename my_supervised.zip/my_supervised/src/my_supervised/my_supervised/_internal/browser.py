"""Open Firefox first, only when the vehicle has a graphical session."""

import os
import shutil
import subprocess


def open_training_browser(port):
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        return
    executable = shutil.which("firefox") or shutil.which("xdg-open")
    if executable:
        try:
            subprocess.Popen([executable, f"http://127.0.0.1:{port}"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError:
            pass
