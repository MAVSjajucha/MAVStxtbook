"""Run one Ultralytics YOLO training job in a separate process."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
import shutil
from pathlib import Path
import sys
import traceback
from typing import Any, Dict, Mapping

from my_supervised._internal.training_settings import (
    TrainingSettingsError,
    TrainingSettingsStore,
)


STATE_FILENAME = "training_state.json"


class TrainingWorkerError(RuntimeError):
    """Raised when a YOLO training job cannot be started or completed."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_json_write(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            dict(value),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _number(value: Any) -> Any:
    """Convert tensor-like scalar values to finite JSON numbers."""
    try:
        converted = float(value)
    except (TypeError, ValueError):
        return None

    if not math.isfinite(converted):
        return None
    return converted


def normalize_configuration(
    configuration: Mapping[str, Any],
) -> Dict[str, Any]:
    """Validate paths and settings without loading or training a model."""
    if not isinstance(configuration, Mapping):
        raise TrainingWorkerError(
            "학습 작업 설정은 JSON 객체여야 합니다."
        )

    task_type = str(
        configuration.get("task_type", "")
    ).strip().lower()

    if task_type not in {"detect", "segment"}:
        raise TrainingWorkerError(
            "작업 유형은 detect 또는 segment여야 합니다."
        )

    data_yaml = Path(
        str(configuration.get("data_yaml", ""))
    ).expanduser()

    run_directory = Path(
        str(configuration.get("run_directory", ""))
    ).expanduser()

    if not data_yaml.is_absolute():
        raise TrainingWorkerError(
            "data.yaml 경로는 절대경로여야 합니다."
        )
    if not data_yaml.is_file():
        raise TrainingWorkerError(
            f"학습 데이터 설정 파일이 없습니다: {data_yaml}"
        )

    if not run_directory.is_absolute():
        raise TrainingWorkerError(
            "학습 결과 폴더는 절대경로여야 합니다."
        )
    if run_directory.name in {"", ".", ".."}:
        raise TrainingWorkerError(
            "학습 결과 폴더 이름이 올바르지 않습니다."
        )

    raw_settings = configuration.get("settings")
    if not isinstance(raw_settings, Mapping):
        raise TrainingWorkerError(
            "저장된 학습 설정을 찾을 수 없습니다."
        )

    try:
        settings = TrainingSettingsStore.validate(
            task_type,
            raw_settings,
        )
        storage = TrainingSettingsStore.inspect_storage(
            str(run_directory.parent)
        )
    except TrainingSettingsError as error:
        raise TrainingWorkerError(str(error)) from error

    return {
        "task_type": task_type,
        "model_path": settings["model_path"],
        "data_yaml": str(data_yaml.resolve()),
        "run_directory": str(run_directory.resolve()),
        "settings": settings,
        "storage": storage,
    }


def build_train_arguments(
    normalized: Mapping[str, Any],
) -> Dict[str, Any]:
    """Translate validated settings into Ultralytics train arguments."""
    settings = normalized["settings"]
    run_directory = Path(normalized["run_directory"])

    return {
        "data": normalized["data_yaml"],
        "epochs": int(settings["epochs"]),
        "imgsz": int(settings["imgsz"]),
        "batch": int(settings["batch"]),
        "optimizer": "Adam" if settings.get("optimizer", "SGD") == "Adam" else "SGD",
        "momentum": 0.9 if settings.get("optimizer", "SGD") == "Adam" else 0.937,
        "lr0": float(settings["lr0"]),
        "patience": int(settings["patience"]),
        "workers": int(settings["workers"]),
        "device": settings["device"],
        "seed": int(settings["seed"]),
        "project": str(run_directory.parent),
        "name": run_directory.name,
        "exist_ok": True,
        "save": True,
        "save_period": 10,
        "plots": True,
        "cache": False,
        "deterministic": True,
        "verbose": True,
    }


def configure_selected_optimizer(trainer, selected):
    """Apply the selected SGD variant before the first optimizer step."""
    if selected == "Adam":
        return
    if selected not in {"SGD", "NesterovSGD"}:
        raise TrainingWorkerError(f"지원하지 않는 옵티마이저: {selected}")
    optimizer = trainer.optimizer
    if type(optimizer).__name__ != "SGD":
        raise TrainingWorkerError("SGD 옵티마이저가 생성되지 않았습니다.")
    nesterov = selected == "NesterovSGD"
    optimizer.defaults["nesterov"] = nesterov
    for group in optimizer.param_groups:
        if nesterov and (group.get("momentum", 0) <= 0 or group.get("dampening", 0) != 0):
            raise TrainingWorkerError("Nesterov SGD 모멘텀 설정을 확인하세요.")
        group["nesterov"] = nesterov


def run_training(configuration: Mapping[str, Any]) -> Dict[str, Any]:
    """Load the task-specific local model and run one training job."""
    normalized = normalize_configuration(configuration)
    run_directory = Path(normalized["run_directory"])
    state_path = run_directory / STATE_FILENAME

    run_directory.mkdir(parents=True, exist_ok=True)

    state: Dict[str, Any] = {
        "schema_version": 1,
        "status": "starting",
        "task_type": normalized["task_type"],
        "model_path": normalized["model_path"],
        "data_yaml": normalized["data_yaml"],
        "run_directory": str(run_directory),
        "pid": os.getpid(),
        "started_at": _utc_now(),
        "updated_at": _utc_now(),
        "current_epoch": 0,
        "total_epochs": normalized["settings"]["epochs"],
        "progress_percent": 0.0,
        "history": [],
        "optimizer": normalized["settings"].get("optimizer", "SGD"),
        "best_pt": None,
        "last_pt": None,
        "error": None,
    }
    _atomic_json_write(state_path, state)

    try:
        from ultralytics import YOLO

        model = YOLO(normalized["model_path"])
        loaded_task = str(getattr(model, "task", "")).lower()

        if loaded_task != normalized["task_type"]:
            raise TrainingWorkerError(
                "가중치 작업 유형이 현재 프로젝트와 다릅니다: "
                f"expected={normalized['task_type']}, "
                f"loaded={loaded_task}"
            )

        history = []

        def on_fit_epoch_end(trainer) -> None:
            epoch = int(getattr(trainer, "epoch", 0)) + 1
            # final_eval(best.pt) may fire this event again for the same epoch.
            if history and epoch <= history[-1]["epoch"]:
                return
            total = int(
                getattr(
                    trainer,
                    "epochs",
                    normalized["settings"]["epochs"],
                )
            )

            metrics = {}
            trainer_metrics = getattr(trainer, "metrics", {}) or {}

            if isinstance(trainer_metrics, Mapping):
                for key, value in trainer_metrics.items():
                    converted = _number(value)
                    if converted is not None:
                        metrics[str(key)] = converted

            record = {
                "epoch": epoch,
                "metrics": metrics,
            }
            history.append(record)

            state.update(
                {
                    "status": "running",
                    "updated_at": _utc_now(),
                    "current_epoch": epoch,
                    "total_epochs": total,
                    "progress_percent": round(
                        100.0 * epoch / max(total, 1),
                        2,
                    ),
                    "history": list(history),
                }
            )
            _atomic_json_write(state_path, state)

        # HUMAN_EPOCH_CHECKPOINT_STAGE6_6E3
        # Ultralytics의 내부 epoch 번호는 0부터 시작한다.
        # 학생에게 표시되는 1부터 시작하는 epoch 번호를 사용해
        # epoch10.pt, epoch20.pt 형식으로 저장한다.
        def on_model_save(trainer) -> None:
            human_epoch = (
                int(getattr(trainer, "epoch", 0)) + 1
            )
            save_period = int(
                normalized["settings"].get(
                    "save_period",
                    10,
                )
            )

            if save_period <= 0:
                return

            if human_epoch % save_period != 0:
                return

            last_value = getattr(trainer, "last", None)

            if last_value is None:
                raise TrainingWorkerError(
                    "체크포인트 저장 시 last.pt 경로가 없습니다."
                )

            last_checkpoint = Path(last_value)
            periodic_checkpoint = (
                run_directory
                / "weights"
                / f"epoch{human_epoch}.pt"
            )

            if not last_checkpoint.is_file():
                raise TrainingWorkerError(
                    "주기 체크포인트 원본이 없습니다: "
                    f"{last_checkpoint}"
                )

            shutil.copy2(
                last_checkpoint,
                periodic_checkpoint,
            )

        model.add_callback(
            "on_fit_epoch_end",
            on_fit_epoch_end,
        )
        def on_train_start(trainer):
            selected = normalized["settings"].get("optimizer", "SGD")
            configure_selected_optimizer(trainer, selected)
            print(f"[my_supervised] optimizer={selected}", flush=True)

        model.add_callback("on_train_start", on_train_start)
        model.add_callback(
            "on_model_save",
            on_model_save,
        )

        state["status"] = "running"
        state["updated_at"] = _utc_now()
        _atomic_json_write(state_path, state)

        train_arguments = build_train_arguments(normalized)

        # 내장 save_period는 내부 0-based epoch를 사용해
        # 첫 epoch에서 epoch0.pt를 만드는 동작이 있으므로 끈다.
        # 위 on_model_save 콜백이 사람 기준 주기 저장을 담당한다.
        train_arguments["save_period"] = -1

        model.train(**train_arguments)

        best_pt = run_directory / "weights" / "best.pt"
        last_pt = run_directory / "weights" / "last.pt"

        if not best_pt.is_file():
            raise TrainingWorkerError(
                f"학습은 종료됐지만 best.pt가 없습니다: {best_pt}"
            )

        checkpoint_files = sorted(
            str(path)
            for path in (run_directory / "weights").glob(
                "epoch*.pt"
            )
        )

        state.update(
            {
                "status": "completed",
                "updated_at": _utc_now(),
                "completed_at": _utc_now(),
                "current_epoch": state["total_epochs"],
                "progress_percent": 100.0,
                "best_pt": str(best_pt),
                "last_pt": (
                    str(last_pt)
                    if last_pt.is_file()
                    else None
                ),
                "checkpoint_files": checkpoint_files,
                "error": None,
            }
        )
        _atomic_json_write(state_path, state)
        return state

    except KeyboardInterrupt:
        state.update(
            {
                "status": "cancelled",
                "updated_at": _utc_now(),
                "completed_at": _utc_now(),
                "error": "사용자 요청으로 학습이 중단되었습니다.",
            }
        )
        _atomic_json_write(state_path, state)
        raise

    except Exception as error:
        state.update(
            {
                "status": "failed",
                "updated_at": _utc_now(),
                "completed_at": _utc_now(),
                "error": str(error),
                "traceback": traceback.format_exc(),
            }
        )
        _atomic_json_write(state_path, state)
        raise


def load_configuration(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise TrainingWorkerError(
            f"학습 작업 설정 파일을 읽을 수 없습니다: {error}"
        ) from error

    if not isinstance(value, dict):
        raise TrainingWorkerError(
            "학습 작업 설정 파일 형식이 올바르지 않습니다."
        )
    return value


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run one my_supervised YOLO training job."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Absolute path to the training job JSON file.",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validate and print arguments without training.",
    )
    arguments = parser.parse_args()

    config_path = Path(arguments.config).expanduser()

    try:
        configuration = load_configuration(config_path)
        normalized = normalize_configuration(configuration)

        if arguments.validate_only:
            print(
                json.dumps(
                    {
                        "normalized": normalized,
                        "train_arguments": build_train_arguments(
                            normalized
                        ),
                    },
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0

        result = run_training(configuration)
        print(
            json.dumps(
                result,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    except Exception as error:
        print(
            f"TRAINING_WORKER_ERROR: {error}",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

# YOLO_UI_SETTINGS_PATCH_V2
