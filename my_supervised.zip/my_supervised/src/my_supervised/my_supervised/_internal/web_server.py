"""Serve the Firefox-first YOLO project-selection workflow."""

from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from functools import wraps
import json
import socket
from threading import RLock, Thread
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

import cv2
from my_supervised._internal.dataset_import import DatasetImportError, scan_external_dataset
from my_supervised._internal.dataset_builder import DatasetBuildError, DatasetBuilder
from my_supervised._internal.box_label_store import BoxLabelError, BoxLabelStore
from my_supervised._internal.polygon_label_store import PolygonLabelError, PolygonLabelStore
from my_supervised._internal.project_validator import ProjectValidationError, ProjectValidator
from my_supervised._internal.training_settings import TrainingSettingsError, TrainingSettingsStore
from my_supervised._internal.training_runner import TrainingRunner, TrainingRunnerError
from my_supervised._internal.image_deletion import delete_project_image

from my_supervised._internal.camera import CameraError
from my_supervised._internal.project_store import (
    ProjectInspection,
    ProjectStore,
    ProjectStoreError,
)

TASK_TYPES = {"detect", "segment"}


def _serialized_project(method):
    """Keep deletion, autosave, project changes and training setup atomic."""
    @wraps(method)
    def locked(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return locked


def _vehicle_identity():
    name = socket.gethostname()
    ip = 'unknown'
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(('10.255.255.255', 1))
        ip = probe.getsockname()[0]
    except OSError:
        try:
            ip = socket.gethostbyname(name)
        except OSError:
            pass
    finally:
        probe.close()
    return {'name': name, 'ip': ip}


class TrainingSession:
    """Keep only the active browser selection for one training server."""

    def __init__(self, app) -> None:
        self._app = app
        self._store = ProjectStore()
        self._box_labels = BoxLabelStore()
        self._polygon_labels = PolygonLabelStore()
        self._project_validator = ProjectValidator()
        self._dataset_builder = DatasetBuilder()
        self._training_runner = TrainingRunner()
        self._training_settings = TrainingSettingsStore()
        self._lock = RLock()
        self._inspection: Optional[ProjectInspection] = None
        self._task_type: Optional[str] = None

    @_serialized_project
    def reset(self) -> Dict[str, Any]:
        """Forget this browser session without deleting any project files."""
        with self._lock:
            self._inspection = None
            self._task_type = None
            self._app.clear_browser_selection()
        return self.status()

    def inspect(self, photo_directory: str, result_directory: str, task_type: str) -> Dict[str, Any]:
        """Validate a folder pair but do not create or select a project yet."""
        task = self._validate_task(task_type)
        inspection = self._store.inspect(photo_directory, result_directory)
        return self._inspection_dict(inspection, task, active=False)

    @_serialized_project
    def activate(self, photo_directory: str, result_directory: str, task_type: str, action: str) -> Dict[str, Any]:
        """Start new or resume only the exact inspected directory pair."""
        task = self._validate_task(task_type)
        if action == "new":
            inspection = self._store.create_new(photo_directory, result_directory)
            inspection = self._store.update(inspection.paths, {"task_type": task, "workflow_step": "capture_or_import"})
        elif action == "resume":
            inspection = self._store.resume(photo_directory, result_directory)
            saved_task = inspection.manifest.get("task_type")
            if saved_task and saved_task != task:
                raise ProjectStoreError("This folder pair belongs to a different YOLO task. Choose its saved task type before resuming.")
        else:
            raise ProjectStoreError("Project action must be new or resume.")
        with self._lock:
            self._inspection = inspection
            self._task_type = task
            self._app.select_photo_directory(str(inspection.paths.photo_directory))
        return self.status()


    # CLASS_MANAGEMENT_STAGE6_1
    @_serialized_project
    def set_classes(self, classes: Any) -> Dict[str, Any]:
        """Validate and immediately save project class names."""
        if not isinstance(classes, list):
            raise ProjectStoreError(
                "클래스 목록 형식이 올바르지 않습니다."
            )

        if len(classes) > 100:
            raise ProjectStoreError(
                "클래스는 최대 100개까지 등록할 수 있습니다."
            )

        cleaned = []
        seen = set()

        for raw_name in classes:
            if not isinstance(raw_name, str):
                raise ProjectStoreError(
                    "클래스 이름은 문자열이어야 합니다."
                )

            name = raw_name.strip()

            if not name:
                raise ProjectStoreError(
                    "빈 클래스 이름은 등록할 수 없습니다."
                )
            if len(name) > 64:
                raise ProjectStoreError(
                    "클래스 이름은 64자 이하여야 합니다."
                )
            if any(
                character in name
                for character in ("\n", "\r", "/", "\\")
            ):
                raise ProjectStoreError(
                    "클래스 이름에 줄바꿈이나 경로 구분자를 사용할 수 없습니다."
                )

            identity = name.casefold()
            if identity in seen:
                raise ProjectStoreError(
                    f"중복된 클래스 이름입니다: {name}"
                )

            seen.add(identity)
            cleaned.append(name)

        with self._lock:
            inspection = self._inspection

        if inspection is None:
            raise ProjectStoreError(
                "먼저 사진 폴더와 결과 폴더를 선택하고 프로젝트를 시작하세요."
            )

        image_suffixes = {
            ".jpg", ".jpeg", ".png", ".bmp",
            ".webp", ".tif", ".tiff",
        }
        has_image = any(
            item.is_file()
            and item.suffix.lower() in image_suffixes
            for item in inspection.paths.photo_directory.rglob('*')
        )

        if not has_image:
            raise ProjectStoreError(
                "사진 폴더에 이미지가 없습니다. "
                "사진을 촬영하거나 외부 이미지를 추가하세요."
            )

        workflow_step = (
            "classes_ready"
            if cleaned
            else "capture_or_import"
        )

        updated = self._store.update(
            inspection.paths,
            {
                "classes": cleaned,
                "workflow_step": workflow_step,
                "validation": None,
            },
        )

        with self._lock:
            self._inspection = updated

        return self.status()


    # EXTERNAL_DATASET_STAGE6_2
    @_serialized_project
    def scan_external_dataset(self) -> Dict[str, Any]:
        """Inspect and register the selected external YOLO dataset."""
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None or task_type is None:
            raise ProjectStoreError(
                "먼저 사진 폴더와 결과 폴더를 선택하고 프로젝트를 시작하세요."
            )

        classes = inspection.manifest.get("classes", [])
        summary = scan_external_dataset(
            inspection.paths.photo_directory,
            task_type,
            classes,
        )

        updated = self._store.update(
            inspection.paths,
            {
                "external_dataset": summary,
                "validation": None,
            },
        )

        with self._lock:
            self._inspection = updated

        return {
            "ok": True,
            "dataset": summary,
            "project": self.status()["project"],
        }




    # PROJECT_VALIDATION_STAGE6_5A
    @_serialized_project
    def validate_active_project(self) -> Dict[str, Any]:
        """Validate all images and labels in the active project."""
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None or task_type is None:
            raise ProjectStoreError(
                "먼저 프로젝트를 시작하세요."
            )

        classes = inspection.manifest.get("classes", [])
        annotation_root = self._box_labels.annotation_root(
            inspection.paths
        )

        summary = self._project_validator.validate(
            inspection.paths.photo_directory,
            annotation_root,
            task_type,
            classes,
        )

        workflow_step = (
            "validated"
            if summary["ready_for_training"]
            else "labeling"
        )

        updated = self._store.update(
            inspection.paths,
            {
                "validation": summary,
                "workflow_step": workflow_step,
            },
        )

        with self._lock:
            self._inspection = updated

        return {
            "ok": True,
            "validation": summary,
            "project": self.status()["project"],
        }

    # POLYGON_LABEL_BACKEND_STAGE6_4A
    def _segmentation_context(self):
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "먼저 프로젝트를 시작하세요."
            )
        if task_type != "segment":
            raise PolygonLabelError(
                "다각형 라벨링은 세그멘테이션 프로젝트에서만 사용할 수 있습니다."
            )

        classes = inspection.manifest.get("classes", [])
        if not classes:
            raise PolygonLabelError(
                "다각형 라벨링 전에 클래스를 한 개 이상 등록하세요."
            )

        annotation_root = self._box_labels.annotation_root(
            inspection.paths
        )
        return inspection, classes, annotation_root

    def list_polygon_images(self) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._segmentation_context()
        )
        result = self._polygon_labels.list_images(
            inspection.paths.photo_directory,
            annotation_root,
        )
        result["classes"] = classes
        result["project_key"] = inspection.paths.project_key
        return {"ok": True, **result}

    def load_polygon_labels(
        self,
        image_path: str,
    ) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._segmentation_context()
        )
        result = self._polygon_labels.load(
            inspection.paths.photo_directory,
            annotation_root,
            image_path,
            len(classes),
        )
        result["classes"] = classes
        return {"ok": True, **result}

    @_serialized_project
    def save_polygon_labels(
        self,
        image_path: str,
        polygons: Any,
    ) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._segmentation_context()
        )
        result = self._polygon_labels.save(
            inspection.paths.photo_directory,
            annotation_root,
            image_path,
            polygons,
            len(classes),
        )

        updated = self._store.update(
            inspection.paths,
            {
                "workflow_step": "labeling",
                "validation": None,
            },
        )
        with self._lock:
            self._inspection = updated

        result["classes"] = classes
        return result

    def polygon_image_jpeg(
        self,
        image_path: str,
    ) -> bytes:
        inspection, _, _ = self._segmentation_context()
        return self._polygon_labels.image_jpeg(
            inspection.paths.photo_directory,
            image_path,
        )

    # BOX_LABEL_BACKEND_STAGE6_3A
    def _detection_context(self):
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "먼저 프로젝트를 시작하세요."
            )
        if task_type != "detect":
            raise BoxLabelError(
                "박스 라벨링은 일반 YOLO 탐지 프로젝트에서만 사용할 수 있습니다."
            )

        classes = inspection.manifest.get("classes", [])
        if not classes:
            raise BoxLabelError(
                "박스 라벨링 전에 클래스를 한 개 이상 등록하세요."
            )

        annotation_root = self._box_labels.annotation_root(
            inspection.paths
        )
        return inspection, classes, annotation_root

    def list_box_images(self) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._detection_context()
        )
        result = self._box_labels.list_images(
            inspection.paths.photo_directory,
            annotation_root,
        )
        result["classes"] = classes
        result["project_key"] = inspection.paths.project_key
        return {"ok": True, **result}

    def load_box_labels(
        self,
        image_path: str,
    ) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._detection_context()
        )
        result = self._box_labels.load(
            inspection.paths.photo_directory,
            annotation_root,
            image_path,
            len(classes),
        )
        result["classes"] = classes
        return {"ok": True, **result}

    @_serialized_project
    def save_box_labels(
        self,
        image_path: str,
        boxes: Any,
    ) -> Dict[str, Any]:
        inspection, classes, annotation_root = (
            self._detection_context()
        )
        result = self._box_labels.save(
            inspection.paths.photo_directory,
            annotation_root,
            image_path,
            boxes,
            len(classes),
        )

        updated = self._store.update(
            inspection.paths,
            {
                "workflow_step": "labeling",
                "validation": None,
            },
        )
        with self._lock:
            self._inspection = updated

        result["classes"] = classes
        return result

    def box_image_jpeg(
        self,
        image_path: str,
    ) -> bytes:
        inspection, _, _ = self._detection_context()
        return self._box_labels.image_jpeg(
            inspection.paths.photo_directory,
            image_path,
        )

    @_serialized_project
    def delete_labeling_image(self, image_path, project_key, confirmed, task_type):
        """Delete a confirmed image from this exact active project only."""
        # Do not call the normal label context here: it creates annotation
        # directories, whereas deletion must only inspect existing targets.
        inspection = self._inspection
        if inspection is None:
            raise ProjectStoreError("먼저 프로젝트를 시작하세요.")
        if task_type not in TASK_TYPES or self._task_type != task_type:
            raise BoxLabelError("현재 프로젝트와 삭제 요청의 YOLO 작업 유형이 다릅니다.")
        classes = inspection.manifest.get("classes", [])
        if confirmed is not True:
            raise BoxLabelError("이미지 영구 삭제 확인이 필요합니다.")
        if project_key != inspection.paths.project_key:
            raise BoxLabelError("프로젝트가 변경되었습니다. 이미지 목록을 새로고침하세요.")
        state = self.get_training_process_status()
        if state.get("process_alive") or state.get("status") in {"queued", "starting", "running"}:
            raise BoxLabelError("학습 중에는 이미지를 삭제할 수 없습니다. 학습을 중단한 뒤 다시 시도하세요.")

        # Persist invalidation before removal so an interrupted request cannot
        # leave stale validation authorizing a new training job.
        def invalidate_dataset():
            self._inspection = self._store.update(inspection.paths, {
                "validation": None,
                "dataset": None,
                "external_dataset": None,
                "workflow_step": "labeling",
            })

        result = delete_project_image(
            inspection.paths.photo_directory,
            inspection.paths.annotations_directory,
            image_path,
            task_type,
            before_delete=invalidate_dataset,
        )
        labels = self._box_labels if task_type == "detect" else self._polygon_labels
        images = labels.list_images(
            inspection.paths.photo_directory, inspection.paths.annotations_directory,
        )
        return {
            "ok": True, **result, **images, "classes": classes,
            "project_key": inspection.paths.project_key,
            "preserved": "외부 라벨·기존 학습 데이터 복사본·학습 결과는 보존됩니다.",
        }

    @_serialized_project
    def capture(self) -> Dict[str, Any]:
        """Save exactly one original-size RGB image into the active folder."""
        with self._lock:
            if self._inspection is None:
                raise ProjectStoreError("Select and start a project before taking a picture.")
        saved_path = self._app.capture_selected_frame()

        with self._lock:
            inspection = self._inspection

        if inspection is not None:
            updated = self._store.update(
                inspection.paths,
                {
                    "workflow_step": "capture_or_import",
                    "validation": None,
                },
            )
            with self._lock:
                self._inspection = updated

        return {"ok": True, "saved_path": str(saved_path)}

    # TRAINING_PROCESS_API_STAGE6_6D3
    @_serialized_project
    def start_yolo_training(self) -> Dict[str, Any]:
        """Rebuild the dataset and start one asynchronous YOLO job."""
        # 항상 최신 레이블과 최신 설정으로 데이터셋을 다시 만든다.
        dataset_response = self.build_training_dataset()
        dataset = dataset_response["dataset"]

        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "활성 프로젝트를 찾을 수 없습니다."
            )

        task_type = (
            task_type
            or inspection.manifest.get("task_type")
        )

        loaded_settings = self._training_settings.load(
            str(inspection.paths.project_directory),
            task_type,
        )
        if not loaded_settings.get("saved"):
            raise TrainingRunnerError(
                "저장된 학습 설정을 찾을 수 없습니다."
            )

        job = self._training_runner.start(
            task_type=task_type,
            data_yaml=dataset["data_yaml"],
            result_directory=str(
                inspection.paths.result_directory
            ),
            settings=loaded_settings["settings"],
        )

        training_record = {
            "status": job["status"],
            "pid": job["pid"],
            "run_directory": job["run_directory"],
            "config_path": job["config_path"],
            "state_path": job["state_path"],
            "log_path": job["log_path"],
        }

        updated = self._store.update(
            inspection.paths,
            {
                "training": training_record,
                "workflow_step": "training",
            },
        )

        with self._lock:
            self._inspection = updated

        return {
            "ok": True,
            "training": job,
            "dataset": dataset,
            "project": self.status()["project"],
        }

    @_serialized_project
    def get_training_process_status(self) -> Dict[str, Any]:
        """Read the persistent worker state for the active project."""
        with self._lock:
            inspection = self._inspection

        if inspection is None:
            raise ProjectStoreError(
                "먼저 프로젝트를 시작하세요."
            )

        training = inspection.manifest.get("training")
        if not isinstance(training, dict):
            return {
                "ok": True,
                "status": "idle",
                "run_directory": None,
                "process_alive": False,
                "history": [],
            }

        run_directory = training.get("run_directory")
        if not run_directory:
            raise TrainingRunnerError(
                "학습 결과 폴더 기록이 올바르지 않습니다."
            )

        state = self._training_runner.status(
            str(run_directory)
        )

        previous_status = training.get("status")
        current_status = state.get("status")

        if current_status != previous_status:
            training_record = dict(training)
            training_record.update(
                {
                    "status": current_status,
                    "pid": state.get("pid"),
                    "best_pt": state.get("best_pt"),
                    "last_pt": state.get("last_pt"),
                    "error": state.get("error"),
                }
            )

            if current_status == "completed":
                workflow_step = "training_complete"
            elif current_status in {
                "failed",
                "cancelled",
                "interrupted",
            }:
                workflow_step = "training_stopped"
            else:
                workflow_step = "training"

            updated = self._store.update(
                inspection.paths,
                {
                    "training": training_record,
                    "workflow_step": workflow_step,
                },
            )

            with self._lock:
                self._inspection = updated

        return state

    @_serialized_project
    def cancel_yolo_training(self) -> Dict[str, Any]:
        """Cancel only the verified worker for the active project."""
        with self._lock:
            inspection = self._inspection

        if inspection is None:
            raise ProjectStoreError(
                "먼저 프로젝트를 시작하세요."
            )

        training = inspection.manifest.get("training")
        if not isinstance(training, dict):
            raise TrainingRunnerError(
                "현재 프로젝트에 시작된 학습이 없습니다."
            )

        run_directory = training.get("run_directory")
        if not run_directory:
            raise TrainingRunnerError(
                "학습 결과 폴더 기록이 올바르지 않습니다."
            )

        state = self._training_runner.cancel(
            str(run_directory)
        )

        training_record = dict(training)
        training_record.update(
            {
                "status": state.get("status"),
                "error": state.get("error"),
            }
        )

        updated = self._store.update(
            inspection.paths,
            {
                "training": training_record,
                "workflow_step": "training_stopped",
            },
        )

        with self._lock:
            self._inspection = updated

        return state

    # DATASET_BUILD_API_STAGE6_6C2
    @_serialized_project
    def build_training_dataset(self) -> Dict[str, Any]:
        """Build a derived dataset only after validation and settings."""
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "먼저 사진 폴더와 결과 폴더를 선택하고 "
                "프로젝트를 시작하세요."
            )

        task_type = (
            task_type
            or inspection.manifest.get("task_type")
        )
        if not task_type:
            raise ProjectStoreError(
                "활성 프로젝트의 YOLO 작업 유형을 확인할 수 없습니다."
            )

        classes = inspection.manifest.get("classes", [])
        validation = inspection.manifest.get("validation")

        if (
            not isinstance(validation, dict)
            or not validation.get("ready_for_training")
        ):
            raise DatasetBuildError(
                "먼저 현재 프로젝트 전체 검사를 통과해야 합니다."
            )

        loaded_settings = self._training_settings.load(
            str(inspection.paths.project_directory),
            task_type,
        )

        if not loaded_settings.get("saved"):
            raise DatasetBuildError(
                "먼저 YOLO 학습 설정을 저장해야 합니다."
            )

        settings = loaded_settings["settings"]
        annotation_root = self._box_labels.annotation_root(
            inspection.paths
        )

        result = self._dataset_builder.build(
            photo_directory=str(
                inspection.paths.photo_directory
            ),
            annotation_directory=str(annotation_root),
            dataset_directory=str(
                inspection.paths.dataset_directory
            ),
            task_type=task_type,
            classes=classes,
            train_ratio=settings["train_ratio"],
            seed=settings["seed"],
        )

        updated = self._store.update(
            inspection.paths,
            {
                "dataset": result,
                "workflow_step": "dataset_ready",
            },
        )

        with self._lock:
            self._inspection = updated

        return {
            "ok": True,
            "dataset": result,
            "project": self.status()["project"],
        }

    # TRAINING_SETTINGS_API_STAGE6_6A2
    def get_training_settings(self) -> Dict[str, Any]:
        """Return saved settings or task-specific defaults."""
        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "먼저 사진 폴더와 결과 폴더를 선택하고 "
                "프로젝트를 시작하세요."
            )

        task_type = (
            task_type
            or inspection.manifest.get("task_type")
        )
        if not task_type:
            raise ProjectStoreError(
                "활성 프로젝트의 YOLO 작업 유형을 확인할 수 없습니다."
            )

        result = self._training_settings.load(
            str(inspection.paths.project_directory),
            task_type,
        )

        # 저장된 값과 별개로 현재 저장 장치의 용량을 다시 확인한다.
        result["storage"] = self._training_settings.inspect_storage(
            str(inspection.paths.result_directory)
        )
        result["ok"] = True
        return result

    @_serialized_project
    def save_training_settings(
        self,
        settings: Any,
    ) -> Dict[str, Any]:
        """Validate and save settings for the exact active folder pair."""
        if not isinstance(settings, dict):
            raise TrainingSettingsError(
                "학습 설정은 JSON 객체 형식이어야 합니다."
            )

        with self._lock:
            inspection = self._inspection
            task_type = self._task_type

        if inspection is None:
            raise ProjectStoreError(
                "먼저 사진 폴더와 결과 폴더를 선택하고 "
                "프로젝트를 시작하세요."
            )

        task_type = (
            task_type
            or inspection.manifest.get("task_type")
        )
        if not task_type:
            raise ProjectStoreError(
                "활성 프로젝트의 YOLO 작업 유형을 확인할 수 없습니다."
            )

        result = self._training_settings.save(
            project_directory=str(
                inspection.paths.project_directory
            ),
            result_directory=str(
                inspection.paths.result_directory
            ),
            task_type=task_type,
            values=settings,
        )

        updated = self._store.update(
            inspection.paths,
            {
                "workflow_step": "training_settings",
                "training_settings_path": result["settings_path"],
            },
        )

        with self._lock:
            self._inspection = updated

        result["ok"] = True
        return result

    def status(self) -> Dict[str, Any]:
        """Return only the current selection; no default folder exists."""
        frame = self._app.frames.status()
        with self._lock:
            inspection = self._inspection
            task = self._task_type
        project = None if inspection is None else self._inspection_dict(inspection, task, active=True)
        return {"ok": True, "project": project, "camera": {"available": frame.available, "width": frame.width, "height": frame.height, "age_seconds": frame.age_seconds}, "vehicle": _vehicle_identity()}

    def frame_jpeg(self) -> bytes:
        """Encode the latest display frame without saving it to disk."""
        frame = self._app.frames.latest()
        if frame is None:
            raise CameraError("No RGB image has been received yet.")
        encoded_ok, encoded = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
        if not encoded_ok:
            raise CameraError("OpenCV could not encode the preview image.")
        return encoded.tobytes()

    @staticmethod
    def _validate_task(value: str) -> str:
        task = str(value or "").strip().lower()
        if task not in TASK_TYPES:
            raise ProjectStoreError("YOLO task must be detect or segment.")
        return task

    @staticmethod
    def _inspection_dict(inspection: ProjectInspection, task_type: Optional[str], active: bool) -> Dict[str, Any]:
        manifest = inspection.manifest or {}
        return {"active": active, "resume_available": inspection.resume_available, "task_type": task_type or manifest.get("task_type"), "workflow_step": manifest.get("workflow_step"), "classes": manifest.get("classes", []), "external_dataset": manifest.get("external_dataset"), "validation": manifest.get("validation"), "paths": inspection.paths.as_dict()}


class TrainingWebServer:
    """Run a dependency-free browser UI alongside the ROS training node."""

    def __init__(self, app, port: int) -> None:
        self.session = TrainingSession(app)
        self._server = self._make_server(int(port))
        self._thread = Thread(target=self._server.serve_forever, daemon=True)

    @property
    def port(self) -> int:
        return int(self._server.server_port)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=2.0)

    def _make_server(self, port: int) -> ThreadingHTTPServer:
        session = self.session

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                path = parsed.path
                if path == "/":
                    self._send_bytes(HTTPStatus.OK, "text/html; charset=utf-8", HTML)
                elif path == "/stream.mjpg":
                    from my_supervised._internal.live_video import send_mjpeg
                    send_mjpeg(self, session._app.preview)
                elif path == "/api/segments/image":
                    try:
                        query = parse_qs(parsed.query)
                        image_path = query.get("path", [""])[0]
                        data = session.polygon_image_jpeg(image_path)
                        self._send_bytes(
                            HTTPStatus.OK,
                            "image/jpeg",
                            data,
                        )
                    except (
                        PolygonLabelError,
                        ProjectStoreError,
                    ) as error:
                        self._send_json(
                            HTTPStatus.BAD_REQUEST,
                            {"error": str(error)},
                        )
                elif path == "/api/labels/image":
                    try:
                        query = parse_qs(parsed.query)
                        image_path = query.get("path", [""])[0]
                        data = session.box_image_jpeg(image_path)
                        self._send_bytes(
                            HTTPStatus.OK,
                            "image/jpeg",
                            data,
                        )
                    except (
                        BoxLabelError,
                        ProjectStoreError,
                    ) as error:
                        self._send_json(
                            HTTPStatus.BAD_REQUEST,
                            {"error": str(error)},
                        )
                elif path == "/api/training/status":
                    try:
                        self._send_json(
                            HTTPStatus.OK,
                            session.get_training_process_status(),
                        )
                    except (
                        ProjectStoreError,
                        TrainingRunnerError,
                    ) as error:
                        self._send_json(
                            HTTPStatus.BAD_REQUEST,
                            {"error": str(error)},
                        )
                elif path == "/api/training/settings":
                    try:
                        self._send_json(
                            HTTPStatus.OK,
                            session.get_training_settings(),
                        )
                    except (
                        ProjectStoreError,
                        TrainingSettingsError,
                    ) as error:
                        self._send_json(
                            HTTPStatus.BAD_REQUEST,
                            {"error": str(error)},
                        )
                elif path == "/api/status":
                    self._send_json(HTTPStatus.OK, session.status())
                elif path == "/api/frame.jpg":
                    try:
                        self._send_bytes(HTTPStatus.OK, "image/jpeg", session.frame_jpeg())
                    except CameraError as error:
                        self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(error)})
                else:
                    self._send_json(HTTPStatus.NOT_FOUND, {"error": "Not found."})

            def do_POST(self):
                parsed = urlparse(self.path)
                path = parsed.path
                try:
                    if path in {"/api/labels/delete-image", "/api/segments/delete-image"}:
                        if self.headers.get_content_type() != "application/json":
                            raise ValueError("이미지 삭제는 JSON 요청으로만 가능합니다.")
                        origin = self.headers.get("Origin")
                        if origin:
                            parsed_origin = urlparse(origin)
                            if parsed_origin.scheme not in {"http", "https"} or parsed_origin.netloc != self.headers.get("Host"):
                                raise ValueError("다른 웹사이트에서 보낸 이미지 삭제 요청은 허용하지 않습니다.")
                    payload = self._read_json()
                    if path == "/api/reset":
                        response = session.reset()
                    elif path == "/api/project/inspect":
                        response = session.inspect(payload.get("photo_directory"), payload.get("result_directory"), payload.get("task_type"))
                    elif path == "/api/project/activate":
                        response = session.activate(payload.get("photo_directory"), payload.get("result_directory"), payload.get("task_type"), payload.get("action"))
                    elif path == "/api/training/start":
                        response = session.start_yolo_training()
                    elif path == "/api/training/cancel":
                        response = session.cancel_yolo_training()
                    elif path == "/api/dataset/build":
                        response = session.build_training_dataset()
                    elif path == "/api/training/settings":
                        response = session.save_training_settings(
                            payload.get("settings")
                        )
                    elif path == "/api/project/validate":
                        response = session.validate_active_project()
                    elif path == "/api/segments/images":
                        response = session.list_polygon_images()
                    elif path == "/api/segments/load":
                        response = session.load_polygon_labels(
                            payload.get("image_path")
                        )
                    elif path == "/api/segments/save":
                        response = session.save_polygon_labels(
                            payload.get("image_path"),
                            payload.get("polygons"),
                        )
                    elif path == "/api/segments/delete-image":
                        response = session.delete_labeling_image(
                            payload.get("image_path"), payload.get("project_key"),
                            payload.get("confirmed"), "segment",
                        )
                    elif path == "/api/labels/images":
                        response = session.list_box_images()
                    elif path == "/api/labels/load":
                        response = session.load_box_labels(
                            payload.get("image_path")
                        )
                    elif path == "/api/labels/save":
                        response = session.save_box_labels(
                            payload.get("image_path"),
                            payload.get("boxes"),
                        )
                    elif path == "/api/labels/delete-image":
                        response = session.delete_labeling_image(
                            payload.get("image_path"), payload.get("project_key"),
                            payload.get("confirmed"), "detect",
                        )
                    elif path == "/api/dataset/scan":
                        response = session.scan_external_dataset()
                    elif path == "/api/classes":
                        response = session.set_classes(
                            payload.get("classes")
                        )
                    elif path == "/api/capture":
                        response = session.capture()
                    else:
                        self._send_json(HTTPStatus.NOT_FOUND, {"error": "Not found."})
                        return
                except (BoxLabelError, CameraError, DatasetBuildError, DatasetImportError, PolygonLabelError, ProjectStoreError, ProjectValidationError, TrainingRunnerError, TrainingSettingsError, ValueError) as error:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
                    return
                self._send_json(HTTPStatus.OK, response)

            def _read_json(self) -> Dict[str, Any]:
                length = int(self.headers.get("Content-Length", "0"))
                if length > 16384:
                    raise ValueError("Request body is too large.")
                raw = self.rfile.read(length) if length else b"{}"
                try:
                    data = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as error:
                    raise ValueError("Request body must be JSON.") from error
                if not isinstance(data, dict):
                    raise ValueError("Request JSON must be an object.")
                return data

            def _send_json(self, status: HTTPStatus, data: Dict[str, Any]) -> None:
                self._send_bytes(status, "application/json; charset=utf-8", json.dumps(data, ensure_ascii=False).encode("utf-8"))

            def _send_bytes(self, status: HTTPStatus, content_type: str, data) -> None:
                if isinstance(data, str):
                    data = data.encode("utf-8")
                self.send_response(int(status))
                self.send_header("Content-Type", content_type)
                self.send_header(
                    "Cache-Control",
                    "no-store, no-cache, must-revalidate, max-age=0",
                )
                self.send_header("Pragma", "no-cache")
                self.send_header("Expires", "0")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, format, *args):
                return

        return ThreadingHTTPServer(("0.0.0.0", port), Handler)


HTML = """<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>YOLO 학습 준비</title><style>
body{margin:0;background:#071421;color:#e8f1fb;font-family:system-ui,sans-serif}main{max-width:1040px;margin:auto;padding:28px}h1{margin:.2em 0;color:#5eead4}.sub{color:#9fb3c8}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card{background:#0e2237;border:1px solid #244460;border-radius:14px;padding:18px}label{display:block;font-weight:700;margin-top:12px}input,select{box-sizing:border-box;width:100%;margin-top:6px;padding:10px;border:1px solid #45627c;border-radius:8px;background:#06111c;color:#fff}button{padding:10px 14px;border:0;border-radius:8px;background:#14b8a6;color:#001d1b;font-weight:800;cursor:pointer;margin:12px 6px 0 0}button:disabled{opacity:.45;cursor:not-allowed}.warn{color:#fbbf24}.ok{color:#5eead4}.error{color:#fb7185}img{width:100%;background:#020617;min-height:240px;object-fit:contain;border-radius:10px}.small{font-size:.9rem;color:#a9bed1;white-space:pre-wrap}
.class-manager{margin-top:18px}
.class-input-row{display:flex;gap:8px;align-items:flex-end}
.class-input-row label{flex:1}
.class-list{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.class-chip{display:inline-flex;align-items:center;gap:8px;
padding:7px 10px;border:1px solid #2dd4bf;border-radius:999px;
background:#092c35;color:#ccfbf1}
.class-chip button{margin:0;padding:1px 7px;border-radius:999px;
background:#fb7185;color:#24040a}

/* BOX_LABEL_UI_STAGE6_3B */
.box-labeler{margin-top:18px}
.box-labeler[hidden]{display:none}
.box-toolbar{display:grid;grid-template-columns:2fr 1fr;gap:10px}
.box-buttons{display:flex;flex-wrap:wrap;gap:8px}
.box-buttons button{margin:8px 0 0}
.box-canvas-wrap{margin-top:14px;overflow:auto;background:#020617;
border:1px solid #36536d;border-radius:10px;text-align:center}
#box-canvas{display:block;max-width:100%;height:auto;margin:auto;
cursor:crosshair;touch-action:none}
@media(max-width:760px){
.box-toolbar{grid-template-columns:1fr}
}

/* POLYGON_LABEL_UI_STAGE6_4B */
.segment-labeler{margin-top:18px}
.segment-labeler[hidden]{display:none}
.segment-toolbar{display:grid;grid-template-columns:2fr 1fr;gap:10px}
.segment-buttons{display:flex;flex-wrap:wrap;gap:8px}
.segment-buttons button{margin:8px 0 0}
.segment-canvas-wrap{margin-top:14px;overflow:auto;background:#020617;
border:1px solid #36536d;border-radius:10px;text-align:center}
#segment-canvas{display:block;max-width:100%;height:auto;margin:auto;
cursor:crosshair;touch-action:none}
@media(max-width:760px){
.segment-toolbar{grid-template-columns:1fr}
}

/* PROJECT_VALIDATION_UI_STAGE6_5B */
.project-validator{margin-top:18px}
.validation-summary{margin-top:12px;padding:12px;border-radius:10px;
background:#06111c;border:1px solid #36536d;white-space:pre-wrap}
.validation-ready{border-color:#34d399;color:#a7f3d0}
.validation-blocked{border-color:#fbbf24;color:#fde68a}

/* TRAINING_SETTINGS_UI_STAGE6_6B */
.training-settings{margin-top:18px}
.training-settings[hidden]{display:none}
.training-settings-grid{
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:14px;
  margin-top:14px
}
.training-settings-grid label{
  display:flex;
  flex-direction:column;
  gap:7px;
  color:#cbd5e1;
  font-size:14px
}
.training-settings-grid input,
.training-settings-grid select{
  width:100%;
  box-sizing:border-box
}
.training-model-box,
.training-storage-box{
  margin-top:12px;
  padding:12px;
  border:1px solid #334155;
  border-radius:10px;
  background:#07111f;
  color:#cbd5e1;
  overflow-wrap:anywhere
}
.training-storage-box.warning{
  border-color:#f59e0b;
  color:#fbbf24
}
.training-actions{
  display:flex;
  gap:10px;
  align-items:center;
  margin-top:14px;
  flex-wrap:wrap
}
.training-actions button{min-width:180px}
@media(max-width:760px){
  .training-settings-grid{grid-template-columns:1fr}
}


/* TRAINING_PROGRESS_UI_STAGE6_6E1 */
.training-process{margin-top:18px}
.training-process[hidden]{display:none}
.training-process-grid{
  display:grid;
  grid-template-columns:minmax(220px,1fr) minmax(220px,1fr);
  gap:14px;
  margin-top:14px
}
.training-status-box{
  padding:14px;
  border:1px solid #334155;
  border-radius:10px;
  background:#07111f
}
.training-progress-track{
  width:100%;
  height:18px;
  margin-top:10px;
  overflow:hidden;
  border-radius:999px;
  background:#1e293b
}
.training-progress-bar{
  width:0%;
  height:100%;
  border-radius:999px;
  background:linear-gradient(90deg,#22d3ee,#2563eb);
  transition:width .25s ease
}
.training-graph-wrap{
  margin-top:14px;
  padding:12px;
  border:1px solid #334155;
  border-radius:10px;
  background:#020617;
  overflow:auto
}
#training-progress-canvas{
  display:block;
  width:100%;
  min-width:620px;
  height:280px
}
.training-process-actions{
  display:flex;
  gap:10px;
  margin-top:14px;
  flex-wrap:wrap
}
.training-process-actions button{min-width:170px}
.training-path{
  margin-top:8px;
  overflow-wrap:anywhere
}
.training-complete-dialog{
  width:min(620px,calc(100vw - 40px));
  color:#e2e8f0;
  border:1px solid #334155;
  border-radius:14px;
  background:#0f172a
}
.training-complete-dialog::backdrop{
  background:rgba(2,6,23,.78)
}
@media(max-width:760px){
  .training-process-grid{grid-template-columns:1fr}
}


/* EDUCATION_LEADER_PALETTE_STAGE8 */
:root{color-scheme:light;--page:#f3f5f5;--panel:#e7edef;--surface:#ffffff;--ink:#171d21;--muted:#657179;--line:#c7d0d4;--primary:#33434c;--accent:#71304f;--teal:#267d78;--danger:#a44855}
body{background:var(--page);color:var(--ink)}
main{max-width:1160px;padding:32px 24px 56px}
h1,h2,h3{color:var(--ink)}
h1{margin:0;color:var(--ink)}
.sub,.small{color:var(--muted)}
.training-header{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-bottom:8px}
.vehicle-pill{flex:0 0 auto;background:var(--surface);color:var(--ink);border:1px solid var(--line);padding:10px 14px;font-weight:700;letter-spacing:.02em}
.grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:stretch}
.grid>.card{min-width:0;width:auto;overflow:hidden}
.card{background:var(--panel);border-color:var(--line);box-shadow:none;color:var(--ink)}
input,select{box-sizing:border-box;background:var(--surface);color:var(--ink);border-color:#9da9ae}
button{background:var(--primary);color:#fff;border-color:transparent}
button:hover:not(:disabled){filter:brightness(1.08)}
button:disabled{background:#aeb8bc;color:#edf0f1;opacity:1}
#new,#resume,#capture,#validate-project,#save-training-settings,#start-yolo-training{background:var(--accent)}
#inspect,#scan-dataset,#add-class,#build-dataset{background:var(--teal)}
.danger,.remove,.delete{background:var(--danger)!important}
#notice,.notice,.validation-summary{overflow-wrap:anywhere;word-break:break-word}
#preview{display:block;width:100%;height:360px;min-height:360px;object-fit:contain;background:#111;border:1px solid var(--line)}
.fixed-setting-value{box-sizing:border-box;width:100%;min-height:42px;padding:10px 12px;background:#dde3e5;border:1px solid #b9c3c7;color:#3c474d;font-weight:700}
.training-complete-dialog{background:var(--surface);color:var(--ink);border-color:var(--line)}
@media(max-width:760px){.grid{grid-template-columns:1fr}.training-header{flex-direction:column}.vehicle-pill{align-self:stretch}}

/* YOLO_UI_SETTINGS_PATCH_V2 */
#training-settings-panel .training-model-box,
#training-settings-panel .training-storage-box,
#training-process-panel .training-status-box{background:#fff;color:#171d21;border:1px solid #c7d0d4;border-radius:8px;padding:16px}
#training-settings-panel .small,#training-settings-panel .training-settings-grid label,
#training-process-panel .small{color:#657179}
#training-settings-panel .training-storage-box.warning{background:#fff9eb;color:#835a16;border-color:#d9b96a}
#training-process-status.ok{color:#267d78!important}
#training-process-status.error{color:#a44855!important}
#training-process-panel .training-progress-track{height:12px;background:#e7edef}
#training-process-panel .training-progress-bar{background:#71304f}
.yolo-metric-charts{display:grid;gap:16px;margin-top:18px}
.yolo-metric-card{background:#fff;border:1px solid #c7d0d4;border-radius:8px;padding:16px;min-width:0}
.yolo-metric-heading{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px 16px}
.yolo-metric-heading h3{margin:0;font-size:17px;color:#171d21}
.yolo-metric-legends{display:flex;justify-content:flex-end;flex-wrap:wrap;gap:8px 20px;margin:12px 0}
.yolo-metric-legend{display:inline-flex;align-items:center;gap:8px;font-size:13px;color:#59656c}
.yolo-metric-legend i{display:inline-block;width:26px;height:3px;flex-shrink:0}
.yolo-metric-card>p.small{margin:8px 0 12px;font-size:13px}
#training-process-panel .yolo-metric-card canvas{display:block;width:100%;min-width:0;height:auto;aspect-ratio:900/300;background:#fff}
.optimizer-help{font-weight:400;font-size:12px;line-height:1.5}
@media(max-width:700px){.training-process-grid{grid-template-columns:minmax(0,1fr)}.yolo-metric-card{padding:10px}.yolo-metric-heading h3{font-size:15px}}

</style></head>
<body><main><header class="training-header"><h1>YOLO 학습</h1><div id="vehicle-info" class="vehicle-pill">차량 확인 중</div></header><p class="sub">화면을 새로고침하면 폴더 선택이 초기화됩니다.</p>
<div class="grid"><section class="card"><h2>1. 폴더 선택</h2><label>사진 저장 폴더<input id="photo" placeholder="예: /home/jetson/my_supervised/my_yolo_data/pictures"></label><label>학습 결과 저장 폴더<input id="result" placeholder="예: /home/jetson/my_supervised/my_yolo_data/results"></label><label>라벨링 방식 선택<select id="task"><option value="detect">박스 라벨링</option><option value="segment">다각형 라벨링</option></select></label><button id="inspect">폴더 경로 검사</button><button id="new" disabled>새 프로젝트 시작</button><button id="resume" disabled>이어서 작업</button><p id="notice" class="small">사진 저장 폴더와 결과 저장 폴더 경로를 모두 입력한 뒤 검사 버튼을 누르세요.</p></section>
<section class="card"><h2>이미지 촬영</h2><img id="preview" alt="이미지 대기 중"><button id="capture" disabled>사진 한 장 촬영</button><p id="camera" class="small">카메라 확인 중</p></section></div>

<section id="class-manager" class="card class-manager">
<h2>2. 클래스 등록</h2>
<p class="small">
인식할 객체의 종류만큼 클래스를 추가합니다.
</p>
<div class="class-input-row">
<label>
등록할 클래스
<input id="class-name" maxlength="64"
placeholder="클래스 이름을 지정하세요(예: standing, running)">
</label>
<button id="class-add" disabled>클래스 추가</button>
</div>
<div id="class-list" class="class-list"></div>
<p id="class-notice" class="small">
프로젝트 시작 후 이용할 수 있습니다.
</p>
</section>

<section id="dataset-importer" class="card class-manager">
<h2>3. 수집한 데이터 검사</h2>
<p class="small">
사진 저장 폴더에 저장된 이미지와 YOLO 레이블 결과를 검사합니다. 외부에서 수집한 데이터도 검사할 수 있습니다.
</p>
<button id="dataset-scan" disabled>
검사 진행
</button>
<pre id="dataset-summary" class="small">
프로젝트 시작 후 이용할 수 있습니다.
</pre>
</section>

<section id="box-labeler" class="card box-labeler" hidden>
<h2>4. 박스 라벨링</h2>
<p class="small">
(1) 드래그하여 박스를 생성합니다. (2) 생성된 박스는 꼭짓점을 클릭해 크기를 조정할 수 있습니다. (3) 생성된 박스를 클릭하여 삭제하거나 클래스를 변경할 수 있습니다.
</p>
<div class="box-toolbar">
<label>
이미지
<select id="box-image-select"></select>
</label>
<label>
클래스 선택
<select id="box-class-select"></select>
</label>
</div>
<div class="box-buttons">
<button id="box-refresh" type="button">이미지 목록 새로고침</button>
<button id="box-prev" type="button">이전</button>
<button id="box-next" type="button">다음</button>
<button id="box-delete" type="button">선택한 박스 삭제</button>
<button id="box-clear" type="button">현재 이미지 삭제</button>
</div>
<div class="box-canvas-wrap">
<canvas id="box-canvas" width="640" height="480" tabindex="0"></canvas>
</div>
<p id="box-status" class="small">
클래스를 등록하면 박스 라벨링을 시작할 수 있습니다.
</p>
</section>

<section id="segment-labeler" class="card segment-labeler" hidden>
<h2>5. 다각형 라벨링</h2>
<p class="small">
(1) 빈 곳을 클릭하여 다각형 좌표를 추가할 수 있습니다. (2) 생성된 다각형은 꼭짓점을 클릭해 크기를 조정할 수 있습니다. (3) 생성된 다각형을 클릭하여 삭제하거나 클래스를 변경할 수 있습니다.
</p>
<div class="segment-toolbar">
<label>
이미지
<select id="segment-image-select"></select>
</label>
<label>
클래스 선택
<select id="segment-class-select"></select>
</label>
</div>
<div class="segment-buttons">
<button id="segment-refresh" type="button">이미지 목록 새로고침</button>
<button id="segment-prev" type="button">이전</button>
<button id="segment-next" type="button">다음</button>
<button id="segment-finish" type="button">다각형 완성</button>
<button id="segment-undo-point" type="button">마지막 점 취소</button>
<button id="segment-cancel" type="button">작성 취소</button>
<button id="segment-delete" type="button">선택한 다각형 삭제</button>
<button id="segment-clear" type="button">현재 이미지 삭제</button>
</div>
<div class="segment-canvas-wrap">
<canvas id="segment-canvas"
width="640" height="480" tabindex="0"></canvas>
</div>
<p id="segment-status" class="small">
클래스를 등록하면 다각형 라벨링을 시작할 수 있습니다.
</p>
</section>

<section id="project-validator" class="card project-validator">
<h2>6. 학습 전 데이터 검사</h2>
<p class="small">
모든 이미지의 레이블 지정 여부, 좌표 형식, 클래스 번호 등 학습 최소 조건을 검사합니다.
</p>
<!-- VALIDATION_BUTTON_CACHE_FINAL_FIX -->
<button id="validate-project" type="button" onclick="(async()=>{const o=document.getElementById('validation-summary');o.textContent='전체 데이터를 검사 중입니다...';try{const r=await fetch('/api/project/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store'});const p=await r.json();if(!r.ok)throw Error(p.error||'검사 실패');const v=p.validation;o.textContent='검사 완료: '+(v.ready_for_training?'학습 준비 완료':'수정 필요')+'\n이미지: '+v.image_count+'개\n레이블 완료: '+v.labeled_image_count+'개\n미작성: '+v.unlabeled_image_count+'개\n형식 오류: '+v.invalid_label_count+'개\n전체 객체: '+v.object_count+'개\n클래스: '+v.class_count+'개';}catch(e){o.textContent='검사 실패: '+e.message}})()">
데이터 검사
</button>
<pre id="validation-summary" class="validation-summary small">
프로젝트를 시작한 후 검사할 수 있습니다.
</pre>
</section>

<section id="training-settings-panel"
         class="card training-settings"
         hidden>
  <h2>YOLO 학습 설정</h2>
  <p class="small">
    에폭 10회마다 체크포인트가 저장됩니다.
  </p>

  <div class="training-model-box">
    <strong>모델 자동 선택</strong>
    <div id="training-model-name" class="small">프로젝트 대기 중</div>
    <div id="training-model-path" class="small"></div>
  </div>

  <div class="training-settings-grid">
    <label>
      훈련 데이터 비율 (%)
      <input id="training-train-percent"
             type="number"
             min="50"
             max="95"
             step="1"
             value="80">
    </label>

    <label>
      검증 데이터 비율 (%)
      <input id="training-val-percent"
             type="number"
             value="20"
             readonly>
    </label>

    <label>
      학습 횟수 (epochs)
      <input id="training-epochs"
             type="number"
             min="1"
             max="500"
             step="1"
             value="100">
    </label>

    <label>
      입력 이미지 크기 (imgsz)
      <input id="training-imgsz" type="hidden" value="640"><div class="fixed-setting-value">640 px (고정)</div>
    </label>

    <label>
      배치 크기 (batch)
      <input id="training-batch"
             type="number"
             min="1"
             max="64"
             step="1"
             value="16">
    </label>

    <label>
      옵티마이저
      <select id="training-optimizer">
        <option value="SGD">SGD (Stochastic Gradient Descent) · 모멘텀 (기본)</option>
        <option value="Adam">Adam</option>
        <option value="NesterovSGD">Nesterov SGD · 가속 모멘텀</option>
      </select>
      <span class="small optimizer-help">SGD는 확률적 경사 하강법입니다. SGD 계열은 모멘텀 0.937을 사용합니다. Adam 선택 시 초기 학습률 0.001부터 비교할 수 있습니다. 학습률은 자동 변경되지 않습니다.</span>
    </label>

    <label>
      초기 학습률 (lr0)
      <input id="training-lr0"
             type="number"
             min="0.000001"
             max="0.1"
             step="0.000001"
             value="0.01">
    </label>

    <label>
      조기 종료 대기 (patience)
      <input id="training-patience" type="hidden" value="50"><div class="fixed-setting-value">50 epochs (고정)</div>
    </label>

    <label>
      데이터 처리 작업 수 (workers)
      <input id="training-workers" type="hidden" value="2"><div class="fixed-setting-value">2 (고정)</div>
    </label>

    <label>
      학습 장치 선택
      <select id="training-device">
        <option value="0">GPU · Jetson Orin</option>
        <option value="cpu">CPU</option>
      </select>
    </label>

    <label>
      데이터 분할 시드 (seed)
      <input id="training-seed" type="hidden" value="0"><div class="fixed-setting-value">0 (고정)</div>
    </label>
  </div>

  <div class="training-model-box">
    <strong>학습 결과 저장 방식</strong>
    <div class="small">
      10 epochs마다 저장합니다. 학습을 마친 후 best.pt를 추가로 저장합니다.
    </div>
  </div>

  <div id="training-storage"
       class="training-storage-box">
    저장 공간 확인 전
  </div>

  <div class="training-actions">
    <button id="save-training-settings"
            type="button">
      학습 설정 저장
    </button>
    <span id="training-settings-result"
          class="small">
      프로젝트 시작 후에 진행할 수 있습니다.
    </span>
  </div>
</section>


<section id="training-process-panel"
         class="card training-process"
         hidden>
  <h2>YOLO 학습 진행</h2>
  <p class="small">
    학습 중 브라우저를 새로고침해도 학습 결과와 상태 파일은 결과 저장 폴더에 유지됩니다.
  </p>

  <div class="training-process-grid">
    <div class="training-status-box">
      <strong>학습 상태</strong>
      <div id="training-process-status"
           class="small">
        프로젝트 대기 중
      </div>
      <div class="training-progress-track">
        <div id="training-progress-bar"
             class="training-progress-bar"></div>
      </div>
      <div id="training-progress-text"
           class="small">
        0 / 0 epochs · 0%
      </div>
    </div>

    <div class="training-status-box">
      <strong>결과 저장 경로</strong>
      <div id="training-run-directory"
           class="small training-path">
        학습 시작 전
      </div>
      <div id="training-best-path"
           class="small training-path">
        best.pt 생성 전
      </div>
    </div>
  </div>

  <div class="yolo-metric-charts">
    <article class="yolo-metric-card">
      <div class="yolo-metric-heading"><h3>성능 검증 지표</h3></div>
      <div class="yolo-metric-legends" aria-label="범례">
        <span class="yolo-metric-legend"><i style="background:#71304f"></i><span id="yolo-map-legend">mAP50-95 · 박스 (B) · 검증</span></span>
        <span class="yolo-metric-legend"><i style="background:#267d78"></i>val/box_loss · 박스 위치 손실</span>
        <span class="yolo-metric-legend"><i style="background:#a66b22"></i>val/cls_loss · 클래스 분류 손실</span>
      </div>
      <p class="small">mAP50-95는 높을수록, 손실(loss)은 낮을수록 좋습니다.<br> </p>
      <canvas id="training-progress-canvas" width="900" height="300" aria-label="mAP50-95, 박스 손실, 클래스 손실 그래프"></canvas>
    </article>
  </div>

  <div class="training-process-actions">
    <button id="start-yolo-training"
            type="button"
            disabled>
      학습 시작
    </button>
    <button id="cancel-yolo-training"
            type="button"
            disabled>
      학습 중단
    </button>
  </div>

  <div id="training-process-message"
       class="small">
    프로젝트 검사와 학습 설정 저장을 완료하세요.
  </div>
</section>

<dialog id="training-complete-dialog"
        class="training-complete-dialog">
  <h2>YOLO 학습 완료</h2>
  <p>학습이 정상 종료. 모델이 저장되었습니다.</p>
  <div id="training-complete-best"
       class="training-path"></div>
  <div id="training-complete-run"
       class="small training-path"></div>
  <div class="training-process-actions">
    <button id="close-training-dialog"
            type="button">
      확인
    </button>
  </div>
</dialog>

</main>
<script>
const $=id=>document.getElementById(id);
async function api(url,data={}) {
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const j=await r.json(); if(!r.ok)throw Error(j.error||'요청 실패'); return j;
}
function values(){return {photo_directory:$('photo').value,result_directory:$('result').value,task_type:$('task').value}}
function guardImageDeletion(editor, sectionId) {
  const section = document.getElementById(sectionId);
  for (const eventName of ['click', 'change', 'pointerdown', 'keydown']) {
    section.addEventListener(eventName, event => {
      if (editor.deleting) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }, true);
  }
}
async function permanentlyDeleteImage(editor, prefix, endpoint, updateOptions, loadImage, setStatus) {
  const selected = editor.images[editor.index];
  if (editor.deleting) return;
  if (!selected) {
    window.alert('삭제할 이미지를 먼저 선택하세요.');
    return;
  }
  if (!editor.imageReady || editor.displayedPath !== selected.path) {
    window.alert('선택한 이미지가 화면에 표시된 뒤 다시 삭제하세요.');
    return;
  }
  const imagePath = selected.path;
  const projectKey = editor.deletionProjectKey;
  const oldIndex = editor.index;
  if (!window.confirm(
    '다음 원본 이미지 파일을 영구 삭제할까요?\\n\\n' + imagePath
    + '\\n\\n현재 프로젝트의 해당 라벨도 삭제됩니다(다른 이미지와 공유하는 라벨은 보존).'
    + '\\n휴지통으로 이동하지 않으며 이 프로그램에서 복구할 수 없습니다.'
    + '\\n외부 라벨·기존 학습 데이터 복사본·학습 결과는 삭제하지 않습니다.'
  )) return;
  editor.deleting = true;
  editor.deletionEpoch += 1;
  editor.loadingToken += 1;
  editor.interaction = null;
  document.getElementById(prefix + '-labeler').setAttribute('aria-busy', 'true');
  let nextIndex = null;
  try {
    // Finish older autosaves before deletion; new autosaves are blocked.
    await Promise.allSettled([...editor.pendingSaves]);
    const result = await api(endpoint, {
      image_path: imagePath, project_key: projectKey, confirmed: true
    });
    editor.images = result.images;
    editor.index = -1;
    editor.selected = -1;
    editor.imageReady = false;
    editor.displayedPath = null;
    if (prefix === 'box') editor.boxes = [];
    else { editor.polygons = []; editor.draft = []; }
    updateOptions();
    nextIndex = Math.min(oldIndex, editor.images.length - 1);
    setStatus(`${imagePath} 영구 삭제 완료 · 남은 이미지 ${result.image_count}개`, 'ok');
    const validation = document.getElementById('validation-summary');
    if (validation) validation.textContent = '이미지가 삭제되었습니다. 학습 전에 데이터 검사를 다시 실행하세요.';
    if (result.warning) window.alert(result.warning);
  } catch (error) {
    window.alert('이미지 삭제 실패: ' + error.message);
    setStatus('이미지 삭제 실패: ' + error.message, 'error');
  } finally {
    editor.deleting = false;
    document.getElementById(prefix + '-labeler').removeAttribute('aria-busy');
  }
  if (nextIndex !== null) await loadImage(nextIndex);
}
function note(text,kind='small'){$('notice').className=kind;$('notice').textContent=text}
let rgbStatusBusy=false;
async function refresh(){
  if(rgbStatusBusy)return; rgbStatusBusy=true;
  try {
    const s=await fetch('/api/status',{cache:'no-store'}).then(r=>r.json());
    const c=s.camera, v=s.vehicle||{}, vi=$('vehicle-info');
    if(vi)vi.textContent='차량 IP '+(v.ip||'-');
    $('camera').textContent=c.available?'RGB 수신 중: '+c.width+'×'+c.height+' · 프레임 경과 '+Number(c.age_seconds||0).toFixed(2)+'초':'RGB 대기 중';
    $('capture').disabled=!s.project||!c.available;
  } finally {rgbStatusBusy=false;}
}
$('inspect').onclick=async()=>{try{const i=await api('/api/project/inspect',values());$('new').disabled=i.resume_available;$('resume').disabled=!i.resume_available;note(i.resume_available?'이전에 작업하던 폴더 쌍입니다. 이어서 작업을 선택하세요.':'새로운 폴더 쌍입니다. 새 프로젝트 시작을 선택하세요.','ok')}catch(e){$('new').disabled=true;$('resume').disabled=true;note(e.message,'error')}};
async function activate(action){try{const s=await api('/api/project/activate',Object.assign(values(),{action}));$('new').disabled=true;$('resume').disabled=true;note((action==='new'?'새 작업':'기존 작업 재개')+' 준비 완료. 사진 저장 폴더: '+s.project.paths.photo_directory,'ok');await refresh()}catch(e){note(e.message,'error')}}
$('new').onclick=()=>activate('new'); $('resume').onclick=()=>activate('resume');
$('capture').onclick=async()=>{try{const r=await api('/api/capture');note('저장됨: '+r.saved_path,'ok')}catch(e){note(e.message,'error')}};
// Video uses one persistent connection; status polling never resets its source.
$('preview').src='/stream.mjpg';
$('preview').onerror=()=>setTimeout(()=>{$('preview').src='/stream.mjpg?retry='+Date.now()},1000);
refresh().catch(e=>note(e.message,'error'));
setInterval(()=>refresh().catch(()=>{}),500);
</script>
<script>
let supervisedClassNames = [];
let supervisedProjectActive = false;

function showClassNotice(message, kind = "small") {
  const output = document.getElementById("class-notice");
  output.className = kind;
  output.textContent = message;
}

function renderSupervisedClasses() {
  const list = document.getElementById("class-list");
  list.replaceChildren();

  if (supervisedClassNames.length === 0) {
    const empty = document.createElement("span");
    empty.className = "small";
    empty.textContent = "등록된 클래스가 없습니다.";
    list.appendChild(empty);
    return;
  }

  supervisedClassNames.forEach((name, index) => {
    const chip = document.createElement("span");
    chip.className = "class-chip";

    const label = document.createElement("span");
    label.textContent = `${index}: ${name}`;

    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "×";
    remove.title = `${name} 삭제`;
    remove.onclick = async () => {
      const next = supervisedClassNames.filter(
        (_, currentIndex) => currentIndex !== index
      );
      await saveSupervisedClasses(next);
    };

    chip.append(label, remove);
    list.appendChild(chip);
  });
}

async function saveSupervisedClasses(nextClasses) {
  try {
    const response = await api(
      "/api/classes",
      {classes: nextClasses}
    );

    supervisedClassNames =
      response.project.classes || [];

    renderSupervisedClasses();
    showClassNotice(
      `클래스 ${supervisedClassNames.length}개가 저장되었습니다.`,
      "ok"
    );
  } catch (error) {
    showClassNotice(error.message, "error");
  }
}

async function refreshSupervisedClasses() {
  try {
    const status = await fetch(
      `/api/status?t=${Date.now()}`,
      {cache: "no-store"}
    ).then(response => response.json());

    supervisedProjectActive = Boolean(status.project);

    document.getElementById("class-name").disabled =
      !supervisedProjectActive;
    document.getElementById("class-add").disabled =
      !supervisedProjectActive;

    const next = status.project
      ? (status.project.classes || [])
      : [];

    if (
      JSON.stringify(next)
      !== JSON.stringify(supervisedClassNames)
    ) {
      supervisedClassNames = next;
      renderSupervisedClasses();
    }

    if (!supervisedProjectActive) {
      showClassNotice(
        "사진 저장 폴더와 결과 저장 폴더를 선택하고 프로젝트를 시작하세요."
      );
    }
  } catch (error) {
    showClassNotice(
      "클래스 상태를 읽지 못했습니다: " + error.message,
      "error"
    );
  }
}

document.getElementById("class-add").onclick = async () => {
  const input = document.getElementById("class-name");
  const name = input.value.trim();

  if (!name) {
    showClassNotice(
      "클래스 이름을 입력하세요.",
      "error"
    );
    return;
  }

  await saveSupervisedClasses([
    ...supervisedClassNames,
    name
  ]);

  input.value = "";
  input.focus();
};

document.getElementById("class-name").addEventListener(
  "keydown",
  event => {
    if (event.key === "Enter") {
      event.preventDefault();
      document.getElementById("class-add").click();
    }
  }
);

renderSupervisedClasses();
refreshSupervisedClasses();
setInterval(refreshSupervisedClasses, 1500);
</script>

<script>
function showDatasetSummary(dataset) {
  const output = document.getElementById(
    "dataset-summary"
  );

  if (!dataset) {
    output.className = "small";
    output.textContent =
      "외부 데이터 검색을 진행하지 않았습니다.";
    return;
  }

  const lines = [
    `이미지: ${dataset.image_count}개`,
    `일치 레이블: ${dataset.matched_label_files}개`,
    `미레이블 이미지: ${dataset.unlabeled_images}개`,
    `객체 레이블: ${dataset.object_count}개`,
    `필요 클래스 수: ${dataset.required_class_count}개`,
    `등록 클래스 수: ${dataset.registered_class_count}개`,
    `형식 검사: ${dataset.compatible ? "정상" : "확인 필요"}`
  ];

  if (dataset.yaml_files.length) {
    lines.push(
      "YAML: " + dataset.yaml_files.join(", ")
    );
  }

  if (dataset.issues.length) {
    lines.push("");
    lines.push("확인할 내용:");
    dataset.issues.forEach(
      issue => lines.push("- " + issue)
    );
  }

  output.className = dataset.compatible
    ? "small ok"
    : "small warn";
  output.textContent = lines.join("\\n");
}

async function refreshDatasetImporter() {
  try {
    const status = await fetch(
      `/api/status?dataset=${Date.now()}`,
      {cache: "no-store"}
    ).then(response => response.json());

    const active = Boolean(status.project);
    document.getElementById(
      "dataset-scan"
    ).disabled = !active;

    if (!active) {
      showDatasetSummary(null);
      return;
    }

    showDatasetSummary(
      status.project.external_dataset || null
    );
  } catch (error) {
    const output = document.getElementById(
      "dataset-summary"
    );
    output.className = "small error";
    output.textContent =
      "데이터 상태를 읽지 못했습니다: "
      + error.message;
  }
}

document.getElementById(
  "dataset-scan"
).onclick = async () => {
  const output = document.getElementById(
    "dataset-summary"
  );

  output.className = "small";
  output.textContent = "데이터를 검사하고 있습니다.";

  try {
    const response = await api(
      "/api/dataset/scan"
    );
    showDatasetSummary(response.dataset);
  } catch (error) {
    output.className = "small error";
    output.textContent = error.message;
  }
};

refreshDatasetImporter();
setInterval(refreshDatasetImporter, 2000);
</script>

<script>
const boxEditor = {
  deleting: false,
  deletionEpoch: 0,
  deletionProjectKey: null,
  pendingSaves: new Set(),
  projectKey: null,
  images: [],
  index: -1,
  classes: [],
  boxes: [],
  selected: -1,
  interaction: null,
  image: new Image(),
  imageReady: false,
  displayedPath: null,
  loadingToken: 0
};

const boxCanvas = document.getElementById("box-canvas");
const boxContext = boxCanvas.getContext("2d");
guardImageDeletion(boxEditor, 'box-labeler');
const boxColors = [
  "#22d3ee", "#fbbf24", "#fb7185", "#a78bfa",
  "#34d399", "#f97316", "#60a5fa", "#e879f9"
];

function setBoxStatus(message, kind = "small") {
  const output = document.getElementById("box-status");
  output.className = kind;
  output.textContent = message;
}

function clampBoxValue(value, minimum = 0, maximum = 1) {
  return Math.max(minimum, Math.min(maximum, value));
}

function boxEdges(box) {
  return {
    left: box.x - box.width / 2,
    right: box.x + box.width / 2,
    top: box.y - box.height / 2,
    bottom: box.y + box.height / 2
  };
}

function boxFromEdges(edges, classId) {
  const left = clampBoxValue(
    Math.min(edges.left, edges.right)
  );
  const right = clampBoxValue(
    Math.max(edges.left, edges.right)
  );
  const top = clampBoxValue(
    Math.min(edges.top, edges.bottom)
  );
  const bottom = clampBoxValue(
    Math.max(edges.top, edges.bottom)
  );

  return {
    class_id: classId,
    x: (left + right) / 2,
    y: (top + bottom) / 2,
    width: right - left,
    height: bottom - top
  };
}

function boxPointer(event) {
  const rectangle = boxCanvas.getBoundingClientRect();

  return {
    x: clampBoxValue(
      (event.clientX - rectangle.left) / rectangle.width
    ),
    y: clampBoxValue(
      (event.clientY - rectangle.top) / rectangle.height
    )
  };
}

function renderBoxEditor() {
  boxContext.clearRect(
    0, 0, boxCanvas.width, boxCanvas.height
  );

  if (!boxEditor.imageReady) {
    boxContext.fillStyle = "#9fb3c8";
    boxContext.font = "20px sans-serif";
    boxContext.textAlign = "center";
    boxContext.fillText(
      "이미지를 선택하세요.",
      boxCanvas.width / 2,
      boxCanvas.height / 2
    );
    return;
  }

  boxContext.drawImage(
    boxEditor.image,
    0, 0,
    boxCanvas.width,
    boxCanvas.height
  );

  boxEditor.boxes.forEach((box, index) => {
    const edges = boxEdges(box);
    const left = edges.left * boxCanvas.width;
    const top = edges.top * boxCanvas.height;
    const width = box.width * boxCanvas.width;
    const height = box.height * boxCanvas.height;
    const color = boxColors[
      box.class_id % boxColors.length
    ];
    const selected = index === boxEditor.selected;
    const className =
      `${box.class_id}, ${boxEditor.classes[box.class_id] ?? "unknown"}`;

    boxContext.strokeStyle = color;
    boxContext.lineWidth = selected ? 4 : 2;
    boxContext.strokeRect(left, top, width, height);

    boxContext.fillStyle = color + "28";
    boxContext.fillRect(left, top, width, height);

    boxContext.font = "16px sans-serif";
    const labelWidth =
      boxContext.measureText(className).width + 12;
    const labelTop = Math.max(0, top - 24);

    boxContext.fillStyle = color;
    boxContext.fillRect(
      left, labelTop, labelWidth, 24
    );
    boxContext.fillStyle = "#001018";
    boxContext.textAlign = "left";
    boxContext.fillText(
      className, left + 6, labelTop + 17
    );

    if (selected) {
      const size = 10;
      const handles = [
        [left, top],
        [left + width, top],
        [left, top + height],
        [left + width, top + height]
      ];

      boxContext.fillStyle = "#ffffff";
      handles.forEach(([x, y]) => {
        boxContext.fillRect(
          x - size / 2,
          y - size / 2,
          size,
          size
        );
        boxContext.strokeStyle = color;
        boxContext.strokeRect(
          x - size / 2,
          y - size / 2,
          size,
          size
        );
      });
    }
  });

  if (
    boxEditor.interaction
    && boxEditor.interaction.type === "draw"
  ) {
    const start = boxEditor.interaction.start;
    const current = boxEditor.interaction.current;
    const left = Math.min(start.x, current.x);
    const right = Math.max(start.x, current.x);
    const top = Math.min(start.y, current.y);
    const bottom = Math.max(start.y, current.y);

    boxContext.strokeStyle = "#ffffff";
    boxContext.lineWidth = 2;
    boxContext.setLineDash([8, 5]);
    boxContext.strokeRect(
      left * boxCanvas.width,
      top * boxCanvas.height,
      (right - left) * boxCanvas.width,
      (bottom - top) * boxCanvas.height
    );
    boxContext.setLineDash([]);
  }
}

function findBoxHandle(point) {
  const index = boxEditor.selected;
  if (index < 0) {
    return null;
  }

  const box = boxEditor.boxes[index];
  const edges = boxEdges(box);
  const rectangle = boxCanvas.getBoundingClientRect();
  const toleranceX = 12 / rectangle.width;
  const toleranceY = 12 / rectangle.height;
  const handles = {
    nw: [edges.left, edges.top],
    ne: [edges.right, edges.top],
    sw: [edges.left, edges.bottom],
    se: [edges.right, edges.bottom]
  };

  for (const [name, location] of Object.entries(handles)) {
    if (
      Math.abs(point.x - location[0]) <= toleranceX
      && Math.abs(point.y - location[1]) <= toleranceY
    ) {
      return name;
    }
  }

  return null;
}

function findBoxAt(point) {
  for (
    let index = boxEditor.boxes.length - 1;
    index >= 0;
    index -= 1
  ) {
    const edges = boxEdges(boxEditor.boxes[index]);

    if (
      point.x >= edges.left
      && point.x <= edges.right
      && point.y >= edges.top
      && point.y <= edges.bottom
    ) {
      return index;
    }
  }
  return -1;
}

function syncSelectedClass() {
  if (boxEditor.selected < 0) {
    return;
  }

  document.getElementById(
    "box-class-select"
  ).value = String(
    boxEditor.boxes[boxEditor.selected].class_id
  );
}

async function saveCurrentBoxes() {
  if (
    boxEditor.deleting || boxEditor.index < 0
    || !boxEditor.images[boxEditor.index]
  ) {
    return;
  }

  const imagePath =
    boxEditor.images[boxEditor.index].path;
  const snapshot = boxEditor.boxes.map(
    box => ({...box})
  );

  setBoxStatus("레이블을 저장하고 있습니다.");

  const token = boxEditor.loadingToken;
  let request;
  try {
    request = api(
      "/api/labels/save",
      {
        image_path: imagePath,
        boxes: snapshot
      }
    );
    boxEditor.pendingSaves.add(request);
    const response = await request;
    if (boxEditor.deleting || token !== boxEditor.loadingToken) return;

    const item = boxEditor.images.find(
      image => image.path === imagePath
    );
    if (item) {
      item.label_source = "project";
    }

    updateBoxImageOptions();
    setBoxStatus(
      `${imagePath}: 박스 ${response.box_count}개 자동 저장됨`,
      "ok"
    );
  } catch (error) {
    if (boxEditor.deleting || token !== boxEditor.loadingToken) return;
    setBoxStatus(
      "레이블 저장 실패: " + error.message,
      "error"
    );
  } finally {
    boxEditor.pendingSaves.delete(request);
  }
}

function updateBoxClassOptions() {
  const select = document.getElementById(
    "box-class-select"
  );
  const previous = select.value;
  select.replaceChildren();

  boxEditor.classes.forEach((name, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${index}: ${name}`;
    select.appendChild(option);
  });

  if (
    previous
    && Number(previous) < boxEditor.classes.length
  ) {
    select.value = previous;
  }
}

function updateBoxImageOptions() {
  const select = document.getElementById(
    "box-image-select"
  );
  select.replaceChildren();

  boxEditor.images.forEach((item, index) => {
    const option = document.createElement("option");
    option.value = String(index);

    const mark = item.label_source === "project"
      ? "[저장]"
      : item.label_source === "external"
        ? "[외부]"
        : "[미작성]";

    option.textContent = `${mark} ${item.path}`;
    select.appendChild(option);
  });

  if (boxEditor.index >= 0) {
    select.value = String(boxEditor.index);
  }
}

async function loadBoxImage(index) {
  if (boxEditor.deleting) return;
  const token = ++boxEditor.loadingToken;
  boxEditor.imageReady = false;
  boxEditor.displayedPath = null;
  boxEditor.boxes = [];
  renderBoxEditor();
  if (
    index < 0
    || index >= boxEditor.images.length
  ) {
    boxEditor.index = -1;
    boxEditor.boxes = [];
    boxEditor.selected = -1;
    boxEditor.imageReady = false;
    renderBoxEditor();
    return;
  }

  boxEditor.index = index;
  boxEditor.selected = -1;
  boxEditor.interaction = null;

  updateBoxImageOptions();

  const item = boxEditor.images[index];

  setBoxStatus(`${item.path} 불러오는 중...`);

  try {
    const labels = await api(
      "/api/labels/load",
      {image_path: item.path}
    );

    if (token !== boxEditor.loadingToken) {
      return;
    }

    boxEditor.boxes = labels.boxes.map(
      box => ({...box})
    );

    const image = new Image();

    image.onload = () => {
      if (token !== boxEditor.loadingToken) {
        return;
      }

      boxEditor.image = image;
      boxEditor.imageReady = true;
      boxEditor.displayedPath = item.path;
      boxCanvas.width = image.naturalWidth;
      boxCanvas.height = image.naturalHeight;
      renderBoxEditor();

      setBoxStatus(
        `${item.path}: 박스 ${boxEditor.boxes.length}개, `
        + `출처 ${labels.label_source}`,
        "ok"
      );
    };

    image.onerror = () => {
      if (token !== boxEditor.loadingToken) return;
      setBoxStatus(
        "이미지를 표시하지 못했습니다.",
        "error"
      );
    };

    image.src =
      `/api/labels/image?path=${
        encodeURIComponent(item.path)
      }&t=${Date.now()}`;
  } catch (error) {
    if (token !== boxEditor.loadingToken) return;
    setBoxStatus(error.message, "error");
  }
}

async function loadBoxImageList() {
  if (boxEditor.deleting) return;
  const deletionEpoch = boxEditor.deletionEpoch;
  setBoxStatus("이미지 목록을 읽고 있습니다.");

  try {
    const response = await api(
      "/api/labels/images"
    );
    if (boxEditor.deleting || deletionEpoch !== boxEditor.deletionEpoch) return;
    boxEditor.deletionProjectKey = response.project_key;

    const currentPath =
      boxEditor.index >= 0
      && boxEditor.images[boxEditor.index]
        ? boxEditor.images[boxEditor.index].path
        : null;

    boxEditor.images = response.images;

    let nextIndex = boxEditor.images.findIndex(
      item => item.path === currentPath
    );
    if (nextIndex < 0 && boxEditor.images.length) {
      nextIndex = 0;
    }

    updateBoxImageOptions();

    if (!boxEditor.images.length) {
      setBoxStatus(
        "라벨링할 이미지가 없습니다.",
        "warn"
      );
      await loadBoxImage(-1);
      return;
    }

    await loadBoxImage(nextIndex);
  } catch (error) {
    if (boxEditor.deleting || deletionEpoch !== boxEditor.deletionEpoch) return;
    setBoxStatus(error.message, "error");
  }
}

async function refreshBoxEditorProject() {
  if (boxEditor.deleting) return;
  const deletionEpoch = boxEditor.deletionEpoch;
  try {
    const status = await fetch(
      `/api/status?box=${Date.now()}`,
      {cache: "no-store"}
    ).then(response => response.json());
    if (boxEditor.deleting || deletionEpoch !== boxEditor.deletionEpoch) return;

    const project = status.project;
    const section = document.getElementById(
      "box-labeler"
    );

    if (!project || project.task_type !== "detect") {
      section.hidden = true;
      boxEditor.projectKey = null;
      return;
    }

    section.hidden = false;

    const classes = project.classes || [];
    const projectKey = JSON.stringify([
      project.paths.photo_directory,
      project.paths.result_directory
    ]);
    const classesChanged =
      JSON.stringify(classes)
      !== JSON.stringify(boxEditor.classes);
    const projectChanged =
      projectKey !== boxEditor.projectKey;

    boxEditor.classes = classes;
    updateBoxClassOptions();

    const enabled = classes.length > 0;
    document.getElementById(
      "box-refresh"
    ).disabled = !enabled;
    document.getElementById(
      "box-class-select"
    ).disabled = !enabled;

    if (!enabled) {
      setBoxStatus(
        "클래스를 한 개 이상 등록하세요.",
        "warn"
      );
      return;
    }

    if (projectChanged) {
      boxEditor.projectKey = projectKey;
      await loadBoxImageList();
    } else if (classesChanged) {
      renderBoxEditor();
    }
  } catch (error) {
    if (boxEditor.deleting || deletionEpoch !== boxEditor.deletionEpoch) return;
    setBoxStatus(
      "박스 편집 상태 확인 실패: " + error.message,
      "error"
    );
  }
}

boxCanvas.addEventListener("pointerdown", event => {
  if (
    !boxEditor.imageReady
    || boxEditor.classes.length === 0
  ) {
    return;
  }

  const point = boxPointer(event);
  const handle = findBoxHandle(point);

  boxCanvas.setPointerCapture(event.pointerId);

  if (handle) {
    const selectedBox =
      boxEditor.boxes[boxEditor.selected];

    boxEditor.interaction = {
      type: "resize",
      handle,
      original: {
        ...boxEdges(selectedBox)
      },
      classId: selectedBox.class_id
    };
    return;
  }

  const hit = findBoxAt(point);

  if (hit >= 0) {
    boxEditor.selected = hit;
    const box = boxEditor.boxes[hit];

    boxEditor.interaction = {
      type: "drag",
      offsetX: point.x - box.x,
      offsetY: point.y - box.y
    };

    syncSelectedClass();
    renderBoxEditor();
    return;
  }

  boxEditor.selected = -1;
  boxEditor.interaction = {
    type: "draw",
    start: point,
    current: point
  };
  renderBoxEditor();
});

boxCanvas.addEventListener("pointermove", event => {
  const action = boxEditor.interaction;
  if (!action) {
    return;
  }

  const point = boxPointer(event);

  if (action.type === "draw") {
    action.current = point;
  } else if (
    action.type === "drag"
    && boxEditor.selected >= 0
  ) {
    const box = boxEditor.boxes[boxEditor.selected];
    const halfWidth = box.width / 2;
    const halfHeight = box.height / 2;

    box.x = clampBoxValue(
      point.x - action.offsetX,
      halfWidth,
      1 - halfWidth
    );
    box.y = clampBoxValue(
      point.y - action.offsetY,
      halfHeight,
      1 - halfHeight
    );
  } else if (
    action.type === "resize"
    && boxEditor.selected >= 0
  ) {
    const edges = {...action.original};

    if (action.handle.includes("n")) {
      edges.top = point.y;
    }
    if (action.handle.includes("s")) {
      edges.bottom = point.y;
    }
    if (action.handle.includes("w")) {
      edges.left = point.x;
    }
    if (action.handle.includes("e")) {
      edges.right = point.x;
    }

    boxEditor.boxes[boxEditor.selected] =
      boxFromEdges(edges, action.classId);
  }

  renderBoxEditor();
});

async function finishBoxInteraction(event) {
  const action = boxEditor.interaction;
  if (!action) {
    return;
  }

  if (action.type === "draw") {
    const edges = {
      left: action.start.x,
      right: action.current.x,
      top: action.start.y,
      bottom: action.current.y
    };
    const classId = Number(
      document.getElementById(
        "box-class-select"
      ).value || 0
    );
    const box = boxFromEdges(edges, classId);

    if (box.width >= 0.005 && box.height >= 0.005) {
      boxEditor.boxes.push(box);
      boxEditor.selected =
        boxEditor.boxes.length - 1;
    }
  }

  boxEditor.interaction = null;

  try {
    boxCanvas.releasePointerCapture(event.pointerId);
  } catch (_) {
  }

  renderBoxEditor();
  await saveCurrentBoxes();
}

boxCanvas.addEventListener(
  "pointerup",
  finishBoxInteraction
);
boxCanvas.addEventListener(
  "pointercancel",
  finishBoxInteraction
);

document.getElementById(
  "box-image-select"
).onchange = async event => {
  await loadBoxImage(Number(event.target.value));
};

document.getElementById(
  "box-class-select"
).onchange = async event => {
  if (boxEditor.selected < 0) {
    return;
  }

  boxEditor.boxes[
    boxEditor.selected
  ].class_id = Number(event.target.value);

  renderBoxEditor();
  await saveCurrentBoxes();
};

document.getElementById(
  "box-refresh"
).onclick = loadBoxImageList;

document.getElementById(
  "box-prev"
).onclick = async () => {
  if (boxEditor.index > 0) {
    await loadBoxImage(boxEditor.index - 1);
  }
};

document.getElementById(
  "box-next"
).onclick = async () => {
  if (
    boxEditor.index >= 0
    && boxEditor.index < boxEditor.images.length - 1
  ) {
    await loadBoxImage(boxEditor.index + 1);
  }
};

document.getElementById(
  "box-delete"
).onclick = async () => {
  if (boxEditor.selected < 0) {
    setBoxStatus(
      "삭제할 박스를 먼저 선택하세요.",
      "warn"
    );
    return;
  }

  boxEditor.boxes.splice(boxEditor.selected, 1);
  boxEditor.selected = -1;
  renderBoxEditor();
  await saveCurrentBoxes();
};

document.getElementById(
  "box-clear"
).onclick = () => permanentlyDeleteImage(
  boxEditor, 'box', '/api/labels/delete-image',
  updateBoxImageOptions, loadBoxImage, setBoxStatus
);

boxCanvas.addEventListener("keydown", async event => {
  if (
    event.key === "Delete"
    || event.key === "Backspace"
  ) {
    event.preventDefault();
    document.getElementById(
      "box-delete"
    ).click();
  }
});

renderBoxEditor();
refreshBoxEditorProject();
setInterval(refreshBoxEditorProject, 2000);
</script>

<script>
const segmentEditor = {
  deleting: false,
  deletionEpoch: 0,
  deletionProjectKey: null,
  pendingSaves: new Set(),
  projectKey: null,
  images: [],
  index: -1,
  classes: [],
  polygons: [],
  selected: -1,
  draft: [],
  interaction: null,
  image: new Image(),
  imageReady: false,
  displayedPath: null,
  loadingToken: 0
};

const segmentCanvas = document.getElementById(
  "segment-canvas"
);
const segmentContext = segmentCanvas.getContext("2d");
guardImageDeletion(segmentEditor, 'segment-labeler');
const segmentColors = [
  "#22d3ee", "#fbbf24", "#fb7185", "#a78bfa",
  "#34d399", "#f97316", "#60a5fa", "#e879f9"
];

function setSegmentStatus(message, kind = "small") {
  const output = document.getElementById(
    "segment-status"
  );
  output.className = kind;
  output.textContent = message;
}

function clampSegmentValue(value) {
  return Math.max(0, Math.min(1, value));
}

function segmentPointer(event) {
  const rectangle = segmentCanvas.getBoundingClientRect();

  return {
    x: clampSegmentValue(
      (event.clientX - rectangle.left) / rectangle.width
    ),
    y: clampSegmentValue(
      (event.clientY - rectangle.top) / rectangle.height
    )
  };
}

function segmentPointDistance(first, second) {
  const rectangle = segmentCanvas.getBoundingClientRect();
  const dx = (
    first.x - second.x
  ) * rectangle.width;
  const dy = (
    first.y - second.y
  ) * rectangle.height;

  return Math.sqrt(dx * dx + dy * dy);
}

function pointInsidePolygon(point, points) {
  let inside = false;

  for (
    let current = 0, previous = points.length - 1;
    current < points.length;
    previous = current, current += 1
  ) {
    const currentPoint = points[current];
    const previousPoint = points[previous];

    const intersects = (
      (currentPoint[1] > point.y)
      !== (previousPoint[1] > point.y)
    ) && (
      point.x
      < (
        (previousPoint[0] - currentPoint[0])
        * (point.y - currentPoint[1])
        / (
          previousPoint[1] - currentPoint[1]
          || Number.EPSILON
        )
        + currentPoint[0]
      )
    );

    if (intersects) {
      inside = !inside;
    }
  }

  return inside;
}

function findSegmentVertex(point) {
  const tolerance = 12;

  for (
    let polygonIndex = segmentEditor.polygons.length - 1;
    polygonIndex >= 0;
    polygonIndex -= 1
  ) {
    const polygon =
      segmentEditor.polygons[polygonIndex];

    for (
      let pointIndex = polygon.points.length - 1;
      pointIndex >= 0;
      pointIndex -= 1
    ) {
      const vertex = {
        x: polygon.points[pointIndex][0],
        y: polygon.points[pointIndex][1]
      };

      if (
        segmentPointDistance(point, vertex)
        <= tolerance
      ) {
        return {
          polygonIndex,
          pointIndex
        };
      }
    }
  }

  return null;
}

function findSegmentPolygon(point) {
  for (
    let index = segmentEditor.polygons.length - 1;
    index >= 0;
    index -= 1
  ) {
    if (
      pointInsidePolygon(
        point,
        segmentEditor.polygons[index].points
      )
    ) {
      return index;
    }
  }

  return -1;
}

function renderSegmentEditor() {
  segmentContext.clearRect(
    0,
    0,
    segmentCanvas.width,
    segmentCanvas.height
  );

  if (!segmentEditor.imageReady) {
    segmentContext.fillStyle = "#9fb3c8";
    segmentContext.font = "20px sans-serif";
    segmentContext.textAlign = "center";
    segmentContext.fillText(
      "이미지를 선택하세요.",
      segmentCanvas.width / 2,
      segmentCanvas.height / 2
    );
    return;
  }

  segmentContext.drawImage(
    segmentEditor.image,
    0,
    0,
    segmentCanvas.width,
    segmentCanvas.height
  );

  segmentEditor.polygons.forEach(
    (polygon, polygonIndex) => {
      if (!polygon.points.length) {
        return;
      }

      const color = segmentColors[
        polygon.class_id % segmentColors.length
      ];
      const selected =
        polygonIndex === segmentEditor.selected;

      segmentContext.beginPath();

      polygon.points.forEach((point, pointIndex) => {
        const x = point[0] * segmentCanvas.width;
        const y = point[1] * segmentCanvas.height;

        if (pointIndex === 0) {
          segmentContext.moveTo(x, y);
        } else {
          segmentContext.lineTo(x, y);
        }
      });

      segmentContext.closePath();
      segmentContext.fillStyle = color + "42";
      segmentContext.fill();
      segmentContext.strokeStyle = color;
      segmentContext.lineWidth = selected ? 4 : 2;
      segmentContext.stroke();

      const first = polygon.points[0];
      const className =
        `${polygon.class_id}, ${segmentEditor.classes[polygon.class_id] ?? "unknown"}`;
      const labelX = first[0] * segmentCanvas.width;
      const labelY = Math.max(
        0,
        first[1] * segmentCanvas.height - 24
      );

      segmentContext.font = "16px sans-serif";
      const labelWidth =
        segmentContext.measureText(className).width + 12;

      segmentContext.fillStyle = color;
      segmentContext.fillRect(
        labelX,
        labelY,
        labelWidth,
        24
      );
      segmentContext.fillStyle = "#001018";
      segmentContext.textAlign = "left";
      segmentContext.fillText(
        className,
        labelX + 6,
        labelY + 17
      );

      if (selected) {
        polygon.points.forEach(point => {
          const x = point[0] * segmentCanvas.width;
          const y = point[1] * segmentCanvas.height;

          segmentContext.beginPath();
          segmentContext.arc(x, y, 6, 0, Math.PI * 2);
          segmentContext.fillStyle = "#ffffff";
          segmentContext.fill();
          segmentContext.lineWidth = 2;
          segmentContext.strokeStyle = color;
          segmentContext.stroke();
        });
      }
    }
  );

  if (segmentEditor.draft.length) {
    segmentContext.beginPath();

    segmentEditor.draft.forEach((point, index) => {
      const x = point[0] * segmentCanvas.width;
      const y = point[1] * segmentCanvas.height;

      if (index === 0) {
        segmentContext.moveTo(x, y);
      } else {
        segmentContext.lineTo(x, y);
      }
    });

    segmentContext.strokeStyle = "#ffffff";
    segmentContext.lineWidth = 2;
    segmentContext.setLineDash([8, 5]);
    segmentContext.stroke();
    segmentContext.setLineDash([]);

    segmentEditor.draft.forEach((point, index) => {
      const x = point[0] * segmentCanvas.width;
      const y = point[1] * segmentCanvas.height;

      segmentContext.beginPath();
      segmentContext.arc(
        x,
        y,
        index === 0 ? 7 : 5,
        0,
        Math.PI * 2
      );
      segmentContext.fillStyle =
        index === 0 ? "#fbbf24" : "#ffffff";
      segmentContext.fill();
      segmentContext.strokeStyle = "#001018";
      segmentContext.stroke();
    });
  }
}

function syncSegmentClass() {
  if (segmentEditor.selected < 0) {
    return;
  }

  document.getElementById(
    "segment-class-select"
  ).value = String(
    segmentEditor.polygons[
      segmentEditor.selected
    ].class_id
  );
}

function updateSegmentClassOptions() {
  const select = document.getElementById(
    "segment-class-select"
  );
  const previous = select.value;
  select.replaceChildren();

  segmentEditor.classes.forEach((name, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${index}: ${name}`;
    select.appendChild(option);
  });

  if (
    previous
    && Number(previous) < segmentEditor.classes.length
  ) {
    select.value = previous;
  }
}

function updateSegmentImageOptions() {
  const select = document.getElementById(
    "segment-image-select"
  );
  select.replaceChildren();

  segmentEditor.images.forEach((item, index) => {
    const option = document.createElement("option");
    option.value = String(index);

    const mark = item.label_source === "project"
      ? "[저장]"
      : item.label_source === "external"
        ? "[외부]"
        : "[미작성]";

    option.textContent = `${mark} ${item.path}`;
    select.appendChild(option);
  });

  if (segmentEditor.index >= 0) {
    select.value = String(segmentEditor.index);
  }
}

async function saveCurrentPolygons() {
  if (
    segmentEditor.deleting || segmentEditor.index < 0
    || !segmentEditor.images[segmentEditor.index]
  ) {
    return;
  }

  const imagePath =
    segmentEditor.images[segmentEditor.index].path;
  const snapshot = segmentEditor.polygons.map(
    polygon => ({
      class_id: polygon.class_id,
      points: polygon.points.map(
        point => [point[0], point[1]]
      )
    })
  );

  setSegmentStatus(
    "다각형 레이블을 저장하고 있습니다."
  );

  const token = segmentEditor.loadingToken;
  let request;
  try {
    request = api(
      "/api/segments/save",
      {
        image_path: imagePath,
        polygons: snapshot
      }
    );
    segmentEditor.pendingSaves.add(request);
    const response = await request;
    if (segmentEditor.deleting || token !== segmentEditor.loadingToken) return;

    const item = segmentEditor.images.find(
      image => image.path === imagePath
    );
    if (item) {
      item.label_source = "project";
    }

    updateSegmentImageOptions();
    setSegmentStatus(
      `${imagePath}: 다각형 `
      + `${response.polygon_count}개 자동 저장됨`,
      "ok"
    );
  } catch (error) {
    if (segmentEditor.deleting || token !== segmentEditor.loadingToken) return;
    setSegmentStatus(
      "레이블 저장 실패: " + error.message,
      "error"
    );
  } finally {
    segmentEditor.pendingSaves.delete(request);
  }
}

async function finishSegmentDraft() {
  if (segmentEditor.draft.length < 3) {
    setSegmentStatus(
      "다각형을 완성하려면 최소 3개 점이 필요합니다.",
      "warn"
    );
    return;
  }

  const classId = Number(
    document.getElementById(
      "segment-class-select"
    ).value || 0
  );

  segmentEditor.polygons.push({
    class_id: classId,
    points: segmentEditor.draft.map(
      point => [point[0], point[1]]
    )
  });

  segmentEditor.draft = [];
  segmentEditor.selected =
    segmentEditor.polygons.length - 1;

  renderSegmentEditor();
  await saveCurrentPolygons();
}

async function loadSegmentImage(index) {
  if (segmentEditor.deleting) return;
  const token = ++segmentEditor.loadingToken;
  segmentEditor.imageReady = false;
  segmentEditor.displayedPath = null;
  segmentEditor.polygons = [];
  renderSegmentEditor();
  if (
    index < 0
    || index >= segmentEditor.images.length
  ) {
    segmentEditor.index = -1;
    segmentEditor.polygons = [];
    segmentEditor.draft = [];
    segmentEditor.selected = -1;
    segmentEditor.imageReady = false;
    renderSegmentEditor();
    return;
  }

  segmentEditor.index = index;
  segmentEditor.selected = -1;
  segmentEditor.draft = [];
  segmentEditor.interaction = null;

  updateSegmentImageOptions();

  const item = segmentEditor.images[index];

  setSegmentStatus(`${item.path} 불러오는 중...`);

  try {
    const labels = await api(
      "/api/segments/load",
      {image_path: item.path}
    );

    if (token !== segmentEditor.loadingToken) {
      return;
    }

    segmentEditor.polygons = labels.polygons.map(
      polygon => ({
        class_id: polygon.class_id,
        points: polygon.points.map(
          point => [point[0], point[1]]
        )
      })
    );

    const image = new Image();

    image.onload = () => {
      if (token !== segmentEditor.loadingToken) {
        return;
      }

      segmentEditor.image = image;
      segmentEditor.imageReady = true;
      segmentEditor.displayedPath = item.path;
      segmentCanvas.width = image.naturalWidth;
      segmentCanvas.height = image.naturalHeight;
      renderSegmentEditor();

      setSegmentStatus(
        `${item.path}: 다각형 `
        + `${segmentEditor.polygons.length}개, `
        + `출처 ${labels.label_source}`,
        "ok"
      );
    };

    image.onerror = () => {
      if (token !== segmentEditor.loadingToken) return;
      setSegmentStatus(
        "이미지를 표시하지 못했습니다.",
        "error"
      );
    };

    image.src =
      `/api/segments/image?path=${
        encodeURIComponent(item.path)
      }&t=${Date.now()}`;
  } catch (error) {
    if (token !== segmentEditor.loadingToken) return;
    setSegmentStatus(error.message, "error");
  }
}

async function loadSegmentImageList() {
  if (segmentEditor.deleting) return;
  const deletionEpoch = segmentEditor.deletionEpoch;
  setSegmentStatus(
    "이미지 목록을 읽고 있습니다."
  );

  try {
    const response = await api(
      "/api/segments/images"
    );
    if (segmentEditor.deleting || deletionEpoch !== segmentEditor.deletionEpoch) return;
    segmentEditor.deletionProjectKey = response.project_key;

    const currentPath =
      segmentEditor.index >= 0
      && segmentEditor.images[segmentEditor.index]
        ? segmentEditor.images[
            segmentEditor.index
          ].path
        : null;

    segmentEditor.images = response.images;

    let nextIndex = segmentEditor.images.findIndex(
      item => item.path === currentPath
    );

    if (
      nextIndex < 0
      && segmentEditor.images.length
    ) {
      nextIndex = 0;
    }

    updateSegmentImageOptions();

    if (!segmentEditor.images.length) {
      setSegmentStatus(
        "라벨링할 이미지가 없습니다.",
        "warn"
      );
      await loadSegmentImage(-1);
      return;
    }

    await loadSegmentImage(nextIndex);
  } catch (error) {
    if (segmentEditor.deleting || deletionEpoch !== segmentEditor.deletionEpoch) return;
    setSegmentStatus(error.message, "error");
  }
}

async function refreshSegmentProject() {
  if (segmentEditor.deleting) return;
  const deletionEpoch = segmentEditor.deletionEpoch;
  try {
    const status = await fetch(
      `/api/status?segment=${Date.now()}`,
      {cache: "no-store"}
    ).then(response => response.json());
    if (segmentEditor.deleting || deletionEpoch !== segmentEditor.deletionEpoch) return;

    const project = status.project;
    const section = document.getElementById(
      "segment-labeler"
    );

    if (
      !project
      || project.task_type !== "segment"
    ) {
      section.hidden = true;
      segmentEditor.projectKey = null;
      return;
    }

    section.hidden = false;

    const classes = project.classes || [];
    const projectKey = JSON.stringify([
      project.paths.photo_directory,
      project.paths.result_directory
    ]);
    const classesChanged =
      JSON.stringify(classes)
      !== JSON.stringify(segmentEditor.classes);
    const projectChanged =
      projectKey !== segmentEditor.projectKey;

    segmentEditor.classes = classes;
    updateSegmentClassOptions();

    const enabled = classes.length > 0;

    document.getElementById(
      "segment-refresh"
    ).disabled = !enabled;
    document.getElementById(
      "segment-class-select"
    ).disabled = !enabled;

    if (!enabled) {
      setSegmentStatus(
        "먼저 클래스를 한 개 이상 등록하세요.",
        "warn"
      );
      return;
    }

    if (projectChanged) {
      segmentEditor.projectKey = projectKey;
      await loadSegmentImageList();
    } else if (classesChanged) {
      renderSegmentEditor();
    }
  } catch (error) {
    if (segmentEditor.deleting || deletionEpoch !== segmentEditor.deletionEpoch) return;
    setSegmentStatus(
      "세그멘테이션 상태 확인 실패: "
      + error.message,
      "error"
    );
  }
}

segmentCanvas.addEventListener(
  "pointerdown",
  async event => {
    if (
      !segmentEditor.imageReady
      || segmentEditor.classes.length === 0
    ) {
      return;
    }

    const point = segmentPointer(event);

    if (segmentEditor.draft.length) {
      const first = {
        x: segmentEditor.draft[0][0],
        y: segmentEditor.draft[0][1]
      };

      if (
        segmentEditor.draft.length >= 3
        && segmentPointDistance(point, first) <= 14
      ) {
        await finishSegmentDraft();
        return;
      }

      segmentEditor.draft.push([
        point.x,
        point.y
      ]);
      renderSegmentEditor();

      setSegmentStatus(
        `작성 중: ${segmentEditor.draft.length}개 점`
      );
      return;
    }

    const vertex = findSegmentVertex(point);

    if (vertex) {
      segmentEditor.selected =
        vertex.polygonIndex;
      segmentEditor.interaction = {
        type: "vertex",
        polygonIndex: vertex.polygonIndex,
        pointIndex: vertex.pointIndex
      };

      syncSegmentClass();
      segmentCanvas.setPointerCapture(
        event.pointerId
      );
      renderSegmentEditor();
      return;
    }

    const polygonIndex = findSegmentPolygon(point);

    if (polygonIndex >= 0) {
      segmentEditor.selected = polygonIndex;
      syncSegmentClass();
      renderSegmentEditor();
      return;
    }

    segmentEditor.selected = -1;
    segmentEditor.draft = [[point.x, point.y]];
    renderSegmentEditor();
    setSegmentStatus("작성 중: 1개 점");
  }
);

segmentCanvas.addEventListener(
  "pointermove",
  event => {
    const action = segmentEditor.interaction;

    if (!action || action.type !== "vertex") {
      return;
    }

    const point = segmentPointer(event);
    segmentEditor.polygons[
      action.polygonIndex
    ].points[action.pointIndex] = [
      point.x,
      point.y
    ];

    renderSegmentEditor();
  }
);

async function finishSegmentPointer(event) {
  if (!segmentEditor.interaction) {
    return;
  }

  segmentEditor.interaction = null;

  try {
    segmentCanvas.releasePointerCapture(
      event.pointerId
    );
  } catch (_) {
  }

  renderSegmentEditor();
  await saveCurrentPolygons();
}

segmentCanvas.addEventListener(
  "pointerup",
  finishSegmentPointer
);
segmentCanvas.addEventListener(
  "pointercancel",
  finishSegmentPointer
);

document.getElementById(
  "segment-image-select"
).onchange = async event => {
  await loadSegmentImage(
    Number(event.target.value)
  );
};

document.getElementById(
  "segment-class-select"
).onchange = async event => {
  if (segmentEditor.selected < 0) {
    return;
  }

  segmentEditor.polygons[
    segmentEditor.selected
  ].class_id = Number(event.target.value);

  renderSegmentEditor();
  await saveCurrentPolygons();
};

document.getElementById(
  "segment-refresh"
).onclick = loadSegmentImageList;

document.getElementById(
  "segment-prev"
).onclick = async () => {
  if (segmentEditor.index > 0) {
    await loadSegmentImage(
      segmentEditor.index - 1
    );
  }
};

document.getElementById(
  "segment-next"
).onclick = async () => {
  if (
    segmentEditor.index >= 0
    && segmentEditor.index
      < segmentEditor.images.length - 1
  ) {
    await loadSegmentImage(
      segmentEditor.index + 1
    );
  }
};

document.getElementById(
  "segment-finish"
).onclick = finishSegmentDraft;

document.getElementById(
  "segment-undo-point"
).onclick = () => {
  if (!segmentEditor.draft.length) {
    return;
  }

  segmentEditor.draft.pop();
  renderSegmentEditor();

  setSegmentStatus(
    segmentEditor.draft.length
      ? `진행 중: ${segmentEditor.draft.length}개 점`
      : "클릭하여 점을 생성하세요."
  );
};

document.getElementById(
  "segment-cancel"
).onclick = () => {
  segmentEditor.draft = [];
  renderSegmentEditor();
  setSegmentStatus(
    "다각형 제작을 취소했습니다."
  );
};

document.getElementById(
  "segment-delete"
).onclick = async () => {
  if (segmentEditor.selected < 0) {
    setSegmentStatus(
      "삭제할 다각형을 먼저 선택하세요.",
      "warn"
    );
    return;
  }

  segmentEditor.polygons.splice(
    segmentEditor.selected,
    1
  );
  segmentEditor.selected = -1;
  renderSegmentEditor();
  await saveCurrentPolygons();
};

document.getElementById(
  "segment-clear"
).onclick = () => permanentlyDeleteImage(
  segmentEditor, 'segment', '/api/segments/delete-image',
  updateSegmentImageOptions, loadSegmentImage, setSegmentStatus
);

segmentCanvas.addEventListener(
  "keydown",
  event => {
    if (event.key === "Escape") {
      event.preventDefault();
      document.getElementById(
        "segment-cancel"
      ).click();
    } else if (
      event.key === "Backspace"
      && segmentEditor.draft.length
    ) {
      event.preventDefault();
      document.getElementById(
        "segment-undo-point"
      ).click();
    } else if (event.key === "Delete") {
      event.preventDefault();
      document.getElementById(
        "segment-delete"
      ).click();
    }
  }
);

renderSegmentEditor();
refreshSegmentProject();
setInterval(refreshSegmentProject, 2000);
</script>

<script>
function renderProjectValidation(result) {
  const output = document.getElementById("validation-summary");

  if (!result) {
    output.className = "validation-summary small";
    output.textContent =
      "아직 검사하지 않았거나 데이터 변경 후 재검사가 필요합니다.";
    return;
  }

  const lines = [
    `작업 유형: ${result.task_type}`,
    `이미지: ${result.image_count}개`,
    `레이블 완료: ${result.labeled_image_count}개`,
    `미작성: ${result.unlabeled_image_count}개`,
    `형식 오류: ${result.invalid_label_count}개`,
    `전체 객체: ${result.object_count}개`,
    `프로젝트 레이블: ${result.project_label_count}개`,
    `외부 레이블: ${result.external_label_count}개`,
    "",
    result.ready_for_training
      ? "YOLO 학습 준비 완료"
      : "경고: 학습 전 수정 필요"
  ];

  if (result.class_statistics.length) {
    lines.push("", "클래스별 객체 수:");
    result.class_statistics.forEach(item => {
      lines.push(
        `- ${item.class_id}: ${item.name}: `
        + `${item.object_count}개`
      );
    });
  }

  if (result.issues.length) {
    lines.push("", "확인할 내용:");
    result.issues.forEach(issue => {
      lines.push("- " + issue);
    });
  }

  output.className =
    "validation-summary small "
    + (
      result.ready_for_training
        ? "validation-ready"
        : "validation-blocked"
    );
  output.textContent = lines.join("\\n");
}

async function refreshProjectValidation() {
  try {
    const status = await fetch(
      `/api/status?validation=${Date.now()}`,
      {cache: "no-store"}
    ).then(response => response.json());

    const active = Boolean(status.project);
    document.getElementById(
      "validate-project"
    ).disabled = !active;

    renderProjectValidation(
      active ? status.project.validation || null : null
    );
  } catch (error) {
    const output = document.getElementById(
      "validation-summary"
    );
    output.className =
      "validation-summary small error";
    output.textContent =
      "검사 상태 확인 실패: " + error.message;
  }
}

document.getElementById(
  "validate-project"
).onclick = async () => {
  const output = document.getElementById(
    "validation-summary"
  );

  output.className = "validation-summary small";
  output.textContent =
    "전체 이미지와 레이블을 검사하고 있습니다...";

  try {
    const response = await api(
      "/api/project/validate"
    );
    renderProjectValidation(response.validation);
  } catch (error) {
    output.className =
      "validation-summary small error";
    output.textContent =
      "검사 실패: " + error.message;
  }
};

refreshProjectValidation();
setInterval(refreshProjectValidation, 2000);
</script>

<script>
/* TRAINING_SETTINGS_UI_LOGIC_STAGE6_6B */
(() => {
  const panel = document.getElementById(
    "training-settings-panel"
  );
  const saveButton = document.getElementById(
    "save-training-settings"
  );
  const result = document.getElementById(
    "training-settings-result"
  );
  const trainPercent = document.getElementById(
    "training-train-percent"
  );
  const valPercent = document.getElementById(
    "training-val-percent"
  );
  const modelName = document.getElementById(
    "training-model-name"
  );
  const modelPath = document.getElementById(
    "training-model-path"
  );
  const storageBox = document.getElementById(
    "training-storage"
  );

  let currentProjectKey = null;
  let loading = false;

  function updateValidationRatio() {
    const train = Number(trainPercent.value);
    valPercent.value = Number.isFinite(train)
      ? Math.max(0, 100 - train)
      : "";
  }

  function setResult(message, kind = "small") {
    result.className = kind;
    result.textContent = message;
  }

  function inputValue(id) {
    return document.getElementById(id).value;
  }

  function collectSettings() {
    return {
      train_ratio:
        Number(inputValue("training-train-percent")) / 100,
      epochs: Number(inputValue("training-epochs")),
      imgsz: Number(inputValue("training-imgsz")),
      batch: Number(inputValue("training-batch")),
      optimizer: inputValue("training-optimizer"),
      lr0: Number(inputValue("training-lr0")),
      patience: Number(inputValue("training-patience")),
      workers: Number(inputValue("training-workers")),
      device: inputValue("training-device"),
      seed: Number(inputValue("training-seed"))
    };
  }

  function renderStorage(storage) {
    if (!storage) {
      storageBox.className = "training-storage-box";
      storageBox.textContent = "저장 공간 정보를 확인할 수 없습니다.";
      return;
    }

    storageBox.className =
      "training-storage-box" +
      (storage.low_space_warning ? " warning" : "");

    storageBox.textContent =
      `결과 저장 장치 여유 공간: ${storage.free_gib} GiB` +
      (
        storage.low_space_warning
          ? " · 5 GiB 미만이므로 학습 전 공간 정리를 권장합니다."
          : " · 학습 가능"
      );
  }

  function renderSettings(response, taskType) {
    const settings = response.settings || {};
    const path = settings.model_path || "";
    const filename = path.split("/").pop() || "확인 불가";

    modelName.textContent =
      taskType === "segment"
        ? `세그멘테이션 · ${filename}`
        : `객체 탐지 · ${filename}`;
    modelPath.textContent = path;

    trainPercent.value = Math.round(
      Number(settings.train_ratio ?? 0.8) * 100
    );
    updateValidationRatio();

    document.getElementById("training-epochs").value =
      settings.epochs ?? 100;
    document.getElementById("training-imgsz").value =
      settings.imgsz ?? 640;
    document.getElementById("training-batch").value =
      settings.batch ?? 16;
    document.getElementById("training-optimizer").value = settings.optimizer ?? "SGD";
    document.getElementById("training-lr0").value =
      settings.lr0 ?? 0.01;
    document.getElementById("training-patience").value =
      settings.patience ?? 50;
    document.getElementById("training-workers").value =
      settings.workers ?? 2;
    document.getElementById("training-device").value =
      String(settings.device ?? "0");
    document.getElementById("training-seed").value =
      settings.seed ?? 0;

    renderStorage(response.storage);

    setResult(
      response.saved
        ? "폴더 쌍에 저장된 학습 설정을 복원했습니다."
        : "기본 설정입니다. 확인 후 저장하세요.",
      response.saved ? "ok" : "small"
    );
  }

  async function loadSettings(taskType) {
    if (loading) return;
    loading = true;
    saveButton.disabled = true;

    try {
      const response = await fetch(
        `/api/training/settings?t=${Date.now()}`,
        {cache: "no-store"}
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "학습 설정 조회 실패");
      }

      renderSettings(data, taskType);
      saveButton.disabled = false;
    } catch (error) {
      setResult(error.message, "error");
    } finally {
      loading = false;
    }
  }

  async function refreshTrainingProject() {
    try {
      const response = await fetch(
        `/api/status?training=${Date.now()}`,
        {cache: "no-store"}
      );
      const status = await response.json();
      const project = status.project;

      if (!project || !project.active) {
        panel.hidden = true;
        saveButton.disabled = true;
        currentProjectKey = null;
        return;
      }

      panel.hidden = false;

      const paths = project.paths || {};
      const projectKey =
        paths.project_key ||
        JSON.stringify([
          paths.photo_directory,
          paths.result_directory
        ]);

      if (projectKey !== currentProjectKey) {
        currentProjectKey = projectKey;
        await loadSettings(project.task_type);
      }
    } catch (error) {
      panel.hidden = false;
      saveButton.disabled = true;
      setResult(error.message, "error");
    }
  }

  trainPercent.addEventListener(
    "input",
    updateValidationRatio
  );

  saveButton.addEventListener("click", async () => {
    saveButton.disabled = true;
    setResult("학습 설정을 검사하고 저장하는 중입니다.");

    try {
      const response = await api(
        "/api/training/settings",
        {settings: collectSettings()}
      );

      renderSettings(
        {
          settings: response.settings,
          storage: response.storage,
          saved: true
        },
        response.settings.task_type
      );
      setResult(
        "학습 설정이 저장되었습니다.",
        "ok"
      );
    } catch (error) {
      setResult(error.message, "error");
    } finally {
      saveButton.disabled = false;
    }
  });

  updateValidationRatio();
  refreshTrainingProject();
  setInterval(refreshTrainingProject, 1000);
})();
</script>


<script>
/* TRAINING_PROGRESS_UI_LOGIC_STAGE6_6E1 */
(() => {
  const panel = document.getElementById(
    "training-process-panel"
  );
  const startButton = document.getElementById(
    "start-yolo-training"
  );
  const cancelButton = document.getElementById(
    "cancel-yolo-training"
  );
  const statusText = document.getElementById(
    "training-process-status"
  );
  const progressBar = document.getElementById(
    "training-progress-bar"
  );
  const progressText = document.getElementById(
    "training-progress-text"
  );
  const runDirectory = document.getElementById(
    "training-run-directory"
  );
  const bestPath = document.getElementById(
    "training-best-path"
  );
  const message = document.getElementById(
    "training-process-message"
  );
  const canvas = document.getElementById(
    "training-progress-canvas"
  );
  const dialog = document.getElementById(
    "training-complete-dialog"
  );

  const activeStates = new Set([
    "queued",
    "starting",
    "running"
  ]);

  let activeProjectKey = null;
  let currentRunDirectory = null;
  let completedDialogRun = null;
  let requestRunning = false;

  function setMessage(value, kind = "small") {
    message.className = kind;
    message.textContent = value;
  }

  function statusLabel(status) {
    const labels = {
      idle: "학습 시작 전",
      queued: "학습 준비 중",
      starting: "모델 불러오는 중",
      running: "학습 진행 중",
      completed: "학습 완료",
      failed: "학습 실패",
      cancelled: "학습 중단됨",
      interrupted: "학습 프로세스 비정상 종료"
    };
    return labels[status] || status || "상태 확인 중";
  }

  function drawGraph(history, taskType) {
    const rows = Array.isArray(history) ? history : [];
    const segment = taskType === 'segment';
    const mapKey = segment ? 'metrics/mAP50-95(M)' : 'metrics/mAP50-95(B)';
    const mapLabel = segment ? 'mAP50-95 · 마스크 (M)' : 'mAP50-95 · 박스 (B)';
    document.getElementById('yolo-map-legend').textContent = mapLabel + ' · 검증';
    const definitions = [
      {key: mapKey, color: '#71304f'},
      {key: 'val/box_loss', color: '#267d78'},
      {key: 'val/cls_loss', color: '#a66b22'},
    ];
    const target = document.getElementById('training-progress-canvas');
    if (!target) return;
    const context = target.getContext("2d"), width = target.width, height = target.height;
    context.clearRect(0, 0, width, height);
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, height);
    const left = 66, top = 30, plotWidth = width - left - 24, plotHeight = height - top - 44;
    const series = definitions.map(definition => {
      const points = rows.map(item => {
        const raw = (item.metrics || {})[definition.key];
        const value = raw === null || raw === undefined || raw === '' ? NaN : Number(raw);
        return {epoch: Number(item.epoch), value};
      });
      const valid = points.filter(p => Number.isFinite(p.epoch) && p.epoch >= 1 && Number.isFinite(p.value));
      const low = valid.length ? Math.min(...valid.map(p => p.value)) : 0;
      const high = valid.length ? Math.max(...valid.map(p => p.value)) : 0;
      // Constant (including one-point) series have no trend; display at the middle.
      const position = value => high > low ? (value - low) / (high - low) : 0.5;
      return {...definition, points, valid, position};
    });
    const maxEpoch = Math.max(2, ...rows.map(item => Number(item.epoch)).filter(Number.isFinite));
    context.font = "13px sans-serif";
    context.fillStyle = "#657179"; context.textAlign = "left";
    context.fillText("상대 변화 (지표별 0~1)", left, 16);
    for (let tick = 0; tick <= 4; tick++) {
      const y = top + tick * plotHeight / 4;
      context.strokeStyle = "#e5eaec";
      context.lineWidth = 1;
      context.beginPath(); context.moveTo(left, y); context.lineTo(left + plotWidth, y); context.stroke();
      context.fillStyle = "#657179"; context.textAlign = "right";
      context.fillText((1 - tick / 4).toFixed(2), left - 10, y + 4);
    }
    context.strokeStyle = "#c7d0d4"; context.strokeRect(left, top, plotWidth, plotHeight);
    context.fillStyle = "#657179"; context.textAlign = "left";
    context.fillText("1", left, height - 22);
    context.textAlign = "right"; context.fillText(String(maxEpoch), left + plotWidth, height - 22);
    context.textAlign = "center"; context.fillText("epoch", left + plotWidth / 2, height - 9);
    if (!series.some(line => line.valid.length)) {
      context.fillText("검증 지표 대기 중", left + plotWidth / 2, top + plotHeight / 2);
      context.textAlign = "left";
      return;
    }
    for (const line of series) {
      if (!line.valid.length) continue;
      context.strokeStyle = line.color; context.fillStyle = line.color; context.lineWidth = 2.5;
      context.beginPath();
      let pen = false;
      for (const p of line.points) {
        if (!Number.isFinite(p.value) || !Number.isFinite(p.epoch) || p.epoch < 1) { pen = false; continue; }
        const x = left + (p.epoch - 1) / (maxEpoch - 1) * plotWidth;
        const y = top + (1 - line.position(p.value)) * plotHeight;
        if (pen) context.lineTo(x, y); else context.moveTo(x, y);
        pen = true;
      }
      context.stroke();
      const last = line.valid[line.valid.length - 1];
      const x = left + (last.epoch - 1) / (maxEpoch - 1) * plotWidth;
      const y = top + (1 - line.position(last.value)) * plotHeight;
      context.beginPath(); context.arc(x, y, 3.5, 0, Math.PI * 2); context.fill();
    }
    context.textAlign = "left";
  }

  function showCompletion(state) {
    const run = state.run_directory || "";
    if (!run || completedDialogRun === run) return;

    completedDialogRun = run;
    document.getElementById(
      "training-complete-best"
    ).textContent = `best.pt: ${state.best_pt || "확인 불가"}`;
    document.getElementById(
      "training-complete-run"
    ).textContent = `결과 폴더: ${run}`;

    if (typeof dialog.showModal === "function") {
      dialog.showModal();
    } else {
      window.alert(
        `YOLO 학습 완료\nbest.pt: ${state.best_pt || ""}`
      );
    }
  }

  function renderTrainingState(state) {
    const status = state.status || "idle";
    const current = Number(state.current_epoch || 0);
    const total = Number(state.total_epochs || 0);
    const percent = Math.max(
      0,
      Math.min(100, Number(state.progress_percent || 0))
    );
    const active = activeStates.has(status);

    statusText.textContent = statusLabel(status);
    statusText.className =
      status === "completed"
        ? "ok"
        : (
            ["failed", "interrupted"].includes(status)
              ? "error"
              : "small"
          );

    progressBar.style.width = `${percent}%`;
    progressText.textContent =
      `${current} / ${total} epochs · ${percent.toFixed(1)}%`;

    currentRunDirectory = state.run_directory || null;
    runDirectory.textContent =
      currentRunDirectory || "학습 시작 전";
    bestPath.textContent = state.best_pt
      ? `best.pt: ${state.best_pt}`
      : "best.pt 생성 전";

    cancelButton.disabled = !active;
    drawGraph(state.history || [], state.task_type);

    if (status === "completed") {
      setMessage(
        "학습과 모델 저장이 정상적으로 완료되었습니다.",
        "ok"
      );
      showCompletion(state);
    } else if (
      ["failed", "interrupted"].includes(status)
    ) {
      setMessage(
        state.error || "학습 중 오류가 발생했습니다.",
        "error"
      );
    } else if (status === "cancelled") {
      setMessage("학습이 중단되었습니다.", "small");
    }
  }

  async function fetchTrainingState() {
    const response = await fetch(
      `/api/training/status?t=${Date.now()}`,
      {cache: "no-store"}
    );
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "학습 상태 조회 실패");
    }
    return data;
  }

  async function refreshTrainingProcess() {
    if (requestRunning) return;

    try {
      const statusResponse = await fetch(
        `/api/status?training_process=${Date.now()}`,
        {cache: "no-store"}
      );
      const appStatus = await statusResponse.json();
      const project = appStatus.project;

      if (!project || !project.active) {
        panel.hidden = true;
        startButton.disabled = true;
        cancelButton.disabled = true;
        activeProjectKey = null;
        return;
      }

      panel.hidden = false;

      const paths = project.paths || {};
      const projectKey =
        paths.project_key ||
        JSON.stringify([
          paths.photo_directory,
          paths.result_directory
        ]);

      if (projectKey !== activeProjectKey) {
        activeProjectKey = projectKey;
        completedDialogRun = null;
        currentRunDirectory = null;
        drawGraph([]);
      }

      const settingsResponse = await fetch(
        `/api/training/settings?ready=${Date.now()}`,
        {cache: "no-store"}
      );
      const settings = await settingsResponse.json();

      let state = {
        status: "idle",
        current_epoch: 0,
        total_epochs:
          Number((settings.settings || {}).epochs || 0),
        progress_percent: 0,
        history: [],
        run_directory: null
      };

      try {
        state = await fetchTrainingState();
      } catch (error) {
        if ((project.training || {}).run_directory) {
          throw error;
        }
      }

      renderTrainingState(state);

      const workflow = project.workflow_step || "";
      const validationReady =
        Boolean(
          (project.validation || {}).ready_for_training
        ) ||
        [
          "validated",
          "training_settings",
          "dataset_ready",
          "training",
          "training_complete"
        ].includes(workflow);

      const settingsSaved = Boolean(settings.saved);
      const active = activeStates.has(state.status);

      startButton.disabled =
        !validationReady || !settingsSaved || active;

      if (!validationReady) {
        setMessage(
          "현재 프로젝트 전체 검사를 통과하세요.",
          "small"
        );
      } else if (!settingsSaved) {
        setMessage(
          "학습 설정을 확인하고 저장하세요.",
          "small"
        );
      } else if (state.status === "idle") {
        setMessage(
          "학습 준비가 완료되었습니다.",
          "ok"
        );
      }
    } catch (error) {
      startButton.disabled = true;
      setMessage(error.message, "error");
    }
  }

  startButton.addEventListener("click", async () => {
    if (requestRunning) return;
    requestRunning = true;
    startButton.disabled = true;
    setMessage(
      "최신 레이블로 데이터셋을 구성하고 학습을 시작합니다."
    );

    try {
      const response = await api("/api/training/start");
      renderTrainingState(response.training);
      setMessage(
        "YOLO 학습 프로세스를 시작했습니다.",
        "ok"
      );
    } catch (error) {
      setMessage(error.message, "error");
    } finally {
      requestRunning = false;
      await refreshTrainingProcess();
    }
  });

  cancelButton.addEventListener("click", async () => {
    if (requestRunning) return;
    requestRunning = true;
    cancelButton.disabled = true;

    try {
      const response = await api("/api/training/cancel");
      renderTrainingState(response);
    } catch (error) {
      setMessage(error.message, "error");
    } finally {
      requestRunning = false;
      await refreshTrainingProcess();
    }
  });

  document.getElementById(
    "close-training-dialog"
  ).addEventListener("click", () => {
    dialog.close();
  });

  drawGraph([]);
  refreshTrainingProcess();
  setInterval(refreshTrainingProcess, 1000);
})();
</script>


<script>
/* PROJECT_VALIDATION_UI_FINAL */
(() => {
  const button = document.getElementById("validate-project");
  const output = document.getElementById("validation-summary");
  if (!button || !output) return;
  function render(validation) {
    const lines = [
      "검사 완료: " + (validation.ready_for_training ? "학습 준비 완료" : "수정 필요"),
      "이미지: " + validation.image_count + "개",
      "레이블 완료: " + validation.labeled_image_count + "개",
      "미작성: " + validation.unlabeled_image_count + "개",
      "형식 오류: " + validation.invalid_label_count + "개",
      "전체 객체: " + validation.object_count + "개",
      "클래스: " + validation.class_count + "개"
    ];
    output.className = "validation-summary small " + (validation.ready_for_training ? "validation-ready" : "validation-blocked");
    output.textContent = lines.join("\\n");
  }
  button.disabled = false;
  button.onclick = async () => {
    button.disabled = true;
    output.className = "validation-summary small";
    output.textContent = "전체 데이터를 검사 중입니다...";
    try {
      const response = await fetch("/api/project/validate", {method:"POST",body:"{}",cache:"no-store"});
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "검사 요청에 실패했습니다.");
      render(payload.validation);
    } catch (error) {
      output.className = "validation-summary small error";
      output.textContent = "검사 실패: " + error.message;
    } finally {
      button.disabled = false;
    }
  };
})();
</script>

<script>
/* EDUCATION_LEADER_UI_RECOMPOSE_STAGE9 */
(() => {
  const style = document.createElement("style");
  style.id = "education-leader-ui-recompose-stage9";
  style.textContent = [
    ".project-capture-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:stretch}",
    ".project-card,.rgb-card,.project-card label{min-width:0}",
    ".project-card{display:flex;flex-direction:column}",
    ".project-card>label{margin-top:10px}",
    ".project-card input,.project-card select{box-sizing:border-box;width:100%;min-height:38px}",
    ".project-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}",
    ".project-actions button{margin:0!important;min-height:36px}",
    "#inspect{background:var(--teal)!important}",
    "#new,.ui-refresh,.ui-nav{background:var(--accent)!important}",
    "#resume{background:var(--primary)!important}",
    "#notice{margin-top:auto;margin-bottom:0;min-height:2.7em;line-height:1.4;overflow-wrap:anywhere;color:var(--muted)}",
    "#notice.small,#notice.ok{color:#75858b}",
    ".rgb-card{display:flex;flex-direction:column}",
    ".rgb-card-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}",
    ".rgb-card-header h2{margin:0}",
    "#capture{display:inline-flex;align-items:center;justify-content:center;gap:7px;margin:0!important;white-space:nowrap;background:var(--accent)!important}",
    "#preview{display:block;width:100%;aspect-ratio:4/3;max-height:none;object-fit:cover;background:#0b1116;border-radius:6px}",
    "#camera{margin:10px 0 0;color:#7a858a}",
    ".vehicle-pill{white-space:nowrap}",
    ".ui-icon-button{display:inline-flex!important;align-items:center;justify-content:center;gap:7px;white-space:nowrap}",
    ".ui-icon{width:15px;height:15px;display:block;flex:0 0 auto}",
    ".capture-icon{width:16px;height:16px}",
    ".box-action-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:12px 0}",
    ".box-action-end{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px}",
    ".box-navigation{display:flex;justify-content:center;gap:8px;margin:12px 0 2px}",
    ".box-action-row button,.box-navigation button{margin:0!important;min-height:36px}",
    ".ui-delete{background:#a94d43!important;color:#fff!important}",
    ".ui-delete:hover{background:#8f3e36!important}",
    "#box-prev .ui-icon{transform:rotate(180deg)}",
    ".training-settings>p.small{display:none!important}",
    ".training-settings h2{margin-bottom:16px}",
    ".training-settings-grid .device-setting{grid-column:1/-1}",
    "#training-settings-result.ok{color:#65b8d0}",
    "#training-process-message{display:none!important}",
    ".training-process-actions button:disabled{background:#bac4c8!important;border-color:#b1bcc1!important;color:#657178!important;opacity:1;cursor:not-allowed}",
    ".training-graph-wrap{position:relative}",
    ".training-legend{position:absolute;z-index:2;top:8px;left:58px;right:24px;display:flex;align-items:center;flex-wrap:wrap;gap:8px 18px;min-height:20px;padding:2px 4px;background:rgba(2,6,23,.96);pointer-events:none}",
    ".training-legend-item{display:inline-flex;align-items:center;gap:6px;color:#d7e0e5;font-size:12px;font-weight:700;line-height:1.3}",
    ".training-legend-dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex:0 0 auto}",
    "@media(max-width:760px){.project-capture-grid{grid-template-columns:1fr}.box-action-row{align-items:stretch;flex-direction:column}.box-action-end{justify-content:flex-start}.training-legend{left:16px;right:16px}.rgb-card-header{align-items:flex-start;flex-direction:column}#capture{align-self:flex-end}}"
  ].join("\\n");
  document.head.appendChild(style);

  const icons = {
    camera: '<svg class="ui-icon capture-icon" viewBox="0 0 32 26" fill="none" aria-hidden="true"><path d="M16.0595 19.8887C19.1646 19.8887 21.6818 17.3715 21.6818 14.2664C21.6818 11.1613 19.1646 8.64404 16.0595 8.64404C12.9543 8.64404 10.4371 11.1613 10.4371 14.2664C10.4371 17.3715 12.9543 19.8887 16.0595 19.8887Z" stroke="currentColor" stroke-width="2.23069"/><path d="M28.1119 3.37343H24.4248L23.5566 0.769141C23.4026 0.309196 22.9742 0 22.4896 0H8.99588C8.51126 0 8.08168 0.309196 7.92987 0.769141L7.06058 3.37343H3.37343C1.51351 3.37343 0 4.88694 0 6.74685V22.4895C0 24.3494 1.51351 25.8629 3.37343 25.8629H28.1119C29.9718 25.8629 31.4854 24.3494 31.4854 22.4895V6.74685C31.4854 4.88694 29.9718 3.37343 28.1119 3.37343ZM29.2364 22.4895C29.2364 23.109 28.7326 23.614 28.1119 23.614H3.37343C2.75272 23.614 2.24892 23.1091 2.24892 22.4895V6.74685C2.24892 6.1273 2.75272 5.62234 3.37343 5.62234H7.87137C8.35598 5.62234 8.7844 5.31315 8.93737 4.8532L9.80655 2.24892H21.6799L22.548 4.8532C22.6998 5.31315 23.1294 5.62234 23.614 5.62234H28.1119C28.7326 5.62234 29.2364 6.1272 29.2364 6.74685V22.4895Z" fill="currentColor"/></svg>',
    refresh: '<svg class="ui-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M11.9305 22.6678C17.8607 22.6678 22.6679 17.8605 22.6679 11.9303C22.6679 9.18026 21.634 6.67168 19.9338 4.77202L16.7027 1.19287M16.7027 7.15812V1.19287H22.6679M11.9305 1.19287C6.00037 1.19287 1.19305 6.00019 1.19305 11.9303C1.19305 14.6804 2.2269 17.1889 3.92713 19.0886L7.15829 22.6678M7.15829 16.7025V22.6678H1.19305" stroke="currentColor" stroke-width="2.3861" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    cube: '<svg class="ui-icon" viewBox="0 0 21 23" fill="none" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.89155 0.3612C9.36139 0.123763 9.88105 0 10.4082 0C10.9353 0 11.4549 0.123763 11.9248 0.3612L19.8008 4.34428C20.4253 4.66045 20.8163 5.29573 20.8163 5.99011V15.9138C20.8163 16.886 20.2662 17.7769 19.3949 18.2186L11.9248 21.9963C11.4546 22.2342 10.9344 22.3583 10.4067 22.3583C9.879 22.3583 9.3588 22.2342 8.88857 21.9963L1.41997 18.2186C0.992377 18.0019 0.633427 17.672 0.382822 17.2652C0.132218 16.8585 -0.000274336 16.3908 4.26485e-07 15.9138V5.99011C4.26485e-07 5.29573 0.392537 4.66045 1.01554 4.34428L8.89155 0.3612ZM10.9137 2.33649C10.7571 2.25735 10.5839 2.21609 10.4082 2.21609C10.2325 2.21609 10.0592 2.25735 9.90262 2.33649L3.30682 5.67247L10.4082 9.20052L17.5095 5.67247L10.9137 2.33649ZM2.23032 15.9138V7.61526L9.293 11.1241V19.7137L2.43402 16.2418C2.37297 16.2111 2.32165 16.1642 2.2857 16.1063C2.24976 16.0485 2.2306 15.9819 2.23032 15.9138ZM11.5233 19.7137L18.3823 16.2418C18.4434 16.2111 18.4947 16.1642 18.5306 16.1063C18.5666 16.0485 18.5857 15.9819 18.586 15.9138V7.61526L11.5233 11.1241V19.7137Z" fill="currentColor"/></svg>',
    image: '<svg class="ui-icon" viewBox="0 0 22 22" fill="none" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M21.5873 2.94372C21.5873 1.31795 20.2694 0 18.6436 0H2.94372C1.31795 0 0 1.31795 0 2.94372V18.6436C0 20.2694 1.31795 21.5873 2.94372 21.5873H18.6436C20.2694 21.5873 21.5873 20.2694 21.5873 18.6436V2.94372ZM19.6248 2.94372C19.6248 2.4018 19.1855 1.96248 18.6436 1.96248H2.94372C2.4018 1.96248 1.96248 2.4018 1.96248 2.94372V18.6436C1.96248 19.1855 2.4018 19.6248 2.94372 19.6248H18.6436C19.1855 19.6248 19.6248 19.1855 19.6248 18.6436V2.94372Z" fill="currentColor"/><path d="M3.73522 16.2111L7.96971 8.44789C8.34162 7.76607 9.32068 7.76607 9.69258 8.44789L12.8017 14.148L13.8667 12.2845C14.2434 11.6253 15.1938 11.6253 15.5705 12.2845L17.8047 16.1942C18.1784 16.8483 17.7061 17.6623 16.9527 17.6623H4.59664C3.85182 17.6623 3.37855 16.865 3.73522 16.2111Z" fill="currentColor"/><path d="M16.6812 6.86873C16.6812 7.95258 15.8026 8.83121 14.7187 8.83121C13.6348 8.83121 12.7562 7.95258 12.7562 6.86873C12.7562 5.78488 13.6348 4.90625 14.7187 4.90625C15.8026 4.90625 16.6812 5.78488 16.6812 6.86873Z" fill="currentColor"/></svg>',
    next: '<svg class="ui-icon" viewBox="0 0 15 18" fill="none" aria-hidden="true"><path d="M15 9L0 0.339744L0 17.6603L15 9Z" fill="currentColor"/></svg>'
  };

  function applyIcon(button, icon, label, className) {
    if (!button) return;
    button.className = className;
    button.innerHTML = icons[icon] + '<span>' + label + '</span>';
  }

  const projectGrid = Array.from(document.querySelectorAll('.grid')).find(grid => grid.querySelector('#photo') && grid.querySelector('#preview'));
  if (projectGrid) {
    projectGrid.classList.add('project-capture-grid');
    const cards = Array.from(projectGrid.children).filter(node => node.tagName === 'SECTION');
    const projectCard = cards.find(card => card.querySelector('#photo'));
    const rgbCard = cards.find(card => card.querySelector('#preview'));
    const notice = document.getElementById('notice');
    if (projectCard) {
      projectCard.classList.add('project-card');
      if (!projectCard.querySelector('.project-actions') && notice) {
        const actions = document.createElement('div');
        actions.className = 'project-actions';
        ['inspect', 'new', 'resume'].forEach(id => {
          const button = document.getElementById(id);
          if (button) actions.appendChild(button);
        });
        projectCard.insertBefore(actions, notice);
      }
      if (notice) projectCard.appendChild(notice);
    }
    if (rgbCard) {
      rgbCard.classList.add('rgb-card');
      const capture = document.getElementById('capture');
      const title = rgbCard.querySelector('h2');
      const preview = document.getElementById('preview');
      if (!rgbCard.querySelector('.rgb-card-header') && title && capture && preview) {
        const header = document.createElement('div');
        header.className = 'rgb-card-header';
        header.append(title, capture);
        rgbCard.insertBefore(header, preview);
      }
      applyIcon(capture, 'camera', '촬영', 'ui-icon-button');
    }
  }

  const boxSection = document.getElementById('box-labeler');
  if (boxSection) {
    const oldButtons = boxSection.querySelector('.box-buttons');
    const refresh = document.getElementById('box-refresh');
    const previous = document.getElementById('box-prev');
    const next = document.getElementById('box-next');
    const removeBox = document.getElementById('box-delete');
    const removeImage = document.getElementById('box-clear');
    if (oldButtons && !boxSection.querySelector('.box-action-row')) {
      const row = document.createElement('div');
      row.className = 'box-action-row';
      const end = document.createElement('div');
      end.className = 'box-action-end';
      if (refresh) row.appendChild(refresh);
      if (removeBox) end.appendChild(removeBox);
      if (removeImage) end.appendChild(removeImage);
      row.appendChild(end);
      oldButtons.replaceWith(row);
      const navigation = document.createElement('div');
      navigation.className = 'box-navigation';
      if (previous) navigation.appendChild(previous);
      if (next) navigation.appendChild(next);
      const canvasNode = document.getElementById('box-canvas');
      const canvasWrap = canvasNode ? canvasNode.closest('.box-canvas-wrap') : null;
      if (canvasWrap) canvasWrap.after(navigation);
      else row.after(navigation);
    }
    applyIcon(refresh, 'refresh', '이미지 목록 갱신', 'ui-icon-button ui-refresh');
    applyIcon(removeBox, 'cube', '선택 박스 삭제', 'ui-icon-button ui-delete');
    applyIcon(removeImage, 'image', '현재 이미지 삭제', 'ui-icon-button ui-delete');
    applyIcon(previous, 'next', '이전', 'ui-icon-button ui-nav');
    applyIcon(next, 'next', '다음', 'ui-icon-button ui-nav');
    if (removeImage && !removeImage.dataset.confirmDelete) {
      removeImage.dataset.confirmDelete = 'true';
      removeImage.addEventListener('click', event => {
        if (!window.confirm('현재 이미지의 모든 박스 레이블을 삭제할까요?')) {
          event.preventDefault();
          event.stopImmediatePropagation();
        }
      }, true);
    }
  }

  const settingsPanel = document.getElementById('training-settings-panel');
  if (settingsPanel) {
    const description = Array.from(settingsPanel.children).find(node => node.tagName === 'P');
    if (description) description.remove();
    const hiddenFixedValues = document.createElement('div');
    hiddenFixedValues.hidden = true;
    ['training-imgsz', 'training-patience', 'training-workers', 'training-seed'].forEach(id => {
      const field = document.getElementById(id);
      const label = field ? field.closest('label') : null;
      if (field && label) {
        hiddenFixedValues.appendChild(field);
        label.remove();
      }
    });
    settingsPanel.appendChild(hiddenFixedValues);
    const deviceInput = document.getElementById('training-device');
    if (deviceInput) {
      const deviceLabel = deviceInput.closest('label');
      if (deviceLabel) deviceLabel.classList.add('device-setting');
    }
  }

})();
</script>
</body></html>"""

# YOLO_UI_SETTINGS_PATCH_V2
