"""Validation and persistence for YOLO training settings."""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Dict, Mapping

from my_supervised._internal.model_paths import resolve_yolo_model


DETECT_MODEL = Path(
    "/home/jetson/ultralytics/ultralytics/yolo11n.pt"
)
SEGMENT_MODEL = Path(
    "/home/jetson/ultralytics/ultralytics/yolo11n-seg.pt"
)

SETTINGS_FILENAME = "training_settings.json"

DEFAULT_SETTINGS: Dict[str, Any] = {
    "train_ratio": 0.8,
    "epochs": 100,
    "imgsz": 640,
    "batch": 16,
    "optimizer": "SGD",
    "lr0": 0.01,
    "patience": 50,
    "workers": 2,
    "device": "0",
    "seed": 0,
}

MINIMUM_FREE_BYTES = 2 * 1024 ** 3
LOW_SPACE_WARNING_BYTES = 5 * 1024 ** 3


class TrainingSettingsError(ValueError):
    """Raised when a training setting or storage location is invalid."""


class TrainingSettingsStore:
    """Validate and persist task-specific YOLO training settings."""

    @staticmethod
    def model_path_for_task(task_type: str) -> Path:
        task = str(task_type).strip().lower()

        if task not in ("detect", "segment"):
            raise TrainingSettingsError(
                "작업 유형은 detect 또는 segment여야 합니다."
            )
        try:
            return resolve_yolo_model(task=task)
        except FileNotFoundError as error:
            raise TrainingSettingsError(str(error)) from error

    @classmethod
    def defaults(cls, task_type: str) -> Dict[str, Any]:
        settings = dict(DEFAULT_SETTINGS)
        settings["task_type"] = str(task_type).strip().lower()
        settings["model_path"] = str(
            cls.model_path_for_task(task_type).resolve()
        )
        settings["save_period"] = 10
        settings["val_ratio"] = round(
            1.0 - float(settings["train_ratio"]), 6
        )
        return settings

    @classmethod
    def validate(
        cls,
        task_type: str,
        values: Mapping[str, Any],
    ) -> Dict[str, Any]:
        defaults = cls.defaults(task_type)
        merged = dict(defaults)
        merged.update(dict(values))
        # FIXED_EDUCATIONAL_SETTINGS_STAGE8
        # These values are curriculum constants and are not student inputs.
        for fixed_key in ("imgsz", "patience", "workers", "seed"):
            merged[fixed_key] = defaults[fixed_key]

        try:
            train_ratio = float(merged["train_ratio"])
            epochs = int(merged["epochs"])
            imgsz = int(merged["imgsz"])
            batch = int(merged["batch"])
            lr0 = float(merged["lr0"])
            patience = int(merged["patience"])
            workers = int(merged["workers"])
            seed = int(merged["seed"])
        except (TypeError, ValueError, KeyError) as exc:
            raise TrainingSettingsError(
                "학습 설정에는 올바른 숫자를 입력해야 합니다."
            ) from exc

        optimizer = str(merged.get("optimizer", "SGD")).strip()
        if optimizer not in {"SGD", "Adam", "NesterovSGD"}:
            raise TrainingSettingsError("옵티마이저는 SGD, Adam, NesterovSGD 중에서 선택하세요.")

        device = str(merged.get("device", "0")).strip().lower()

        if not 0.50 <= train_ratio <= 0.95:
            raise TrainingSettingsError(
                "훈련 데이터 비율은 0.50~0.95 범위여야 합니다."
            )

        if not 1 <= epochs <= 500:
            raise TrainingSettingsError(
                "epochs는 1~500 범위여야 합니다."
            )

        if not 320 <= imgsz <= 1280 or imgsz % 32 != 0:
            raise TrainingSettingsError(
                "imgsz는 320~1280 범위의 32 배수여야 합니다."
            )

        if not 1 <= batch <= 64:
            raise TrainingSettingsError(
                "batch는 1~64 범위여야 합니다."
            )

        if not 0.000001 <= lr0 <= 0.1:
            raise TrainingSettingsError(
                "초기 학습률 lr0는 0.000001~0.1 범위여야 합니다."
            )

        if not 0 <= patience <= 500:
            raise TrainingSettingsError(
                "patience는 0~500 범위여야 합니다."
            )

        if not 0 <= workers <= 8:
            raise TrainingSettingsError(
                "workers는 0~8 범위여야 합니다."
            )

        if device not in {"0", "cpu"}:
            raise TrainingSettingsError(
                "device는 0(GPU) 또는 cpu만 사용할 수 있습니다."
            )

        if not 0 <= seed <= 2147483647:
            raise TrainingSettingsError(
                "seed는 0 이상의 정수여야 합니다."
            )

        task = str(task_type).strip().lower()
        model_path = cls.model_path_for_task(task)

        return {
            "task_type": task,
            "model_path": str(model_path.resolve()),
            "train_ratio": round(train_ratio, 6),
            "val_ratio": round(1.0 - train_ratio, 6),
            "epochs": epochs,
            "imgsz": imgsz,
            "batch": batch,
            "optimizer": optimizer,
            "lr0": lr0,
            "patience": patience,
            "workers": workers,
            "device": device,
            "seed": seed,
            # 사용자가 변경하지 않는 고정 요구사항
            "save_period": 10,
        }

    @staticmethod
    def inspect_storage(result_directory: str) -> Dict[str, Any]:
        result_path = Path(result_directory).expanduser()

        if not result_path.is_absolute():
            raise TrainingSettingsError(
                "결과 저장 폴더는 절대경로로 지정해야 합니다."
            )

        try:
            result_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise TrainingSettingsError(
                f"결과 저장 폴더를 준비할 수 없습니다: {exc}"
            ) from exc

        if not result_path.is_dir():
            raise TrainingSettingsError(
                "결과 저장 경로가 폴더가 아닙니다."
            )

        if not os.access(result_path, os.W_OK):
            raise TrainingSettingsError(
                "결과 저장 폴더에 쓰기 권한이 없습니다."
            )

        usage = shutil.disk_usage(result_path)

        if usage.free < MINIMUM_FREE_BYTES:
            raise TrainingSettingsError(
                "학습을 시작하려면 결과 저장 장치에 "
                "최소 2 GiB의 여유 공간이 필요합니다."
            )

        return {
            "result_directory": str(result_path.resolve()),
            "total_bytes": int(usage.total),
            "used_bytes": int(usage.used),
            "free_bytes": int(usage.free),
            "free_gib": round(usage.free / 1024 ** 3, 2),
            "low_space_warning": usage.free < LOW_SPACE_WARNING_BYTES,
        }

    @classmethod
    def save(
        cls,
        project_directory: str,
        result_directory: str,
        task_type: str,
        values: Mapping[str, Any],
    ) -> Dict[str, Any]:
        project_path = Path(project_directory).expanduser().resolve()

        if not project_path.is_dir():
            raise TrainingSettingsError(
                "활성 프로젝트 폴더를 찾을 수 없습니다."
            )

        settings = cls.validate(task_type, values)
        storage = cls.inspect_storage(result_directory)

        document = {
            "version": 1,
            "settings": settings,
            "storage": storage,
        }

        destination = project_path / SETTINGS_FILENAME
        temporary = project_path / f".{SETTINGS_FILENAME}.tmp"

        temporary.write_text(
            json.dumps(
                document,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        temporary.replace(destination)

        return {
            "settings_path": str(destination),
            **document,
        }

    @classmethod
    def load(
        cls,
        project_directory: str,
        task_type: str,
    ) -> Dict[str, Any]:
        project_path = Path(project_directory).expanduser().resolve()
        source = project_path / SETTINGS_FILENAME

        if not source.is_file():
            return {
                "saved": False,
                "settings_path": str(source),
                "settings": cls.defaults(task_type),
            }

        try:
            document = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise TrainingSettingsError(
                f"저장된 학습 설정을 읽을 수 없습니다: {exc}"
            ) from exc

        saved_settings = document.get("settings")
        if not isinstance(saved_settings, dict):
            raise TrainingSettingsError(
                "저장된 학습 설정 형식이 올바르지 않습니다."
            )

        validated = cls.validate(task_type, saved_settings)

        return {
            "saved": True,
            "settings_path": str(source),
            "settings": validated,
            "storage": document.get("storage"),
        }

# YOLO_UI_SETTINGS_PATCH_V2
