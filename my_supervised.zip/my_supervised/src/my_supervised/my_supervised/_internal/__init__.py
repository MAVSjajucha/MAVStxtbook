"""Internal implementation modules.

Students should write driving rules only in decision_node.py.
"""
