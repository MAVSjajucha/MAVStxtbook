"""Delete one selected project image without following filesystem links."""

from contextlib import ExitStack
import os
from pathlib import Path
import stat

from my_supervised._internal.box_label_store import BoxLabelError
from my_supervised._internal.dataset_import import IMAGE_SUFFIXES


def _open_parent(stack, root, relative, missing_ok=False):
    """Anchor each directory component with no-follow directory descriptors."""
    root = Path(root)
    if not root.is_absolute():
        raise BoxLabelError("삭제 폴더는 절대 경로여야 합니다.")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    descriptor = os.open(root.anchor, flags)
    stack.callback(os.close, descriptor)
    try:
        for name in (*root.parts[1:], *relative.parts[:-1]):
            if name in {".", ".."}:
                raise BoxLabelError("삭제 경로에 상위 폴더 이동을 사용할 수 없습니다.")
            descriptor = os.open(name, flags, dir_fd=descriptor)
            stack.callback(os.close, descriptor)
        info = os.stat(relative.name, dir_fd=descriptor, follow_symlinks=False)
    except FileNotFoundError:
        if missing_ok:
            return None
        raise
    if not stat.S_ISREG(info.st_mode):
        raise BoxLabelError("일반 파일만 삭제할 수 있습니다. 심볼릭 링크는 삭제하지 않습니다.")
    return descriptor, relative.name, info


def _unlink_checked(target):
    descriptor, name, original = target
    current = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
    if (current.st_dev, current.st_ino, current.st_mode) != (
        original.st_dev, original.st_ino, original.st_mode
    ):
        raise BoxLabelError("삭제 대상이 변경되었습니다. 이미지 목록을 새로고침하세요.")
    os.unlink(name, dir_fd=descriptor)


def delete_project_image(photo_root, annotation_root, image_path, task_type, before_delete=None):
    """Permanently delete the image and its unshared project annotation only.

    Imported/original labels and already-built datasets/model outputs are not
    deleted. Callers must invalidate cached validation/dataset metadata.
    """
    if not isinstance(image_path, str) or not image_path or "\\" in image_path:
        raise BoxLabelError("이미지 상대 경로가 올바르지 않습니다.")
    relative = Path(image_path)
    if relative.is_absolute() or ".." in relative.parts or relative.suffix.lower() not in IMAGE_SUFFIXES:
        raise BoxLabelError("사진 폴더 안의 이미지 상대 경로만 삭제할 수 있습니다.")
    if task_type not in {"detect", "segment"}:
        raise BoxLabelError("YOLO 작업 유형이 올바르지 않습니다.")

    try:
        with ExitStack() as stack:
            image = _open_parent(stack, photo_root, relative)
            shared_label = any(
                name != relative.name
                and Path(name).stem == relative.stem
                and Path(name).suffix.lower() in IMAGE_SUFFIXES
                and stat.S_ISREG(os.stat(name, dir_fd=image[0], follow_symlinks=False).st_mode)
                for name in os.listdir(image[0])
            )
            label_relative = (Path(task_type) / relative).with_suffix(".txt")
            label = None if shared_label else _open_parent(
                stack, annotation_root, label_relative, missing_ok=True,
            )
            # Validate both targets before removing either file. unlink(dir_fd=)
            # never follows a final-component symlink outside these roots.
            if before_delete is not None:
                before_delete()
            _unlink_checked(image)
            warning = None
            if label is not None:
                try:
                    _unlink_checked(label)
                except (OSError, BoxLabelError) as error:
                    warning = f"이미지는 삭제되었지만 프로젝트 라벨 정리에 실패했습니다: {error}"
            return {
                "deleted_image": relative.as_posix(),
                "deleted_project_label": label is not None and warning is None,
                "shared_project_label_preserved": shared_label,
                "warning": warning,
            }
    except (OSError, ValueError) as error:
        raise BoxLabelError(
            f"이미지를 삭제하지 못했습니다. 경로·파일 권한을 확인하세요: {error}"
        ) from error
