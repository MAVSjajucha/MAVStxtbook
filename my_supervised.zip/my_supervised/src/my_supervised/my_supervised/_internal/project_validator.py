"""Validate a labeled YOLO project before dataset creation."""

from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Sequence

from my_supervised._internal.box_label_store import (
    BoxLabelError,
    BoxLabelStore,
)
from my_supervised._internal.polygon_label_store import (
    PolygonLabelError,
    PolygonLabelStore,
)


MAX_ISSUES = 100


class ProjectValidationError(RuntimeError):
    """Raised when project validation cannot be performed."""


class ProjectValidator:
    """Validate detection or segmentation labels without changing them."""

    def __init__(self) -> None:
        self._box_store = BoxLabelStore()
        self._polygon_store = PolygonLabelStore()

    def validate(
        self,
        photo_directory: Path,
        annotation_directory: Path,
        task_type: str,
        classes: Sequence[str],
    ) -> Dict[str, object]:
        if task_type == "detect":
            store = self._box_store
            value_key = "boxes"
        elif task_type == "segment":
            store = self._polygon_store
            value_key = "polygons"
        else:
            raise ProjectValidationError(
                "작업 유형은 detect 또는 segment여야 합니다."
            )

        photo_root = Path(photo_directory).resolve()
        annotation_root = Path(annotation_directory).resolve()

        try:
            listing = store.list_images(
                photo_root,
                annotation_root,
            )
        except (BoxLabelError, OSError) as error:
            raise ProjectValidationError(
                f"이미지 목록을 검사할 수 없습니다: {error}"
            ) from error

        images = listing["images"]
        issues: List[str] = []
        labeled_count = 0
        unlabeled_count = 0
        invalid_count = 0
        object_count = 0
        project_label_count = 0
        external_label_count = 0
        class_counts = [0 for _ in classes]

        if not classes:
            issues.append(
                "등록된 클래스가 없습니다."
            )

        if len(images) < 2:
            issues.append(
                "훈련·검증 분리를 위해 이미지가 최소 2개 필요합니다."
            )

        for item in images:
            image_path = item["path"]
            source = item["label_source"]

            if source == "none":
                unlabeled_count += 1
                if len(issues) < MAX_ISSUES:
                    issues.append(
                        f"레이블 미작성: {image_path}"
                    )
                continue

            if source == "project":
                project_label_count += 1
            elif source == "external":
                external_label_count += 1

            try:
                loaded = store.load(
                    photo_root,
                    annotation_root,
                    image_path,
                    len(classes),
                )
            except (
                BoxLabelError,
                PolygonLabelError,
                OSError,
            ) as error:
                invalid_count += 1
                if len(issues) < MAX_ISSUES:
                    issues.append(
                        f"레이블 오류: {image_path}: {error}"
                    )
                continue

            labeled_count += 1
            values = loaded[value_key]
            object_count += len(values)

            for value in values:
                class_id = int(value["class_id"])
                if 0 <= class_id < len(class_counts):
                    class_counts[class_id] += 1

        if unlabeled_count:
            issues.insert(
                0,
                f"레이블이 작성되지 않은 이미지가 "
                f"{unlabeled_count}개 있습니다.",
            )

        if invalid_count:
            issues.insert(
                0,
                f"형식이 잘못된 레이블이 "
                f"{invalid_count}개 있습니다.",
            )

        if object_count == 0:
            issues.insert(
                0,
                "학습할 객체 레이블이 하나도 없습니다.",
            )

        ready = (
            bool(classes)
            and len(images) >= 2
            and unlabeled_count == 0
            and invalid_count == 0
            and object_count > 0
        )

        return {
            "task_type": task_type,
            "checked_at": datetime.now(
                timezone.utc
            ).isoformat(),
            "ready_for_training": ready,
            "image_count": len(images),
            "labeled_image_count": labeled_count,
            "unlabeled_image_count": unlabeled_count,
            "invalid_label_count": invalid_count,
            "object_count": object_count,
            "project_label_count": project_label_count,
            "external_label_count": external_label_count,
            "class_count": len(classes),
            "class_statistics": [
                {
                    "class_id": index,
                    "name": name,
                    "object_count": class_counts[index],
                }
                for index, name in enumerate(classes)
            ],
            "issues": issues[:MAX_ISSUES],
            "source_files_modified": False,
        }
