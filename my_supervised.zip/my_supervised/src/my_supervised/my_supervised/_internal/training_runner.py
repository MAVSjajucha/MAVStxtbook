"""Prepare, launch, inspect, and cancel YOLO training processes."""

from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
from threading import Lock
from typing import Any, Dict, Mapping, Optional
from uuid import uuid4

from my_supervised._internal.training_settings import (
    TrainingSettingsError,
    TrainingSettingsStore,
)
from my_supervised._internal.training_worker import (
    STATE_FILENAME,
)


OUTPUT_DIRECTORY_NAME = "my_supervised_training"
JOB_FILENAME = "training_job.json"
LOG_FILENAME = "training.log"

_ACTIVE_STATES = {"queued", "starting", "running"}


class TrainingRunnerError(RuntimeError):
    """Raised when a training process cannot be managed safely."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(
            dict(value),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise TrainingRunnerError(
            f"학습 상태 파일을 읽을 수 없습니다: {path}: {error}"
        ) from error

    if not isinstance(value, dict):
        raise TrainingRunnerError(
            f"학습 상태 파일 형식이 올바르지 않습니다: {path}"
        )
    return value


def _pid_alive(pid: Any) -> bool:
    try:
        numeric_pid = int(pid)
    except (TypeError, ValueError):
        return False

    if numeric_pid <= 0:
        return False

    try:
        os.kill(numeric_pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _is_expected_worker(pid: Any, config_path: Path) -> bool:
    """Protect against terminating an unrelated process after PID reuse."""
    try:
        numeric_pid = int(pid)
    except (TypeError, ValueError):
        return False

    command_path = Path(f"/proc/{numeric_pid}/cmdline")

    try:
        command = command_path.read_bytes().replace(
            b"\x00",
            b" ",
        ).decode("utf-8", errors="replace")
    except OSError:
        return False

    return (
        "my_supervised._internal.training_worker"
        in command
        and str(config_path) in command
    )


class TrainingRunner:
    """Manage at most one training subprocess for this server."""

    def __init__(self) -> None:
        self._lock = Lock()
        self._process: Optional[subprocess.Popen] = None
        self._active_run_directory: Optional[Path] = None

    @staticmethod
    def _find_running_job(output_root: Path) -> Optional[Path]:
        if not output_root.is_dir():
            return None

        for state_path in sorted(
            output_root.glob(f"*/{STATE_FILENAME}")
        ):
            try:
                state = _read_json(state_path)
            except TrainingRunnerError:
                continue

            if state.get("status") not in _ACTIVE_STATES:
                continue

            config_path = state_path.parent / JOB_FILENAME
            pid = state.get("pid")

            if (
                _pid_alive(pid)
                and _is_expected_worker(pid, config_path)
            ):
                return state_path.parent

        return None

    def prepare_job(
        self,
        task_type: str,
        data_yaml: str,
        result_directory: str,
        settings: Mapping[str, Any],
    ) -> Dict[str, Any]:
        """Create a unique visible result folder and queued job files."""
        task = str(task_type).strip().lower()

        try:
            checked_settings = TrainingSettingsStore.validate(
                task,
                settings,
            )
            storage = TrainingSettingsStore.inspect_storage(
                result_directory
            )
        except TrainingSettingsError as error:
            raise TrainingRunnerError(str(error)) from error

        data_path = Path(data_yaml).expanduser()
        if not data_path.is_absolute() or not data_path.is_file():
            raise TrainingRunnerError(
                f"유효한 data.yaml 파일이 아닙니다: {data_path}"
            )
        data_path = data_path.resolve()

        result_root = Path(
            storage["result_directory"]
        ).resolve()
        output_root = result_root / OUTPUT_DIRECTORY_NAME
        output_root.mkdir(parents=True, exist_ok=True)

        running_job = self._find_running_job(output_root)
        if running_job is not None:
            raise TrainingRunnerError(
                f"이미 실행 중인 학습이 있습니다: {running_job}"
            )

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_name = f"{task}_{stamp}_{uuid4().hex[:6]}"
        run_directory = output_root / run_name
        run_directory.mkdir(parents=False, exist_ok=False)

        configuration = {
            "schema_version": 1,
            "created_at": _utc_now(),
            "task_type": task,
            "data_yaml": str(data_path),
            "run_directory": str(run_directory),
            "settings": checked_settings,
        }

        config_path = run_directory / JOB_FILENAME
        state_path = run_directory / STATE_FILENAME
        log_path = run_directory / LOG_FILENAME

        _write_json(config_path, configuration)
        _write_json(
            state_path,
            {
                "schema_version": 1,
                "status": "queued",
                "task_type": task,
                "model_path": checked_settings["model_path"],
                "data_yaml": str(data_path),
                "run_directory": str(run_directory),
                "pid": None,
                "created_at": _utc_now(),
                "updated_at": _utc_now(),
                "current_epoch": 0,
                "total_epochs": checked_settings["epochs"],
                "progress_percent": 0.0,
                "history": [],
                "best_pt": None,
                "last_pt": None,
                "error": None,
            },
        )

        return {
            "ok": True,
            "status": "queued",
            "task_type": task,
            "run_directory": str(run_directory),
            "config_path": str(config_path),
            "state_path": str(state_path),
            "log_path": str(log_path),
            "storage": storage,
        }

    def start(
        self,
        task_type: str,
        data_yaml: str,
        result_directory: str,
        settings: Mapping[str, Any],
    ) -> Dict[str, Any]:
        """Start a separate training worker process."""
        with self._lock:
            if (
                self._process is not None
                and self._process.poll() is None
            ):
                raise TrainingRunnerError(
                    "현재 서버에서 이미 학습이 실행 중입니다."
                )

            job = self.prepare_job(
                task_type=task_type,
                data_yaml=data_yaml,
                result_directory=result_directory,
                settings=settings,
            )

            config_path = Path(job["config_path"])
            log_path = Path(job["log_path"])
            state_path = Path(job["state_path"])

            command = [
                sys.executable,
                "-m",
                (
                    "my_supervised._internal."
                    "training_worker"
                ),
                "--config",
                str(config_path),
            ]

            try:
                with log_path.open(
                    "ab",
                    buffering=0,
                ) as log_file:
                    process = subprocess.Popen(
                        command,
                        stdin=subprocess.DEVNULL,
                        stdout=log_file,
                        stderr=subprocess.STDOUT,
                        cwd=job["run_directory"],
                        start_new_session=True,
                        close_fds=True,
                    )
            except OSError as error:
                state = _read_json(state_path)
                state.update(
                    {
                        "status": "failed",
                        "updated_at": _utc_now(),
                        "error": (
                            "학습 프로세스를 시작할 수 없습니다: "
                            f"{error}"
                        ),
                    }
                )
                _write_json(state_path, state)
                raise TrainingRunnerError(
                    state["error"]
                ) from error

            self._process = process
            self._active_run_directory = Path(
                job["run_directory"]
            )

            # 작업자가 먼저 상태를 갱신했다면 덮어쓰지 않는다.
            state = _read_json(state_path)
            if state.get("status") == "queued":
                state["pid"] = process.pid
                state["updated_at"] = _utc_now()
                _write_json(state_path, state)

            job["pid"] = process.pid
            job["status"] = "starting"
            return job

    def status(
        self,
        run_directory: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Read persistent state even after a browser refresh."""
        if run_directory:
            run_path = Path(run_directory).expanduser().resolve()
        else:
            with self._lock:
                run_path = self._active_run_directory

        if run_path is None:
            return {
                "ok": True,
                "status": "idle",
                "run_directory": None,
                "process_alive": False,
            }

        state_path = run_path / STATE_FILENAME
        if not state_path.is_file():
            raise TrainingRunnerError(
                f"학습 상태 파일이 없습니다: {state_path}"
            )

        state = _read_json(state_path)
        pid = state.get("pid")
        config_path = run_path / JOB_FILENAME
        process_alive = (
            _pid_alive(pid)
            and _is_expected_worker(pid, config_path)
        )

        if (
            state.get("status") in _ACTIVE_STATES
            and pid is not None
            and not process_alive
        ):
            state.update(
                {
                    "status": "interrupted",
                    "updated_at": _utc_now(),
                    "error": (
                        "학습 프로세스가 정상 완료 전에 종료되었습니다."
                    ),
                }
            )
            _write_json(state_path, state)

        state["ok"] = True
        state["process_alive"] = process_alive
        state["state_path"] = str(state_path)
        state["log_path"] = str(run_path / LOG_FILENAME)
        return state

    def cancel(self, run_directory: str) -> Dict[str, Any]:
        """Stop only the verified worker process for this training run."""
        run_path = Path(run_directory).expanduser().resolve()
        state_path = run_path / STATE_FILENAME
        config_path = run_path / JOB_FILENAME
        state = _read_json(state_path)

        if state.get("status") not in _ACTIVE_STATES:
            return self.status(str(run_path))

        pid = state.get("pid")
        if not _is_expected_worker(pid, config_path):
            raise TrainingRunnerError(
                "대상 학습 프로세스를 안전하게 확인하지 못했습니다."
            )

        try:
            os.killpg(int(pid), signal.SIGTERM)
        except ProcessLookupError:
            pass
        except OSError as error:
            raise TrainingRunnerError(
                f"학습 프로세스를 중단할 수 없습니다: {error}"
            ) from error

        state.update(
            {
                "status": "cancelled",
                "updated_at": _utc_now(),
                "completed_at": _utc_now(),
                "error": "사용자 요청으로 학습이 중단되었습니다.",
            }
        )
        _write_json(state_path, state)

        with self._lock:
            if self._active_run_directory == run_path:
                self._active_run_directory = run_path

        state["ok"] = True
        state["process_alive"] = False
        state["state_path"] = str(state_path)
        state["log_path"] = str(run_path / LOG_FILENAME)
        return state
