"""One latest JPEG shared by all viewers; no unbounded video queues."""

import threading
import time


class LatestJpeg:
    def __init__(self):
        self.condition = threading.Condition()
        self.data = b""
        self.sequence = 0
        self.updated_at = None
        self.viewers = 0
        self.closed = False

    def update(self, data):
        with self.condition:
            self.data = bytes(data)
            self.sequence += 1
            self.updated_at = time.monotonic()
            self.condition.notify_all()

    def wait(self, sequence, timeout=1.0):
        with self.condition:
            self.condition.wait_for(lambda: self.sequence != sequence or self.closed, timeout)
            return self.sequence, self.data

    def close(self):
        with self.condition:
            self.closed = True
            self.condition.notify_all()


def send_mjpeg(handler, frames):
    handler.connection.settimeout(3.0)
    handler.send_response(200)
    handler.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
    handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
    handler.end_headers()
    with frames.condition:
        frames.viewers += 1
    sequence = -1
    try:
        while not frames.closed:
            next_sequence, data = frames.wait(sequence)
            changed = next_sequence != sequence
            sequence = next_sequence
            if not data or not changed:
                continue
            header = ("--frame\r\nContent-Type: image/jpeg\r\n"
                      f"Content-Length: {len(data)}\r\n\r\n").encode("ascii")
            handler.wfile.write(header + data + b"\r\n")
            handler.wfile.flush()
    except (OSError, TimeoutError):
        pass
    finally:
        with frames.condition:
            frames.viewers -= 1
        handler.close_connection = True
