"""Read-only inspection of external YOLO datasets."""

from math import isfinite
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence


IMAGE_SUFFIXES = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".webp",
    ".tif",
    ".tiff",
}
MAX_FILES = 100000
MAX_DEPTH = 6
MAX_REPORTED_ISSUES = 50


class DatasetImportError(RuntimeError):
    """Raised when an external dataset cannot be inspected safely."""


def _walk_files(root: Path) -> Iterable[Path]:
    root_depth = len(root.parts)
    found = 0

    for current, directories, filenames in os.walk(
        root,
        followlinks=False,
    ):
        current_path = Path(current)
        depth = len(current_path.parts) - root_depth

        directories[:] = [
            name
            for name in directories
            if not name.startswith(".")
            and name != "__pycache__"
            and depth < MAX_DEPTH
        ]

        for filename in filenames:
            if filename.startswith("."):
                continue

            found += 1
            if found > MAX_FILES:
                raise DatasetImportError(
                    "선택한 폴더의 파일이 100000개를 초과합니다."
                )

            yield current_path / filename


def _label_candidates(root: Path, image: Path) -> List[Path]:
    relative = image.relative_to(root)
    candidates = [
        image.with_suffix(".txt"),
        root / "labels" / relative.with_suffix(".txt"),
    ]

    parts = list(relative.parts)
    for index, part in enumerate(parts):
        if part.lower() == "images":
            changed = list(parts)
            changed[index] = "labels"
            candidates.append(
                root.joinpath(*changed).with_suffix(".txt")
            )

    if root.name.lower() == "images":
        candidates.append(
            root.parent
            / "labels"
            / relative.with_suffix(".txt")
        )

    unique = []
    seen = set()

    for candidate in candidates:
        identity = str(candidate.resolve(strict=False))
        if identity not in seen:
            seen.add(identity)
            unique.append(candidate)

    return unique


def _find_label(root: Path, image: Path) -> Optional[Path]:
    for candidate in _label_candidates(root, image):
        if candidate.is_file():
            return candidate
    return None


def _validate_label_file(
    label_path: Path,
    task_type: str,
) -> Dict[str, object]:
    issues: List[str] = []
    class_ids = set()
    object_count = 0

    try:
        lines = label_path.read_text(
            encoding="utf-8"
        ).splitlines()
    except (OSError, UnicodeDecodeError) as error:
        return {
            "valid": False,
            "object_count": 0,
            "class_ids": [],
            "issues": [
                f"{label_path}: 읽을 수 없습니다: {error}"
            ],
        }

    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line:
            continue

        tokens = line.split()

        if task_type == "detect":
            valid_length = len(tokens) == 5
            expected = "class x_center y_center width height"
        else:
            valid_length = (
                len(tokens) >= 7
                and len(tokens) % 2 == 1
            )
            expected = (
                "class x1 y1 x2 y2 x3 y3 ..."
            )

        if not valid_length:
            issues.append(
                f"{label_path}:{line_number}: "
                f"{task_type} 형식이 아닙니다. "
                f"필요 형식: {expected}"
            )
            continue

        try:
            class_id = int(tokens[0])
        except ValueError:
            issues.append(
                f"{label_path}:{line_number}: "
                "클래스 번호가 정수가 아닙니다."
            )
            continue

        if class_id < 0:
            issues.append(
                f"{label_path}:{line_number}: "
                "클래스 번호는 0 이상이어야 합니다."
            )
            continue

        try:
            coordinates = [
                float(value)
                for value in tokens[1:]
            ]
        except ValueError:
            issues.append(
                f"{label_path}:{line_number}: "
                "좌표에 숫자가 아닌 값이 있습니다."
            )
            continue

        if any(
            not isfinite(value)
            or value < 0.0
            or value > 1.0
            for value in coordinates
        ):
            issues.append(
                f"{label_path}:{line_number}: "
                "YOLO 정규화 좌표는 0~1 범위여야 합니다."
            )
            continue

        class_ids.add(class_id)
        object_count += 1

    return {
        "valid": not issues,
        "object_count": object_count,
        "class_ids": sorted(class_ids),
        "issues": issues,
    }


def scan_external_dataset(
    photo_directory: Path,
    task_type: str,
    registered_classes: Sequence[str],
) -> Dict[str, object]:
    """Inspect without copying or modifying source images and labels."""
    root = Path(photo_directory).expanduser().resolve()

    if task_type not in {"detect", "segment"}:
        raise DatasetImportError(
            "YOLO 작업 유형은 detect 또는 segment여야 합니다."
        )
    if not root.is_dir():
        raise DatasetImportError(
            f"사진 폴더가 존재하지 않습니다: {root}"
        )

    all_files = list(_walk_files(root))
    images = sorted(
        path
        for path in all_files
        if path.suffix.lower() in IMAGE_SUFFIXES
    )

    if not images:
        raise DatasetImportError(
            "선택한 사진 폴더에서 이미지를 찾지 못했습니다."
        )

    matched_labels = 0
    unlabeled_images = 0
    valid_label_files = 0
    invalid_label_files = 0
    object_count = 0
    class_ids = set()
    issues: List[str] = []
    labels_directories = set()

    for image in images:
        label = _find_label(root, image)

        if label is None:
            unlabeled_images += 1
            continue

        matched_labels += 1
        labels_directories.add(str(label.parent))

        checked = _validate_label_file(
            label,
            task_type,
        )

        object_count += int(checked["object_count"])
        class_ids.update(checked["class_ids"])

        if checked["valid"]:
            valid_label_files += 1
        else:
            invalid_label_files += 1
            remaining = (
                MAX_REPORTED_ISSUES - len(issues)
            )
            if remaining > 0:
                issues.extend(
                    checked["issues"][:remaining]
                )

    highest_class_id = (
        max(class_ids)
        if class_ids
        else None
    )
    required_class_count = (
        highest_class_id + 1
        if highest_class_id is not None
        else 0
    )

    if (
        registered_classes
        and required_class_count
        > len(registered_classes)
    ):
        issues.append(
            "레이블에 사용된 클래스 번호가 등록된 "
            "클래스 개수를 초과합니다."
        )

    yaml_files = sorted(
        str(path)
        for path in all_files
        if path.name.lower()
        in {"data.yaml", "data.yml", "dataset.yaml", "dataset.yml"}
    )[:10]

    compatible = (
        invalid_label_files == 0
        and (
            not registered_classes
            or required_class_count
            <= len(registered_classes)
        )
    )

    return {
        "task_type": task_type,
        "root_directory": str(root),
        "image_count": len(images),
        "matched_label_files": matched_labels,
        "valid_label_files": valid_label_files,
        "invalid_label_files": invalid_label_files,
        "unlabeled_images": unlabeled_images,
        "object_count": object_count,
        "class_ids": sorted(class_ids),
        "required_class_count": required_class_count,
        "registered_class_count": len(registered_classes),
        "labels_directories": sorted(labels_directories),
        "yaml_files": yaml_files,
        "compatible": compatible,
        "issues": issues[:MAX_REPORTED_ISSUES],
        "source_files_modified": False,
    }
