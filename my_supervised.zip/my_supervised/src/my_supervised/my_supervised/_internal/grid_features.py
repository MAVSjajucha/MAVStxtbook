"""Chapter 1 grid features, shared unchanged between recording and driving."""

from collections.abc import Mapping
import numbers

DEFAULT_GRID = {
    "processing_width": 640,
    "processing_height": 480,
    "rows": 3,
    "cols": 7,
    "roi_b": 50,
    "roi_t": 150,
    "ths1": 100,
    "ths2": 300,
    "ker_size": 5,
}

VERTICAL_LINE_BGR = (0, 255, 255)
HORIZONTAL_LINE_BGR = (255, 246, 0)
V_POINT_BGR = (0, 0, 255)
L_POINT_BGR = (130, 160, 0)
R_POINT_BGR = (227, 110, 0)


def validate_grid(config):
    """Return complete settings and reject invalid or duplicate grid lines."""
    if not isinstance(config, Mapping):
        raise ValueError("격자 설정은 이름과 정수 값으로 구성해야 합니다.")
    unknown = set(config) - set(DEFAULT_GRID)
    if unknown:
        raise ValueError("알 수 없는 격자 설정: " + ", ".join(sorted(unknown)))
    result = dict(DEFAULT_GRID)
    for key, value in config.items():
        if isinstance(value, bool) or not isinstance(value, numbers.Integral):
            raise ValueError(f"{key}: 정수를 입력하세요.")
        result[key] = int(value)
    width, height = result["processing_width"], result["processing_height"]
    if not (2 <= width <= 4096 and 2 <= height <= 4096):
        raise ValueError("영상 너비와 높이는 2~4096 픽셀이어야 합니다.")
    if not 0 <= result["roi_b"] < result["roi_t"] <= height:
        raise ValueError("ROI는 0 <= roi_b < roi_t <= 영상 높이여야 합니다.")
    roi_height = result["roi_t"] - result["roi_b"]
    if not 1 <= result["rows"] < roi_height:
        raise ValueError("rows는 1 이상, ROI 높이보다 작아야 합니다.")
    if not 1 <= result["cols"] < width:
        raise ValueError("cols는 1 이상, 영상 너비보다 작아야 합니다.")
    if not 0 <= result["ths1"] < result["ths2"] <= 65535:
        raise ValueError("Canny 임곗값은 0 <= ths1 < ths2 <= 65535여야 합니다.")
    kernel = result["ker_size"]
    if kernel <= 0 or kernel % 2 == 0 or kernel > min(width, height):
        raise ValueError("ker_size는 영상 크기 이하의 양의 홀수여야 합니다.")
    return result


def process_grid(image_bgr, config, draw=True):
    """Extract the original V/L/R distances and optionally draw their grid.

    ROI heights are measured upward from the image bottom. L/R are ordered
    bottom to top, V left to right. No-hit is ROI height + 1 for V and width // 2 + 1 for both L/R.
    """
    import cv2
    import numpy as np

    settings = validate_grid(config)
    if (not isinstance(image_bgr, np.ndarray) or image_bgr.dtype != np.uint8
            or image_bgr.ndim != 3 or image_bgr.shape[2] != 3
            or image_bgr.size == 0):
        raise ValueError("image_bgr은 비어 있지 않은 uint8 BGR 영상이어야 합니다.")
    width = settings["processing_width"]
    height = settings["processing_height"]
    image = image_bgr
    if image.shape[:2] != (height, width):
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_LINEAR)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    kernel = settings["ker_size"]
    blurred = cv2.GaussianBlur(gray, (kernel, kernel), 0)
    edges = cv2.Canny(blurred, settings["ths1"], settings["ths2"])
    top = height - settings["roi_t"]
    bottom = height - settings["roi_b"]
    roi_height = bottom - top
    center = width // 2
    horizontal_y = [
        height - 1 - (settings["roi_b"] + round(
            (index + 1) * roi_height / (settings["rows"] + 1)))
        for index in range(settings["rows"])
    ]
    vertical_x = [
        round((index + 1) * width / (settings["cols"] + 1))
        for index in range(settings["cols"])
    ]
    features = {
        "V": [], "L": [], "R": [],
        "V_NO_HIT": roi_height + 1, "L_NO_HIT": center + 1,
        "R_NO_HIT": center + 1,
    }
    for y in horizontal_y:
        left = np.flatnonzero(edges[y, :center + 1])
        right = np.flatnonzero(edges[y, center:])
        features["L"].append(center - int(left[-1]) if left.size else features["L_NO_HIT"])
        features["R"].append(int(right[0]) if right.size else features["R_NO_HIT"])
    for x in vertical_x:
        hits = np.flatnonzero(edges[top:bottom, x])
        features["V"].append(roi_height - 1 - int(hits[-1]) if hits.size else features["V_NO_HIT"])
    if not draw:
        return image, features
    rendered = image.copy()
    rendered[top:bottom][edges[top:bottom] > 0] = (255, 255, 255)
    for x in vertical_x:
        cv2.line(rendered, (x, top), (x, bottom - 1), VERTICAL_LINE_BGR, 1)
    for index, y in enumerate(horizontal_y):
        cv2.line(rendered, (0, y), (width - 1, y), HORIZONTAL_LINE_BGR, 1)
    for index, y in enumerate(horizontal_y):
        if features["L"][index] != features["L_NO_HIT"]:
            cv2.circle(rendered, (center - features["L"][index], y), 5, L_POINT_BGR, -1)
        if features["R"][index] != features["R_NO_HIT"]:
            cv2.circle(rendered, (center + features["R"][index], y), 5, R_POINT_BGR, -1)
    for index, x in enumerate(vertical_x):
        if features["V"][index] != features["V_NO_HIT"]:
            cv2.circle(rendered, (x, bottom - 1 - features["V"][index]), 5, V_POINT_BGR, -1)
    return rendered, features
