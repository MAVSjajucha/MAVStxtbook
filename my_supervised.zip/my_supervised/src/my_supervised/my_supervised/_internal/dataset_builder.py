"""Build a derived YOLO train/validation dataset safely."""

from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path, PurePosixPath
import random
import shutil
from typing import Dict, List, Sequence, Tuple
from uuid import uuid4

from my_supervised._internal.box_label_store import (
    BoxLabelError,
    BoxLabelStore,
)
from my_supervised._internal.polygon_label_store import (
    PolygonLabelError,
    PolygonLabelStore,
)
from my_supervised._internal.project_validator import (
    ProjectValidationError,
    ProjectValidator,
)


class DatasetBuildError(RuntimeError):
    """Raised when a safe training dataset cannot be built."""


class DatasetBuilder:
    """Create a deterministic YOLO dataset without editing source data."""

    def __init__(self) -> None:
        self._box_store = BoxLabelStore()
        self._polygon_store = PolygonLabelStore()
        self._validator = ProjectValidator()

    @staticmethod
    def _safe_relative_path(value: str) -> Path:
        pure = PurePosixPath(str(value))

        if pure.is_absolute() or ".." in pure.parts:
            raise DatasetBuildError(
                f"안전하지 않은 이미지 상대경로입니다: {value}"
            )

        relative = Path(*pure.parts)
        if not relative.parts:
            raise DatasetBuildError(
                "비어 있는 이미지 경로가 발견되었습니다."
            )
        return relative

    @staticmethod
    def _format_number(value) -> str:
        number = float(value)
        if not 0.0 <= number <= 1.0:
            raise DatasetBuildError(
                f"정규화 좌표가 0~1 범위를 벗어났습니다: {number}"
            )
        return f"{number:.8f}"

    @classmethod
    def _box_lines(
        cls,
        boxes: Sequence[Dict[str, object]],
    ) -> List[str]:
        lines = []

        for box in boxes:
            class_id = int(box["class_id"])
            if class_id < 0:
                raise DatasetBuildError(
                    "음수 클래스 ID는 사용할 수 없습니다."
                )

            lines.append(
                " ".join(
                    [
                        str(class_id),
                        cls._format_number(box["x"]),
                        cls._format_number(box["y"]),
                        cls._format_number(box["width"]),
                        cls._format_number(box["height"]),
                    ]
                )
            )

        return lines

    @classmethod
    def _polygon_lines(
        cls,
        polygons: Sequence[Dict[str, object]],
    ) -> List[str]:
        lines = []

        for polygon in polygons:
            class_id = int(polygon["class_id"])
            if class_id < 0:
                raise DatasetBuildError(
                    "음수 클래스 ID는 사용할 수 없습니다."
                )

            points = polygon.get("points", [])
            if len(points) < 3:
                raise DatasetBuildError(
                    "세그멘테이션 다각형에는 점이 최소 3개 필요합니다."
                )

            tokens = [str(class_id)]
            for point in points:
                if len(point) != 2:
                    raise DatasetBuildError(
                        "다각형 점 좌표 형식이 올바르지 않습니다."
                    )
                tokens.append(cls._format_number(point[0]))
                tokens.append(cls._format_number(point[1]))

            lines.append(" ".join(tokens))

        return lines

    @staticmethod
    def _link_image(source: Path, target: Path) -> str:
        """Prefer a hard link; use a symbolic link across filesystems."""
        target.parent.mkdir(parents=True, exist_ok=True)

        try:
            os.link(source, target)
            return "hardlink"
        except OSError:
            try:
                target.symlink_to(source)
                return "symlink"
            except OSError as error:
                raise DatasetBuildError(
                    f"이미지 링크를 만들 수 없습니다: "
                    f"{source} -> {target}: {error}"
                ) from error

    @staticmethod
    def _write_label(target: Path, lines: Sequence[str]) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        content = "\n".join(lines)
        if content:
            content += "\n"
        target.write_text(content, encoding="utf-8")

    @staticmethod
    def _write_data_yaml(
        dataset_root: Path,
        classes: Sequence[str],
        declared_root=None,
    ) -> Path:
        # DATASET_FINAL_PATH_FIX_STAGE6_6E2
        # 파일은 임시 staging 폴더에 작성하되 data.yaml에는
        # 원자적 이동 이후의 최종 dataset 경로를 기록한다.
        yaml_path = dataset_root / "data.yaml"
        yaml_root = (
            dataset_root
            if declared_root is None
            else Path(declared_root)
        )
        lines = [
            f"path: {json.dumps(str(yaml_root), ensure_ascii=False)}",
            "train: images/train",
            "val: images/val",
            f"nc: {len(classes)}",
            "names:",
        ]

        for class_id, name in enumerate(classes):
            lines.append(
                f"  {class_id}: "
                f"{json.dumps(str(name), ensure_ascii=False)}"
            )

        yaml_path.write_text(
            "\n".join(lines) + "\n",
            encoding="utf-8",
        )
        return yaml_path

    @staticmethod
    def _split_items(
        items: Sequence[Dict[str, object]],
        train_ratio: float,
        seed: int,
    ) -> Tuple[List[Dict[str, object]], List[Dict[str, object]]]:
        if len(items) < 2:
            raise DatasetBuildError(
                "훈련·검증 분리를 위해 이미지가 최소 2개 필요합니다."
            )

        if not 0.50 <= float(train_ratio) <= 0.95:
            raise DatasetBuildError(
                "훈련 데이터 비율은 0.50~0.95 범위여야 합니다."
            )

        shuffled = list(items)
        random.Random(int(seed)).shuffle(shuffled)

        validation_count = round(
            len(shuffled) * (1.0 - float(train_ratio))
        )
        validation_count = max(
            1,
            min(validation_count, len(shuffled) - 1),
        )

        validation = shuffled[:validation_count]
        training = shuffled[validation_count:]
        return training, validation

    def build(
        self,
        photo_directory: str,
        annotation_directory: str,
        dataset_directory: str,
        task_type: str,
        classes: Sequence[str],
        train_ratio: float,
        seed: int,
    ) -> Dict[str, object]:
        """Build one complete derived dataset atomically."""
        task = str(task_type).strip().lower()
        if task not in {"detect", "segment"}:
            raise DatasetBuildError(
                "작업 유형은 detect 또는 segment여야 합니다."
            )

        class_names = [str(name).strip() for name in classes]
        if not class_names or any(not name for name in class_names):
            raise DatasetBuildError(
                "등록된 클래스 이름이 필요합니다."
            )

        photo_root = Path(photo_directory).expanduser().resolve()
        annotation_root = (
            Path(annotation_directory).expanduser().resolve()
        )
        dataset_root = Path(dataset_directory).expanduser().resolve()

        if not photo_root.is_dir():
            raise DatasetBuildError(
                f"사진 폴더가 존재하지 않습니다: {photo_root}"
            )
        if dataset_root.name != "dataset":
            raise DatasetBuildError(
                "학습 데이터셋 대상 폴더 이름은 dataset이어야 합니다."
            )

        try:
            validation = self._validator.validate(
                photo_root,
                annotation_root,
                task,
                class_names,
            )
        except ProjectValidationError as error:
            raise DatasetBuildError(str(error)) from error

        if not validation["ready_for_training"]:
            issues = validation.get("issues", [])
            detail = (
                " / ".join(str(issue) for issue in issues[:5])
                if issues
                else "프로젝트 검사를 통과하지 못했습니다."
            )
            raise DatasetBuildError(
                f"학습용 데이터셋을 만들 수 없습니다: {detail}"
            )

        store = (
            self._box_store
            if task == "detect"
            else self._polygon_store
        )

        try:
            listing = store.list_images(
                photo_root,
                annotation_root,
            )
        except (BoxLabelError, PolygonLabelError, OSError) as error:
            raise DatasetBuildError(
                f"이미지 목록을 읽을 수 없습니다: {error}"
            ) from error

        source_items = []
        project_root = dataset_root.parent.resolve()

        for item in listing["images"]:
            relative = self._safe_relative_path(item["path"])
            source = (photo_root / relative).resolve()

            # 결과 폴더가 사진 폴더 내부일 때 파생 데이터 재수집 방지
            try:
                source.relative_to(project_root)
                continue
            except ValueError:
                pass

            if not source.is_file():
                raise DatasetBuildError(
                    f"원본 이미지가 없습니다: {source}"
                )

            if item["label_source"] == "none":
                raise DatasetBuildError(
                    f"레이블이 작성되지 않은 이미지입니다: {relative}"
                )

            source_items.append(
                {
                    "path": relative.as_posix(),
                    "source": source,
                    "label_source": item["label_source"],
                }
            )

        training, validation_items = self._split_items(
            source_items,
            float(train_ratio),
            int(seed),
        )

        build_id = uuid4().hex
        staging = dataset_root.parent / f".dataset_build_{build_id}"
        previous = dataset_root.parent / f".dataset_previous_{build_id}"

        if staging.exists() or previous.exists():
            raise DatasetBuildError(
                "임시 데이터셋 경로 충돌이 발생했습니다."
            )

        link_counts = {"hardlink": 0, "symlink": 0}
        source_counts = {"project": 0, "external": 0}
        object_count = 0
        manifest_items = []

        try:
            for split_name, split_items in (
                ("train", training),
                ("val", validation_items),
            ):
                for item in split_items:
                    relative = Path(item["path"])
                    source = Path(item["source"])

                    image_target = (
                        staging
                        / "images"
                        / split_name
                        / relative
                    )
                    label_target = (
                        staging
                        / "labels"
                        / split_name
                        / relative.with_suffix(".txt")
                    )

                    link_type = self._link_image(
                        source,
                        image_target,
                    )
                    link_counts[link_type] += 1

                    try:
                        loaded = store.load(
                            photo_root,
                            annotation_root,
                            relative.as_posix(),
                            len(class_names),
                        )
                    except (
                        BoxLabelError,
                        PolygonLabelError,
                        OSError,
                    ) as error:
                        raise DatasetBuildError(
                            f"레이블을 읽을 수 없습니다: "
                            f"{relative}: {error}"
                        ) from error

                    if task == "detect":
                        values = loaded["boxes"]
                        lines = self._box_lines(values)
                    else:
                        values = loaded["polygons"]
                        lines = self._polygon_lines(values)

                    self._write_label(label_target, lines)
                    object_count += len(values)

                    label_source = loaded["label_source"]
                    if label_source in source_counts:
                        source_counts[label_source] += 1

                    manifest_items.append(
                        {
                            "split": split_name,
                            "source_image": str(source),
                            "relative_path": relative.as_posix(),
                            "label_source": label_source,
                            "object_count": len(values),
                            "image_link": link_type,
                        }
                    )

            yaml_path = self._write_data_yaml(
                staging,
                class_names,
                dataset_root,
            )

            manifest = {
                "schema_version": 1,
                "created_at": datetime.now(
                    timezone.utc
                ).isoformat(),
                "task_type": task,
                "classes": class_names,
                "train_ratio_requested": float(train_ratio),
                "train_count": len(training),
                "val_count": len(validation_items),
                "total_image_count": len(source_items),
                "object_count": object_count,
                "seed": int(seed),
                "source_label_counts": source_counts,
                "image_link_counts": link_counts,
                "source_files_modified": False,
                "items": manifest_items,
            }

            (staging / "dataset_manifest.json").write_text(
                json.dumps(
                    manifest,
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )

            if dataset_root.exists():
                dataset_root.rename(previous)

            try:
                staging.rename(dataset_root)
            except Exception:
                if previous.exists() and not dataset_root.exists():
                    previous.rename(dataset_root)
                raise

            if previous.exists():
                shutil.rmtree(previous)

        except Exception:
            if staging.exists():
                shutil.rmtree(staging)
            if previous.exists() and not dataset_root.exists():
                previous.rename(dataset_root)
            raise

        return {
            "ok": True,
            "dataset_directory": str(dataset_root),
            "data_yaml": str(dataset_root / yaml_path.name),
            "task_type": task,
            "train_count": len(training),
            "val_count": len(validation_items),
            "total_image_count": len(source_items),
            "object_count": object_count,
            "source_label_counts": source_counts,
            "image_link_counts": link_counts,
            "source_files_modified": False,
        }
