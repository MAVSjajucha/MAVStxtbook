"""Safe storage for YOLO detection box labels."""

from math import isfinite
import os
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2

from my_supervised._internal.dataset_import import (
    IMAGE_SUFFIXES,
)


MAX_IMAGES = 100000
MAX_DEPTH = 6
MAX_BOXES_PER_IMAGE = 2000


class BoxLabelError(RuntimeError):
    """Raised for an invalid image path or detection label."""


class BoxLabelStore:
    """Load external labels read-only and save edits separately."""

    @staticmethod
    def annotation_root(project_paths) -> Path:
        for attribute in (
            "annotations_directory",
            "annotation_directory",
            "annotations_dir",
        ):
            value = getattr(project_paths, attribute, None)
            if value:
                root = Path(value)
                root.mkdir(parents=True, exist_ok=True)
                return root

        manifest_path = getattr(
            project_paths,
            "manifest_path",
            None,
        )
        if manifest_path:
            root = Path(manifest_path).parent / "annotations"
            root.mkdir(parents=True, exist_ok=True)
            return root

        project_directory = getattr(
            project_paths,
            "project_directory",
            None,
        )
        if project_directory:
            root = Path(project_directory) / "annotations"
            root.mkdir(parents=True, exist_ok=True)
            return root

        data = project_paths.as_dict()
        for key, value in data.items():
            if "annotation" in key and value:
                root = Path(value)
                root.mkdir(parents=True, exist_ok=True)
                return root

        for key, value in data.items():
            if "manifest" in key and value:
                root = Path(value).parent / "annotations"
                root.mkdir(parents=True, exist_ok=True)
                return root

        raise BoxLabelError(
            "프로젝트 레이블 저장 폴더를 결정할 수 없습니다."
        )

    @staticmethod
    def _walk_images(root: Path) -> Iterable[Path]:
        root_depth = len(root.parts)
        count = 0

        for current, directories, filenames in os.walk(
            root,
            followlinks=False,
        ):
            current_path = Path(current)
            depth = len(current_path.parts) - root_depth

            directories[:] = [
                name
                for name in directories
                if not name.startswith(".")
                and name != "__pycache__"
                and depth < MAX_DEPTH
            ]

            for filename in filenames:
                path = current_path / filename

                if path.suffix.lower() not in IMAGE_SUFFIXES:
                    continue

                count += 1
                if count > MAX_IMAGES:
                    raise BoxLabelError(
                        "이미지가 100000개를 초과합니다."
                    )

                yield path

    @staticmethod
    def _safe_image(
        photo_root: Path,
        relative_path: str,
    ) -> Tuple[Path, Path]:
        root = Path(photo_root).expanduser().resolve()

        if not isinstance(relative_path, str):
            raise BoxLabelError(
                "이미지 경로 형식이 올바르지 않습니다."
            )

        relative = Path(relative_path)

        if relative.is_absolute():
            raise BoxLabelError(
                "이미지는 사진 폴더 기준 상대 경로여야 합니다."
            )

        image = (root / relative).resolve()

        try:
            image.relative_to(root)
        except ValueError as error:
            raise BoxLabelError(
                "사진 폴더 밖의 이미지는 열 수 없습니다."
            ) from error

        if (
            not image.is_file()
            or image.suffix.lower() not in IMAGE_SUFFIXES
        ):
            raise BoxLabelError(
                f"이미지를 찾을 수 없습니다: {relative_path}"
            )

        return root, image

    @staticmethod
    def _project_label(
        photo_root: Path,
        annotation_root: Path,
        image: Path,
    ) -> Path:
        relative = image.relative_to(photo_root)
        return (
            Path(annotation_root)
            / "detect"
            / relative
        ).with_suffix(".txt")

    @staticmethod
    def _external_candidates(
        photo_root: Path,
        image: Path,
    ) -> List[Path]:
        relative = image.relative_to(photo_root)
        candidates = [
            image.with_suffix(".txt"),
            (
                photo_root
                / "labels"
                / relative
            ).with_suffix(".txt"),
        ]

        parts = list(relative.parts)

        for index, part in enumerate(parts):
            if part.lower() == "images":
                changed = list(parts)
                changed[index] = "labels"
                candidates.append(
                    photo_root.joinpath(
                        *changed
                    ).with_suffix(".txt")
                )

        if photo_root.name.lower() == "images":
            candidates.append(
                (
                    photo_root.parent
                    / "labels"
                    / relative
                ).with_suffix(".txt")
            )

        unique = []
        seen = set()

        for candidate in candidates:
            identity = str(
                candidate.resolve(strict=False)
            )
            if identity not in seen:
                seen.add(identity)
                unique.append(candidate)

        return unique

    @classmethod
    def _external_label(
        cls,
        photo_root: Path,
        image: Path,
    ):
        for candidate in cls._external_candidates(
            photo_root,
            image,
        ):
            if candidate.is_file():
                return candidate
        return None

    @staticmethod
    def _parse_label(
        label_path: Path,
        class_count: int,
    ) -> List[Dict[str, object]]:
        boxes = []

        try:
            lines = label_path.read_text(
                encoding="utf-8"
            ).splitlines()
        except (OSError, UnicodeDecodeError) as error:
            raise BoxLabelError(
                f"레이블을 읽을 수 없습니다: {label_path}"
            ) from error

        for line_number, raw_line in enumerate(
            lines,
            start=1,
        ):
            line = raw_line.strip()
            if not line:
                continue

            tokens = line.split()

            if len(tokens) != 5:
                raise BoxLabelError(
                    f"{label_path}:{line_number}: "
                    "박스 레이블은 5개 값이어야 합니다."
                )

            try:
                class_id = int(tokens[0])
                x, y, width, height = [
                    float(value)
                    for value in tokens[1:]
                ]
            except ValueError as error:
                raise BoxLabelError(
                    f"{label_path}:{line_number}: "
                    "레이블 값 형식이 올바르지 않습니다."
                ) from error

            if not 0 <= class_id < class_count:
                raise BoxLabelError(
                    f"{label_path}:{line_number}: "
                    "등록되지 않은 클래스 번호입니다."
                )

            values = (x, y, width, height)

            if any(
                not isfinite(value)
                or value < 0.0
                or value > 1.0
                for value in values
            ):
                raise BoxLabelError(
                    f"{label_path}:{line_number}: "
                    "좌표는 0~1 범위여야 합니다."
                )

            if width <= 0.0 or height <= 0.0:
                raise BoxLabelError(
                    f"{label_path}:{line_number}: "
                    "박스 크기는 0보다 커야 합니다."
                )

            boxes.append(
                {
                    "class_id": class_id,
                    "x": x,
                    "y": y,
                    "width": width,
                    "height": height,
                }
            )

        return boxes

    def list_images(
        self,
        photo_root: Path,
        annotation_root: Path,
    ) -> Dict[str, object]:
        root = Path(photo_root).resolve()
        images = sorted(self._walk_images(root))
        items = []

        for image in images:
            relative = image.relative_to(root)
            project_label = self._project_label(
                root,
                annotation_root,
                image,
            )
            external_label = self._external_label(
                root,
                image,
            )

            if project_label.is_file():
                source = "project"
            elif external_label is not None:
                source = "external"
            else:
                source = "none"

            items.append(
                {
                    "path": relative.as_posix(),
                    "label_source": source,
                }
            )

        return {
            "images": items,
            "image_count": len(items),
            "project_labeled_count": sum(
                item["label_source"] == "project"
                for item in items
            ),
            "external_labeled_count": sum(
                item["label_source"] == "external"
                for item in items
            ),
            "unlabeled_count": sum(
                item["label_source"] == "none"
                for item in items
            ),
        }

    def load(
        self,
        photo_root: Path,
        annotation_root: Path,
        relative_path: str,
        class_count: int,
    ) -> Dict[str, object]:
        root, image = self._safe_image(
            photo_root,
            relative_path,
        )
        project_label = self._project_label(
            root,
            annotation_root,
            image,
        )

        if project_label.is_file():
            label_path = project_label
            source = "project"
        else:
            label_path = self._external_label(
                root,
                image,
            )
            source = (
                "external"
                if label_path is not None
                else "none"
            )

        boxes = (
            self._parse_label(label_path, class_count)
            if label_path is not None
            else []
        )

        return {
            "image_path": image.relative_to(root).as_posix(),
            "label_source": source,
            "boxes": boxes,
        }

    def save(
        self,
        photo_root: Path,
        annotation_root: Path,
        relative_path: str,
        boxes: Sequence[Dict[str, object]],
        class_count: int,
    ) -> Dict[str, object]:
        root, image = self._safe_image(
            photo_root,
            relative_path,
        )

        if not isinstance(boxes, list):
            raise BoxLabelError(
                "박스 목록 형식이 올바르지 않습니다."
            )
        if len(boxes) > MAX_BOXES_PER_IMAGE:
            raise BoxLabelError(
                "한 이미지에는 최대 2000개 박스를 저장할 수 있습니다."
            )

        normalized = []
        lines = []

        for index, box in enumerate(boxes, start=1):
            if not isinstance(box, dict):
                raise BoxLabelError(
                    f"{index}번 박스 형식이 올바르지 않습니다."
                )

            try:
                class_id = int(box["class_id"])
                x = float(box["x"])
                y = float(box["y"])
                width = float(box["width"])
                height = float(box["height"])
            except (KeyError, TypeError, ValueError) as error:
                raise BoxLabelError(
                    f"{index}번 박스 값이 올바르지 않습니다."
                ) from error

            if not 0 <= class_id < class_count:
                raise BoxLabelError(
                    f"{index}번 박스의 클래스가 등록되지 않았습니다."
                )

            values = (x, y, width, height)
            if any(
                not isfinite(value)
                or value < 0.0
                or value > 1.0
                for value in values
            ):
                raise BoxLabelError(
                    f"{index}번 박스 좌표가 0~1 범위를 벗어났습니다."
                )

            if width <= 0.0 or height <= 0.0:
                raise BoxLabelError(
                    f"{index}번 박스 크기는 0보다 커야 합니다."
                )

            if (
                x - width / 2.0 < 0.0
                or x + width / 2.0 > 1.0
                or y - height / 2.0 < 0.0
                or y + height / 2.0 > 1.0
            ):
                raise BoxLabelError(
                    f"{index}번 박스가 이미지 범위를 벗어났습니다."
                )

            normalized.append(
                {
                    "class_id": class_id,
                    "x": x,
                    "y": y,
                    "width": width,
                    "height": height,
                }
            )
            lines.append(
                f"{class_id} "
                f"{x:.8f} {y:.8f} "
                f"{width:.8f} {height:.8f}"
            )

        target = self._project_label(
            root,
            annotation_root,
            image,
        )
        target.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        temporary = target.with_suffix(
            target.suffix + ".tmp"
        )
        content = (
            "\n".join(lines) + "\n"
            if lines
            else ""
        )
        temporary.write_text(
            content,
            encoding="utf-8",
        )
        temporary.replace(target)

        return {
            "ok": True,
            "image_path": image.relative_to(root).as_posix(),
            "label_path": str(target),
            "label_source": "project",
            "box_count": len(normalized),
            "boxes": normalized,
        }

    def image_jpeg(
        self,
        photo_root: Path,
        relative_path: str,
    ) -> bytes:
        _, image_path = self._safe_image(
            photo_root,
            relative_path,
        )
        image = cv2.imread(str(image_path))

        if image is None:
            raise BoxLabelError(
                f"이미지를 열 수 없습니다: {relative_path}"
            )

        encoded_ok, encoded = cv2.imencode(
            ".jpg",
            image,
            [int(cv2.IMWRITE_JPEG_QUALITY), 90],
        )

        if not encoded_ok:
            raise BoxLabelError(
                "이미지를 JPEG로 변환할 수 없습니다."
            )

        return encoded.tobytes()
