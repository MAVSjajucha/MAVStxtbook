"""CSV collection and classification/regression workspace (no ROS dependency)."""

import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .csv_recorder import CsvRecorder
from .grid_features import DEFAULT_GRID, validate_grid
from .live_video import LatestJpeg, send_mjpeg
from .tree_learning import (
    DEFAULT_TRAINING_SETTINGS, inspect_csv, normalize_settings,
    validate_session_selection,
)


def absolute_directory(value):
    if not str(value or "").strip():
        raise ValueError("차량의 결과 저장 폴더를 먼저 지정하세요.")
    path = Path(str(value)).expanduser()
    if not path.is_absolute():
        raise ValueError("폴더는 차량의 절대 경로로 입력하세요.")
    # REQUIRE_EXISTING_USER_DIRECTORY
    if not path.exists():
        raise ValueError(
            f"폴더가 존재하지 않습니다. 먼저 폴더를 만든 뒤 지정하세요: {path}"
        )
    if not path.is_dir():
        raise ValueError("선택한 경로의 폴더가 아닙니다.")
    return path.resolve()


class TreeWorkspace:
    """Hold collection state; browser refresh does not erase recorded files."""

    def __init__(self, command_topic="/cmd_vel", max_delta_ms=200.0, apply_grid=None):
        self.recorder = CsvRecorder(max_delta_ms=max_delta_ms)
        self.preview = LatestJpeg()
        self.command_topic = command_topic
        self.max_delta_ms = max_delta_ms
        self.apply_grid = apply_grid
        self._lock = threading.RLock()
        self._grid_lock = threading.Lock()
        self._result = None
        self._expected_grid = None
        self._latest_command = None
        self._selected_csv = None
        self._files = set()
        self._process = None
        self._job_directory = None
        self._status_path = None
        self._log = None
        self._job_lock = threading.Lock()
        self.vehicle = {}

    def receive_result(self, result):
        with self._lock:
            if self._expected_grid is not None:
                if result.get("grid") != self._expected_grid:
                    return
                self._expected_grid = None
            self._result = result
        self.recorder.on_features(result)

    def receive_command(self, linear_x, angular_z, received_ns=None):
        received_ns = time.time_ns() if received_ns is None else received_ns
        self.recorder.on_command(linear_x, angular_z, received_ns)
        with self._lock:
            self._latest_command = {"linear_x": linear_x, "angular_z": angular_z,
                                    "received_ns": received_ns}

    def status(self):
        with self._lock:
            result = self._result
            command = self._latest_command
            selected = self._selected_csv
        now = time.time_ns()
        return {"ok": True, "vehicle": self.vehicle, "lane": result,
                "frame_age_seconds": None if result is None else max(0, (now - result["received_ns"]) / 1e9),
                "command": command, "command_topic": self.command_topic,
                "command_age_seconds": None if command is None else max(0, (now-command["received_ns"])/1e9),
                "max_delta_ms": self.max_delta_ms, "recording": self.recorder.status(),
                "selected_csv": selected, "training": self.training_status(),
                "grid_defaults": DEFAULT_GRID, "training_defaults": DEFAULT_TRAINING_SETTINGS}

    def start_recording(self, directory):
        with self._lock:
            result = self._result
            if result is None or result.get("error") or time.time_ns()-result["received_ns"] > 2_000_000_000:
                raise ValueError("격자 영상이 최신화되지 않습니다. 카메라 상태를 확인하세요.")
            state = self.recorder.start(str(absolute_directory(directory)), result["grid"])
            path = state.get("path")
            if path:
                self._files.add(str(Path(path).resolve()))
        return {"ok": True, "recording": state}

    def stop_recording(self):
        return {"ok": True, "recording": self.recorder.stop()}

    def set_grid(self, config):
        checked = validate_grid(config)
        with self._grid_lock:
            with self._lock:
                if self.recorder.status()["recording"]:
                    raise ValueError("기록을 중지한 뒤 격자 설정을 변경하세요.")
                if self.apply_grid is None:
                    raise ValueError("격자 생성 노드가 실행되지 않았습니다.")
                previous_result, previous_expected = self._result, self._expected_grid
                self._expected_grid = checked
                self._result = None
            try:
                self.apply_grid(checked)
            except Exception:
                with self._lock:
                    self._expected_grid = previous_expected
                    if self._result is None:
                        self._result = previous_result
                raise
        # A matching frame may already have arrived during the parameter request;
        # retain it. A queued old-grid frame must not reopen the record button.
        return {"ok": True, "grid": checked}

    def select_csv(self, path, model_type="decision_tree_classification"):
        # A failed replacement must not leave the previous CSV trainable by accident.
        with self._lock:
            self._selected_csv = None
        selected = Path(str(path)).expanduser()
        if not selected.is_absolute() or selected.suffix.lower() != ".csv":
            raise ValueError("학습할 CSV 파일의 경로를 지정하세요.")
        active = self.recorder.status()
        if active["recording"] and selected.resolve() == Path(active["path"]).resolve():
            raise ValueError("기록 중인 파일입니다. 기록을 중지한 뒤 검사하세요.")
        summary = inspect_csv(str(selected), model_type=model_type)
        with self._lock:
            self._selected_csv = str(selected.resolve())
            self._files.add(self._selected_csv)
        return {"ok": True, "path": self._selected_csv, "summary": summary}

    def upload_csv(self, directory, filename, data, model_type="decision_tree_classification"):
        with self._lock:
            self._selected_csv = None
        if not filename or Path(filename).name != filename or not filename.lower().endswith(".csv"):
            raise ValueError("업로드할 파일은 .csv 형식이어야 합니다.")
        if not data or len(data) > 50 * 1024 * 1024:
            raise ValueError("CSV는 0바이트 초과, 50 MiB 이하로 업로드하세요.")
        folder = absolute_directory(directory)
        destination = folder / f"edited_{uuid.uuid4().hex[:8]}_{filename}"
        # Keep the uploaded file even when validation fails so the student can fix it.
        with destination.open("xb") as output:
            output.write(data)
        try:
            return self.select_csv(str(destination), model_type=model_type)
        except ValueError as error:
            raise ValueError(f"업로드됨: {destination}\n검사 오류: {error}") from error

    def downloadable(self, path):
        selected = str(Path(path).expanduser().resolve())
        if selected not in self._files:
            raise ValueError("현재 화면에서 기록하거나 선택한 CSV만 다운로드할 수 있습니다.")
        state = self.recorder.status()
        if state["recording"] and selected == str(Path(state["path"]).resolve()):
            raise ValueError("기록을 중지한 뒤 다운로드하세요.")
        return Path(selected)

    def start_training(self, settings, output_directory):
        with self._job_lock:
            if self._process is not None and self._process.poll() is None:
                # A worker writes its terminal status before Python finishes teardown.
                # The web already shows completion at that point; reap that worker
                # briefly before accepting the next model, never overlap workers.
                if self.training_status().get("state") not in ("completed", "failed", "cancelled"):
                    raise ValueError("이미 학습 중입니다.")
                try:
                    self._process.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    raise ValueError("이전 학습 프로세스가 종료 중입니다. 잠시 후 다시 시작하세요.") from None
                if self._process.poll() is None:
                    raise ValueError("이전 학습 프로세스가 아직 종료되지 않았습니다.")
            settings = normalize_settings(settings)
            with self._lock:
                csv_path = self._selected_csv
            if csv_path is None:
                raise ValueError("CSV를 먼저 선택한 후 검사하세요.")
            selected = self.select_csv(csv_path, model_type=settings["model_type"])
            if settings["split_mode"] == "session":
                validate_session_selection(
                    [session["session_id"] for session in selected["summary"]["sessions"]], settings,
                )
            output = absolute_directory(output_directory)
            job = output / ".tree_jobs" / uuid.uuid4().hex
            job.mkdir(parents=True)
            status_path = job / "status.json"
            status_path.write_text(json.dumps({"state": "starting"}), encoding="utf-8")
            config = {"csv_path": csv_path, "output_directory": str(output),
                      "settings": settings, "status_path": str(status_path)}
            config_path = job / "job.json"
            config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
            environment = dict(os.environ)
            for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
                environment[key] = "1"
            if self._log is not None:
                self._log.close()
            self._log = (job / "worker.log").open("ab")
            self._job_directory, self._status_path = job, status_path
            try:
                self._process = subprocess.Popen(
                    [sys.executable, "-m", "my_supervised._internal.tree_learning",
                     "--job", str(config_path)], env=environment,
                    stdout=self._log, stderr=subprocess.STDOUT, start_new_session=True,
                )
            except Exception as error:
                self._log.close()
                self._log = None
                status_path.write_text(json.dumps({"state": "failed", "error": str(error)}), encoding="utf-8")
                raise
        return {"ok": True, "training": self.training_status()}

    def training_status(self):
        if self._status_path is None:
            return {"state": "idle"}
        try:
            status = json.loads(self._status_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            status = {"state": "starting"}
        # The worker owns `status`; the web API consistently exposes `state`.
        status["state"] = status.pop("status", status.get("state", "starting"))
        if self._process is not None:
            code = self._process.poll()
            if code is not None and status.get("state") not in ("completed", "failed", "cancelled"):
                status = {"state": "failed", "error": f"학습 프로세스 종료 code={code}"}
        status["log_path"] = str(self._job_directory / "worker.log")
        return status

    def cancel_training(self):
        with self._job_lock:
            process = self._process
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
                self._status_path.write_text(json.dumps({"state": "cancelled"}), encoding="utf-8")
        return {"ok": True, "training": self.training_status()}

    def close(self):
        self.recorder.stop()
        self.cancel_training()
        self.preview.close()
        if self._log is not None:
            self._log.close()


class TreeWebServer:
    def __init__(self, workspace, port):
        self.workspace = workspace
        self.server = ThreadingHTTPServer(("0.0.0.0", int(port)), self.handler_type())
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def port(self):
        return self.server.server_port

    def start(self):
        self.thread.start()

    def stop(self):
        self.workspace.preview.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def handler_type(self):
        workspace = self.workspace

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def send(self, status, content, kind="application/json; charset=utf-8"):
                if isinstance(content, (dict, list)):
                    content = json.dumps(content, ensure_ascii=False, allow_nan=False).encode()
                elif isinstance(content, str):
                    content = content.encode()
                self.send_response(status)
                self.send_header("Content-Type", kind)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)

            def do_GET(self):
                parsed = urlparse(self.path)
                try:
                    if parsed.path == "/":
                        self.send(200, TREE_PAGE, "text/html; charset=utf-8")
                    elif parsed.path == "/stream.mjpg":
                        send_mjpeg(self, workspace.preview)
                    elif parsed.path == "/api/status":
                        self.send(200, workspace.status())
                    elif parsed.path == "/api/csv/download":
                        path = workspace.downloadable(parse_qs(parsed.query).get("path", [""])[0])
                        with path.open("rb") as source:
                            self.send_response(200)
                            self.send_header("Content-Type", "text/csv; charset=utf-8")
                            self.send_header("Content-Disposition", 'attachment; filename="recording.csv"')
                            self.send_header("Content-Length", str(os.fstat(source.fileno()).st_size))
                            self.send_header("Cache-Control", "no-store")
                            self.end_headers()
                            while True:
                                chunk = source.read(65536)
                                if not chunk:
                                    break
                                self.wfile.write(chunk)
                    else:
                        self.send(404, {"error": "Not found"})
                except (ValueError, OSError, KeyError) as error:
                    self.send(400, {"error": str(error)})

            def do_POST(self):
                parsed = urlparse(self.path)
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    limit = 50 * 1024 * 1024 if parsed.path == "/api/csv/upload" else 65536
                    if size < 0 or size > limit:
                        raise ValueError("요청 파일이 너무 큽니다.")
                    body = self.rfile.read(size)
                    if parsed.path == "/api/csv/upload":
                        query = parse_qs(parsed.query)
                        response = workspace.upload_csv(
                            query.get("directory", [""])[0],
                            query.get("filename", [""])[0], body,
                            model_type=query.get("model_type", ["decision_tree_classification"])[0],
                        )
                    else:
                        data = json.loads(body or b"{}")
                        if not isinstance(data, dict):
                            raise ValueError("요청 내용은 JSON 객체여야 합니다.")
                        if parsed.path == "/api/record/start":
                            response = workspace.start_recording(data.get("directory", ""))
                        elif parsed.path == "/api/record/stop":
                            response = workspace.stop_recording()
                        elif parsed.path == "/api/grid":
                            response = workspace.set_grid(data)
                        elif parsed.path == "/api/csv/select":
                            response = workspace.select_csv(
                                data.get("path", ""),
                                model_type=data.get("model_type", "decision_tree_classification"),
                            )
                        elif parsed.path == "/api/tree/train":
                            response = workspace.start_training(data.get("settings", {}), data.get("output_directory", ""))
                        elif parsed.path == "/api/tree/cancel":
                            response = workspace.cancel_training()
                        else:
                            self.send(404, {"error": "Not found"})
                            return
                    self.send(200, response)
                except (ValueError, OSError, KeyError, TypeError, RuntimeError) as error:
                    self.send(400, {"ok": False, "error": str(error)})
        return Handler


TREE_PAGE = r'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>차선 주행 지도 학습</title>
<style>
:root{color-scheme:light;--page:#f3f5f5;--panel:#e7edef;--ink:#171d21;--muted:#59656c;--line:#c7d0d4;--accent:#71304f;--teal:#267d78;--danger:#a44855}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font-family:Arial,sans-serif;font-size:16px}.wrap{max-width:1180px;margin:auto;padding:24px}header,.toolbar{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}h1{font-size:26px}h2{font-size:21px;margin-top:0}h3{font-size:17px}.pill{background:white;border:1px solid var(--line);padding:10px 14px}.card{padding:20px;background:var(--panel);border:1px solid var(--line);border-radius:14px;margin:18px 0;min-width:0}.columns{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px}.columns>.card{margin:0}.small,label{color:var(--muted);line-height:1.55}.small{font-size:14px}label{display:block;font-size:14px;font-weight:600;margin-bottom:7px}input,select{width:100%;font:inherit;border:1px solid var(--line);border-radius:5px;background:white;color:var(--ink);padding:9px;min-width:0}input[type=checkbox]{width:auto}.fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field-wide{grid-column:1/-1}button,.download{display:inline-block;border:0;border-radius:5px;padding:11px 15px;background:var(--accent);color:white;font-size:14px;cursor:pointer;text-decoration:none}button.secondary{background:var(--teal)}button.stop{background:var(--danger)}button:disabled,.download[aria-disabled=true]{background:#aebbc0;cursor:default;pointer-events:none}.actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:16px}.status{white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;line-height:1.65;padding:12px;background:white;border:1px solid var(--line);border-radius:5px}.error{color:#a12b3d}.ok{color:#17645f}#preview{display:block;width:100%;aspect-ratio:4/3;object-fit:contain;background:#111;border-radius:7px}.features{font-family:monospace}.notice{min-height:24px;overflow-wrap:anywhere}details{margin-top:16px}summary{cursor:pointer;font-weight:600;margin-bottom:14px}canvas{width:100%;height:220px;background:white;border:1px solid var(--line);border-radius:5px}code{overflow-wrap:anywhere}dialog{max-width:540px;border:1px solid var(--line);border-radius:12px}dialog::backdrop{background:#0005}@media(max-width:800px){.columns{grid-template-columns:1fr}.wrap{padding:14px}.fields{grid-template-columns:1fr}}

button[aria-disabled=true],.download[aria-disabled=true]{background:#aebbc0;cursor:help;pointer-events:auto}
.chart-legend{display:flex;gap:24px;justify-content:flex-end;flex-wrap:wrap;margin:10px 0;font-size:14px}
.chart-legend span{display:inline-flex;align-items:center;gap:8px}
.chart-key{display:inline-block;width:32px;border-top:3px solid #8a969d}
.chart-key.predicted{border-color:#71304f}
.session-table{border-collapse:collapse;width:100%;font-size:14px}.session-table th,.session-table td{border:1px solid var(--line);padding:10px;text-align:left;background:white;overflow-wrap:anywhere}.session-table th{background:var(--panel)}.session-table td:first-child{word-break:break-all}.session-table select{min-width:120px}#session-selection{min-width:0;border:0;padding:0;margin:16px 0 0}#session-selection legend{font-weight:600;margin-bottom:8px}
.model-options{display:flex;flex-wrap:wrap;gap:10px;border:0;padding:0;margin:16px 0}.model-options legend{font-weight:bold;margin-bottom:10px}.model-options label{margin:0;padding:12px 15px;border:1px solid var(--line);border-radius:6px;background:white;cursor:pointer}.model-options label:has(input:checked){border-color:var(--accent);color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent)}input[type=radio]{width:auto;accent-color:var(--accent)}[hidden]{display:none!important}.chart-caption{margin-bottom:6px}.confusion{border-collapse:collapse;width:100%;max-width:560px;margin:8px 0 20px;font-size:14px}.confusion caption{text-align:left;font-weight:600;padding:8px 0}.confusion th,.confusion td{border:1px solid var(--line);padding:8px;text-align:center;background:white}.confusion th{background:var(--panel)}
</style></head><body><main class="wrap">
<header><h1>차선 주행 지도학습</h1><span id="vehicle" class="pill">차량 IP 확인 중</span></header>
<p class="small"></p>
<div class="columns">
<section class="card"><h2>1. 주행 데이터 수집</h2>
<label for="record-directory">CSV 저장 폴더</label><input id="record-directory" placeholder="예: /home/jetson/my_supervised/my_lane_data/dataset" autocomplete="off">
<div class="actions"><button id="record-start">기록 시작</button><button id="record-stop" class="stop" disabled>기록 중지</button><a id="download" class="download" aria-disabled="true">CSV 다운로드</a></div>
<p class="small">리모컨을 이용해서 직접 주행하며 데이터를 수집하세요.</p>
<div id="record-status" class="status">기록 대기</div><p id="command-status" class="small"></p>
<p class="small"><code id="command-topic"></code>. 사진·명령의 수신 시간이 맞지 않는 샘플은 기록하지 않으며 제외 수로 표시합니다.</p>
<p id="notice" class="notice small" role="status"></p>
</section>
<section class="card"><h2>카메라</h2><img id="preview" src="/stream.mjpg" alt="영상 수신 대기"><p id="camera-status" class="small">카메라 대기 중</p><div id="features" class="status features">V: []
L: []
R: []</div></section>
</div>
<section class="card"><h2>격자 설정 변경</h2><p class="small">데이터 수집 중에는 변경할 수 없습니다. 설정 정보는 CSV와 학습 모델에 함께 저장됩니다.</p>
<div class="fields" id="grid-fields"></div><div class="actions"><button id="apply-grid" class="secondary">격자 설정 적용</button></div></section>
<section class="card"><h2>2. CSV 파일 선택</h2><p class="small">파일 형식은 CSV UTF-8입니다.</p>
<label for="csv-path">자주차에 저장된 CSV 파일 경로</label><input id="csv-path" placeholder="예: /home/jetson/my_supervised/my_lane_data/example_dataset/recording_example.csv">
<div class="actions"><button id="select-csv">선택한 CSV 검사</button></div>
<details><summary>내 PC 저장된 CSV 업로드</summary><label for="upload-directory">업로드할 파일의 차량 저장 경로</label><input id="upload-directory" placeholder="예: /home/jetson/my_supervised/my_lane_data/dataset/edited"><label for="csv-file">업로드할 파일 선택</label><input type="file" id="csv-file" accept=".csv,text/csv"><div class="actions"><button id="upload-csv" class="secondary">업로드한 파일 검사</button></div></details>
<div id="csv-summary" class="status" role="status" aria-live="polite" style="margin-top:16px">학습할 파일을 선택하세요.</div></section>
<section class="card"><h2>3. 모델 선택 및 설정 변경</h2>
<fieldset class="model-options" id="model-options"><legend>모델 선택</legend>
<label><input type="radio" name="model_type" value="decision_tree_classification" checked> 의사결정분류트리(기본)</label>
<label hidden><input type="radio" name="model_type" value="decision_tree_regression"> 의사결정회귀트리</label>
<label hidden><input type="radio" name="model_type" value="linear_regression"> 다중선형회귀</label></fieldset>
<p id="target-description" class="small" aria-live="polite">조향 방향(direction)을 'left', 'straight', 'right'로 구분하며 학습합니다.</p>
<div class="actions"><label><input type="checkbox" name="features" value="V" checked> V 사용</label><label><input type="checkbox" name="features" value="L" checked> L 사용</label><label><input type="checkbox" name="features" value="R" checked> R 사용</label></div>
<div class="fields">
<label data-tree-field>max_depth<input id="max_depth" type="number" min="1" value="6" placeholder="비우면 제한 없음"></label>
<label data-tree-field>min_samples_leaf<input id="min_samples_leaf" type="number" min="1" value="5"></label>
<label data-tree-field>min_samples_split<input id="min_samples_split" type="number" min="2" value="10"></label>
<label data-linear-field hidden><input id="fit_intercept" type="checkbox" checked> 절편 학습 · fit_intercept</label>
<label id="train-percent-field">훈련 데이터 비율 (%)<input id="train_percent" type="number" min="50" max="95" value="80"></label>
<label>데이터 분리 방법<select id="split_mode"><option value="session">수집 회차별 분리</option><option value="row" selected>CSV 행 순서(앞부분은 학습, 뒷부분은 검증에 사용)</option></select></label>
<label>결과 저장 폴더<input id="output-directory" placeholder="예: /home/jetson/my_supervised/my_lane_data/results"></label>
</div>
<fieldset id="session-selection" hidden><legend>훈련용·검증용 회차 선택</legend><p class="small">각 회차를 훈련용 또는 검증용으로 직접 지정하세요. 모든 회차를 한 번씩 배정하고, 양쪽에 각각 최소 1회차가 필요합니다. 선택한 회차의 모든 행이 해당 용도로 사용됩니다.</p><div id="session-rows"></div><p id="session-summary" class="small" role="status" aria-live="polite">CSV를 먼저 검사·선택하세요.</p></fieldset>
<p class="small"></p>
<details data-tree-field><summary>추가 하이퍼파라미터</summary><div class="fields"><label>max_leaf_nodes<input id="max_leaf_nodes" type="number" min="2" placeholder="미입력은 '제한 없음'"></label><label>분할 기준 · criterion<select id="criterion"><option value="gini">지니 불순도</option><option value="entropy">엔트로피</option></select></label><label>random_state<input id="random_state" type="number" min="0" value="0"></label></div></details>
<div class="actions"><button id="train">학습 시작</button><button id="cancel" class="stop" disabled>학습 중단</button></div>
</section>
<section class="card"><h2>4. 학습 결과</h2><div id="training-status" class="status">학습 대기</div><div id="metrics" class="status" style="margin-top:12px">검증 결과가 이곳에 표시됩니다.</div><div id="confusion-matrices"></div><p id="chart-description" class="small chart-caption">검증 데이터에 대한 정답(회색)과 예측(자주색) 결과 비교</p><h3 id="chart-title">angular_z (rad/s)</h3><div class="chart-legend" aria-label="범례"><span><i class="chart-key" aria-hidden="true"></i><span id="actual-legend">정답</span></span><span><i class="chart-key predicted" aria-hidden="true"></i><span id="predicted-legend">예측</span></span></div><canvas id="angular-chart" width="1000" height="240"></canvas><p id="model-path" class="status"></p></section>
<dialog id="done-dialog"><h2>학습 정상 종료. 모델 저장 완료.</h2><p id="done-path" class="status"></p><button id="close-dialog">확인</button></dialog>
</main><script>
const $=id=>document.getElementById(id);
const gridLabels={processing_width:'처리 너비',processing_height:'처리 높이',rows:'가로선 수 · rows',cols:'세로선 수 · cols',roi_b:'ROI 아래 · roi_b',roi_t:'ROI 위 · roi_t',ths1:'Canny 낮은 임곗값 · ths1',ths2:'Canny 높은 임곗값 · ths2',ker_size:'블러 크기 · 홀수'};
let gridInitialized=false, lastDone='', lastFailure='', pollBusy=false, selectedCsv=null;
let trainingRequestInFlight=false, csvRequestInFlight=false, trainingRevision=0, lastTrainingState='idle';
const sessionAssignments=new Map();
const modelNames={decision_tree_classification:'의사결정분류트리',decision_tree_regression:'의사결정회귀트리',linear_regression:'다중선형회귀'};
const directionNames={left:'좌회전',straight:'직진',right:'우회전'};
const criteria={decision_tree_classification:[['gini','지니 불순도'],['entropy','엔트로피']],decision_tree_regression:[['squared_error','제곱 오차'],['absolute_error','절대 오차'],['friedman_mse','Friedman 제곱 오차']]};
const selectedCriteria={decision_tree_classification:'gini',decision_tree_regression:'squared_error'};
let lastModelType='decision_tree_classification';
function modelType(){return document.querySelector('input[name=model_type]:checked').value}

// MODEL_CHART_LEGEND_V1
let displayedChartModel = null;

function updateChartLegend(type) {
  const classification = type === 'decision_tree_classification';
  const name = modelNames[type] || type;

  $('chart-title').textContent =
    name + ' · 회전 명령 angular_z (rad/s)';

  $('actual-legend').textContent = classification
    ? '정답 · direction을 회전 명령으로 변환'
    : '정답 · CSV에 기록된 angular_z';

  $('predicted-legend').textContent = classification
    ? '예측 · 분류한 방향을 회전 명령으로 변환'
    : '예측 · ' + name + '의 angular_z';

  $('chart-description').textContent =
    '검증 데이터에 대한 정답(회색)과 예측(자주색) 결과 비교';
    
}

function modelView(){
  const type=modelType(),linear=type==='linear_regression',classification=type==='decision_tree_classification';
  if(criteria[lastModelType])selectedCriteria[lastModelType]=$('criterion').value;
  document.querySelectorAll('[data-tree-field]').forEach(e=>{e.hidden=linear});
  document.querySelectorAll('[data-linear-field]').forEach(e=>{e.hidden=!linear});
  if(!linear){
    $('criterion').replaceChildren();
    for(const [value,label]of criteria[type]){const option=document.createElement('option');option.value=value;option.textContent=label;$('criterion').append(option)}
    $('criterion').value=selectedCriteria[type];
  }
  $('target-description').textContent = classification
    ? "조향 방향(direction)을 'left', 'straight', 'right'로 구분하며 학습합니다."
    : "회전 속도(angular_z)를 예측하도록 학습합니다.";
  lastModelType=type;
  updateChartLegend(displayedChartModel || type);
  if(selectedCsv)renderCsvSummary(selectedCsv);
}

// TREE_LEGEND_FEEDBACK_20260918
const buttonReasons={
  'record-start':'기록 중입니다. 먼저 기록을 중지하세요.',
  'record-stop':'기록 중이 아닙니다. 기록 시작을 먼저 누르세요.',
  'apply-grid':'기록을 중지한 뒤 격자 설정을 변경하세요.',
  'train':'학습 요청 처리 중이거나 이미 학습 중입니다.',
  'cancel':'현재 중단할 학습이 없습니다.',
  'select-csv':'CSV 검사 중입니다. 응답을 기다리세요.',
  'upload-csv':'CSV 검사 중입니다. 응답을 기다리세요.'
};
function gate(id,blocked){
  const b=$(id);b.disabled=false;
  b.setAttribute('aria-disabled',String(!!blocked));
  b.title=blocked?buttonReasons[id]:'';
}
function warning(message){
  message=String(message||'요청을 완료하지 못했습니다.');
  // POPUP_ONLY_WARNING
  window.alert(message);
}
document.addEventListener('click',event=>{
  const b=event.target.closest('button,a.download');
  if(!b)return;
  if(b.getAttribute('aria-disabled')==='true'||b.dataset.pending==='true'){
    event.preventDefault();event.stopImmediatePropagation();
    warning(b.dataset.pending==='true'?'요청 처리 중입니다. 응답을 기다리세요.':
      (buttonReasons[b.id]||'다운로드할 CSV가 없습니다. 기록을 시작하고 중지한 뒤 다운로드하세요.'));
  }
},true);

function notice(text,error=false){$('notice').textContent=text;$('notice').className='notice '+(error?'error':'ok')}
async function api(url,data){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),60000);
  try{
    const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{}),signal:controller.signal});
    const result=await response.json();
    if(!response.ok||result.ok===false)throw Error(result.error||result.message||'요청 실패');
    return result;
  }catch(error){
    if(error.name==='AbortError')throw Error('60초 안에 응답이 없습니다. 서버에서 실행되었을 수 있으므로 상태를 확인한 뒤 재시도하세요.');
    throw error;
  }finally{clearTimeout(timer)}
}
async function action(fn){try{await fn();await refresh()}catch(error){warning(error.message)}}
function buildGrid(grid){if(gridInitialized)return;for(const [key,title]of Object.entries(gridLabels)){const label=document.createElement('label');label.textContent=title;const input=document.createElement('input');input.type='number';input.id='grid-'+key;input.value=grid[key];label.append(input);$('grid-fields').append(label)}gridInitialized=true}
function showCsv(result){
  selectedCsv=result;
  $('csv-path').value=result.path;
  resetSessionSelection();
  renderCsvSummary(result);
  notice('CSV 검사 완료.');
}
function renderCsvSummary(result){
  const s=result.summary,g=s.grid;
  const classification=modelType()==='decision_tree_classification';
  const counts=s.direction_counts||{};
  $('csv-summary').className='status ok';
  const lines=[
    '선택 파일: '+result.path,
    '데이터 '+s.row_count+'행 · 수집 '+s.session_count+'회차 · 직진 방향 '+s.straight_row_count+'행',
    s.stopped_row_count==null?'정지 여부: linear_x 기록 없음':'기록 확인용 정지 행: '+s.stopped_row_count+'행 (행은 유지, linear_x는 기록용)',
    '격자: 가로선 '+g.rows+'개 · 세로선 '+g.cols+'개 · 영상 '+g.processing_width+' × '+g.processing_height,
    '입력 특징 열: '+s.feature_columns.length+'개 · 선택 모델: '+modelNames[modelType()],
    classification?'정답: direction (left / straight / right)':'정답: 회전 속도 angular_z만',
    'linear_x는 학습에 사용하지 않습니다. 전진 속도는 주행 함수 내부 command.linear.x로 지정하세요. 런치의 max_linear_speed는 전진 명령의 출력 상한입니다.',
    s.source_files_modified===false?'원본 변경 없음 · 유효한 모든 샘플을 유지했습니다.':'원본 변경 상태를 확인하세요.'
  ];
  if(classification&&Object.keys(counts).length)lines.push('방향 분포: 좌회전 '+(counts.left||0)+' · 직진 '+(counts.straight||0)+' · 우회전 '+(counts.right||0));
  for(const warningText of s.warnings||[])lines.push('주의: '+warningText);
  $('csv-summary').textContent=lines.join('\n');
}
function csvSessions(){return selectedCsv?.summary?.sessions||[]}
function resetSessionSelection(){
  sessionAssignments.clear();
  const output=$('session-rows');output.replaceChildren();
  const sessions=csvSessions();
  if(sessions.length){
    const table=document.createElement('table');table.className='session-table';
    const head=document.createElement('tr');
    for(const text of ['수집 회차 · session_id','데이터 행 수','사용 용도']){const th=document.createElement('th');th.scope='col';th.textContent=text;head.append(th)}
    table.append(head);
    for(const session of sessions){
      const row=document.createElement('tr'),id=document.createElement('td'),count=document.createElement('td'),role=document.createElement('td'),select=document.createElement('select');
      id.textContent=session.session_id;count.textContent=String(session.row_count);
      select.setAttribute('aria-label',session.session_id+' 사용 용도');
      for(const [value,text]of [['','선택하세요'],['train','훈련용'],['validation','검증용']]){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option)}
      select.value='';
      select.onchange=()=>{if(select.value)sessionAssignments.set(session.session_id,select.value);else sessionAssignments.delete(session.session_id);updateSessionSummary()};
      role.append(select);row.append(id,count,role);table.append(row);
    }
    output.append(table);
  }
  splitView();
}
function updateSessionSummary(){
  const sessions=csvSessions(),output=$('session-summary');
  if(!sessions.length){output.textContent='CSV를 먼저 검사·선택하세요.';return}
  if(sessions.length<2){output.textContent='회차별 분리에는 서로 다른 session_id가 최소 2개 필요합니다. 서로 다른 주행 기록을 합친 CSV를 선택하세요.';return}
  const train=sessions.filter(s=>sessionAssignments.get(s.session_id)==='train'),validation=sessions.filter(s=>sessionAssignments.get(s.session_id)==='validation');
  const rows=group=>group.reduce((sum,s)=>sum+Number(s.row_count),0);
  output.textContent='훈련용 '+train.length+'회차 · '+rows(train)+'행 / 검증용 '+validation.length+'회차 · '+rows(validation)+'행 / 미선택 '+(sessions.length-train.length-validation.length)+'회차';
}
function splitView(){
  const session=$('split_mode').value==='session',busy=trainingRequestInFlight||csvRequestInFlight||['starting','running'].includes(lastTrainingState);
  $('train-percent-field').hidden=$('split_mode').value!=='row';
  $('session-selection').hidden=!session;
  $('session-selection').disabled=busy;
  $('split_mode').disabled=busy;$('train_percent').disabled=busy;
  updateSessionSummary();
}
function manualSessionSettings(){
  const sessions=csvSessions();
  if(sessions.length<2)throw Error('회차별 분리에는 서로 다른 session_id가 최소 2개 필요합니다. 서로 다른 주행 기록을 합친 CSV를 선택하세요.');
  if(sessions.some(s=>!['train','validation'].includes(sessionAssignments.get(s.session_id))))throw Error('모든 회차를 훈련용 또는 검증용으로 선택하세요.');
  const train_sessions=sessions.filter(s=>sessionAssignments.get(s.session_id)==='train').map(s=>s.session_id);
  const validation_sessions=sessions.filter(s=>sessionAssignments.get(s.session_id)==='validation').map(s=>s.session_id);
  if(!train_sessions.length||!validation_sessions.length)throw Error('훈련용과 검증용에 각각 최소 1회차를 선택하세요.');
  return {train_sessions,validation_sessions};
}
function metricsText(m,type){
  const number=value=>Number.isFinite(value)?value.toFixed(4):'계산 대상 아님';
  const percent=value=>Number.isFinite(value)?(value*100).toFixed(2)+'%':'자료 없음';
  const lines=['학습 모델: '+(modelNames[type]||type),'훈련 '+m.train_row_count+'행 · 검증 '+m.validation_row_count+'행'];
  if(Number.isFinite(m.tree_depth))lines.push('트리 깊이 '+m.tree_depth+' · 리프 '+m.leaf_count+'개');
  for(const [key,title]of [['training','훈련 데이터'],['validation','검증 데이터']]){
    lines.push('',title);
    const score=m[key]||{};
    if(type==='decision_tree_classification')lines.push('방향 분류: 정확도 '+percent(score.accuracy)+' · 정밀도(macro) '+percent(score.macro_precision)+' · 재현율(macro) '+percent(score.macro_recall));
    else{const angular=score.angular_z||{};lines.push('회전 속도: MAE '+number(angular.mae)+' rad/s · RMSE '+number(angular.rmse)+' rad/s · R² '+number(angular.r2))}
  }
  return lines.join('\n');
}
function confusionMatrices(metrics,type){
  const output=$('confusion-matrices');output.replaceChildren();
  if(type!=='decision_tree_classification')return;
  for(const [key,title]of [['training','훈련'],['validation','검증']]){
    const score=metrics[key]||{},labels=score.class_labels||[],matrix=score.confusion_matrix;
    if(!matrix||!labels.length)continue;
    const table=document.createElement('table');table.className='confusion';
    const caption=document.createElement('caption');caption.textContent=title+' 혼동행렬 · 행: 정답 / 열: 예측 (개수)';table.append(caption);
    const head=document.createElement('tr');
    for(const text of ['정답 ╲ 예측',...labels.map(v=>directionNames[v]||v)]){const cell=document.createElement('th');cell.scope='col';cell.textContent=text;head.append(cell)}
    table.append(head);
    labels.forEach((label,i)=>{const row=document.createElement('tr'),heading=document.createElement('th');heading.scope='row';heading.textContent=directionNames[label]||label;row.append(heading);labels.forEach((_,j)=>{const cell=document.createElement('td');cell.textContent=String(matrix[i]?.[j]??0);row.append(cell)});table.append(row)});
    output.append(table);
  }
}
function settings(){
  const type=modelType(),values={model_type:type};
  const keys=type==='linear_regression'?[]:['max_depth','min_samples_leaf','min_samples_split','max_leaf_nodes','random_state'];
  for(const key of keys)values[key]=$(key).value===''?null:Number($(key).value);
  if(type==='linear_regression')values.fit_intercept=$('fit_intercept').checked;
  else values.criterion=$('criterion').value;
  values.split_mode=$('split_mode').value;
  if(values.split_mode==='row')values.train_percent=$('train_percent').value===''?null:Number($('train_percent').value);
  else if(values.split_mode==='session')Object.assign(values,manualSessionSettings());
  values.feature_groups=Array.from(document.querySelectorAll('input[name=features]:checked')).map(e=>e.value);
  return values;
}
function chart(id, rows){const canvas=$(id),ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);if(!rows||!rows.length)return;const pairs=rows.map(r=>[r.actual_angular_z,r.predicted_angular_z]).filter(p=>p.every(Number.isFinite));if(!pairs.length)return;let lo=Math.min(...pairs.flat()),hi=Math.max(...pairs.flat());if(hi-lo<1e-6){const center=(hi+lo)/2;lo=center-0.05;hi=center+0.05}const left=65,top=20,w=canvas.width-left-20,h=canvas.height-top-35;ctx.font='14px Arial';ctx.fillStyle='#59656c';ctx.fillText(hi.toFixed(3),5,top+5);ctx.fillText(lo.toFixed(3),5,top+h);ctx.strokeStyle='#c7d0d4';ctx.strokeRect(left,top,w,h);for(let line=0;line<2;line++){ctx.beginPath();ctx.strokeStyle=line?'#71304f':'#8a969d';ctx.lineWidth=2;for(let i=0;i<pairs.length;i++){const x=left+i/Math.max(1,pairs.length-1)*w,y=top+(hi-pairs[i][line])/(hi-lo)*h;i?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.stroke()}}
function trainingView(t){
  const state=t.state||'idle',labels={idle:'학습 대기',starting:'학습 준비 중',running:'학습 중',completed:'학습 완료',failed:'학습 실패',cancelled:'학습 중단'};
  $('training-status').textContent=(labels[state]||state)+(t.error?'\n'+t.error:'')+(t.log_path?'\n로그: '+t.log_path:'');
  $('training-status').className='status '+(state==='failed'?'error':'');
  lastTrainingState=state;
  const busy=['starting','running'].includes(state);
  gate('train',busy||trainingRequestInFlight||csvRequestInFlight);gate('cancel',!busy);
  $('model-options').disabled=busy||trainingRequestInFlight||csvRequestInFlight;
  splitView();
  if(state==='failed'&&lastFailure!==String(t.log_path)+String(t.error)){lastFailure=String(t.log_path)+String(t.error);warning('학습 실패: '+(t.error||'학습 로그를 확인하세요.'))}
  if(state!=='completed'){
    if(displayedChartModel !== null){
      chart('angular-chart', []);
      $('metrics').textContent='학습 결과 대기';
      $('confusion-matrices').replaceChildren();
      $('model-path').textContent='';
    }
    displayedChartModel = null;
    updateChartLegend(modelType());
    return;
  }
  const r=t.result||t,type=r.model_type||r.settings?.model_type||'decision_tree_regression',classification=type==='decision_tree_classification';
  $('metrics').textContent=metricsText(r.metrics||{},type);confusionMatrices(r.metrics||{},type);
  displayedChartModel = type;
  updateChartLegend(type);
  const path=r.model_path||'';$('model-path').textContent='저장된 '+(modelNames[type]||type)+' 모델: '+path;
  chart('angular-chart',r.curve_sample);
  if(path&&lastDone!==path){lastDone=path;$('done-path').textContent=path;if(!$('done-dialog').open)$('done-dialog').showModal()}
}
async function refresh(){if(pollBusy)return;pollBusy=true;const requestedTrainingRevision=trainingRevision;try{const response=await fetch('/api/status',{cache:'no-store'});if(!response.ok)throw Error('서버 응답 오류');const s=await response.json();$('vehicle').textContent='차량 IP '+(s.vehicle.ip||location.hostname);buildGrid(s.lane?.grid||s.grid_defaults);const r=s.recording;gate('record-start',r.recording);gate('record-stop',!r.recording);gate('apply-grid',r.recording);for(const input of $('grid-fields').querySelectorAll('input'))input.disabled=r.recording;$('record-status').textContent=(r.recording?'기록 중':'기록 중지')+'\n저장 샘플 수: '+(r.rows_written||0)+' · 시간 미일치 등 제외: '+(r.skipped_unmatched||0)+'\n파일: '+(r.path||'미지정')+(r.error?'\n'+r.error:'');const ready=!!r.path&&!r.recording;$('download').setAttribute('aria-disabled',String(!ready));if(ready)$('download').href='/api/csv/download?path='+encodeURIComponent(r.path);$('command-topic').textContent=s.command_topic;$('command-status').textContent=s.command?'전진 '+Number(s.command.linear_x).toFixed(3)+' m/s · 회전 '+Number(s.command.angular_z).toFixed(3)+' rad/s · 명령 경과 '+Number(s.command_age_seconds).toFixed(2)+'초':'리모컨 수신 대기';$('camera-status').textContent=s.lane?'영상 경과 '+Number(s.frame_age_seconds).toFixed(2)+'초 · 처리 '+Number(s.lane.processing_ms||0).toFixed(1)+' ms'+(s.lane.error?' · '+s.lane.error:''):'격자 영상 수신 대기';if(s.lane?.features){const f=s.lane.features;$('features').textContent='V: '+JSON.stringify(f.V)+'\nL: '+JSON.stringify(f.L)+'\nR: '+JSON.stringify(f.R)}if(requestedTrainingRevision===trainingRevision)trainingView(s.training)}catch(error){notice(error.message,true)}finally{pollBusy=false}}
$('record-start').onclick=()=>action(async()=>{await api('/api/record/start',{directory:$('record-directory').value});notice('기록을 시작했습니다. 리모컨을 이용해 주행하세요.')});
$('record-stop').onclick=()=>action(async()=>{await api('/api/record/stop');notice('기록을 저장했습니다. 다운로드하여 이용하세요.')});
$('apply-grid').onclick=()=>action(async()=>{const config={};for(const key of Object.keys(gridLabels))config[key]=Number($('grid-'+key).value);await api('/api/grid',config);notice('격자 설정을 적용했습니다.')});
// ANGULAR_ONLY_CSV_FEEDBACK: show errors beside the button, not only at the page top.
async function csvAction(url, options){
  if(csvRequestInFlight){warning('CSV 검사 중입니다. 응답을 기다리세요.');return;}
  csvRequestInFlight=true;
  selectedCsv=null;resetSessionSelection();
  $('model-options').disabled=true;gate('train',true);
  const output=$('csv-summary');
  output.className='status';output.textContent='CSV 검사 중…';
  gate('select-csv',true);gate('upload-csv',true);
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),60000);
  try{
    const response=await fetch(url,{...options,signal:controller.signal});
    const result=await response.json();
    if(!response.ok||result.ok===false)throw Error(result.error||'CSV 검사 실패');
    showCsv(result);
  }catch(error){
    selectedCsv=null;
    resetSessionSelection();
    output.className='status error';
    output.textContent=error.name==='AbortError'?'60초 안에 응답이 없습니다. 서버 상태를 확인하고 다시 검사하세요.':'CSV 검사 실패: '+error.message;
    warning(output.textContent);
  }finally{
    csvRequestInFlight=false;
    const busy=trainingRequestInFlight||['starting','running'].includes(lastTrainingState);
    $('model-options').disabled=busy;gate('train',busy);
    splitView();
    clearTimeout(timer);gate('select-csv',false);gate('upload-csv',false);
  }
}
$('select-csv').onclick=()=>csvAction('/api/csv/select',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:$('csv-path').value.trim(),model_type:modelType()})});
$('upload-csv').onclick=()=>{
  const file=$('csv-file').files[0];
  if(!file){selectedCsv=null;resetSessionSelection();$('csv-summary').className='status error';$('csv-summary').textContent='수정한 CSV를 선택하세요.';warning('수정한 CSV를 선택하세요.');return;}
  const url='/api/csv/upload?directory='+encodeURIComponent($('upload-directory').value.trim())+'&filename='+encodeURIComponent(file.name)+'&model_type='+encodeURIComponent(modelType());
  return csvAction(url,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:file});
};
$('train').onclick=async()=>{
  if(csvRequestInFlight){warning('CSV 검사 중입니다. 응답을 기다리세요.');return;}
  if(!selectedCsv||$('csv-path').value.trim()!==selectedCsv.path){warning('현재 CSV 경로를 검사·선택한 뒤 학습을 시작하세요.');return;}
  if(trainingRequestInFlight||['starting','running'].includes(lastTrainingState)){warning(buttonReasons.train);return;}
  trainingRequestInFlight=true;
  splitView();
  trainingRevision++;
  gate('train',true);
  $('model-options').disabled=true;
  try{
    const result=await api('/api/tree/train',{settings:settings(),output_directory:$('output-directory').value});
    trainingView(result.training);
    notice('학습을 시작했습니다.');
  }catch(error){
    warning(error.message);
  }finally{
    trainingRequestInFlight=false;
    trainingRevision++;
    gate('train',['starting','running'].includes(lastTrainingState));
    $('model-options').disabled=['starting','running'].includes(lastTrainingState);
    splitView();
    await refresh();
  }
};
$('cancel').onclick=()=>action(async()=>{await api('/api/tree/cancel');notice('학습을 중단했습니다.')});
$('close-dialog').onclick=()=>$('done-dialog').close();
$('preview').onerror=()=>setTimeout(()=>{$('preview').src='/stream.mjpg?retry='+Date.now()},1000);

// Retain existing handlers and backend validation; serialize each explicit action.
for(const id of ['record-start','record-stop','apply-grid','select-csv','upload-csv','train','cancel']){
  const button=$(id),original=button.onclick;
  button.onclick=async function(event){
    if(button.dataset.pending==='true')return;
    button.dataset.pending='true';
    try{await original.call(this,event)}
    catch(error){warning(error.message)}
    finally{delete button.dataset.pending}
  };
}
$('download').onclick=async event=>{
  event.preventDefault();
  const b=$('download');b.dataset.pending='true';
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),60000);
  try{
    const r=await fetch(b.href,{cache:'no-store',signal:controller.signal});
    if(!r.ok){const j=await r.json();throw Error(j.error||'CSV 다운로드 실패')}
    const blob=await r.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download=new URL(b.href).searchParams.get('path').split('/').pop();
    document.body.append(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),60000);
  }catch(error){warning(error.name==='AbortError'?'다운로드 응답 시간이 초과됐습니다.':error.message)}
  finally{clearTimeout(timer);delete b.dataset.pending}
};
gate('record-stop',true);gate('cancel',true);
$('csv-path').addEventListener('input',()=>{
  if(selectedCsv&&$('csv-path').value.trim()!==selectedCsv.path){selectedCsv=null;resetSessionSelection();$('csv-summary').className='status';$('csv-summary').textContent='CSV 경로가 변경되었습니다. CSV 검사·선택을 다시 누르세요.'}
});
$('csv-file').addEventListener('change',()=>{selectedCsv=null;resetSessionSelection();$('csv-summary').className='status';$('csv-summary').textContent='업로드할 파일이 변경되었습니다. 업로드한 파일 검사를 누르세요.'});
$('split_mode').addEventListener('change',splitView);
document.querySelectorAll('input[name=model_type]').forEach(input=>input.addEventListener('change',()=>{
  modelView();
  if(selectedCsv)$('select-csv').click();
}));
document.querySelector('input[name=model_type][value=decision_tree_classification]').checked=true;
modelView();
splitView();

refresh();setInterval(refresh,500);
</script></body></html>'''
