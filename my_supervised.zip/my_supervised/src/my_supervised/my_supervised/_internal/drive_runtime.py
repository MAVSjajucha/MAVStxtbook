"""Camera, inference, motion gate and live display for the two student missions."""

from collections import deque
import json
import math
import signal
import socket
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Dict
from urllib.parse import urlparse

import cv2
import numpy as np
import rclpy
from geometry_msgs.msg import Twist
from rcl_interfaces.srv import SetParameters
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile, HistoryPolicy, ReliabilityPolicy, DurabilityPolicy
from rclpy.signals import SignalHandlerOptions
from sensor_msgs.msg import CompressedImage, Image
from std_msgs.msg import String

from my_supervised._internal.grid_features import (
    DEFAULT_GRID, process_grid, validate_grid,
)
from my_supervised._internal.model_paths import resolve_yolo_model
from my_supervised._internal.joy_control import JoyControl


DRIVE_PAGE = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>지도 학습 주행 확인</title><style>
:root{color-scheme:light;--page:#f3f5f5;--panel:#e7edef;--ink:#171d21;
--muted:#536269;--line:#c7d0d4;--accent:#71304f;--teal:#267d78;--danger:#a44855}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font-family:Arial,sans-serif}
.wrap{max-width:1120px;margin:auto;padding:22px}
.header,.row,.toolbar,.controls{display:flex;align-items:center;gap:14px}
.header{justify-content:space-between;margin-bottom:18px;flex-wrap:wrap}h1{margin:0;font-size:26px}
.vehicle{background:white;border:1px solid var(--line);padding:10px 14px;font-weight:700}
.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;
padding:18px;margin-bottom:16px;min-width:0}
.controls{margin-left:auto}.state{font-weight:bold}.ok{color:var(--teal)}.stop,.error{color:var(--danger)}
button{width:62px;height:62px;border:0;border-radius:50%;font-size:26px;color:white;cursor:pointer}
button:disabled{background:#a8b3b8;cursor:not-allowed}
.pause{background:var(--danger)}.start{background:var(--teal)}
.handover{display:flex;gap:12px;flex-wrap:wrap}.handover button{width:auto;height:auto;
padding:12px 18px;border-radius:7px;font-size:16px;background:var(--accent)}
.handover button:disabled{background:#a8b3b8}
button:focus-visible,input:focus-visible,select:focus-visible{
outline:3px solid var(--accent);outline-offset:3px}
.small{color:var(--muted);font-size:14px;line-height:1.6;overflow-wrap:anywhere}
.toolbar{justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}
.options{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
label{display:flex;align-items:center;gap:8px}
select{background:white;color:var(--ink);border:1px solid var(--line);padding:7px}
#frame-wrap{width:100%;margin:0 auto}
#frame{display:block;width:100%;height:auto;background:#000;border-radius:10px}
#error{min-height:1.5em;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere}
@media(max-width:560px){.wrap{padding:12px}h1{font-size:22px}.row{gap:8px}
button{width:50px;height:50px}.card{padding:12px}}
</style></head><body><main class="wrap">
<header class="header"><h1>지도 학습 주행 확인</h1>
<div id="vehicle" class="vehicle">차량 IP 확인 중</div></header>
<section class="card"><div class="row"><span>주행 상태</span>
<span id="state" class="state stop">정지</span><div class="controls">
<button id="pause" class="pause" title="자동 주행 정지 (p)" aria-label="자동 주행 정지">Ⅱ</button>
<button id="start" class="start" title="주행 허용 (s)" aria-label="주행 허용" disabled>▶</button>
</div></div><p id="detail" class="small">상태 확인 중</p><p id="model" class="small"></p>
<p id="error" class="error" role="status"></p>
<p id="runtime-error" class="error" role="status"></p>
<div class="handover"><button id="auto-mode">리모컨 연결 해제</button>
<button id="manual-mode">리모컨 연결</button></div>
<p id="joy-status" class="small" role="status"></p>
<p class="small"></p></section>
<section class="card"><div class="toolbar"><strong>출력 영상</strong><div class="options">
<label><input id="show-grid" type="checkbox">격자 표시</label>
<label>영상 크기 <select id="image-scale"><option value="100">100%</option>
<option value="75">75%</option><option value="50">50%</option></select></label>
</div></div><div id="frame-wrap"><img id="frame" alt="차량 카메라 주행 영상"></div>
<p id="rates" class="small"></p><p class="small">p: 자동 주행 정지 · s: 자동 주행 허용</p>
<pre id="features" class="small"></pre></section></main><script>
const $=id=>document.getElementById(id);let gridBusy=false,refreshBusy=false,retryTimer=null;
async function request(url,data){
  const r=await fetch(url,{method:data?'POST':'GET',cache:'no-store',
    headers:{'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});
  const j=await r.json();
  if(!r.ok||j.ok===false)throw Error(j.message||j.error||'요청 실패');
  return j;
}
async function control(action){
  try{await request('/api/control',{action});$('error').textContent='';await refresh()}
  catch(e){$('error').textContent=e.message}
}
function hz(v){return Number(v||0).toFixed(1)}
async function refresh(){
  if(refreshBusy)return;refreshBusy=true;
  try{
    const s=await request('/api/status');
    const local=['localhost','127.0.0.1','::1'].includes(location.hostname);
    $('vehicle').textContent='차량 IP '+(local?s.vehicle.ip:location.hostname);
    $('state').textContent=s.joystick.mode==='manual'?'리모컨 연결':
      (s.driving_enabled?'자동 주행 허용':'자동 주행 정지');
    $('state').className='state '+(s.driving_enabled?'ok':'stop');
    $('start').disabled=!s.enable_motion||!s.ready||!s.joystick.auto_ready;
    $('auto-mode').disabled=$('manual-mode').disabled=!s.enable_motion||s.joystick.busy;
    $('joy-status').textContent=s.joystick.message;
    const mode=s.mission_mode==='obstacle'?'YOLO 장애물 회피':'분류·회귀 모델 차선 주행';
    $('detail').textContent='모드: '+mode+' | 모터: '+(s.enable_motion?'작동':'미작동');
    $('model').textContent='모델: '+(s.model_path||'대기 중');
    $('runtime-error').textContent=s.last_error||'';
    if(!gridBusy)$('show-grid').checked=s.show_grid;
    const input=s.mission_mode==='obstacle'?'카메라 수신':'차선 예측 수신';
    const age=s.frame_age_seconds===null?'-':s.frame_age_seconds.toFixed(2);
    $('rates').textContent=input+' '+hz(s.input_hz)+' Hz · 판단 처리 '+hz(s.decision_hz)
      +' Hz · 웹용 영상 생성/수신 '+hz(s.preview_hz)+' Hz · 영상 갱신 후 '+age+'초';
    const f=s.features;
    $('features').textContent=f?'V: '+JSON.stringify(f.V)+'\nL: '+JSON.stringify(f.L)
      +'\nR: '+JSON.stringify(f.R)+'\n예측 회전 속도 (angular_z, rad/s): '
      +(s.prediction?s.prediction.angular_z:'대기 중')
      +(s.prediction&&s.prediction.direction?'\n예측 방향: '+s.prediction.direction:'')
      +'\n전진 속도는 decision_node.py에서 학생이 직접 지정합니다.':
      '';
  }catch(e){$('error').textContent=e.message}finally{refreshBusy=false}
}
$('pause').onclick=()=>control('pause');$('start').onclick=()=>control('start');
async function switchMode(mode){
  if(!confirm('차량을 정지했나요? 리모컨 연결 상태를 전환합니다. 리모컨 연결 시 서보가 초기화될 수 있습니다.'))return;
  $('start').disabled=$('auto-mode').disabled=$('manual-mode').disabled=true;
  try{await request('/api/joystick/mode',{mode});$('error').textContent='';await refresh()}
  catch(e){$('error').textContent=e.message;await refresh()}
}
$('auto-mode').onclick=()=>switchMode('auto');
$('manual-mode').onclick=()=>switchMode('manual');
$('image-scale').onchange=()=>{$('frame-wrap').style.width=$('image-scale').value+'%'};
$('show-grid').onchange=async()=>{
  gridBusy=true;$('show-grid').disabled=true;
  try{await request('/api/view',{show_grid:$('show-grid').checked});$('error').textContent=''}
  catch(e){$('error').textContent=e.message}
  finally{gridBusy=false;$('show-grid').disabled=false;await refresh()}
};
document.addEventListener('keydown',e=>{
  if(e.repeat||e.ctrlKey||e.metaKey||e.altKey)return;
  const key=e.key.toLowerCase();
  if(key==='p'){e.preventDefault();control('pause')}
  else if(key==='s'){e.preventDefault();control('start')}
});
function connect(){clearTimeout(retryTimer);$('frame').src='/stream.mjpg?t='+Date.now()}
$('frame').onerror=()=>{clearTimeout(retryTimer);retryTimer=setTimeout(connect,1500)};
window.addEventListener('online',connect);connect();refresh();setInterval(refresh,700);
</script></body></html>"""


class LatestInput:
    """One waiting item only: an overloaded consumer skips old frames."""

    def __init__(self):
        """Create an empty latest-value mailbox."""
        self.condition = threading.Condition()
        self.sequence = 0
        self.item = None
        self.closed = False

    def put(self, value, generation):
        """Replace an older waiting item and notify a consumer."""
        with self.condition:
            self.sequence += 1
            self.item = (self.sequence, value, generation)
            self.condition.notify_all()

    def take_after(self, sequence, timeout=0.5):
        """Return only a newer item, or None after timeout or closure."""
        with self.condition:
            self.condition.wait_for(
                lambda: self.closed or self.sequence > sequence, timeout=timeout)
            if self.closed or self.sequence <= sequence:
                return None
            return self.item

    def close(self):
        """Wake all waiters when the runtime stops."""
        with self.condition:
            self.closed = True
            self.condition.notify_all()


class RateMeter:
    """Observed event frequency over the last two seconds, not a configured FPS."""

    def __init__(self):
        """Keep a short, bounded event history."""
        self.times = deque(maxlen=400)

    def mark(self):
        """Record an event at the current monotonic time."""
        self.times.append(time.monotonic())

    def rate(self):
        """Return the observed recent event rate."""
        now = time.monotonic()
        while self.times and now - self.times[0] > 2.0:
            self.times.popleft()
        if len(self.times) < 2:
            return 0.0
        return (len(self.times) - 1) / max(now - self.times[0], 1e-6)


def sensor_qos():
    """Use a one-message best-effort queue for live sensor data."""
    return QoSProfile(depth=1, history=HistoryPolicy.KEEP_LAST,
                      reliability=ReliabilityPolicy.BEST_EFFORT,
                      durability=DurabilityPolicy.VOLATILE)


def _vehicle_identity():
    name, ip = socket.gethostname(), 'unknown'
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(('10.255.255.255', 1))
        ip = probe.getsockname()[0]
    except OSError:
        try:
            ip = socket.gethostbyname(name)
        except OSError:
            pass
    finally:
        probe.close()
    return {'name': name, 'ip': ip}


class DecisionRuntime(Node):
    """Keep inference off ROS callbacks and serialize pause with command publishing."""

    def __init__(self, student_functions: Dict[str, Callable]):
        """Load the selected model and start input, output and web services."""
        super().__init__('supervised_decision_node')
        defaults = {
            'mission_mode': 'obstacle', 'enable_motion': True,
            'rgb_topic': '/ascamera_hp60c/camera_publisher/rgb0/image',
            'box_model': '', 'lane_model': '', 'show_grid': True,
            'max_linear_speed': 0.5, 'max_angular_speed': 0.5,
            'inference_hz': 25.0, 'preview_hz': 25.0,
            'confidence': 0.25, 'iou': 0.45, 'device': '0', 'web_port': 8082,
        }
        defaults.update(DEFAULT_GRID)
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        self._student_functions = student_functions
        self.mode = str(self.get_parameter('mission_mode').value)
        if self.mode not in ('obstacle', 'lane'):
            raise ValueError('mission_mode는 obstacle 또는 lane이어야 합니다.')
        if not callable(student_functions.get(self.mode)):
            raise ValueError(f'{self.mode}_decision 함수를 decision_node.py에 작성하세요.')
        self.enable_motion = bool(self.get_parameter('enable_motion').value)
        self.max_linear = abs(float(self.get_parameter('max_linear_speed').value))
        self.max_angular = abs(float(self.get_parameter('max_angular_speed').value))
        self.inference_hz = float(self.get_parameter('inference_hz').value)
        self.preview_hz = float(self.get_parameter('preview_hz').value)
        if not all(math.isfinite(v) and v > 0 for v in (
                self.max_linear, self.max_angular, self.inference_hz, self.preview_hz)):
            raise ValueError('속도 상한과 처리 주기는 양의 유한한 숫자여야 합니다.')
        self.confidence = float(self.get_parameter('confidence').value)
        self.iou = float(self.get_parameter('iou').value)
        self.device = str(self.get_parameter('device').value)
        self._grid = validate_grid({key: self.get_parameter(key).value for key in DEFAULT_GRID})
        self._show_grid = bool(self.get_parameter('show_grid').value)
        self._identity = _vehicle_identity()
        self._lock = threading.RLock()
        self._view_lock = threading.Lock()
        self._frame_condition = threading.Condition(self._lock)
        self._pending = LatestInput()
        self._stop = threading.Event()
        self._generation = 0
        self._driving_enabled = False
        self._inference_count = 0
        self._last_error = ''
        self._last_boxes = []
        self._features = None
        self._prediction = None
        self._lane_ready = False
        self._display_jpeg = b''
        self._display_sequence = 0
        self._display_time = None
        self._viewers = 0
        self._frame_requested_at = 0.0
        self._preview_subscription = None
        self._httpd = None
        self._input_rate, self._decision_rate, self._preview_rate = (
            RateMeter(), RateMeter(), RateMeter())
        self._box_model = None
        self._model_path = str(self.get_parameter('lane_model').value)
        if self.mode == 'obstacle':
            from ultralytics import YOLO
            self._model_path = str(resolve_yolo_model(
                str(self.get_parameter('box_model').value), task='detect'))
            self._box_model = YOLO(self._model_path)
            if self._box_model.task != 'detect':
                raise ValueError('box_model에는 객체 탐지 모델을 지정하세요.')
            self.get_logger().info(f'Obstacle model: {self._model_path}')
        self._cmd_pub = self.create_publisher(
            Twist, '/cmd_vel', 10) if self.enable_motion else None
        if self._cmd_pub is not None:
            self._cmd_pub.publish(Twist())
        self._joy = JoyControl(self.pause, self.enable_motion)
        if self.mode == 'obstacle':
            self.create_subscription(Image, str(self.get_parameter('rgb_topic').value),
                                     self._on_image, sensor_qos())
        else:
            self.create_subscription(String, '/supervised/lane_result',
                                     self._on_lane_result, sensor_qos())
            self._grid_client = self.create_client(
                SetParameters, '/supervised_lane_processor/set_parameters')
            self.create_timer(0.2, self._update_preview_subscription)
        self._start_web(int(self.get_parameter('web_port').value))
        self._worker = threading.Thread(
            target=self._work, daemon=True, name='decision-latest-frame')
        self._worker.start()
        self.get_logger().info(
            f'Decision ready: mode={self.mode}, enable_motion={self.enable_motion}, '
            f'web=http://{self._identity["ip"]}:{self.get_parameter("web_port").value}')

    @property
    def ready(self):
        """Return whether the selected model can supply student inputs."""
        return self._box_model is not None if self.mode == 'obstacle' else self._lane_ready

    def _on_image(self, msg):
        # Store the ROS message only. Conversion/inference never block camera reception.
        with self._lock:
            self._input_rate.mark()
            generation = self._generation
        self._pending.put(msg, generation)

    def _on_lane_result(self, msg):
        try:
            result = json.loads(msg.data)
            if not isinstance(result, dict):
                raise ValueError('lane_result must be a JSON object')
            with self._lock:
                self._input_rate.mark()
                generation = self._generation
            self._pending.put(result, generation)
        except (ValueError, TypeError) as error:
            self.pause()
            self._set_error(f'차선 예측 수신 오류: {error}')

    def _update_preview_subscription(self):
        # Called on the ROS executor, not a web thread. No subscribers => no lane JPEG work.
        with self._lock:
            wanted = self._viewers > 0 or time.monotonic() - self._frame_requested_at < 2.0
        if wanted and self._preview_subscription is None:
            self._preview_subscription = self.create_subscription(
                CompressedImage, '/supervised/lane_preview', self._on_lane_preview, sensor_qos())
        elif not wanted and self._preview_subscription is not None:
            self.destroy_subscription(self._preview_subscription)
            self._preview_subscription = None

    def _on_lane_preview(self, msg):
        self._store_frame(bytes(msg.data))

    @staticmethod
    def _image_to_bgr(msg):
        encoding = msg.encoding.lower()
        if encoding not in ('bgr8', 'rgb8', 'bgra8', 'rgba8'):
            raise ValueError(f'지원하지 않는 RGB 인코딩: {msg.encoding}')
        channels = 4 if encoding in ('bgra8', 'rgba8') else 3
        rows = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.step)
        image = rows[:, :msg.width * channels].reshape(msg.height, msg.width, channels).copy()
        conversion = {'rgb8': cv2.COLOR_RGB2BGR, 'rgba8': cv2.COLOR_RGBA2BGR,
                      'bgra8': cv2.COLOR_BGRA2BGR}
        return cv2.cvtColor(image, conversion[encoding]) if encoding in conversion else image

    @staticmethod
    def _boxes(result):
        if result.boxes is None:
            return []
        # One transfer per tensor, rather than a GPU transfer per individual object.
        coordinates = result.boxes.xyxy.cpu().tolist()
        classes = result.boxes.cls.cpu().tolist()
        confidences = result.boxes.conf.cpu().tolist()
        output = []
        for xyxy, class_id, confidence in zip(coordinates, classes, confidences):
            x1, y1, x2, y2 = map(float, xyxy)
            class_id = int(class_id)
            name = (result.names.get(class_id, class_id) if isinstance(result.names, dict)
                    else result.names[class_id])
            output.append(dict(class_id=class_id, class_name=str(name),
                               confidence=float(confidence),
                               x1=x1, y1=y1, x2=x2, y2=y2, center_x=(x1 + x2) / 2,
                               center_y=(y1 + y2) / 2, width=x2 - x1, height=y2 - y1))
        return output

    def _limit_command(self, command):
        if not isinstance(command, Twist):
            raise TypeError('학생 판단 함수는 Twist를 반환해야 합니다.')
        limits = ((command.linear, self.max_linear), (command.angular, self.max_angular))
        for vector, limit in limits:
            for axis in ('x', 'y', 'z'):
                value = float(getattr(vector, axis))
                if not math.isfinite(value):
                    raise ValueError('Twist 값에 NaN 또는 무한대가 있습니다.')
                setattr(vector, axis, max(-limit, min(limit, value)))
        return command

    @staticmethod
    def _lane_prediction(prediction):
        """Accept angular-only regression or an explicitly mapped direction class."""
        if not isinstance(prediction, dict) or set(prediction) not in (
                {'angular_z'}, {'angular_z', 'direction'}):
            raise ValueError(
                '차선 예측은 angular_z(분류 모델은 direction도 포함)이어야 합니다. '
                '수정된 패키지로 재학습하고 차선 처리 노드도 다시 실행하세요.')
        value = prediction['angular_z']
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError('예측 angular_z는 유한한 숫자여야 합니다.')
        if not math.isfinite(value):
            raise ValueError('예측 angular_z는 유한한 숫자여야 합니다.')
        output = {'angular_z': float(value)}
        if 'direction' in prediction:
            direction = prediction['direction']
            commands = {'left': 0.5, 'right': -0.5, 'straight': 0.0}
            if not isinstance(direction, str) or direction not in commands:
                raise ValueError('분류 방향은 left, right, straight 중 하나이어야 합니다.')
            if value != commands[direction]:
                raise ValueError('분류 방향과 회전 명령이 일치하지 않습니다: 좌 +0.5, 우 -0.5, 직진 0.')
            output['direction'] = direction
        return output

    def _publish_if_allowed(self, command, generation):
        # The same lock protects p, s and publishing. A pre-pause job cannot publish after s.
        with self._lock:
            if (self._cmd_pub is not None and self._driving_enabled
                    and self._joy.allowed.is_set()
                    and generation == self._generation and not self._stop.is_set()):
                self._cmd_pub.publish(command)

    def _work(self):
        sequence, next_work, last_preview = 0, 0.0, 0.0
        while not self._stop.is_set():
            if self._stop.wait(max(0.0, next_work - time.monotonic())):
                break
            item = self._pending.take_after(sequence)
            if item is None:
                continue
            sequence, payload, generation = item
            started = time.monotonic()
            next_work = started + 1.0 / self.inference_hz
            try:
                preview = None
                if self.mode == 'obstacle':
                    image = self._image_to_bgr(payload)
                    result = self._box_model.predict(
                        source=image, conf=self.confidence, iou=self.iou,
                        device=self.device, verbose=False)[0]
                    boxes = self._boxes(result)
                    command = self._student_functions['obstacle'](image.copy(), boxes)
                    with self._lock:
                        self._last_boxes = boxes
                        viewers = (self._viewers > 0
                                   or time.monotonic() - self._frame_requested_at < 2.0)
                        show_grid = self._show_grid
                    if viewers and time.monotonic() - last_preview >= 1.0 / self.preview_hz:
                        preview = (image, boxes, show_grid)
                else:
                    error, prediction = payload.get('error'), payload.get('prediction')
                    with self._lock:
                        self._features = payload.get('features')
                        self._prediction = None
                        self._lane_ready = False
                    if error or prediction is None:
                        raise ValueError(error or '차선 모델의 예측 결과가 없습니다.')
                    prediction = self._lane_prediction(prediction)
                    features = payload['features']
                    command = self._student_functions['lane'](
                        list(features['V']), list(features['L']),
                        list(features['R']), dict(prediction))
                command = self._limit_command(command)
                self._publish_if_allowed(command, generation)
                with self._lock:
                    if self.mode == 'lane':
                        self._prediction = prediction
                        self._lane_ready = True
                    self._inference_count += 1
                    self._decision_rate.mark()
                    self._last_error = ''
                # Display conversion must not delay a motion command already computed.
                if preview is not None:
                    self._store_frame(self._render_box(*preview))
                    last_preview = time.monotonic()
            except Exception as error:
                self.pause()
                self._set_error(f'판단 오류: {type(error).__name__}: {error}',
                                detail=traceback.format_exc())

    def _render_box(self, image, boxes, show_grid):
        canvas = process_grid(image, self._grid, draw=True)[0] if show_grid else image.copy()
        sx, sy = canvas.shape[1] / image.shape[1], canvas.shape[0] / image.shape[0]
        for box in boxes:
            p1 = (int(box['x1'] * sx), int(box['y1'] * sy))
            p2 = (int(box['x2'] * sx), int(box['y2'] * sy))
            cv2.rectangle(canvas, p1, p2, (255, 180, 0), 2)
            cv2.putText(canvas, f"{box['class_id']}, {box['class_name']} {box['confidence']:.2f}",
                        (p1[0], max(18, p1[1])), cv2.FONT_HERSHEY_SIMPLEX, .55, (255, 180, 0), 2)
        ok, output = cv2.imencode('.jpg', canvas, [cv2.IMWRITE_JPEG_QUALITY, 80])
        if not ok:
            raise ValueError('JPEG 인코딩 실패')
        return output.tobytes()

    def _store_frame(self, jpeg):
        if not jpeg:
            return
        with self._frame_condition:
            self._display_jpeg = jpeg
            self._display_sequence += 1
            self._display_time = time.monotonic()
            self._preview_rate.mark()
            self._frame_condition.notify_all()

    def _set_error(self, text, detail=''):
        with self._lock:
            changed = text != self._last_error
            self._last_error = text
        if changed:
            self.get_logger().error(text + ('\n' + detail if detail else ''))

    def start(self):
        """Permit commands from new frames after an explicit start action."""
        with self._lock:
            if not self.enable_motion:
                return False, 'enable_motion=false: 현재는 영상 확인 모드입니다.'
            if not self._joy.allowed.is_set():
                return False, '리모컨 연결 해제를 먼저 완료하세요.'
            if not self.ready:
                return False, self._last_error or '모델 또는 차선 예측을 기다리고 있습니다.'
            self._generation += 1
            self._driving_enabled = True
        return True, '주행 허용'

    def pause(self, force=False):
        """Invalidate pending commands and publish zero while holding the motion lock."""
        with self._lock:
            was_driving = self._driving_enabled
            self._generation += 1
            self._driving_enabled = False
            if self._cmd_pub is not None and (was_driving or force
                                             or self._joy.allowed.is_set()):
                self._cmd_pub.publish(Twist())

    def set_show_grid(self, enabled):
        """Change only grid visibility, using the lane node's parameter service."""
        if not isinstance(enabled, bool):
            raise ValueError('show_grid에는 true 또는 false를 지정하세요.')
        with self._view_lock:
            if self.mode == 'lane':
                if not self._grid_client.wait_for_service(timeout_sec=1.0):
                    raise RuntimeError('차선 처리 노드의 격자 설정 서비스를 찾지 못했습니다.')
                request = SetParameters.Request()
                request.parameters = [Parameter('show_grid', value=enabled).to_parameter_msg()]
                finished = threading.Event()
                future = self._grid_client.call_async(request)
                future.add_done_callback(lambda _: finished.set())
                # An HTTP thread waits; the ROS executor stays free to finish the future.
                if not finished.wait(3.0):
                    raise TimeoutError('격자 표시 변경 응답 시간이 초과되었습니다.')
                response = future.result()
                if not response.results or not all(item.successful for item in response.results):
                    raise RuntimeError(
                        '; '.join(item.reason for item in response.results) or '격자 변경 실패')
            with self._lock:
                self._show_grid = enabled

    def status(self):
        """Return runtime state and measured frequencies for the web display."""
        joystick = self._joy.status()
        with self._lock:
            frame_age = (None if self._display_time is None
                         else time.monotonic() - self._display_time)
            return dict(ok=True, mission_mode=self.mode, enable_motion=self.enable_motion,
                        driving_enabled=self._driving_enabled, ready=self.ready,
                        joystick=joystick,
                        show_grid=self._show_grid,
                        model_path=self._model_path, inference_hz=self.inference_hz,
                        inference_count=self._inference_count, input_hz=self._input_rate.rate(),
                        decision_hz=self._decision_rate.rate(),
                        preview_hz=self._preview_rate.rate(),
                        preview_hz_limit=self.preview_hz,
                        frame_age_seconds=frame_age,
                        box_count=len(self._last_boxes), features=self._features,
                        prediction=self._prediction,
                        last_error=self._last_error, vehicle=self._identity,
                        max_linear_speed=self.max_linear, max_angular_speed=self.max_angular)

    def frame_jpeg(self):
        """Request fresh preview work and return the latest cached JPEG."""
        with self._lock:
            self._frame_requested_at = time.monotonic()
            return self._display_jpeg

    def wait_frame_jpeg(self, sequence, timeout=1.0):
        """Wait for a newer cached JPEG or node shutdown."""
        with self._frame_condition:
            self._frame_condition.wait_for(
                lambda: self._stop.is_set() or self._display_sequence != sequence, timeout=timeout)
            return self._display_sequence, self._display_jpeg

    def _start_web(self, port):
        runtime = self

        class Handler(BaseHTTPRequestHandler):
            """Serve the monitor and control actions on independent HTTP threads."""

            def log_message(self, *_):
                """Omit routine per-frame HTTP logging."""
                pass

            def setup(self):
                """Bound socket write time so slow viewers cannot accumulate frames."""
                super().setup()
                self.connection.settimeout(3.0)

            def send(self, code, body, kind):
                """Send one uncached response."""
                self.send_response(code)
                self.send_header('Content-Type', kind)
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def json(self, code, value):
                """Send a JSON response with readable Korean text."""
                self.send(code, json.dumps(value, ensure_ascii=False).encode(),
                          'application/json; charset=utf-8')

            def stream(self):
                """Send only the most recent JPEG through one persistent connection."""
                with runtime._lock:
                    runtime._viewers += 1
                try:
                    self.send_response(200)
                    self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=frame')
                    self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
                    self.end_headers()
                    sequence = -1
                    while not runtime._stop.is_set():
                        latest, jpeg = runtime.wait_frame_jpeg(sequence)
                        if latest == sequence:
                            continue
                        sequence = latest
                        if not jpeg:
                            continue
                        header = (b'--frame\r\nContent-Type: image/jpeg\r\nContent-Length: '
                                  + str(len(jpeg)).encode() + b'\r\n\r\n')
                        self.wfile.write(header + jpeg + b'\r\n')
                        self.wfile.flush()
                except (OSError, TimeoutError):
                    pass
                finally:
                    with runtime._lock:
                        runtime._viewers -= 1

            def do_GET(self):
                """Serve status, preview or the monitor page."""
                path = urlparse(self.path).path
                try:
                    if path == '/api/status':
                        self.json(200, runtime.status())
                    elif path == '/stream.mjpg':
                        self.stream()
                    elif path == '/frame.jpg':
                        jpeg = runtime.frame_jpeg()
                        self.send(200 if jpeg else 503, jpeg, 'image/jpeg')
                    elif path == '/':
                        self.send(200, DRIVE_PAGE.encode(), 'text/html; charset=utf-8')
                    else:
                        self.send(404, b'not found', 'text/plain')
                except (OSError, TimeoutError):
                    pass

            def do_POST(self):
                """Apply bounded control and view requests."""
                path = urlparse(self.path).path
                try:
                    size = int(self.headers.get('Content-Length', '0'))
                    if not 0 <= size <= 8192:
                        raise ValueError('요청 크기가 잘못되었습니다.')
                    data = json.loads(self.rfile.read(size) or b'{}')
                    if path == '/api/control':
                        action = data.get('action')
                        if action in ('pause', 'p', 'stop'):
                            runtime.pause()
                            ok, message = True, '자동 주행 정지 (수동 리모컨 명령은 별도)'
                        elif action in ('start', 's'):
                            ok, message = runtime.start()
                        else:
                            raise ValueError('action은 start 또는 pause이어야 합니다.')
                        self.json(200 if ok else 409, dict(
                            ok=ok, message=message, status=runtime.status()))
                    elif path == '/api/joystick/mode':
                        runtime._joy.request(data.get('mode'))
                        self.json(200, dict(ok=True, joystick=runtime._joy.status()))
                    elif path == '/api/view':
                        runtime.set_show_grid(data.get('show_grid'))
                        self.json(200, dict(ok=True, show_grid=runtime.status()['show_grid']))
                    else:
                        self.json(404, dict(ok=False, error='not found'))
                except (ValueError, RuntimeError, TimeoutError) as error:
                    self.json(400, dict(ok=False, error=str(error)))
                except OSError:
                    pass

        self._httpd = ThreadingHTTPServer(('0.0.0.0', port), Handler)
        self._httpd.daemon_threads = True
        threading.Thread(target=self._httpd.serve_forever, daemon=True, name='drive-web').start()

    def destroy_node(self):
        """Publish a stop command and release runtime resources."""
        self.pause()
        self._joy.close()
        self._stop.set()
        self._pending.close()
        with self._frame_condition:
            self._frame_condition.notify_all()
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
        if hasattr(self, '_worker'):
            self._worker.join(timeout=3.0)
        return super().destroy_node()


def run_decision_node(student_functions: Dict[str, Callable]):
    """Run only the selected student's function; Ctrl-C publishes a stop command."""
    # Keep the context alive long enough to publish zero on launch SIGINT and SIGTERM.
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)

    def interrupt(_signum, _frame):
        raise KeyboardInterrupt
    previous_term = signal.signal(signal.SIGTERM, interrupt)
    node = None
    try:
        node = DecisionRuntime(student_functions)
        # Bound the native wait so Python signal handlers also run without input.
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        signal.signal(signal.SIGTERM, previous_term)


# YOLO_UI_SETTINGS_PATCH_V2
