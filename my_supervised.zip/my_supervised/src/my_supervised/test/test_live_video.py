"""Verify persistent MJPEG waiting and viewer cleanup without opening a socket."""

import threading
from types import SimpleNamespace

import pytest

from my_supervised._internal.live_video import LatestJpeg, send_mjpeg


class Writer:
    """Capture multipart writes and notify assertions when bytes are sent."""

    def __init__(self, on_write=None):
        self.condition = threading.Condition()
        self.writes = []
        self.on_write = on_write

    def write(self, data):
        if self.on_write:
            self.on_write(data)
        with self.condition:
            self.writes.append(data)
            self.condition.notify_all()

    def flush(self):
        pass

    def wait_for_count(self, count):
        with self.condition:
            return self.condition.wait_for(lambda: len(self.writes) >= count, timeout=1.0)


def handler(writer):
    result = SimpleNamespace(timeout=None, status=None, headers=[], close_connection=False)
    result.connection = SimpleNamespace(settimeout=lambda value: setattr(result, 'timeout', value))
    result.send_response = lambda code: setattr(result, 'status', code)
    result.send_header = lambda name, value: result.headers.append((name, value))
    result.end_headers = lambda: None
    result.wfile = writer
    return result


def start_stream(client, frames):
    errors = []

    def run():
        try:
            send_mjpeg(client, frames)
        except BaseException as error:
            errors.append(error)

    worker = threading.Thread(target=run)
    worker.start()
    return worker, errors


def test_empty_stream_advances_initial_sequence_then_blocks_until_close():
    frames = LatestJpeg()
    waiting = threading.Event()
    sequences = []
    original_wait = frames.wait

    def tracked_wait(sequence, timeout=1.0):
        sequences.append(sequence)
        if len(sequences) == 2:
            waiting.set()
        if len(sequences) > 5:
            raise AssertionError('An empty stream must wait, not spin.')
        return original_wait(sequence, timeout)

    frames.wait = tracked_wait
    client = handler(Writer())
    worker, errors = start_stream(client, frames)
    try:
        assert waiting.wait(1.0)
        assert sequences[:2] == [-1, 0]
        worker.join(0.03)
        assert worker.is_alive()
        assert sequences == [-1, 0]
        assert client.wfile.writes == []
        assert frames.viewers == 1
    finally:
        frames.close()
        worker.join(1.0)
    assert not worker.is_alive()
    assert not errors
    assert frames.viewers == 0
    assert client.close_connection


def test_new_jpeg_is_sent_once_and_the_next_frame_uses_same_connection():
    frames = LatestJpeg()
    writer = Writer()
    client = handler(writer)
    worker, errors = start_stream(client, frames)
    try:
        first = b'\xff\xd8first-jpeg\xff\xd9'
        second = b'\xff\xd8second-jpeg\xff\xd9'
        frames.update(first)
        assert writer.wait_for_count(1)
        worker.join(0.03)
        assert len(writer.writes) == 1
        assert first in writer.writes[0]
        assert f'Content-Length: {len(first)}\r\n'.encode() in writer.writes[0]
        frames.update(second)
        assert writer.wait_for_count(2)
        assert second in writer.writes[1]
        assert first not in writer.writes[1]
        assert client.timeout == 3.0
        assert client.status == 200
    finally:
        frames.close()
        worker.join(1.0)
    assert not worker.is_alive()
    assert not errors
    assert frames.viewers == 0


def test_updates_before_viewer_connects_send_only_latest_jpeg():
    frames = LatestJpeg()
    for index in range(25):
        frames.update(f'jpeg-{index}'.encode())
    writer = Writer(on_write=lambda _: frames.close())
    client = handler(writer)
    send_mjpeg(client, frames)
    assert len(writer.writes) == 1
    assert b'jpeg-24' in writer.writes[0]
    assert b'jpeg-23' not in writer.writes[0]
    assert frames.viewers == 0


@pytest.mark.parametrize('exception', [TimeoutError('slow socket'), OSError('disconnected')])
def test_socket_failure_removes_viewer_and_closes_connection(exception):
    frames = LatestJpeg()
    frames.update(b'jpeg')

    def fail(_):
        assert frames.viewers == 1
        raise exception

    client = handler(Writer(on_write=fail))
    send_mjpeg(client, frames)
    assert frames.viewers == 0
    assert client.close_connection
    assert client.timeout == 3.0


def test_close_wakes_a_waiter_without_a_new_frame():
    frames = LatestJpeg()
    started = threading.Event()
    returned = []

    def wait():
        started.set()
        returned.append(frames.wait(0, timeout=10.0))

    worker = threading.Thread(target=wait)
    worker.start()
    assert started.wait(1.0)
    frames.close()
    worker.join(1.0)
    assert not worker.is_alive()
    assert returned == [(0, b'')]
