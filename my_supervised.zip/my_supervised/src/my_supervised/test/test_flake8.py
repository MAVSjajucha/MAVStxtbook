# Copyright 2015 Open Source Robotics Foundation, Inc.
"""Check Stage 7 Python code with flake8."""
from pathlib import Path
from ament_flake8.main import main_with_errors
import pytest

@pytest.mark.flake8
def test_flake8():
    """Run flake8 on the student file and stable runtime."""
    root = Path(__file__).resolve().parents[1]
    targets = [
        str(root / "my_supervised" / "decision_node.py"),
        str(root / "my_supervised" / "_internal" / "drive_runtime.py"),
    ]
    rc, errors = main_with_errors(argv=targets)
    assert rc == 0, "Found code style errors / warnings:\n" + "\n".join(errors)
