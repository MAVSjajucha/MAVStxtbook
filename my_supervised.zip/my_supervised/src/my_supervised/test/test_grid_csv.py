"""Verify grid semantics and the recorded input/target association without ROS."""

import csv
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from types import ModuleType, SimpleNamespace

import cv2
import numpy as np
import pytest

from my_supervised._internal.csv_recorder import CsvRecorder
from my_supervised._internal.grid_features import (
    DEFAULT_GRID, process_grid, validate_grid,
)


def test_black_image_preserves_no_hit_and_hidden_image():
    image = np.zeros((480, 640, 3), dtype=np.uint8)
    hidden, values = process_grid(image, DEFAULT_GRID, draw=False)
    assert hidden is image
    assert values == {"V": [101] * 7, "L": [321] * 3, "R": [321] * 3,
                      "V_NO_HIT": 101, "L_NO_HIT": 321, "R_NO_HIT": 321}
    visible, drawn_values = process_grid(image, DEFAULT_GRID, draw=True)
    assert drawn_values == values
    assert np.any(visible != image)
    assert not np.any(image)


def test_grid_order_origin_and_nearest_hit(monkeypatch):
    settings = validate_grid({"processing_width": 20, "processing_height": 12,
                              "roi_b": 0, "roi_t": 8, "rows": 3, "cols": 3,
                              "ker_size": 1})
    edges = np.zeros((12, 20), dtype=np.uint8)
    for y, x in [(9, 4), (9, 17), (7, 8), (7, 12), (5, 10), (11, 15)]:
        edges[y, x] = 255
    monkeypatch.setattr(cv2, "Canny", lambda *_: edges)
    _, features = process_grid(np.zeros((12, 20, 3), dtype=np.uint8), settings, False)
    assert features == {"V": [9, 6, 0], "L": [6, 2, 0], "R": [7, 2, 0],
                        "V_NO_HIT": 9, "L_NO_HIT": 11, "R_NO_HIT": 11}


@pytest.mark.parametrize("config", [
    {"rows": 0}, {"cols": 640}, {"rows": 100}, {"roi_b": -1},
    {"roi_t": 481}, {"roi_b": 150}, {"ker_size": 4}, {"ker_size": 999},
    {"ths1": 300}, {"processing_width": True}, {"rows": 3.2}, {"unknown": 1},
])
def test_grid_rejects_invalid_or_out_of_bounds(config):
    with pytest.raises(ValueError):
        validate_grid(config)


def test_smallest_grid_has_no_out_of_bounds():
    settings = {"processing_width": 2, "processing_height": 2,
                "rows": 1, "cols": 1, "roi_b": 0, "roi_t": 2, "ker_size": 1}
    _, features = process_grid(np.zeros((2, 2, 3), np.uint8), settings)
    assert features["V"] == [3]
    assert features["L"] == [2]
    assert features["R"] == [2]


def test_exact_chapter_one_reference_when_supplied():
    reference = os.environ.get("RULE_GRID_REFERENCE")
    if not reference or not Path(reference).is_file():
        pytest.skip("Set RULE_GRID_REFERENCE to compare the supplied Chapter 1 source.")
    spec = importlib.util.spec_from_file_location("chapter_one_grid", reference)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    random = np.random.default_rng(7)
    for height, width, rows, cols, bottom, top in [
        (480, 640, 3, 7, 50, 150), (240, 320, 7, 13, 0, 240),
        (121, 161, 2, 3, 10, 111),
    ]:
        image = random.integers(0, 256, (height, width, 3), dtype=np.uint8)
        config = validate_grid({"processing_width": width, "processing_height": height,
                                "rows": rows, "cols": cols, "roi_b": bottom, "roi_t": top})
        actual, features = process_grid(image, config)
        expected, legacy_features = module.compute_grid_features(
            image, rows, cols, bottom, top, config["ths1"], config["ths2"], config["ker_size"])
        # The new release changes only no-hit codes from the chapter-one reference.
        for group in ("V", "L", "R"):
            expected_values = [features[group + "_NO_HIT"]
                               if value == legacy_features[group + "_NO_HIT"] else value
                               for value in legacy_features[group]]
            assert features[group] == expected_values
        assert np.array_equal(actual, expected)


def feature_result(sequence, received_ns, grid=None):
    settings = DEFAULT_GRID if grid is None else validate_grid(grid)
    width = settings["processing_width"]
    return {"sequence": sequence, "received_ns": received_ns, "grid": settings,
            "error": "", "features": {
                "V": [settings["roi_t"] - settings["roi_b"] + 1] * settings["cols"],
                "L": [width // 2 + 1] * settings["rows"],
                "R": [width // 2 + 1] * settings["rows"],
            }}


def read_rows(path):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def test_recorder_causal_match_stale_reject_dedupe_and_zero_preservation(tmp_path):
    recorder = CsvRecorder(max_delta_ms=200)
    started = recorder.start(tmp_path, DEFAULT_GRID)
    origin = time.time_ns() + 1_000_000
    recorder.on_command(0.0, 0.0, origin)
    # A command received after feature capture cannot become that frame's label.
    recorder.on_command(.2, -.1, origin + 100_000_000)
    recorder.on_features(feature_result(1, origin + 50_000_000))
    recorder.on_features(feature_result(1, origin + 50_000_000))
    recorder.on_features(feature_result(2, origin + 150_000_000))
    recorder.on_features(feature_result(3, origin + 400_000_000))
    status = recorder.stop()
    rows = read_rows(started["path"])
    assert len(rows) == 2
    assert float(rows[0]["linear_x"]) == float(rows[0]["angular_z"]) == 0.0
    assert float(rows[1]["linear_x"]) == .2
    assert rows[0]["direction"] == "straight"
    assert rows[1]["direction"] == "right"
    assert float(rows[0]["delta_ms"]) == 50.0
    assert int(rows[0]["v_0"]) == 101
    assert int(rows[0]["l_0"]) == 321
    assert int(rows[0]["r_0"]) == 321
    assert status["skipped_duplicate"] == 1
    assert status["skipped_unmatched"] == 1
    assert not status["recording"]


def test_csv_direction_uses_ros_yaw_sign_without_quantizing_recorded_command(tmp_path):
    recorder = CsvRecorder()
    started = recorder.start(tmp_path, DEFAULT_GRID)
    origin = time.time_ns() + 1_000_000
    for index, angular in enumerate((0.13, -0.27, 0.0)):
        stamp = origin + index * 10_000_000
        recorder.on_command(.2, angular, stamp)
        recorder.on_features(feature_result(index + 1, stamp + 1))
    recorder.stop()
    rows = read_rows(started["path"])
    assert [row["direction"] for row in rows] == ["left", "right", "straight"]
    assert [float(row["angular_z"]) for row in rows] == [0.13, -0.27, 0.0]
    assert list(rows[0])[-3:] == ["linear_x", "angular_z", "direction"]


def test_recorder_no_matching_command_or_prestart_frame(tmp_path):
    recorder = CsvRecorder()
    start = recorder.start(tmp_path, DEFAULT_GRID)
    origin = time.time_ns() + 1_000_000
    recorder.on_features(feature_result(1, origin))
    recorder.on_command(.1, .1, origin + 10)
    recorder.on_features(feature_result(2, origin + 5))
    recorder.on_features(feature_result(3, 1))
    assert recorder.stop()["skipped_unmatched"] == 3
    assert read_rows(start["path"]) == []


def test_grid_change_stops_recording_and_retains_previous_rows(tmp_path):
    recorder = CsvRecorder()
    start = recorder.start(tmp_path, DEFAULT_GRID)
    origin = time.time_ns() + 1_000_000
    recorder.on_command(.1, .0, origin)
    recorder.on_features(feature_result(1, origin + 10))
    recorder.on_features(feature_result(2, origin + 20, {"rows": 4}))
    state = recorder.status()
    assert not state["recording"]
    assert "격자 설정" in state["error"]
    assert len(read_rows(start["path"])) == 1
    second = recorder.start(tmp_path, DEFAULT_GRID)
    recorder.stop()
    assert second["path"] != start["path"]


def test_recorder_requires_explicit_folder_and_finite_commands(tmp_path):
    recorder = CsvRecorder()
    with pytest.raises(ValueError):
        recorder.start("", DEFAULT_GRID)
    with pytest.raises(ValueError):
        recorder.start("relative/path", DEFAULT_GRID)
    with pytest.raises(ValueError):
        recorder.on_command(float("nan"), 0)
    recorder.start(tmp_path, DEFAULT_GRID)
    with pytest.raises(ValueError):
        recorder.start(tmp_path, DEFAULT_GRID)
    recorder.stop()


@pytest.fixture
def lane_runtime(monkeypatch):
    """Exercise the actual ROS adapter with small public-interface stand-ins."""
    class Parameter:
        def __init__(self, name, value):
            self.name, self.value = name, value

    class Publisher:
        def __init__(self, topic, qos):
            self.topic, self.qos = topic, qos
            self.messages = []
            self.subscribers = 0
            self.on_publish = lambda message: None

        def get_subscription_count(self):
            return self.subscribers

        def publish(self, message):
            self.messages.append(message)
            self.on_publish(message)

    class Node:
        def __init__(self, name):
            self.name, self.parameters, self.publishers, self.subscriptions = name, {}, {}, []
            self.log = SimpleNamespace(info=lambda *args, **kwargs: None,
                                       error=lambda *args, **kwargs: None)

        def declare_parameter(self, name, default):
            self.parameters[name] = overrides.get(name, default)

        def get_parameter(self, name):
            return Parameter(name, self.parameters[name])

        def set_parameters(self, parameters):
            for parameter in parameters:
                self.parameters[parameter.name] = parameter.value

        def add_on_set_parameters_callback(self, callback):
            self.parameter_callback = callback

        def create_publisher(self, message_type, topic, qos):
            publisher = Publisher(topic, qos)
            self.publishers[topic] = publisher
            return publisher

        def create_subscription(self, message_type, topic, callback, qos):
            subscription = SimpleNamespace(topic=topic, callback=callback, qos=qos)
            self.subscriptions.append(subscription)
            return subscription

        def get_logger(self):
            return self.log

        def destroy_node(self):
            return True

    class Bridge:
        def __init__(self):
            self.messages = []

        def imgmsg_to_cv2(self, message, desired_encoding):
            self.messages.append(message)
            if getattr(message, "bad", False):
                raise ValueError("bad image")
            return message.pixels

    class NotStartedThread:
        def __init__(self, **kwargs):
            self.target = kwargs["target"]

        def start(self):
            pass

        def join(self, **kwargs):
            pass

    overrides = {"rgb_topic": "/camera/image"}
    modules = {
        "cv_bridge": {"CvBridge": Bridge},
        "rclpy": {"ok": lambda: True, "parameter": SimpleNamespace(Parameter=Parameter)},
        "rclpy.node": {"Node": Node},
        "rclpy.qos": {
            "QoSProfile": lambda **kwargs: SimpleNamespace(**kwargs),
            "HistoryPolicy": SimpleNamespace(KEEP_LAST="keep-last"),
            "ReliabilityPolicy": SimpleNamespace(BEST_EFFORT="best-effort"),
            "DurabilityPolicy": SimpleNamespace(VOLATILE="volatile"),
        },
        "rcl_interfaces": {},
        "rcl_interfaces.msg": {"SetParametersResult": lambda **kw: SimpleNamespace(**kw)},
        "sensor_msgs": {},
        "sensor_msgs.msg": {"CompressedImage": SimpleNamespace, "Image": SimpleNamespace},
        "std_msgs": {},
        "std_msgs.msg": {"String": lambda **kw: SimpleNamespace(**kw)},
    }
    for name, attributes in modules.items():
        module = ModuleType(name)
        module.__dict__.update(attributes)
        monkeypatch.setitem(sys.modules, name, module)
    source = Path(__file__).parents[1] / "my_supervised/_internal/lane_node.py"
    spec = importlib.util.spec_from_file_location("lane_contract_test", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    monkeypatch.setattr(module, "Thread", NotStartedThread)
    module.test_parameter = Parameter
    module.test_overrides = overrides
    return module


def camera_message(stamp=7, bad=False):
    return SimpleNamespace(header=SimpleNamespace(stamp=SimpleNamespace(sec=stamp, nanosec=123),
                                                 frame_id="camera"),
                           pixels=np.zeros((480, 640, 3), dtype=np.uint8), bad=bad)


def test_lane_adapter_atomic_settings_and_image_contract(lane_runtime):
    node = lane_runtime.LaneNode()
    parameter = lane_runtime.test_parameter
    assert node.name == "supervised_lane_processor"
    assert list(node.publishers) == ["/supervised/lane_result", "/supervised/lane_preview"]
    assert node.subscriptions[0].qos.depth == 1
    assert node.subscriptions[0].qos.reliability == "best-effort"
    assert node._preview.qos.depth == 1
    # Intermediate roi_b=160 would be invalid against old roi_t=150, but an
    # atomic request with the new upper bound must be accepted as one change.
    result = node._on_grid_parameters([parameter("roi_b", 160), parameter("roi_t", 260)])
    assert result.successful
    assert node._grid["roi_b"] == 160 and node._grid["roi_t"] == 260
    generation = node._config_generation
    result = node._on_grid_parameters([parameter("rows", 100), parameter("show_grid", False)])
    assert not result.successful
    assert node._grid["rows"] == 3 and node._show_grid
    assert node._config_generation == generation
    assert node._on_grid_parameters([parameter("show_grid", False)]).successful
    assert not node._show_grid
    assert not node._on_grid_parameters([parameter("rgb_topic", "/new")]).successful
    node.destroy_node()


def test_lane_adapter_model_grid_is_locked(lane_runtime, monkeypatch):
    from my_supervised._internal import tree_learning
    artifact = {"grid": validate_grid({"rows": 4, "roi_b": 10, "roi_t": 210})}
    monkeypatch.setattr(tree_learning, "load_model", lambda path: artifact)
    lane_runtime.test_overrides["lane_model"] = "model.json"
    node = lane_runtime.LaneNode()
    assert node._grid == artifact["grid"]
    assert node.parameters["rows"] == 4
    assert not node._on_grid_parameters([lane_runtime.test_parameter("rows", 3)]).successful
    assert node._on_grid_parameters([lane_runtime.test_parameter("show_grid", False)]).successful
    node.destroy_node()


def test_lane_latest_frame_callback_does_no_conversion(lane_runtime, monkeypatch):
    node = lane_runtime.LaneNode()
    messages = [camera_message(i) for i in range(3)]
    for message in messages:
        node._on_rgb(message)
    assert node._bridge.messages == []
    # No subscriber means no drawing/JPEG work, while features still publish.
    monkeypatch.setattr(cv2, "imencode", lambda *args, **kw: pytest.fail("unexpected JPEG"))
    node._results.on_publish = lambda message: node._stopping.set()
    node._run()
    assert node._bridge.messages == [messages[-1]]
    payload = json.loads(node._results.messages[0].data)
    assert payload["sequence"] == 3 and payload["stamp_ns"] == 2_000_000_123
    assert payload["features"]["V"] == [101] * 7
    assert payload["received_ns"] <= payload["processed_ns"]
    assert node._preview.messages == []
    node.destroy_node()


def test_lane_processing_error_is_published(lane_runtime):
    node = lane_runtime.LaneNode()
    node._on_rgb(camera_message(bad=True))
    node._results.on_publish = lambda message: node._stopping.set()
    node._run()
    payload = json.loads(node._results.messages[0].data)
    assert payload["error"] == "bad image"
    assert payload["features"] is None and payload["prediction"] is None
    node.destroy_node()


def test_lane_discards_old_grid_frame_computed_during_parameter_change(lane_runtime, monkeypatch):
    node = lane_runtime.LaneNode()
    node._preview.subscribers = 1
    node._on_rgb(camera_message())
    observed_grids = []
    original = lane_runtime.process_grid

    def change_during_compute(image, config, draw):
        observed_grids.append(dict(config))
        if len(observed_grids) == 1:
            accepted = node._on_grid_parameters([lane_runtime.test_parameter("rows", 4)])
            assert accepted.successful
            # A fresh camera frame gives the worker a new-config frame next.
            node._on_rgb(camera_message(stamp=8))
        return original(image, config, draw)

    monkeypatch.setattr(lane_runtime, "process_grid", change_during_compute)
    node._results.on_publish = lambda message: node._stopping.set()
    node._run()
    assert [config["rows"] for config in observed_grids] == [3, 4]
    assert len(node._results.messages) == len(node._preview.messages) == 1
    payload = json.loads(node._results.messages[0].data)
    assert payload["grid"]["rows"] == 4 and payload["config_generation"] == 1
    assert len(payload["features"]["L"]) == 4
    assert node._preview.messages[0].header.stamp.sec == 8
    node.destroy_node()


def test_lane_result_publishes_before_jpeg_encoding(lane_runtime, monkeypatch):
    node = lane_runtime.LaneNode()
    node._preview.subscribers = 1
    node._on_rgb(camera_message())
    events = []

    def encoded(*args, **kwargs):
        events.append("jpeg")
        return True, np.asarray([1, 2, 3], dtype=np.uint8)

    def preview_published(message):
        events.append("preview")
        node._stopping.set()

    monkeypatch.setattr(cv2, "imencode", encoded)
    node._results.on_publish = lambda message: events.append("result")
    node._preview.on_publish = preview_published
    node._run()
    assert events == ["result", "jpeg", "preview"]
    node.destroy_node()


def test_lane_discards_preview_if_settings_change_during_jpeg(lane_runtime, monkeypatch):
    node = lane_runtime.LaneNode()
    node._preview.subscribers = 1
    node._on_rgb(camera_message())

    def encoded(*args, **kwargs):
        accepted = node._on_grid_parameters([lane_runtime.test_parameter("show_grid", False)])
        assert accepted.successful
        node._stopping.set()
        return True, np.asarray([1, 2, 3], dtype=np.uint8)

    monkeypatch.setattr(cv2, "imencode", encoded)
    node._run()
    assert len(node._results.messages) == 1
    assert node._preview.messages == []
    node.destroy_node()


def test_jpeg_failure_does_not_duplicate_valid_lane_result(lane_runtime, monkeypatch):
    node = lane_runtime.LaneNode()
    node._preview.subscribers = 1
    node._on_rgb(camera_message())
    errors = []

    def log_error(message, **kwargs):
        errors.append(message)
        node._stopping.set()

    monkeypatch.setattr(cv2, "imencode", lambda *args, **kw: (False, None))
    node.log.error = log_error
    node._run()
    assert len(node._results.messages) == 1
    assert not json.loads(node._results.messages[0].data)["error"]
    assert node._preview.messages == []
    assert "Lane preview failed" in errors[0]
    node.destroy_node()
