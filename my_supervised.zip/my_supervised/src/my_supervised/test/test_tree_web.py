"""Exercise CSV/tree HTTP flows with real files, recorder, and training worker."""

from concurrent.futures import ThreadPoolExecutor
import csv
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from my_supervised._internal.grid_features import DEFAULT_GRID
from my_supervised._internal.tree_learning import load_model, predict_model
from my_supervised._internal.tree_web import TREE_PAGE, TreeWebServer, TreeWorkspace


class TreePageScriptTest(unittest.TestCase):
    def test_split_selector_offers_only_session_and_row(self):
        selector = re.search(r'<select id="split_mode">(.*?)</select>', TREE_PAGE).group(1)
        self.assertEqual(re.findall(r'<option value="([^"]+)"', selector), ["session", "row"])
        self.assertIn('<option value="row" selected>', selector)

    def run_script(self, assertion_script):
        node = shutil.which("node")
        if node is None:
            self.skipTest("Node.js is required to exercise browser helper functions")
        metrics_function = TREE_PAGE.split("function metricsText(", 1)[1].split("function confusionMatrices(", 1)[0]
        settings_function = TREE_PAGE.split("function settings(", 1)[1].split("function chart(", 1)[0]
        session_functions = TREE_PAGE.split("function csvSessions(", 1)[1].split("function metricsText(", 1)[0]
        script = (
            "const assert = require('node:assert/strict');\n"
            "new (require('node:vm').Script)("
            + json.dumps(TREE_PAGE.split("<script>", 1)[1].split("</script>", 1)[0]) + ");\n"
            "const modelNames = {};\n"
            "function metricsText(" + metrics_function
            + "function settings(" + settings_function
            + "function csvSessions(" + session_functions
            + assertion_script
        )
        result = subprocess.run([node, "-"], input=script, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_metrics_render_new_and_legacy_classification_reports(self):
        self.run_script(r"""
const current = metricsText({train_row_count: 8, validation_row_count: 8,
  training: {accuracy: 1, macro_precision: 1, macro_recall: 1},
  validation: {accuracy: .5, macro_precision: 13/36, macro_recall: 5/12}
}, 'decision_tree_classification');
assert.ok(current.includes('정확도 50.00% · 정밀도(macro) 36.11% · 재현율(macro) 41.67%'));
assert.ok(current.includes('정확도 100.00% · 정밀도(macro) 100.00% · 재현율(macro) 100.00%'));
assert.ok(!current.includes('F1'));
const old = metricsText({train_row_count: 8, validation_row_count: 2,
  validation: {accuracy: .5, macro_f1: .4}
}, 'decision_tree_classification');
assert.ok(old.includes('정확도 50.00% · 정밀도(macro) 자료 없음 · 재현율(macro) 자료 없음'));
assert.ok(!old.includes('F1'));
assert.ok(!old.includes('NaN'));
const zero = metricsText({training: {accuracy: 0, macro_precision: 0, macro_recall: 0}},
  'decision_tree_classification');
assert.ok(zero.includes('정확도 0.00% · 정밀도(macro) 0.00% · 재현율(macro) 0.00%'));
""")

    def test_manual_session_payload_has_no_percentage_and_requires_both_roles(self):
        self.run_script(r"""
const controls = {max_depth: {value: '6'}, min_samples_leaf: {value: '5'},
  min_samples_split: {value: '10'}, max_leaf_nodes: {value: ''},
  train_percent: {value: 'invalid-hidden-value'}, random_state: {value: '0'},
  criterion: {value: 'gini'}, split_mode: {value: 'session'}, fit_intercept: {checked: true}};
function $(id) { return controls[id]; }
const document = {querySelectorAll: () => [{value: 'V'}]};
let selectedType = 'decision_tree_classification';
function modelType() { return selectedType; }
let selectedCsv = {summary: {sessions: [{session_id: 'earlier', row_count: 9}, {session_id: 'later', row_count: 3}]}};
const sessionAssignments = new Map();
assert.throws(() => settings(), /모든 회차/);
sessionAssignments.set('earlier', 'train');
sessionAssignments.set('later', 'train');
assert.throws(() => settings(), /각각 최소 1회차/);
sessionAssignments.set('earlier', 'validation');
for (const type of ['decision_tree_classification', 'decision_tree_regression', 'linear_regression']) {
  selectedType = type;
  const payload = settings();
  assert.equal(payload.split_mode, 'session');
  assert.ok(!Object.hasOwn(payload, 'train_percent'));
  assert.deepEqual(payload.train_sessions, ['later']);
  assert.deepEqual(payload.validation_sessions, ['earlier']);
}
selectedCsv = {summary: {sessions: [{session_id: 'only', row_count: 10}]}};
assert.throws(() => settings(), /최소 2개/);
selectedCsv = null;
assert.throws(() => settings(), /최소 2개/);
""")

    def test_session_panel_resets_safely_and_percentage_is_row_only(self):
        self.assertIn('id="train-percent-field"', TREE_PAGE)
        self.assertIn('id="session-selection" hidden', TREE_PAGE)
        self.run_script(r"""
class Element {
  constructor(tag) { this.tag=tag; this.children=[]; this.value=''; this.attributes={}; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children=children; }
  setAttribute(name, value) { this.attributes[name]=value; }
  set innerHTML(_) { throw Error('CSV session ID must never be interpreted as HTML'); }
}
const ids = ['session-rows','session-summary','session-selection','split_mode','train-percent-field','train_percent'];
const controls = Object.fromEntries(ids.map(id=>[id,new Element(id)]));
function $(id) { return controls[id]; }
const document = {createElement: tag=>new Element(tag)};
let trainingRequestInFlight=false, csvRequestInFlight=false, lastTrainingState='idle';
const unsafe = '<img src=x onerror=alert(1)>';
let selectedCsv={summary:{sessions:[{session_id:unsafe,row_count:11},{session_id:'__proto__',row_count:4}]}};
const sessionAssignments=new Map([['stale-id','train']]);
$('split_mode').value='row';
resetSessionSelection();
assert.equal(sessionAssignments.size,0);
assert.equal($('train-percent-field').hidden,false);
assert.equal($('session-selection').hidden,true);
const table=$('session-rows').children[0];
assert.equal(table.children[1].children[0].textContent,unsafe);
assert.equal(table.children[2].children[0].textContent,'__proto__');
const first=table.children[1].children[2].children[0], second=table.children[2].children[2].children[0];
assert.equal(first.value,'');
assert.deepEqual(first.children.map(c=>c.textContent),['선택하세요','훈련용','검증용']);
first.value='train';first.onchange();second.value='validation';second.onchange();
assert.equal(sessionAssignments.get(unsafe),'train');
assert.equal(sessionAssignments.get('__proto__'),'validation');
assert.ok($('session-summary').textContent.includes('훈련용 1회차 · 11행 / 검증용 1회차 · 4행 / 미선택 0회차'));
$('split_mode').value='session';splitView();
assert.equal($('train-percent-field').hidden,true);
assert.equal($('session-selection').hidden,false);
lastTrainingState='running';splitView();
assert.equal($('session-selection').disabled,true);
assert.equal($('split_mode').disabled,true);
lastTrainingState='completed';splitView();
assert.equal($('session-selection').disabled,false);
selectedCsv={summary:{sessions:[{session_id:'only',row_count:8}]}};
resetSessionSelection();
assert.equal(sessionAssignments.size,0);
assert.ok($('session-summary').textContent.includes('최소 2개'));
selectedCsv=null;resetSessionSelection();
assert.equal($('session-rows').children.length,0);
assert.equal($('session-summary').textContent,'CSV를 먼저 검사·선택하세요.');
""")

    def test_csv_reinspection_clears_session_choices_before_success_or_failure(self):
        csv_action = "async function csvAction(" + TREE_PAGE.split("async function csvAction(", 1)[1].split("$('select-csv').onclick=", 1)[0]
        self.run_script(csv_action + r"""
let selectedCsv={path:'/old.csv',summary:{sessions:[{session_id:'old',row_count:1}]}}, csvRequestInFlight=false,
    trainingRequestInFlight=false,lastTrainingState='idle';
const sessionAssignments=new Map([['old','train']]);
const controls = new Map();
function $(id) { if(!controls.has(id))controls.set(id,{replaceChildren(){},value:'session'});return controls.get(id); }
function gate() {}
const warnings=[];
function warning(text) { warnings.push(text); }
function showCsv(result) { selectedCsv=result;resetSessionSelection(); }
let requests=0;
async function fetch() {
  requests++;
  assert.equal(selectedCsv,null);
  assert.equal(sessionAssignments.size,0);
  assert.equal($('session-selection').disabled,true);
  return requests===1 ? {ok:true,json:async()=>({ok:true,path:'/new.csv',summary:{sessions:[]}})}
    : {ok:false,json:async()=>({ok:false,error:'잘못된 CSV'})};
}
(async()=>{
  await csvAction('/select',{});
  assert.equal(selectedCsv.path,'/new.csv');
  assert.equal(sessionAssignments.size,0);
  sessionAssignments.set('new','train');
  await csvAction('/select',{});
  assert.equal(selectedCsv,null);
  assert.equal(sessionAssignments.size,0);
  assert.equal($('session-selection').disabled,false);
  assert.ok(warnings[0].includes('잘못된 CSV'));
})().catch(error=>{console.error(error);process.exitCode=1});
""")

    def test_regression_metrics_keep_units_and_missing_r2(self):
        self.run_script(r"""
for (const type of ['decision_tree_regression', 'linear_regression']) {
  const text = metricsText({training: {angular_z: {mae: .1, rmse: .2, r2: .75}},
    validation: {angular_z: {mae: .3, rmse: .4, r2: null}}}, type);
  assert.ok(text.includes('MAE 0.1000 rad/s · RMSE 0.2000 rad/s · R² 0.7500'));
  assert.ok(text.includes('MAE 0.3000 rad/s · RMSE 0.4000 rad/s · R² 계산 대상 아님'));
  assert.ok(!text.includes('정밀도'));
}
""")

    def test_settings_uses_existing_controls_and_omits_pruning(self):
        self.assertNotIn("ccp_alpha", TREE_PAGE)
        ids = re.findall(r'\bid="([^"]+)"', TREE_PAGE)
        self.run_script("const pageIds = new Set(" + json.dumps(ids) + ");\n" + r"""
const controls = {max_depth: {value: '6'}, min_samples_leaf: {value: '5'},
  min_samples_split: {value: '10'}, max_leaf_nodes: {value: ''},
  train_percent: {value: '80'}, random_state: {value: '0'},
  criterion: {value: 'gini'}, split_mode: {value: 'row'}, fit_intercept: {checked: true}};
function $(id) {
  assert.ok(pageIds.has(id), 'settings read a nonexistent control: ' + id);
  assert.ok(Object.hasOwn(controls, id), 'unexpected settings control: ' + id);
  return controls[id];
}
const document = {querySelectorAll: () => [{value: 'V'}, {value: 'L'}, {value: 'R'}]};
let selectedType;
function modelType() { return selectedType; }
for (const type of ['decision_tree_classification', 'decision_tree_regression', 'linear_regression']) {
  selectedType = type;
  const payload = settings();
  assert.equal(payload.model_type, type);
  assert.equal(payload.train_percent, 80);
  assert.equal(payload.split_mode, 'row');
  assert.deepEqual(payload.feature_groups, ['V', 'L', 'R']);
  assert.ok(!Object.hasOwn(payload, 'ccp_alpha'));
  if (type === 'linear_regression') assert.equal(payload.fit_intercept, true);
  else {
    assert.equal(payload.max_depth, 6);
    assert.equal(payload.max_leaf_nodes, null);
  }
}
""")


class TreeWorkspaceGridTest(unittest.TestCase):
    def test_terminal_worker_is_reaped_before_next_training(self):
        class Process:
            def __init__(self, stuck=False):
                self.returncode = None
                self.wait_calls = []
                self.stuck = stuck

            def poll(self):
                return self.returncode

            def wait(self, timeout=None):
                self.wait_calls.append(timeout)
                if self.stuck and self.returncode is None:
                    raise subprocess.TimeoutExpired("worker", timeout)
                if self.returncode is None:
                    self.returncode = 0
                return self.returncode

            def terminate(self):
                self.returncode = -15

        with tempfile.TemporaryDirectory() as directory:
            for state in ("completed", "failed", "cancelled"):
                with self.subTest(state=state):
                    workspace = TreeWorkspace()
                    workspace._selected_csv = str(Path(directory) / "selected.csv")
                    workspace._job_directory = Path(directory)
                    workspace._status_path = Path(directory) / "previous_status.json"
                    workspace._status_path.write_text(json.dumps({"status": state}))
                    previous, following = Process(), Process()
                    workspace._process = previous
                    with patch.object(workspace, "select_csv"), patch(
                            "my_supervised._internal.tree_web.subprocess.Popen",
                            return_value=following) as spawn:
                        result = workspace.start_training({}, directory)
                    self.assertEqual(previous.wait_calls, [1.0])
                    self.assertEqual(previous.returncode, 0)
                    self.assertEqual(spawn.call_count, 1)
                    self.assertEqual(result["training"]["state"], "starting")
                    workspace.close()

            workspace = TreeWorkspace()
            workspace._selected_csv = str(Path(directory) / "selected.csv")
            workspace._job_directory = Path(directory)
            workspace._status_path = Path(directory) / "stuck_status.json"
            workspace._status_path.write_text(json.dumps({"state": "completed"}))
            previous = Process(stuck=True)
            workspace._process = previous
            with patch("my_supervised._internal.tree_web.subprocess.Popen") as spawn:
                with self.assertRaisesRegex(ValueError, "종료 중"):
                    workspace.start_training({}, directory)
            self.assertFalse(spawn.called)
            self.assertEqual(previous.wait_calls, [1.0])
            workspace.close()

    def test_grid_transition_rejects_queued_old_result_and_retains_new_frame(self):
        workspace = TreeWorkspace()
        old = {"sequence": 1, "received_ns": time.time_ns(), "grid": dict(DEFAULT_GRID),
               "features": {"V": [0] * 7, "L": [0] * 3, "R": [0] * 3}, "error": ""}
        workspace.receive_result(old)
        changed = {**DEFAULT_GRID, "cols": 5}

        def apply(config):
            workspace.receive_result({**old, "sequence": 2})
            self.assertIsNone(workspace.status()["lane"])
            with tempfile.TemporaryDirectory() as directory:
                with self.assertRaises(ValueError):
                    workspace.start_recording(directory)
            workspace.receive_result({**old, "sequence": 3, "grid": config,
                                      "features": {"V": [0] * 5, "L": [0] * 3, "R": [0] * 3}})

        workspace.apply_grid = apply
        workspace.set_grid(changed)
        self.assertEqual(workspace.status()["lane"]["grid"], changed)
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(workspace.start_recording(directory)["recording"]["grid"], changed)
            workspace.close()

    def test_grid_failure_restores_previous_expectation_and_frame(self):
        workspace = TreeWorkspace()
        old = {"sequence": 1, "received_ns": time.time_ns(), "grid": dict(DEFAULT_GRID),
               "features": {"V": [0] * 7, "L": [0] * 3, "R": [0] * 3}, "error": ""}
        workspace.receive_result(old)

        def fail(_):
            raise RuntimeError("parameter service unavailable")

        workspace.apply_grid = fail
        with self.assertRaises(RuntimeError):
            workspace.set_grid({**DEFAULT_GRID, "cols": 5})
        self.assertIsNone(workspace._expected_grid)
        self.assertEqual(workspace.status()["lane"], old)
        workspace.close()


class TreeWebTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for name in ("records", "edited", "models", "invalid_upload"):
            (self.root / name).mkdir()
        self.workspace = TreeWorkspace()
        self.server = TreeWebServer(self.workspace, 0)
        self.server.start()
        self.base = f"http://127.0.0.1:{self.server.port}"
        package_root = str(Path(__file__).resolve().parents[1])
        self.environment = patch.dict(os.environ, {"PYTHONPATH": package_root + os.pathsep + os.environ.get("PYTHONPATH", "")})
        self.environment.start()

    def tearDown(self):
        self.workspace.close()
        self.server.stop()
        self.environment.stop()
        self.temporary.cleanup()

    def request(self, endpoint, values=None, raw=None, method=None):
        body = raw if raw is not None else (None if values is None else json.dumps(values).encode())
        request = Request(self.base + endpoint, data=body, method=method,
                          headers={"Content-Type": "application/json"})
        try:
            response = urlopen(request, timeout=10)
        except HTTPError as error:
            response = error
        with response:
            payload = response.read()
            if "application/json" in response.headers.get("Content-Type", ""):
                payload = json.loads(payload)
            return response.status, payload

    def result(self, sequence, stamp, value=1):
        return {"sequence": sequence, "received_ns": stamp,
                "grid": dict(DEFAULT_GRID),
                "features": {"V": [value] * DEFAULT_GRID["cols"],
                             "L": [value + 1] * DEFAULT_GRID["rows"],
                             "R": [value + 2] * DEFAULT_GRID["rows"]},
                "processing_ms": 2.0, "error": ""}

    def record(self, count=12):
        self.workspace.receive_result(self.result(0, time.time_ns()))
        code, started = self.request("/api/record/start", {"directory": str(self.root / "records")})
        self.assertEqual(code, 200, started)
        path = Path(started["recording"]["path"])
        # A result without a preceding command must be counted as unmatched.
        stamp = time.time_ns() + 1000000
        self.workspace.receive_result(self.result(1, stamp))
        for index in range(count):
            stamp += 1000000
            self.workspace.receive_command(0.0 if index == 0 else .06,
                                           0.0 if index == 0 else (.1 if index % 2 else -.1),
                                           stamp - 500000)
            self.workspace.receive_result(self.result(index + 2, stamp, index))
        code, stopped = self.request("/api/record/stop", {})
        self.assertEqual(code, 200, stopped)
        self.assertEqual(stopped["recording"]["rows_written"], count)
        self.assertEqual(stopped["recording"]["skipped_unmatched"], 1)
        return path

    def test_http_record_download_manual_edit_upload_train_and_predict(self):
        try:
            import sklearn  # noqa: F401
        except ImportError:
            self.skipTest("scikit-learn is required for the real worker integration")
        path = self.record()
        original = path.read_bytes()
        code, downloaded = self.request("/api/csv/download?" + urlencode({"path": str(path)}))
        self.assertEqual(code, 200)
        self.assertEqual(downloaded, original)
        rows = list(csv.DictReader(io.StringIO(downloaded.decode())))
        self.assertEqual(len(rows), 12)
        self.assertEqual(float(rows[0]["linear_x"]), 0.0)
        self.assertEqual(float(rows[0]["angular_z"]), 0.0)
        self.assertEqual(rows[0]["direction"], "straight")
        self.assertEqual(rows[1]["direction"], "left")
        self.assertEqual(rows[2]["direction"], "right")
        # The student deletes one unwanted row and uploads a separate file.
        del rows[5]
        edited = io.StringIO(newline="")
        writer = csv.DictWriter(edited, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        upload_url = "/api/csv/upload?" + urlencode({"directory": str(self.root / "edited"), "filename": "manual.csv"})
        code, selected = self.request(upload_url, raw=edited.getvalue().encode())
        self.assertEqual(code, 200, selected)
        self.assertEqual(selected["summary"]["row_count"], 11)
        self.assertEqual(selected["summary"]["stopped_row_count"], 1)
        self.assertNotEqual(selected["path"], str(path))
        self.assertEqual(path.read_bytes(), original)
        code, started = self.request("/api/tree/train", {"output_directory": str(self.root / "models"),
                                                          "settings": {"max_depth": 3, "min_samples_leaf": 1, "min_samples_split": 2}})
        self.assertEqual(code, 200, started)
        seen = []
        for _ in range(150):
            code, status = self.request("/api/status")
            self.assertEqual(code, 200, status)
            state = status["training"]["state"]
            seen.append(state)
            if state in ("completed", "failed"):
                break
            time.sleep(.05)
        self.assertEqual(seen[-1], "completed", status)
        result = status["training"]["result"]
        self.assertTrue(Path(result["model_path"]).is_file())
        self.assertTrue(Path(result["report_path"]).is_file())
        self.assertTrue(result["curve_sample"])
        self.assertNotIn("actual_linear_x", result["curve_sample"][0])
        self.assertIn("actual_direction", result["curve_sample"][0])
        self.assertEqual(result["model_type"], "decision_tree_classification")
        self.assertEqual(result["target_columns"], ["direction"])
        self.assertIn("accuracy", result["metrics"]["validation"])
        self.assertIn("macro_precision", result["metrics"]["validation"])
        self.assertIn("macro_recall", result["metrics"]["validation"])
        self.assertNotIn("macro_f1", result["metrics"]["validation"])
        self.assertEqual(result["settings"]["ccp_alpha"], 0.0)
        self.assertIn("predicted_angular_z", result["curve_sample"][0])
        self.assertEqual(result["csv"]["row_count"], 11)
        self.assertEqual(result["csv"]["stopped_row_count"], 1)
        artifact = load_model(result["model_path"])
        prediction = predict_model(artifact, self.result(1, 1)["features"], DEFAULT_GRID)
        self.assertEqual(set(prediction), {"direction", "angular_z"})
        self.assertIn(prediction["angular_z"], (-0.5, 0.0, 0.5))
        self.assertEqual(path.read_bytes(), original)

    def test_invalid_paths_and_json_give_visible_errors(self):
        cases = [
            ("/api/record/start", {"directory": ""}),
            ("/api/csv/select", {"path": "relative.csv"}),
            ("/api/csv/select", {"path": str(self.root / "missing.csv")}),
            ("/api/tree/train", {"output_directory": str(self.root), "settings": {}}),
        ]
        for endpoint, values in cases:
            code, body = self.request(endpoint, values)
            self.assertEqual(code, 400, (endpoint, body))
            self.assertTrue(body["error"])
        code, body = self.request("/api/csv/select", raw=b"[]")
        self.assertEqual(code, 400, body)
        code, body = self.request("/api/csv/download?" + urlencode({"path": str(self.root / "private.csv")}))
        self.assertEqual(code, 400, body)
        query = urlencode({"directory": str(self.root), "filename": "../invalid.csv"})
        code, body = self.request("/api/csv/upload?" + query, raw=b"invalid")
        self.assertEqual(code, 400, body)

    def test_http_manual_session_training_honors_explicit_assignment(self):
        try:
            import sklearn  # noqa: F401
        except ImportError:
            self.skipTest("scikit-learn is required for real worker integration")
        path = self.record(24)
        with path.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        # Synthetic recording groups: deliberately train on the later group,
        # and make all timestamps equal to rule out automatic time ordering.
        for index, row in enumerate(rows):
            row["session_id"] = "earlier" if index < 16 else "later"
            row["timestamp_ns"] = "1.79009E+18"
        with path.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        code, selected = self.request("/api/csv/select", {"path": str(path)})
        self.assertEqual(code, 200, selected)
        self.assertEqual(selected["summary"]["session_count"], 2)
        code, started = self.request("/api/tree/train", {
            "output_directory": str(self.root / "models"),
            "settings": {"split_mode": "session", "train_sessions": ["later"],
                         "validation_sessions": ["earlier"], "min_samples_leaf": 1,
                         "min_samples_split": 2},
        })
        self.assertEqual(code, 200, started)
        for _ in range(200):
            _, status = self.request("/api/status")
            if status["training"]["state"] in ("completed", "failed"):
                break
            time.sleep(.05)
        self.assertEqual(status["training"]["state"], "completed", status)
        result = status["training"]["result"]
        self.assertEqual(result["metrics"]["train_sessions"], ["later"])
        self.assertEqual(result["metrics"]["validation_sessions"], ["earlier"])
        self.assertEqual(result["metrics"]["train_row_count"], 8)
        self.assertEqual(result["metrics"]["validation_row_count"], 16)
        self.assertIsNone(result["settings"]["train_percent"])
        self.assertEqual(result["settings"]["train_sessions"], ["later"])
        self.assertEqual(result["settings"]["validation_sessions"], ["earlier"])

    def test_invalid_session_assignment_is_rejected_before_worker_start(self):
        path = self.record(24)
        with path.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        for index, row in enumerate(rows):
            row["session_id"] = "run" + str(index // 8)
        with path.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        self.assertEqual(self.request("/api/csv/select", {"path": str(path)})[0], 200)
        assignments = [
            ([], []),
            (["run0"], []),
            (["run0"], ["run0", "run1", "run2"]),
            (["run0"], ["run1"]),
            (["run0"], ["run1", "missing"]),
            (["run0", "run0"], ["run1", "run2"]),
        ]
        with patch("my_supervised._internal.tree_web.subprocess.Popen") as spawn:
            for train, validation in assignments:
                with self.subTest(train=train, validation=validation):
                    code, result = self.request("/api/tree/train", {
                        "output_directory": str(self.root / "models"),
                        "settings": {"split_mode": "session", "train_sessions": train,
                                     "validation_sessions": validation},
                    })
                    self.assertEqual(code, 400, result)
                    self.assertTrue(result["error"])
                    self.assertFalse(spawn.called)
                    self.assertFalse((self.root / "models" / ".tree_jobs").exists())

    def test_invalid_upload_is_preserved_for_student_correction(self):
        folder = self.root / "invalid_upload"
        query = urlencode({"directory": str(folder), "filename": "wrong.csv"})
        data = b"wrong,columns\n1,2\n"
        code, body = self.request("/api/csv/upload?" + query, raw=data)
        self.assertEqual(code, 400, body)
        saved = list(folder.glob("*.csv"))
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0].read_bytes(), data)
        self.assertIn(str(saved[0]), body["error"])

    def test_early_upload_failure_clears_previous_selection(self):
        path = self.record()
        cases = [
            ({"directory": str(self.root / "missing"), "filename": "manual.csv"}, b"data"),
            ({"directory": str(self.root), "filename": "../wrong.csv"}, b"data"),
            ({"directory": str(self.root), "filename": "manual.csv"}, b""),
        ]
        for query, data in cases:
            self.assertEqual(self.request("/api/csv/select", {"path": str(path)})[0], 200)
            code, body = self.request("/api/csv/upload?" + urlencode(query), raw=data)
            self.assertEqual(code, 400, body)
            self.assertIsNone(self.workspace.status()["selected_csv"])
            with patch("my_supervised._internal.tree_web.subprocess.Popen") as spawn:
                code, result = self.request("/api/tree/train", {
                    "output_directory": str(self.root / "models"), "settings": {},
                })
                self.assertEqual(code, 400, result)
                self.assertFalse(spawn.called)

    def test_active_csv_cannot_be_downloaded_or_selected(self):
        self.workspace.receive_result(self.result(0, time.time_ns()))
        code, started = self.request("/api/record/start", {"directory": str(self.root / "records")})
        self.assertEqual(code, 200, started)
        path = started["recording"]["path"]
        code, body = self.request("/api/csv/select", {"path": path})
        self.assertEqual(code, 400, body)
        code, body = self.request("/api/csv/download?" + urlencode({"path": path}))
        self.assertEqual(code, 400, body)
        code, body = self.request("/api/grid", dict(DEFAULT_GRID))
        self.assertEqual(code, 400, body)

    def test_concurrent_train_requests_start_only_one_worker(self):
        class Process:
            returncode = None

            def poll(self):
                return self.returncode

            def terminate(self):
                self.returncode = -15

            def kill(self):
                self.returncode = -9

            def wait(self, timeout=None):
                return self.returncode

        path = self.record()
        self.assertEqual(self.request("/api/csv/select", {"path": str(path)})[0], 200)
        barrier = threading.Barrier(2)

        def launch():
            barrier.wait()
            return self.request("/api/tree/train", {"output_directory": str(self.root / "models"), "settings": {}})

        with patch("my_supervised._internal.tree_web.subprocess.Popen", return_value=Process()) as spawn:
            with ThreadPoolExecutor(max_workers=2) as executor:
                results = list(executor.map(lambda _: launch(), range(2)))
            self.assertEqual(sorted(code for code, _ in results), [200, 400])
            self.assertEqual(spawn.call_count, 1)
            code, cancelled = self.request("/api/tree/cancel", {})
            self.assertEqual(code, 200, cancelled)
            self.assertEqual(cancelled["training"]["state"], "cancelled")

    def test_settings_errors_are_reported_before_worker_start(self):
        path = self.record()
        self.request("/api/csv/select", {"path": str(path)})
        with patch("my_supervised._internal.tree_web.subprocess.Popen") as spawn:
            code, body = self.request("/api/tree/train", {"output_directory": str(self.root / "models"),
                                                         "settings": {"max_depth": 0}})
            self.assertEqual(code, 400, body)
            self.assertFalse(spawn.called)
            self.assertFalse((self.root / "models" / ".tree_jobs").exists())

    def test_csv_model_selection_validates_target_before_start(self):
        path = self.record()
        for model_type, target in (("decision_tree_classification", "direction"),
                                   ("decision_tree_regression", "angular_z"),
                                   ("linear_regression", "angular_z")):
            code, selected = self.request("/api/csv/select", {
                "path": str(path), "model_type": model_type,
            })
            self.assertEqual(code, 200, selected)
            self.assertEqual(selected["summary"]["target_columns"], [target])
        code, result = self.request("/api/csv/select", {
            "path": str(path), "model_type": "invalid_model",
        })
        self.assertEqual(code, 400, result)
        self.assertTrue(result["error"])
        self.assertIsNone(self.workspace.status()["selected_csv"])
        with patch("my_supervised._internal.tree_web.subprocess.Popen") as spawn:
            code, result = self.request("/api/tree/train", {
                "output_directory": str(self.root / "models"), "settings": {},
            })
            self.assertEqual(code, 400, result)
            self.assertFalse(spawn.called)

    def test_regression_workers_train_angular_only(self):
        try:
            import sklearn  # noqa: F401
        except ImportError:
            self.skipTest("scikit-learn is required for real worker integration")
        path = self.record(24)
        for model_type in ("decision_tree_regression", "linear_regression"):
            code, selected = self.request("/api/csv/select", {
                "path": str(path), "model_type": model_type,
            })
            self.assertEqual(code, 200, selected)
            code, result = self.request("/api/tree/train", {
                "output_directory": str(self.root / "models"),
                "settings": {"model_type": model_type, "split_mode": "row"},
            })
            self.assertEqual(code, 200, result)
            for _ in range(200):
                _, status = self.request("/api/status")
                if status["training"]["state"] in ("completed", "failed"):
                    break
                time.sleep(.05)
            self.assertEqual(status["training"]["state"], "completed", status)
            result = status["training"]["result"]
            self.assertEqual(result["model_type"], model_type)
            self.assertEqual(result["target_columns"], ["angular_z"])
            self.assertIn("angular_z", result["metrics"]["validation"])
            if model_type == "linear_regression":
                self.assertNotIn("tree_depth", result["metrics"])
            artifact = load_model(result["model_path"])
            prediction = predict_model(artifact, self.result(1, 1)["features"], DEFAULT_GRID)
            self.assertEqual(set(prediction), {"angular_z"})

    def test_http_page_exposes_models_legends_row_split_and_popup_only_errors(self):
        code, page = self.request("/")
        self.assertEqual(code, 200)
        page = page.decode()
        self.assertIn('value="decision_tree_classification" checked', page)
        self.assertIn('value="decision_tree_regression"', page)
        self.assertIn('value="linear_regression"', page)
        self.assertIn('value="row"', page)
        self.assertIn('id="fit_intercept"', page)
        self.assertIn('id="confusion-matrices"', page)
        self.assertIn('aria-label="범례"', page)
        self.assertIn('window.alert(message)', page)
        self.assertNotIn('action-warning', page)


if __name__ == "__main__":
    unittest.main()
