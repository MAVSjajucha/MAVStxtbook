"""Run control and latest-frame behavior without ROS hardware or a loaded YOLO model."""

import importlib.util
import math
from pathlib import Path
import sys
import threading
import time
from types import ModuleType, SimpleNamespace

import numpy as np
import pytest


@pytest.fixture
def runtime_module(monkeypatch):
    """Only message transport is stubbed; the runtime implementation is imported unchanged."""
    class Twist:
        def __init__(self):
            self.linear = SimpleNamespace(x=0.0, y=0.0, z=0.0)
            self.angular = SimpleNamespace(x=0.0, y=0.0, z=0.0)

    class Node:
        pass

    modules = {
        'rclpy': {}, 'rclpy.node': {'Node': Node},
        'rclpy.parameter': {'Parameter': object},
        'rclpy.qos': {'QoSProfile': lambda **kwargs: kwargs,
                      'HistoryPolicy': SimpleNamespace(KEEP_LAST=1),
                      'ReliabilityPolicy': SimpleNamespace(BEST_EFFORT=1),
                      'DurabilityPolicy': SimpleNamespace(VOLATILE=1)},
        'rclpy.signals': {'SignalHandlerOptions': SimpleNamespace(NO=0)},
        'rcl_interfaces': {}, 'rcl_interfaces.srv': {'SetParameters': object},
        'geometry_msgs': {}, 'geometry_msgs.msg': {'Twist': Twist},
        'sensor_msgs': {}, 'sensor_msgs.msg': {'Image': object, 'CompressedImage': object},
        'std_msgs': {}, 'std_msgs.msg': {'String': object},
    }
    for name, values in modules.items():
        module = ModuleType(name)
        module.__dict__.update(values)
        monkeypatch.setitem(sys.modules, name, module)
    source = Path(__file__).parents[1] / 'my_supervised' / \
        '_internal' / 'drive_runtime.py'
    spec = importlib.util.spec_from_file_location('_tested_drive_runtime', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_runtime(module):
    """Initialize the state consumed by the real worker, without a ROS executor."""
    runtime = module.DecisionRuntime.__new__(module.DecisionRuntime)
    runtime.mode = 'obstacle'
    runtime.enable_motion = True
    runtime._box_model = object()
    runtime._lock = threading.RLock()
    runtime._stop = threading.Event()
    runtime._generation = 0
    runtime._driving_enabled = False
    runtime._last_error = ''
    runtime._pending = module.LatestInput()
    runtime._input_rate = module.RateMeter()
    runtime._decision_rate = module.RateMeter()
    runtime._preview_rate = module.RateMeter()
    runtime._inference_count = 0
    runtime._viewers = 0
    runtime._frame_requested_at = 0.0
    runtime._show_grid = False
    runtime.inference_hz = 100.0
    runtime.preview_hz = 25.0
    runtime.confidence, runtime.iou, runtime.device = 0.25, 0.45, 'cpu'
    runtime.max_linear = runtime.max_angular = 0.5
    runtime.published = []
    runtime._cmd_pub = SimpleNamespace(publish=runtime.published.append)
    allowed = threading.Event()
    allowed.set()
    runtime._joy = SimpleNamespace(allowed=allowed)
    runtime.errors = []
    runtime.get_logger = lambda: SimpleNamespace(error=runtime.errors.append)
    return runtime


@pytest.mark.parametrize('interrupt_kind', ['keyboard', 'sigterm'])
def test_run_decision_node_bounds_idle_wait_and_cleans_up_before_context_shutdown(
        runtime_module, monkeypatch, interrupt_kind):
    """An idle camera must not prevent Python shutdown handlers from running."""
    module = runtime_module
    events = []
    context = {'ok': False}
    previous_handlers = {
        module.signal.SIGINT: object(), module.signal.SIGTERM: object(),
    }
    handlers = dict(previous_handlers)
    functions = {'obstacle': lambda *_: module.Twist()}

    def init(*, signal_handler_options):
        assert signal_handler_options == module.SignalHandlerOptions.NO
        context['ok'] = True
        events.append('init')

    def install_handler(signum, handler):
        previous = handlers[signum]
        handlers[signum] = handler
        return previous

    class Runtime:
        def __init__(self, supplied_functions):
            assert supplied_functions is functions
            assert context['ok']
            events.append('construct')

        def destroy_node(self):
            # Runtime destruction publishes the zero command. Its ROS context
            # must still be usable here, not shut down by a ROS signal handler.
            assert context['ok']
            events.append('destroy')

    def spin_once(node, *, timeout_sec):
        assert isinstance(node, Runtime)
        assert timeout_sec == pytest.approx(0.1)
        assert context['ok']
        events.append('spin_once')
        if events.count('spin_once') == 3:
            if interrupt_kind == 'sigterm':
                handlers[module.signal.SIGTERM](module.signal.SIGTERM, None)
                pytest.fail('SIGTERM handler did not interrupt the idle loop')
            raise KeyboardInterrupt
        # Simulate a timeout without a callback: no camera, timer or guard wakeup.

    def forbidden_spin(*args, **kwargs):
        pytest.fail('Unbounded rclpy.spin reintroduces idle-input shutdown hangs')

    def shutdown():
        assert context['ok']
        assert events[-1] == 'destroy'
        context['ok'] = False
        events.append('shutdown')

    monkeypatch.setattr(module.rclpy, 'init', init, raising=False)
    monkeypatch.setattr(module.rclpy, 'ok', lambda: context['ok'], raising=False)
    monkeypatch.setattr(module.rclpy, 'spin_once', spin_once, raising=False)
    monkeypatch.setattr(module.rclpy, 'spin', forbidden_spin, raising=False)
    monkeypatch.setattr(module.rclpy, 'shutdown', shutdown, raising=False)
    monkeypatch.setattr(module.signal, 'signal', install_handler)
    monkeypatch.setattr(module, 'DecisionRuntime', Runtime)

    module.run_decision_node(functions)

    assert events == ['init', 'construct', 'spin_once', 'spin_once', 'spin_once',
                      'destroy', 'shutdown']
    assert context['ok'] is False
    assert handlers == previous_handlers


@pytest.fixture
def student_functions(runtime_module):
    """Exercise the supplied manual examples with ROS message transport replaced."""
    import ast
    source = Path(__file__).resolve().parents[3] / 'docs' / 'examples' / 'decision_node_example.py'
    tree = ast.parse(source.read_text())
    functions = [item for item in tree.body if isinstance(
        item, ast.FunctionDef) and item.name.endswith('_decision')]
    namespace = {'Twist': runtime_module.Twist}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), namespace)
    return {item.name.removesuffix('_decision'): namespace[item.name] for item in functions}


def test_unedited_student_template_returns_zero_commands(runtime_module):
    import ast
    source = Path(__file__).parents[1] / 'my_supervised' / 'decision_node.py'
    functions = [item for item in ast.parse(source.read_text()).body
                 if isinstance(item, ast.FunctionDef) and item.name.endswith('_decision')]
    namespace = {'Twist': runtime_module.Twist}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), namespace)
    lane = namespace['lane_decision']([], [], [], {'direction': 'left'})
    obstacle = namespace['obstacle_decision'](np.zeros((100, 100, 3)), [])
    for command in (lane, obstacle):
        assert (command.linear.x, command.angular.z) == (0.0, 0.0)


def test_latest_input_discards_backlog_and_never_repeats(runtime_module):
    queue = runtime_module.LatestInput()
    for value in range(100):
        queue.put(value, generation=7)
    assert queue.take_after(0, timeout=0) == (100, 99, 7)
    assert queue.take_after(100, timeout=0) is None
    queue.close()
    assert queue.take_after(0, timeout=0) is None


def test_start_pause_start_rejects_inflight_old_command(runtime_module):
    runtime = make_runtime(runtime_module)
    command = runtime_module.Twist()
    command.linear.x = 0.12
    assert runtime.start()[0]
    old_generation = runtime._generation
    runtime.pause()
    assert runtime.published[-1].linear.x == 0.0
    assert runtime.start()[0]
    runtime._publish_if_allowed(command, old_generation)
    assert len(runtime.published) == 1
    runtime._publish_if_allowed(command, runtime._generation)
    assert runtime.published[-1].linear.x == 0.12


@pytest.mark.parametrize('mode', ['obstacle', 'lane'])
def test_enabled_motion_still_requires_explicit_start(runtime_module, mode):
    runtime = make_runtime(runtime_module)
    runtime.mode = mode
    runtime._lane_ready = True
    command = runtime_module.Twist()
    command.linear.x = 0.2
    runtime._publish_if_allowed(command, runtime._generation)
    assert runtime.enable_motion is True
    assert runtime._driving_enabled is False
    assert runtime.published == []
    assert runtime.start()[0] is True
    runtime._publish_if_allowed(command, runtime._generation)
    assert runtime.published[-1].linear.x == 0.2


def test_start_requires_auto_handover_even_when_motion_enabled(runtime_module):
    runtime = make_runtime(runtime_module)
    runtime._joy.allowed.clear()
    assert runtime.start()[0] is False
    assert runtime._driving_enabled is False
    assert runtime.published == []


def test_revoked_remote_handover_blocks_commands_after_start(runtime_module):
    runtime = make_runtime(runtime_module)
    assert runtime.start()[0] is True
    command = runtime_module.Twist()
    command.linear.x = 0.2
    runtime._joy.allowed.clear()
    runtime._publish_if_allowed(command, runtime._generation)
    assert runtime.published == []


def test_pause_serializes_zero_after_already_started_publish(runtime_module):
    runtime = make_runtime(runtime_module)
    runtime.start()
    entered, release, paused = threading.Event(), threading.Event(), threading.Event()

    def publish(command):
        if command.linear.x != 0:
            entered.set()
            assert release.wait(1)
        runtime.published.append(command)

    runtime._cmd_pub.publish = publish
    command = runtime_module.Twist()
    command.linear.x = 0.1
    sending = threading.Thread(target=runtime._publish_if_allowed,
                               args=(command, runtime._generation))
    sending.start()
    assert entered.wait(1)
    stopping = threading.Thread(target=lambda: (runtime.pause(), paused.set()))
    stopping.start()
    assert not paused.wait(0.02)
    release.set()
    sending.join(1)
    stopping.join(1)
    assert paused.is_set()
    assert [item.linear.x for item in runtime.published] == [0.1, 0.0]


def test_motor_disabled_cannot_start_or_publish(runtime_module):
    runtime = make_runtime(runtime_module)
    runtime.enable_motion = False
    runtime._cmd_pub = None
    assert runtime.start()[0] is False
    runtime.pause()
    runtime._publish_if_allowed(runtime_module.Twist(), runtime._generation)
    assert runtime.published == []


def test_command_clamps_and_rejects_nan_and_wrong_type(runtime_module):
    runtime = make_runtime(runtime_module)
    command = runtime_module.Twist()
    command.linear.x, command.angular.z = 1.0, -1.0
    limited = runtime._limit_command(command)
    assert (limited.linear.x, limited.angular.z) == (0.5, -0.5)
    command.linear.x = math.nan
    with pytest.raises(ValueError, match='NaN'):
        runtime._limit_command(command)
    with pytest.raises(TypeError, match='Twist'):
        runtime._limit_command(None)


def test_rgb_padding_is_respected(runtime_module):
    message = SimpleNamespace(encoding='rgb8', height=1, width=2, step=8,
                              data=bytes([255, 0, 0, 0, 255, 0, 91, 92]))
    image = runtime_module.DecisionRuntime._image_to_bgr(message)
    assert image.tolist() == [[[0, 0, 255], [0, 255, 0]]]


def test_worker_processes_each_received_image_at_most_once(runtime_module):
    runtime = make_runtime(runtime_module)
    calls, done = [], threading.Event()
    runtime._box_model = SimpleNamespace(predict=lambda **kwargs: [SimpleNamespace(boxes=None)])

    def student(image, boxes):
        calls.append((image.copy(), boxes))
        done.set()
        return runtime_module.Twist()

    runtime._student_functions = {'obstacle': student}
    message = SimpleNamespace(encoding='bgr8', height=2, width=2, step=6,
                              data=bytes(range(12)))
    runtime._on_image(message)
    worker = threading.Thread(target=runtime._work)
    worker.start()
    try:
        assert done.wait(1)
        time.sleep(0.06)  # Six processing periods without any new camera frame.
        assert len(calls) == 1
        assert calls[0][0].shape == (2, 2, 3)
    finally:
        runtime._stop.set()
        runtime._pending.close()
        worker.join(1)


@pytest.mark.parametrize('prediction', [
    {'angular_z': -0.13}, {'angular_z': 0.5, 'direction': 'left'},
])
def test_lane_worker_passes_features_and_predictions_without_reinterpreting(runtime_module, prediction):
    runtime = make_runtime(runtime_module)
    runtime.mode = 'lane'
    runtime._lane_ready = False
    received, done = [], threading.Event()

    def student(V, L, R, prediction):
        received.append((V, L, R, prediction))
        done.set()
        command = runtime_module.Twist()
        command.linear.x = 0.2
        command.angular.z = prediction['angular_z']
        return command

    runtime._student_functions = {'lane': student}
    runtime._pending.put({'features': {'V': [2, 5], 'L': [20], 'R': [30]},
                          'prediction': prediction, 'error': ''}, 0)
    worker = threading.Thread(target=runtime._work)
    worker.start()
    try:
        assert done.wait(1)
        assert received == [([2, 5], [20], [30], prediction)]
        assert runtime.published == []  # Prediction never overrides the initial paused state.
    finally:
        runtime._stop.set()
        runtime._pending.close()
        worker.join(1)


def test_student_lane_function_is_direct_prediction_to_twist(student_functions):
    command = student_functions['lane']([], [], [], {'angular_z': -0.2})
    assert (command.linear.x, command.angular.z) == (0.1, -0.2)
    for direction, expected in [('left', 0.5), ('right', -0.5), ('straight', 0.0)]:
        command = student_functions['lane']([], [], [], {'direction': direction})
        assert (command.linear.x, command.angular.z) == (0.1, expected)
    assert set(student_functions) == {'lane', 'obstacle'}


@pytest.mark.parametrize('boxes,expected_angular', [
    ([], 0.0),
    ([{'y2': 60, 'center_x': 25}], 0.0),
    ([{'y2': 70, 'center_x': 25}], -0.5),
    ([{'y2': 70, 'center_x': 75}], 0.5),
    ([{'y2': 70, 'center_x': 50}], 0.5),
    ([{'y2': 70, 'center_x': 25}, {'y2': 80, 'center_x': 75}], 0.5),
])
def test_obstacle_rule_preserves_three_actions(student_functions, boxes, expected_angular):
    command = student_functions['obstacle'](np.zeros((100, 100, 3)), boxes)
    assert (command.linear.x, command.angular.z) == (0.2, expected_angular)


@pytest.mark.parametrize('mode,prediction,boxes,limits,expected', [
    ('lane', {'direction': 'left', 'angular_z': 0.5}, [], (0.5, 0.5), (0.1, 0.5)),
    ('lane', {'direction': 'right', 'angular_z': -0.5}, [], (0.05, 0.2), (0.05, -0.2)),
    ('lane', {'direction': 'left', 'angular_z': 0.5}, [], (0.9, 0.9), (0.1, 0.5)),
    ('lane', {'angular_z': -0.37}, [], (0.5, 0.5), (0.1, -0.37)),
    ('lane', {'angular_z': -0.9}, [], (0.5, 0.5), (0.1, -0.5)),
    ('obstacle', None, [{'y2': 80, 'center_x': 25}], (0.5, 0.5), (0.2, -0.5)),
    ('obstacle', None, [{'y2': 80, 'center_x': 75}], (0.05, 0.2), (0.05, 0.2)),
    ('obstacle', None, [], (0.9, 0.9), (0.2, 0.0)),
])
def test_worker_runs_student_functions_with_internal_speeds_and_runtime_caps(
        runtime_module, student_functions, mode, prediction, boxes, limits, expected):
    """Exercise both real decision paths through the real worker and publish gate."""
    runtime = make_runtime(runtime_module)
    runtime.mode = mode
    runtime.max_linear, runtime.max_angular = limits
    runtime._student_functions = student_functions
    runtime._lane_ready = True
    runtime._box_model = SimpleNamespace(predict=lambda **kwargs: [object()])
    runtime._boxes = lambda _: boxes
    done = threading.Event()

    def publish(command):
        runtime.published.append(command)
        done.set()

    runtime._cmd_pub.publish = publish
    assert runtime.start()[0] is True
    if mode == 'lane':
        runtime._pending.put({'features': {'V': [2, 5], 'L': [20], 'R': [30]},
                              'prediction': prediction, 'error': ''}, runtime._generation)
    else:
        runtime._on_image(SimpleNamespace(encoding='bgr8', height=100, width=100, step=300,
                                         data=bytes(100 * 100 * 3)))
    worker = threading.Thread(target=runtime._work)
    worker.start()
    try:
        assert done.wait(1), runtime.errors
    finally:
        runtime._stop.set()
        runtime._pending.close()
        worker.join(1)
    assert not worker.is_alive()
    assert runtime.errors == []
    assert len(runtime.published) == 1
    command = runtime.published[0]
    assert (command.linear.x, command.angular.z) == expected


@pytest.mark.parametrize('direction,angular', [('left', 0.5), ('right', -0.5), ('straight', 0.0)])
def test_classifier_prediction_contract(runtime_module, direction, angular):
    prediction = {'direction': direction, 'angular_z': angular}
    assert runtime_module.DecisionRuntime._lane_prediction(prediction) == prediction


@pytest.mark.parametrize('prediction', [
    {'linear_x': 0.2, 'angular_z': 0.1}, {'angular_z': True},
    {'angular_z': float('nan')}, {'angular_z': float('inf')},
    {'angular_z': -0.5, 'direction': 'left'},
    {'angular_z': 0.5, 'direction': 'right'},
    {'angular_z': 0.1, 'direction': 'straight'},
    {'angular_z': 0, 'direction': 'unknown'},
])
def test_reject_invalid_or_legacy_lane_prediction(runtime_module, prediction):
    with pytest.raises(ValueError):
        runtime_module.DecisionRuntime._lane_prediction(prediction)


@pytest.mark.parametrize('mode', ['obstacle', 'lane'])
def test_runtime_constructor_defaults_motion_on_but_remains_paused(runtime_module, monkeypatch, mode):
    """Construct the actual runtime while replacing only external transport and workers."""
    runtime_class = runtime_module.DecisionRuntime
    parameters, published = {}, []
    overrides = {'mission_mode': mode, 'lane_model': '/fixture/model.json'}
    monkeypatch.setattr(runtime_class.__bases__[0], '__init__', lambda self, name: None)
    monkeypatch.setattr(runtime_class, 'declare_parameter',
                        lambda self, name, value: parameters.setdefault(name, overrides.get(name, value)),
                        raising=False)
    monkeypatch.setattr(runtime_class, 'get_parameter',
                        lambda self, name: SimpleNamespace(value=parameters[name]), raising=False)
    monkeypatch.setattr(runtime_class, 'create_publisher',
                        lambda *args: SimpleNamespace(publish=published.append), raising=False)
    monkeypatch.setattr(runtime_class, 'create_subscription', lambda *args: None, raising=False)
    monkeypatch.setattr(runtime_class, 'create_client', lambda *args: None, raising=False)
    monkeypatch.setattr(runtime_class, 'create_timer', lambda *args: None, raising=False)
    monkeypatch.setattr(runtime_class, 'get_logger',
                        lambda self: SimpleNamespace(info=lambda message: None), raising=False)
    monkeypatch.setattr(runtime_class, '_start_web', lambda *args: None)
    monkeypatch.setattr(runtime_module, '_vehicle_identity', lambda: {'name': 'test', 'ip': '127.0.0.1'})
    monkeypatch.setattr(runtime_module, 'resolve_yolo_model', lambda *args, **kwargs: '/fixture/best.pt')
    dummy_yolo = ModuleType('ultralytics')
    dummy_yolo.YOLO = lambda path: SimpleNamespace(task='detect')
    monkeypatch.setitem(sys.modules, 'ultralytics', dummy_yolo)
    monkeypatch.setattr(runtime_module, 'JoyControl',
                        lambda *args: SimpleNamespace(allowed=threading.Event()))
    monkeypatch.setattr(runtime_module.threading, 'Thread',
                        lambda **kwargs: SimpleNamespace(start=lambda: None))
    runtime = runtime_class({mode: lambda *args: runtime_module.Twist()})
    assert parameters['enable_motion'] is True
    assert runtime.enable_motion is True
    assert runtime._driving_enabled is False
    assert runtime.start()[0] is False  # Auto handover not yet requested.
    command = runtime_module.Twist()
    command.linear.x = 0.2
    runtime._publish_if_allowed(command, runtime._generation)
    assert all(item.linear.x == 0 and item.angular.z == 0 for item in published)


@pytest.fixture
def launch_module(monkeypatch):
    """Evaluate launch configuration with real file paths and transport-free actions."""
    class Action:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.__dict__.update(kwargs)

    class Configuration:
        def __init__(self, name):
            self.name = name

        def perform(self, context):
            return context[self.name]

    package = Path(__file__).parents[1]
    modules = {
        'ament_index_python': {},
        'ament_index_python.packages': {'get_package_share_directory': lambda _: str(package)},
        'launch': {'LaunchDescription': list},
        'launch.actions': {name: Action for name in ('DeclareLaunchArgument',
                           'IncludeLaunchDescription', 'LogInfo', 'OpaqueFunction',
                           'SetEnvironmentVariable')},
        'launch.launch_description_sources': {'PythonLaunchDescriptionSource': Action},
        'launch.substitutions': {'LaunchConfiguration': Configuration},
        'launch_ros': {}, 'launch_ros.actions': {'Node': Action},
        'launch_ros.parameter_descriptions': {'ParameterValue': Action},
    }
    for name, values in modules.items():
        module = ModuleType(name)
        module.__dict__.update(values)
        monkeypatch.setitem(sys.modules, name, module)
    spec = importlib.util.spec_from_file_location('_tested_drive_launch', package / 'launch/drive.launch.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    calls = []

    def environment(require_driver):
        calls.append(require_driver)
        return SimpleNamespace(domain_id='62', rmw_implementation='rmw_fastrtps_cpp')

    monkeypatch.setattr(module, 'detect_vehicle_ros_environment', environment)
    monkeypatch.setattr(module, 'resolve_camera_selection', lambda *_: SimpleNamespace(
        mode='nuwa', topic='/rgb', should_start=False))
    description = module.generate_launch_description()
    defaults = {action.args[0]: action.default_value for action in description
                if hasattr(action, 'default_value')}
    configure = next(action.function for action in description if hasattr(action, 'function'))
    return configure, defaults, calls


def test_launch_obstacle_defaults_to_motion_enabled_and_can_select_preview(launch_module):
    configure, values, requirements = launch_module
    assert values['mission_mode'] == 'obstacle'
    assert values['enable_motion'] == 'true'
    actions = configure(values)
    executables = [item.executable for item in actions if hasattr(item, 'executable')]
    assert executables == ['decision_node']
    assert requirements == [True]
    values['enable_motion'] = 'false'
    configure(values)
    assert requirements == [True, False]


def test_launch_rejects_removed_box_mission(launch_module):
    configure, values, _ = launch_module
    values['mission_mode'] = 'box'
    with pytest.raises(ValueError, match='obstacle'):
        configure(values)


def test_launch_lane_requires_explicit_model_and_starts_lane_processor(launch_module, tmp_path):
    configure, values, requirements = launch_module
    values['mission_mode'] = 'lane'
    with pytest.raises(ValueError, match='lane_model'):
        configure(values)
    values['lane_model'] = str(tmp_path / 'missing.json')
    with pytest.raises(FileNotFoundError, match='모델'):
        configure(values)
    model = tmp_path / 'model.json'
    model.write_text('{}')  # Model content validation belongs to the lane/model loader.
    values['lane_model'] = str(model)
    actions = configure(values)
    nodes = [item for item in actions if hasattr(item, 'executable')]
    assert [node.executable for node in nodes] == ['lane_processor', 'decision_node']
    assert nodes[0].name == 'supervised_lane_processor'
    assert requirements == [True]
