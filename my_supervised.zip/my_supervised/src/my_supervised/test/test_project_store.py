"""Tests for exact-pair project persistence."""

import json
from pathlib import Path

import pytest

from my_supervised._internal.project_store import (
    ProjectStatus,
    ProjectStore,
    ProjectStoreError,
)


@pytest.fixture
def directories(tmp_path):
    """Create independent photo and result folders."""
    photos = tmp_path / "photos"
    results = tmp_path / "results"
    other_photos = tmp_path / "other_photos"
    other_results = tmp_path / "other_results"
    for path in (photos, results, other_photos, other_results):
        path.mkdir()
    return photos, results, other_photos, other_results


def test_inspection_has_no_default_and_does_not_write(directories):
    """Inspection should report new without creating hidden state."""
    photos, results, _, _ = directories
    inspection = ProjectStore().inspect(str(photos), str(results))

    assert inspection.status is ProjectStatus.NEW
    assert not inspection.resume_available
    assert not (results / ".my_supervised").exists()


def test_exact_pair_can_resume(directories):
    """Only the exact initialized pair should be resumable."""
    photos, results, _, _ = directories
    store = ProjectStore()
    created = store.create_new(str(photos), str(results))
    resumed = store.resume(str(photos), str(results))

    assert created.paths.project_key == resumed.paths.project_key
    assert resumed.resume_available
    assert resumed.paths.annotations_directory.is_dir()
    assert resumed.paths.dataset_directory.is_dir()
    assert resumed.paths.checkpoints_directory.is_dir()


def test_other_pair_is_new_and_does_not_overwrite(directories):
    """Changing either selected path must produce a new project identity."""
    photos, results, other_photos, other_results = directories
    store = ProjectStore()
    original = store.create_new(str(photos), str(results))

    changed_photo = store.inspect(str(other_photos), str(results))
    changed_result = store.inspect(str(photos), str(other_results))

    assert changed_photo.status is ProjectStatus.NEW
    assert changed_result.status is ProjectStatus.NEW
    assert changed_photo.paths.project_key != original.paths.project_key
    assert changed_result.paths.project_key != original.paths.project_key
    assert original.paths.manifest_path.is_file()


def test_manifest_records_canonical_pair(directories):
    """The persisted identity should contain both canonical paths."""
    photos, results, _, _ = directories
    created = ProjectStore().create_new(str(photos), str(results))
    manifest = json.loads(created.paths.manifest_path.read_text())

    assert manifest["photo_directory"] == str(photos.resolve())
    assert manifest["result_directory"] == str(results.resolve())
    assert manifest["workflow_step"] == "class_setup"


def test_empty_relative_and_missing_paths_are_rejected(directories):
    """Unselected, relative, and missing directories must be rejected."""
    photos, results, _, _ = directories
    store = ProjectStore()

    with pytest.raises(ProjectStoreError, match="not selected"):
        store.inspect("", str(results))
    with pytest.raises(ProjectStoreError, match="absolute path"):
        store.inspect("photos", str(results))
    with pytest.raises(ProjectStoreError, match="does not exist"):
        store.inspect(str(Path(photos) / "missing"), str(results))


def test_identity_fields_cannot_be_updated(directories):
    """Progress updates must not alter the path-pair identity."""
    photos, results, _, _ = directories
    store = ProjectStore()
    created = store.create_new(str(photos), str(results))

    updated = store.update(created.paths, {"workflow_step": "labeling"})
    assert updated.manifest["workflow_step"] == "labeling"

    with pytest.raises(ProjectStoreError, match="identity"):
        store.update(created.paths, {"photo_directory": "/tmp/other"})
