"""File and inference contracts for student CSV regression learning."""

import copy
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from my_supervised._internal import tree_learning as tree


GRID = {
    "processing_width": 640, "processing_height": 480,
    "rows": 2, "cols": 3, "roi_b": 50, "roi_t": 150,
    "ths1": 100, "ths2": 300, "ker_size": 5,
}


def write_csv(path, count=20, update=None):
    columns = tree._columns(GRID)
    rows = []
    for index in range(count):
        row = {
            "session_id": f"run{index // 5}", "timestamp_ns": 1700000000000000000 + index * 100000000,
            "feature_received_ns": 1700000000000000000 + index * 100000000,
            "cmd_received_ns": 1700000000000000000 + index * 100000000 - 1000000,
            "delta_ms": 1,
            **GRID,
            **{key: (index * (offset + 1)) % 100 for offset, key in enumerate(columns)},
            "linear_x": 0.0 if index % 4 == 0 else 0.08,
            "angular_z": (index % 3 - 1) * 0.2,
        }
        if index == 0:
            row["angular_z"] = 0.0
        rows.append(row)
    if update:
        update(rows)
    with path.open("w", newline="", encoding="utf-8") as stream:
        extra_columns = [key for key in ("linear_x", "direction") if any(key in row for row in rows)]
        writer = csv.DictWriter(stream, fieldnames=[*tree.RECORD_FIELDS, *tree.GRID_FIELDS, *columns, *tree.TARGET_COLUMNS, *extra_columns])
        writer.writeheader()
        writer.writerows(rows)
    return rows


class TreeLearningTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.csv = self.root / "drive.csv"
        self.rows = write_csv(self.csv)
        (self.root / "results").mkdir()

    def tearDown(self):
        self.temporary.cleanup()

    def test_inspection_retains_stopped_rows_and_source(self):
        original = self.csv.read_bytes()
        info = tree.inspect_csv(self.csv)
        self.assertEqual(info["row_count"], 20)
        self.assertGreater(info["stopped_row_count"], 0)
        self.assertEqual(info["session_count"], 4)
        self.assertEqual(self.csv.read_bytes(), original)
        self.assertEqual(info["first_timestamp_ns"], self.rows[0]["timestamp_ns"])

    def test_invalid_data_rejected_instead_of_filtered(self):
        for key, value in (("v_0", "NaN"), ("linear_x", "inf"), ("rows", 3), ("session_id", "")):
            write_csv(self.csv, update=lambda rows: rows[3].update({key: value}))
            with self.assertRaisesRegex(tree.TreeLearningError, "CSV 5행"):
                tree.inspect_csv(self.csv)

    def test_spreadsheet_scientific_timestamps_are_exact_integers(self):
        self.assertEqual(tree._integer("1.700000000123456789E+18", "timestamp_ns"), 1700000000123456789)
        write_csv(self.csv, update=lambda rows: rows[0].update({"timestamp_ns": "1.700000000000000000E+18"}))
        self.assertEqual(tree.inspect_csv(self.csv)["first_timestamp_ns"], 1700000000000000000)
        with self.assertRaises(tree.TreeLearningError):
            tree._integer("1.7E-1", "timestamp_ns")

    def test_time_and_session_splits_have_no_overlap(self):
        records = tree._read_csv(self.csv)[3]
        for mode in ("time", "session"):
            settings = tree.normalize_settings({
                "split_mode": mode, "train_percent": 70,
                "train_sessions": ["run0", "run2"],
                "validation_sessions": ["run1", "run3"],
            })
            training, validation = tree._split(records, settings)
            self.assertFalse(set(training) & set(validation))
            self.assertEqual(len(training) + len(validation), len(records))
            if mode == "time":
                self.assertLess(max(records[i]["timestamp_ns"] for i in training), min(records[i]["timestamp_ns"] for i in validation))
            else:
                self.assertFalse({records[i]["session_id"] for i in training} & {records[i]["session_id"] for i in validation})
        for row in records:
            row["session_id"] = "single"
        with self.assertRaises(tree.TreeLearningError):
            tree._split(records, tree.normalize_settings({"split_mode": "session"}))

    def test_two_sessions_are_explicit_even_with_unequal_row_counts(self):
        records = [
            {"session_id": session, "timestamp_ns": stamp}
            for session, stamp, count in (("first", 1, 8), ("second", 2, 2))
            for _ in range(count)
        ]
        for percent in (None, 0, 50, 80, 95, 100, "unused"):
            settings = tree.normalize_settings({
                "split_mode": "session", "train_percent": percent,
                "train_sessions": ["second"], "validation_sessions": ["first"],
            })
            training, validation = tree._split(
                records, settings)
            self.assertEqual(training, [8, 9])
            self.assertEqual(validation, list(range(8)))
            self.assertIsNone(settings["train_percent"])

    def test_five_sessions_allow_nonchronological_assignment(self):
        records = [
            {"session_id": f"run{session}", "timestamp_ns": session * 10 + offset}
            for session in range(5) for offset in range(session + 1)
        ]
        records.reverse()  # Both session membership and internal ordering are checked.
        settings = tree.normalize_settings({
            "split_mode": "session", "train_sessions": ["run4", "run1"],
            "validation_sessions": ["run0", "run2", "run3"],
        })
        training, validation = tree._split(
            records, settings)
        self.assertEqual(len(training), 7)
        self.assertEqual(len(validation), 8)
        self.assertEqual({records[index]["session_id"] for index in training}, {"run1", "run4"})
        self.assertEqual({records[index]["session_id"] for index in validation}, {"run0", "run2", "run3"})
        for indices in (training, validation):
            stamps = [records[index]["timestamp_ns"] for index in indices]
            self.assertEqual(stamps, sorted(stamps))

    def test_session_split_accepts_identical_rounded_timestamps(self):
        write_csv(self.csv, update=lambda rows: [row.update(timestamp_ns="1.79009E+18") for row in rows])
        records = tree._read_csv(self.csv)[3]
        training, validation = tree._split(records, tree.normalize_settings({
            "split_mode": "session", "train_sessions": ["run3", "run1"],
            "validation_sessions": ["run0", "run2"],
        }))
        self.assertEqual(training, list(range(5, 10)) + list(range(15, 20)))
        self.assertEqual(validation, list(range(5)) + list(range(10, 15)))

    def test_invalid_session_assignments_are_actionable(self):
        records = [{"session_id": f"run{i}", "timestamp_ns": i} for i in range(3)]
        cases = (
            ({"train_sessions": [], "validation_sessions": ["run0", "run1", "run2"]}, "훈련용 회차를 최소"),
            ({"train_sessions": ["run0", "run1", "run2"], "validation_sessions": []}, "검증용 회차를 최소"),
            ({"train_sessions": ["run0", "run1"], "validation_sessions": ["run1", "run2"]}, "동시에"),
            ({"train_sessions": ["run0", "run1"], "validation_sessions": ["run2", "missing"]}, "CSV에 없는"),
            ({"train_sessions": ["run0"], "validation_sessions": ["run1"]}, "미지정 회차: run2"),
            ({}, "훈련용 회차를 최소"),
        )
        for selection, message in cases:
            with self.subTest(selection=selection), self.assertRaisesRegex(tree.TreeLearningError, message):
                tree._split(records, tree.normalize_settings({"split_mode": "session", **selection}))

    def test_session_selection_requires_exact_unique_strings(self):
        invalid = (None, True, False, "run0", 1, {}, [None], [True], [1], [""], [" "], ["run0", "run0"])
        for key in ("train_sessions", "validation_sessions"):
            for value in invalid:
                with self.subTest(key=key, value=value), self.assertRaises(tree.TreeLearningError):
                    tree.normalize_settings({"split_mode": "session", key: value})
        with self.assertRaisesRegex(tree.TreeLearningError, "CSV에 없는"):
            tree.validate_session_selection(["run0", "run1"], {
                "train_sessions": [" run0"], "validation_sessions": ["run1"],
            })
        with self.assertRaisesRegex(tree.TreeLearningError, "중복"):
            tree.validate_session_selection(["run0", "run1"], {
                "train_sessions": ["run0", "run0"], "validation_sessions": ["run1"],
            })

    def test_split_defaults_are_independent_and_row_ratio_still_validated(self):
        first = tree.normalize_settings({})
        first["train_sessions"].append("run0")
        self.assertEqual(tree.normalize_settings({})["train_sessions"], [])
        for mode in ("row", "time"):
            for ratio in (None, 0, 100, "unused"):
                with self.subTest(mode=mode, ratio=ratio), self.assertRaises(tree.TreeLearningError):
                    tree.normalize_settings({"split_mode": mode, "train_percent": ratio})

    def test_equal_timestamps_not_split_between_partitions(self):
        records = tree._read_csv(self.csv)[3]
        for index, row in enumerate(records):
            row["timestamp_ns"] = index // 3
        training, validation = tree._split(records, tree.normalize_settings({"split_mode": "time"}))
        self.assertFalse({records[i]["timestamp_ns"] for i in training} & {records[i]["timestamp_ns"] for i in validation})

    def test_inference_import_needs_only_standard_library(self):
        package_root = str(Path(tree.__file__).resolve().parents[2])
        code = (
            "import sys; sys.path.insert(0, " + repr(package_root) + "); "
            "from my_supervised._internal.tree_learning import predict_model, load_model; "
            "assert not any(name in sys.modules for name in ('sklearn', 'cv2', 'numpy', 'rclpy'))"
        )
        result = subprocess.run([sys.executable, "-S", "-c", code], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def train(self, model_type="decision_tree_regression", **overrides):
        try:
            import sklearn  # noqa: F401
        except ImportError:
            self.skipTest("scikit-learn unavailable; file-contract tests still run")
        return tree.train_csv(self.csv, self.root / "results", {"model_type": model_type, "min_samples_leaf": 1, "min_samples_split": 2, "feature_groups": ["L", "V"], **overrides})

    def test_actual_training_export_and_prediction_match_sklearn(self):
        result = self.train()
        from sklearn.tree import DecisionTreeRegressor
        import numpy as np
        artifact = tree.load_model(result["model_path"])
        records = tree._read_csv(self.csv)[3]
        settings = tree.normalize_settings(result["settings"])
        training, validation = tree._split(records, settings)
        columns = artifact["feature_columns"]
        x = np.asarray([[row[key] for key in columns] for row in records], dtype=np.float32)
        y = np.asarray([[row[key] for key in tree.TARGET_COLUMNS] for row in records])
        reference = DecisionTreeRegressor(**{key: settings[key] for key in ("max_depth", "min_samples_leaf", "min_samples_split", "max_leaf_nodes", "ccp_alpha", "criterion", "random_state")}).fit(x[training], y[training])
        for index, expected in enumerate(reference.predict(x)):
            features = {group: [records[index][key] for key in tree._columns(GRID, [group])] for group in ("V", "L", "R")}
            predicted = tree.predict_model(artifact, features, GRID)
            np.testing.assert_allclose([predicted[key] for key in tree.TARGET_COLUMNS], expected, atol=1e-12)
        self.assertEqual(result["metrics"]["train_row_count"] + result["metrics"]["validation_row_count"], 20)
        second = self.train()
        self.assertNotEqual(result["model_path"], second["model_path"])
        self.assertTrue(Path(result["model_path"]).exists())
        self.assertEqual(json.loads(Path(result["report_path"]).read_text())["model_path"], result["model_path"])

    def test_manual_session_selection_is_exported_for_all_models(self):
        selection = {"split_mode": "session", "train_sessions": ["run3", "run1"],
                     "validation_sessions": ["run0", "run2"]}
        for kind in tree.MODEL_TYPES:
            with self.subTest(model_type=kind):
                result = self.train(kind, **selection)
                artifact = tree.load_model(result["model_path"])
                report = json.loads(Path(result["report_path"]).read_text())
                for settings in (result["settings"], artifact["hyperparameters"], report["settings"]):
                    self.assertEqual(settings["train_sessions"], selection["train_sessions"])
                    self.assertEqual(settings["validation_sessions"], selection["validation_sessions"])
                    self.assertIsNone(settings["train_percent"])
                self.assertEqual(result["metrics"]["train_sessions"], ["run1", "run3"])
                self.assertEqual(result["metrics"]["validation_sessions"], ["run0", "run2"])
                self.assertEqual(result["metrics"]["actual_train_percent"], 50.0)
                self.assertEqual({point["session_id"] for point in result["curve_sample"]}, {"run0", "run2"})

    def test_invalid_session_selection_does_not_publish_results(self):
        with self.assertRaisesRegex(tree.TreeLearningError, "미지정 회차"):
            tree.train_csv(self.csv, self.root / "results", {
                "split_mode": "session", "train_sessions": ["run0"],
                "validation_sessions": ["run1"],
            })
        self.assertEqual(list((self.root / "results").iterdir()), [])

    def test_session_single_class_error_explains_assignment_not_ratio(self):
        def labels(rows):
            for index, row in enumerate(rows):
                row["direction"] = "left" if row["session_id"] == "run3" else tree.CLASS_LABELS[index % 3]
        write_csv(self.csv, update=labels)
        with self.assertRaisesRegex(tree.TreeLearningError, "훈련용 회차 선택"):
            self.train("decision_tree_classification", split_mode="session", train_sessions=["run3"],
                       validation_sessions=["run0", "run1", "run2"])
        self.assertEqual(list((self.root / "results").iterdir()), [])

    def test_grid_mismatch_and_invalid_models_rejected(self):
        result = self.train()
        artifact = tree.load_model(result["model_path"])
        features = {"V": [0] * 3, "L": [0] * 2, "R": [0] * 2}
        with self.assertRaises(tree.TreeLearningError):
            tree.predict_model(artifact, features, {**GRID, "roi_t": 151})
        with self.assertRaises(tree.TreeLearningError):
            tree.predict_model(artifact, {**features, "V": [0]}, GRID)
        mutations = [
            lambda model: model["children_left"].__setitem__(0, 0),
            lambda model: model["value"].__setitem__(0, [float("nan"), 0]),
            lambda model: model["threshold"].append(0),
            lambda model: model["feature"].__setitem__(0, 999),
            lambda model: model["threshold"].__setitem__(0, "1.0"),
        ]
        for mutate in mutations:
            corrupted = copy.deepcopy(artifact)
            mutate(corrupted["model"])
            with self.assertRaises(tree.TreeLearningError):
                tree.validate_model(corrupted)

    def test_job_reports_failure_and_success(self):
        status = self.root / "status.json"
        job = self.root / "job.json"
        job.write_text(json.dumps({"csv_path": str(self.root / "missing.csv"), "output_directory": str(self.root / "results"), "status_path": str(status)}))
        self.assertEqual(tree.main(["--job", str(job)]), 1)
        self.assertEqual(json.loads(status.read_text())["status"], "failed")
        self.train()  # skip the success branch when sklearn is absent
        job.write_text(json.dumps({"csv_path": str(self.csv), "output_directory": str(self.root / "results"), "settings": {
            "split_mode": "session", "train_sessions": ["run1", "run3"],
            "validation_sessions": ["run0", "run2"],
        }, "status_path": str(status)}))
        self.assertEqual(tree.main(["--job", str(job)]), 0)
        completed = json.loads(status.read_text())
        self.assertEqual(completed["status"], "completed")
        self.assertEqual(completed["result"]["metrics"]["train_sessions"], ["run1", "run3"])

    def test_default_is_classification_and_model_criteria_are_checked(self):
        settings = tree.normalize_settings({})
        self.assertEqual(settings["model_type"], "decision_tree_classification")
        self.assertEqual(settings["criterion"], "gini")
        self.assertEqual(settings["ccp_alpha"], 0.0)
        for kind in ("decision_tree_regression", "linear_regression"):
            self.assertEqual(tree.normalize_settings({"model_type": kind})["criterion"], "squared_error")
        for raw in ({"model_type": "unknown"}, {"criterion": "squared_error"}, {"fit_intercept": "false"}):
            with self.assertRaises(tree.TreeLearningError):
                tree.normalize_settings(raw)

    def test_classification_metrics_use_equal_class_precision_and_recall(self):
        actual = ["left"] * 4 + ["straight"] * 2 + ["right"] * 2
        predicted = ["left", "left", "left", "straight", "straight", "right", "left", "straight"]
        metrics = tree._classification_metrics(actual, predicted)
        self.assertEqual(metrics["confusion_matrix"], [[3, 1, 0], [0, 1, 1], [1, 1, 0]])
        self.assertEqual(metrics["class_labels"], ["left", "straight", "right"])
        self.assertEqual(metrics["accuracy"], 1 / 2)
        self.assertAlmostEqual(metrics["macro_precision"], 13 / 36)
        self.assertAlmostEqual(metrics["macro_recall"], 5 / 12)
        self.assertNotIn("macro_f1", metrics)

    def test_classification_metrics_count_absent_classes_as_zero(self):
        for actual, predicted, precision, recall in (
            ([], [], 0.0, 0.0),
            (["left"], ["left"], 1 / 3, 1 / 3),
            (["left", "straight"], ["left", "left"], 1 / 6, 1 / 3),
            (["left"], ["right"], 0.0, 0.0),
        ):
            with self.subTest(actual=actual, predicted=predicted):
                metrics = tree._classification_metrics(actual, predicted)
                self.assertAlmostEqual(metrics["macro_precision"], precision)
                self.assertAlmostEqual(metrics["macro_recall"], recall)
                if not actual:
                    self.assertEqual(metrics["accuracy"], 0.0)

    def test_old_classifier_with_pruning_and_f1_metrics_still_loads(self):
        artifact = {
            "format_version": 3,
            "model_type": "decision_tree_classification",
            "grid": GRID,
            "feature_columns": tree._columns(GRID),
            "target_columns": ["direction"],
            "hyperparameters": {"ccp_alpha": 0.003},
            "metrics": {"validation": {"accuracy": 0.8, "macro_f1": 0.7}},
            "model": {
                "children_left": [-1], "children_right": [-1],
                "feature": [-2], "threshold": [-2.0], "value": [[1.0, 0.0]],
                "classes": ["left", "right"],
                "direction_commands": dict(tree.DIRECTION_COMMANDS),
            },
        }
        path = self.root / "old_model.json"
        path.write_text(json.dumps(artifact), encoding="utf-8")
        restored = tree.load_model(path)
        self.assertEqual(restored["hyperparameters"]["ccp_alpha"], 0.003)
        self.assertEqual(restored["metrics"]["validation"]["macro_f1"], 0.7)
        features = {"V": [0] * 3, "L": [0] * 2, "R": [0] * 2}
        self.assertEqual(tree.predict_model(restored, features, GRID),
                         {"direction": "left", "angular_z": 0.5})
        # A prior automatic session split did not save explicit selections.
        artifact["hyperparameters"].update(split_mode="session", train_percent=80)
        path.write_text(json.dumps(artifact), encoding="utf-8")
        legacy_session_model = tree.load_model(path)
        self.assertEqual(legacy_session_model["hyperparameters"]["train_sessions"], [])
        self.assertEqual(tree.predict_model(legacy_session_model, features, GRID),
                         {"direction": "left", "angular_z": 0.5})

    def test_direction_derivation_and_row_split_are_explicit(self):
        info = tree.inspect_csv(self.csv)
        self.assertEqual(info["target_columns"], ["direction"])
        self.assertTrue(any("direction 열이 없어" in warning for warning in info["warnings"]))
        self.assertEqual(tree.direction_from_angular(0.2), "left")
        self.assertEqual(tree.direction_from_angular(-0.2), "right")
        self.assertEqual(tree.direction_from_angular(0), "straight")
        write_csv(self.csv, update=lambda rows: [row.update(timestamp_ns="1.78973E+18") for row in rows])
        records = tree._read_csv(self.csv)[3]
        with self.assertRaises(tree.TreeLearningError):
            tree._split(records, tree.normalize_settings({"split_mode": "time"}))
        train, validation = tree._split(records, tree.normalize_settings({"split_mode": "row"}))
        self.assertEqual(train, list(range(16)))
        self.assertEqual(validation, list(range(16, 20)))
        self.assertTrue(any("timestamp_ns가 모두" in warning for warning in tree.inspect_csv(self.csv)["warnings"]))

    def test_classifier_learns_direction_not_angular_values(self):
        def labels(rows):
            for index, row in enumerate(rows):
                row["direction"] = tree.CLASS_LABELS[index % 3]
                row["angular_z"] = 0.123  # Deliberately unrelated audit output.
        write_csv(self.csv, update=labels)
        original = self.csv.read_bytes()
        result = self.train("decision_tree_classification", criterion="entropy")
        from sklearn.tree import DecisionTreeClassifier
        import numpy as np
        artifact = tree.load_model(result["model_path"])
        records = tree._read_csv(self.csv)[3]
        settings = result["settings"]
        training, validation = tree._split(records, settings)
        columns = artifact["feature_columns"]
        x = np.asarray([[row[key] for key in columns] for row in records], dtype=np.float32)
        y = np.asarray([row["direction"] for row in records])
        reference = DecisionTreeClassifier(**{key: settings[key] for key in ("max_depth", "min_samples_leaf", "min_samples_split", "max_leaf_nodes", "ccp_alpha", "criterion", "random_state")}).fit(x[training], y[training])
        for index, label in enumerate(reference.predict(x)):
            features = {group: [records[index][key] for key in tree._columns(GRID, [group])] for group in ("V", "L", "R")}
            self.assertEqual(tree.predict_model(artifact, features, GRID), {"direction": label, "angular_z": tree.DIRECTION_COMMANDS[label]})
        self.assertEqual(result["target_columns"], ["direction"])
        self.assertEqual(artifact["format_version"], 3)
        metric = result["metrics"]["validation"]
        self.assertEqual(metric["class_labels"], tree.CLASS_LABELS)
        self.assertEqual(sum(map(sum, metric["confusion_matrix"])), len(validation))
        from sklearn.metrics import accuracy_score, precision_score, recall_score
        expected_predictions = reference.predict(x[validation])
        self.assertAlmostEqual(metric["accuracy"], accuracy_score(y[validation], expected_predictions))
        self.assertAlmostEqual(metric["macro_precision"], precision_score(
            y[validation], expected_predictions, labels=tree.CLASS_LABELS, average="macro", zero_division=0))
        self.assertAlmostEqual(metric["macro_recall"], recall_score(
            y[validation], expected_predictions, labels=tree.CLASS_LABELS, average="macro", zero_division=0))
        report = json.loads(Path(result["report_path"]).read_text())
        self.assertEqual(report["metrics"]["validation"], metric)
        self.assertNotIn("macro_f1", metric)
        for point in result["curve_sample"]:
            self.assertEqual(point["actual_angular_z"], tree.DIRECTION_COMMANDS[point["actual_direction"]])
        self.assertEqual(original, self.csv.read_bytes())

    def test_classifier_rejects_bad_or_single_class_labels(self):
        write_csv(self.csv, update=lambda rows: [row.update(direction="unknown") for row in rows])
        with self.assertRaisesRegex(tree.TreeLearningError, "direction"):
            tree.inspect_csv(self.csv)
        write_csv(self.csv, update=lambda rows: [row.update(direction="left") for row in rows])
        with self.assertRaisesRegex(tree.TreeLearningError, "한 종류"):
            self.train("decision_tree_classification")

    def test_linear_regression_export_predicts_like_sklearn(self):
        for fit_intercept in (True, False):
            result = self.train("linear_regression", fit_intercept=fit_intercept)
            from sklearn.linear_model import LinearRegression
            import numpy as np
            artifact = tree.load_model(result["model_path"])
            records = tree._read_csv(self.csv)[3]
            training, validation = tree._split(records, result["settings"])
            x = np.asarray([[row[key] for key in artifact["feature_columns"]] for row in records], dtype=np.float64)
            y = np.asarray([row["angular_z"] for row in records])
            reference = LinearRegression(fit_intercept=fit_intercept).fit(x[training], y[training])
            for index, expected in enumerate(reference.predict(x)):
                features = {group: [records[index][key] for key in tree._columns(GRID, [group])] for group in ("V", "L", "R")}
                actual = tree.predict_model(artifact, features, GRID)
                self.assertEqual(set(actual), {"angular_z"})
                self.assertAlmostEqual(actual["angular_z"], expected, places=10)
            self.assertNotIn("tree_depth", result["metrics"])
            self.assertEqual(result["target_columns"], ["angular_z"])
            for key, value in (("coefficients", [0.0]), ("intercept", float("inf")), ("intercept", True)):
                corrupted = copy.deepcopy(artifact)
                corrupted["model"][key] = value
                with self.assertRaises(tree.TreeLearningError):
                    tree.validate_model(corrupted)

    def test_classification_schema_and_old_v2_regression(self):
        result = self.train()
        artifact = tree.load_model(result["model_path"])
        artifact["format_version"] = 2
        del artifact["hyperparameters"]["model_type"]
        del artifact["hyperparameters"]["fit_intercept"]
        self.assertEqual(tree.validate_model(artifact)["model_type"], "decision_tree_regression")
        classifier = tree.load_model(self.train("decision_tree_classification")["model_path"])
        for mutation in (
            lambda data: data["model"]["direction_commands"].update(left=-0.5),
            lambda data: data["model"].update(classes=["left", "left"]),
            lambda data: data["model"]["value"].__setitem__(0, [-1.0] * len(data["model"]["classes"])),
            lambda data: data.update(target_columns=["angular_z"]),
        ):
            invalid = copy.deepcopy(classifier)
            mutation(invalid)
            with self.assertRaises(tree.TreeLearningError):
                tree.validate_model(invalid)

    def test_classification_csv_can_use_direction_without_angular_target(self):
        write_csv(self.csv, update=lambda rows: [row.update(direction=tree.CLASS_LABELS[index % 3]) for index, row in enumerate(rows)])
        with self.csv.open(newline="", encoding="utf-8") as stream:
            reader = csv.DictReader(stream)
            columns = [key for key in reader.fieldnames if key != "angular_z"]
            rows = [{key: row[key] for key in columns} for row in reader]
        with self.csv.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)
        self.assertEqual(tree.inspect_csv(self.csv)["target_columns"], ["direction"])
        self.assertEqual(self.train("decision_tree_classification")["target_columns"], ["direction"])
        with self.assertRaisesRegex(tree.TreeLearningError, "angular_z"):
            tree.inspect_csv(self.csv, "linear_regression")

    def test_all_exported_models_predict_without_third_party_imports(self):
        package_root = str(Path(tree.__file__).resolve().parents[2])
        features = {"V": [10, 20, 30], "L": [10, 20], "R": [10, 20]}
        for kind in tree.MODEL_TYPES:
            result = self.train(kind)
            expected = tree.predict_model(tree.load_model(result["model_path"]), features, GRID)
            code = (
                "import sys,json; sys.path.insert(0," + repr(package_root) + "); "
                "from my_supervised._internal.tree_learning import load_model,predict_model; "
                "model=load_model(" + repr(result["model_path"]) + "); "
                "print(json.dumps(predict_model(model," + repr(features) + "," + repr(GRID) + "))); "
                "assert not any(name in sys.modules for name in ('sklearn','cv2','numpy','rclpy'))"
            )
            process = subprocess.run([sys.executable, "-S", "-B", "-c", code], capture_output=True, text=True)
            self.assertEqual(process.returncode, 0, process.stderr)
            self.assertEqual(json.loads(process.stdout), expected)


if __name__ == "__main__":
    unittest.main()
