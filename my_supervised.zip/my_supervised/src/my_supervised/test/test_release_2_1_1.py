"""Check the requested browser defaults and YOLO labels without ROS or motors."""

import ast
from html.parser import HTMLParser
from pathlib import Path

import pytest

from my_supervised._internal.web_server import HTML


ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("filename", ["train_app.py", "tree_app.py"])
def test_training_node_does_not_open_browser_by_default(filename):
    source = ROOT / "my_supervised" / "_internal" / filename
    declarations = [node for node in ast.walk(ast.parse(source.read_text()))
                    if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "declare_parameter"
                    and len(node.args) == 2
                    and isinstance(node.args[0], ast.Constant)
                    and node.args[0].value == "open_local_browser"]
    assert len(declarations) == 1
    assert ast.literal_eval(declarations[0].args[1]) is False


def test_training_launch_defaults_to_manual_url_entry():
    source = ROOT / "launch" / "train.launch.py"
    declarations = [node for node in ast.walk(ast.parse(source.read_text()))
                    if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "DeclareLaunchArgument"
                    and node.args and isinstance(node.args[0], ast.Constant)
                    and node.args[0].value == "open_local_browser"]
    assert len(declarations) == 1
    values = {item.arg: ast.literal_eval(item.value)
              for item in declarations[0].keywords}
    assert values["default_value"] == "false"
    assert values["choices"] == ["true", "false"]


def test_yolo_optimizer_choices_are_visible_and_round_trip_in_js():
    class Controls(HTMLParser):
        def __init__(self):
            super().__init__()
            self.active = False
            self.options = []

        def handle_starttag(self, tag, attributes):
            attributes = dict(attributes)
            if tag == "select" and attributes.get("id") == "training-optimizer":
                self.active = True
                assert "hidden" not in attributes
                assert "display:none" not in attributes.get("style", "").replace(" ", "")
            if tag == "option" and self.active:
                self.options.append(attributes["value"])

        def handle_endtag(self, tag):
            if tag == "select":
                self.active = False

    controls = Controls()
    controls.feed(HTML)
    assert controls.options == ["SGD", "Adam", "NesterovSGD"]
    assert "SGD (Stochastic Gradient Descent)" in HTML
    assert 'optimizer: inputValue("training-optimizer")' in HTML
    assert 'settings.optimizer ?? "SGD"' in HTML


def test_yolo_validation_button_has_requested_label():
    assert "전체 데이터 검사" not in HTML
    assert "\n데이터 검사\n" in HTML
