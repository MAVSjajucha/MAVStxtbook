# Copyright 2015 Open Source Robotics Foundation, Inc.
"""Check Stage 7 Python code docstrings."""
from pathlib import Path
from ament_pep257.main import main
import pytest

@pytest.mark.pep257
def test_pep257():
    """Run pydocstyle on the student file and stable runtime."""
    root = Path(__file__).resolve().parents[1]
    targets = [
        str(root / "my_supervised" / "decision_node.py"),
        str(root / "my_supervised" / "_internal" / "drive_runtime.py"),
    ]
    rc = main(argv=targets)
    assert rc == 0, "Found code style errors / warnings"
