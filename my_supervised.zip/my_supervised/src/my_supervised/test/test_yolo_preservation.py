"""Preserve YOLO box and polygon preparation without running GPU training."""

from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import cv2
import numpy as np
import yaml

from my_supervised._internal.model_paths import resolve_yolo_model
from my_supervised._internal.web_server import TrainingSession


class CameraApp:
    """Use image files in a temporary project instead of starting a ROS camera."""

    def __init__(self):
        self.photo_directory = None
        self.frames = SimpleNamespace(status=lambda: SimpleNamespace(
            available=True, width=80, height=60, age_seconds=0.0,
        ))

    def select_photo_directory(self, path):
        self.photo_directory = path

    def clear_browser_selection(self):
        self.photo_directory = None


class YoloPreservationTest(unittest.TestCase):
    def exercise_project(self, task):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            photos, results = root / "photos", root / "results"
            photos.mkdir()
            results.mkdir()
            app = CameraApp()
            with patch("my_supervised._internal.web_server._vehicle_identity",
                       return_value={"name": "test-vehicle", "ip": "127.0.0.1"}):
                session = TrainingSession(app)
                inspection = session.inspect(str(photos), str(results), task)
                self.assertFalse(inspection["resume_available"])
                active = session.activate(str(photos), str(results), task, "new")
                self.assertTrue(active["project"]["active"])
                self.assertEqual(active["project"]["task_type"], task)

                original_images = {}
                for index in range(2):
                    image = np.zeros((60, 80, 3), dtype=np.uint8)
                    image[:, :, index] = 140 + index * 30
                    image[15:45, 20:60] = (30, 100, 240)
                    path = photos / f"sample_{index}.png"
                    self.assertTrue(cv2.imwrite(str(path), image))
                    original_images[path] = path.read_bytes()

                registered = session.set_classes(["cone" if task == "detect" else "lane"])
                self.assertEqual(len(registered["project"]["classes"]), 1)
                list_images = session.list_box_images if task == "detect" else session.list_polygon_images
                image_list = list_images()
                self.assertEqual(image_list["image_count"], 2)
                label_files = []
                for item in image_list["images"]:
                    if task == "detect":
                        saved = session.save_box_labels(item["path"], [{
                            "class_id": 0, "x": 0.5, "y": 0.5,
                            "width": 0.5, "height": 0.5,
                        }])
                        loaded = session.load_box_labels(item["path"])
                        self.assertEqual(len(loaded["boxes"]), 1)
                    else:
                        saved = session.save_polygon_labels(item["path"], [{
                            "class_id": 0,
                            "points": [[0.3, 0.2], [0.7, 0.2], [0.9, 0.9], [0.1, 0.9]],
                        }])
                        loaded = session.load_polygon_labels(item["path"])
                        self.assertEqual(len(loaded["polygons"]), 1)
                    self.assertTrue(saved["ok"])
                    label = Path(saved["label_path"])
                    label_files.append((label, label.read_bytes()))
                    self.assertEqual(len(label.read_text().strip().split()), 5 if task == "detect" else 9)

                validation = session.validate_active_project()
                self.assertTrue(validation["validation"]["ready_for_training"], validation)
                self.assertEqual(validation["validation"]["image_count"], 2)
                self.assertEqual(validation["validation"]["labeled_image_count"], 2)
                self.assertEqual(validation["validation"]["object_count"], 2)

                defaults = session.get_training_settings()
                expected_filename = "yolo11n.pt" if task == "detect" else "yolo11n-seg.pt"
                model_path = Path(defaults["settings"]["model_path"])
                self.assertEqual(model_path.name, expected_filename)
                self.assertTrue(model_path.is_file())
                self.assertGreater(model_path.stat().st_size, 1000000)
                packaged = Path(__file__).resolve().parents[1] / "models" / expected_filename
                self.assertTrue(packaged.is_file())
                self.assertEqual(resolve_yolo_model(str(packaged), task), packaged.resolve())

                settings = session.save_training_settings({"train_ratio": 0.5, "epochs": 10,
                                                            "imgsz": 320, "batch": 1,
                                                            "workers": 0, "device": "cpu"})
                self.assertTrue(settings["ok"])
                dataset = session.build_training_dataset()["dataset"]
                self.assertEqual(dataset["train_count"], 1)
                self.assertEqual(dataset["val_count"], 1)
                self.assertFalse(dataset["source_files_modified"])
                dataset_root = Path(dataset["dataset_directory"])
                data_yaml = Path(dataset["data_yaml"])
                metadata = yaml.safe_load(data_yaml.read_text())
                self.assertEqual(Path(metadata["path"]).resolve(), dataset_root.resolve())
                self.assertNotIn(".dataset_build_", str(metadata["path"]))
                for split in ("train", "val"):
                    images = list((dataset_root / metadata[split]).glob("*"))
                    labels = list((dataset_root / "labels" / split).glob("*.txt"))
                    self.assertEqual(len(images), 1)
                    self.assertEqual(len(labels), 1)
                    self.assertEqual(cv2.imread(str(images[0])).shape, (60, 80, 3))
                    self.assertEqual(len(labels[0].read_text().strip().split()), 5 if task == "detect" else 9)

                self.assertIsNone(session.reset()["project"])
                resumed = session.activate(str(photos), str(results), task, "resume")
                self.assertTrue(resumed["project"]["resume_available"])
                self.assertEqual(list_images()["project_labeled_count"], 2)
                for image_path, content in original_images.items():
                    self.assertEqual(image_path.read_bytes(), content)
                for label_path, content in label_files:
                    self.assertEqual(label_path.read_bytes(), content)

    def test_detection_labels_validate_and_build_training_dataset(self):
        self.exercise_project("detect")

    def test_segmentation_labels_validate_and_build_training_dataset(self):
        self.exercise_project("segment")


if __name__ == "__main__":
    unittest.main()
