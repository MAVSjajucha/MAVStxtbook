"""Check preview subscription lifetime and invalid command handling without ROS."""

import importlib.util
import math
from pathlib import Path
import sys
import threading
from types import ModuleType, SimpleNamespace

import pytest


@pytest.fixture
def tree_app(monkeypatch):
    """Stub transport and storage boundaries, retaining the app's real callbacks."""
    class Node:
        def __init__(self, name):
            self.name = name
            self.parameters = {}
            self.subscriptions = []
            self.destroyed_subscriptions = []
            self.errors = []
            self.destroyed = False

        def declare_parameter(self, name, value):
            self.parameters[name] = value

        def get_parameter(self, name):
            return SimpleNamespace(value=self.parameters[name])

        def create_subscription(self, message_type, topic, callback, qos):
            result = SimpleNamespace(topic=topic, callback=callback, qos=qos)
            self.subscriptions.append(result)
            return result

        def destroy_subscription(self, subscription):
            self.destroyed_subscriptions.append(subscription)

        def create_timer(self, period, callback):
            timer = SimpleNamespace(period=period, callback=callback, cancelled=False)
            timer.cancel = lambda: setattr(timer, 'cancelled', True)
            return timer

        def create_client(self, message_type, service_name):
            return SimpleNamespace(service_name=service_name)

        def get_logger(self):
            return SimpleNamespace(info=lambda *_: None,
                                   error=lambda text, **_: self.errors.append(text))

        def destroy_node(self):
            self.destroyed = True
            return True

    class Workspace:
        def __init__(self, command_topic, **kwargs):
            self.command_topic = command_topic
            self.commands, self.results, self.images = [], [], []
            self.preview = SimpleNamespace(condition=threading.Condition(), viewers=0,
                                           closed=False, update=self.images.append)
            self.closed = False

        def receive_command(self, linear_x, angular_z):
            self.commands.append((linear_x, angular_z))

        def receive_result(self, result):
            self.results.append(result)

        def close(self):
            self.closed = True
            self.preview.closed = True

    class WebServer:
        def __init__(self, workspace, port):
            self.port = port
            self.stopped = False

        def start(self):
            pass

        def stop(self):
            self.stopped = True

    modules = {
        'rclpy': {}, 'rclpy.node': {'Node': Node},
        'rclpy.parameter': {'Parameter': object},
        'rclpy.parameter_client': {'AsyncParameterClient': lambda *_: object()},
        'rcl_interfaces': {},
        'rcl_interfaces.srv': {'SetParametersAtomically': object},
        'rclpy.qos': {'QoSProfile': lambda **kwargs: kwargs,
                      'ReliabilityPolicy': SimpleNamespace(BEST_EFFORT=1)},
        'geometry_msgs': {}, 'geometry_msgs.msg': {'Twist': object},
        'sensor_msgs': {}, 'sensor_msgs.msg': {'CompressedImage': object},
        'std_msgs': {}, 'std_msgs.msg': {'String': object},
        'my_supervised._internal.tree_web': {
            'TreeWebServer': WebServer, 'TreeWorkspace': Workspace},
        'my_supervised._internal.web_server': {'_vehicle_identity': lambda: {}},
    }
    for name, values in modules.items():
        module = ModuleType(name)
        module.__dict__.update(values)
        monkeypatch.setitem(sys.modules, name, module)
    source = Path(__file__).parents[1] / 'my_supervised/_internal/tree_app.py'
    spec = importlib.util.spec_from_file_location(
        'my_supervised._internal._tested_tree_app', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.TreeTrainingApp()


def test_no_viewer_keeps_feature_and_command_subscriptions_only(tree_app):
    tree_app._update_preview_subscription()
    assert [item.topic for item in tree_app.subscriptions] == [
        '/supervised/lane_result', '/cmd_vel']
    assert tree_app._preview_subscription is None


def test_preview_subscribes_once_then_disconnects_when_last_viewer_leaves(tree_app):
    tree_app.workspace.preview.viewers = 1
    tree_app._update_preview_subscription()
    subscription = tree_app._preview_subscription
    assert subscription.topic == '/supervised/lane_preview'
    assert subscription.qos['depth'] == 1
    tree_app.workspace.preview.viewers = 2
    tree_app._update_preview_subscription()
    assert tree_app._preview_subscription is subscription
    assert len(tree_app.subscriptions) == 3
    tree_app.workspace.preview.viewers = 0
    tree_app._update_preview_subscription()
    assert tree_app._preview_subscription is None
    assert tree_app.destroyed_subscriptions == [subscription]
    assert '/supervised/lane_result' not in [
        item.topic for item in tree_app.destroyed_subscriptions]


def test_shutdown_prevents_queued_timer_or_data_callback_reopening_workspace(tree_app):
    tree_app.workspace.preview.viewers = 1
    tree_app._update_preview_subscription()
    subscription = tree_app._preview_subscription
    assert tree_app.destroy_node()
    tree_app._update_preview_subscription()  # Simulate a timer already queued at shutdown.
    tree_app._preview(SimpleNamespace(data=b'late jpeg'))
    tree_app._result(SimpleNamespace(data='{"sequence":1}'))
    tree_app._command(SimpleNamespace(linear=SimpleNamespace(x=0.1),
                                      angular=SimpleNamespace(z=0.2)))
    assert tree_app._preview_timer.cancelled
    assert tree_app._preview_subscription is None
    assert len(tree_app.subscriptions) == 3
    assert tree_app.destroyed_subscriptions == [subscription]
    assert tree_app.workspace.closed and tree_app.web_server.stopped and tree_app.destroyed
    assert tree_app.workspace.images == tree_app.workspace.results == tree_app.workspace.commands == []


@pytest.mark.parametrize('linear,angular', [
    (math.nan, 0.1), (0.1, math.inf), (-math.inf, 0.1), ('invalid', 0.1),
])
def test_invalid_command_is_logged_skipped_and_next_valid_command_still_received(
        tree_app, linear, angular):
    tree_app._command(SimpleNamespace(linear=SimpleNamespace(x=linear),
                                      angular=SimpleNamespace(z=angular)))
    assert tree_app.workspace.commands == []
    assert len(tree_app.errors) == 1 and 'CSV/command' in tree_app.errors[0]
    assert not tree_app.destroyed
    tree_app._command(SimpleNamespace(linear=SimpleNamespace(x=0.07),
                                      angular=SimpleNamespace(z=-0.12)))
    assert tree_app.workspace.commands == [(0.07, -0.12)]


def test_recorder_write_failure_does_not_escape_ros_callback(tree_app):
    def failure(*_):
        raise OSError('disk full')
    tree_app.workspace.receive_command = failure
    tree_app._command(SimpleNamespace(linear=SimpleNamespace(x=0.1),
                                      angular=SimpleNamespace(z=0.2)))
    assert 'disk full' in tree_app.errors[0]
    assert not tree_app.destroyed
