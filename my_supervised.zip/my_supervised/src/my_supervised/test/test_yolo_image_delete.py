"""Image deletion tests use temporary fixtures, never user datasets."""

from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from threading import Event, Thread
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import cv2
import numpy as np

from my_supervised._internal.box_label_store import BoxLabelError
from my_supervised._internal.web_server import HTML, TrainingSession, TrainingWebServer


class FakeApp:
    def __init__(self):
        self.frames = SimpleNamespace(
            status=lambda: SimpleNamespace(available=False, width=80, height=60, age_seconds=None),
            latest=lambda: None,
        )

    def select_photo_directory(self, path):
        self.photo_directory = path

    def clear_browser_selection(self):
        self.photo_directory = None


class ImageDeleteTest(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name).resolve()
        self.photos, self.results = self.root / "photos", self.root / "results"
        self.photos.mkdir()
        self.results.mkdir()
        for name in ("first.png", "second.png"):
            cv2.imwrite(str(self.photos / name), np.zeros((60, 80, 3), dtype=np.uint8))
        self.identity = patch("my_supervised._internal.web_server._vehicle_identity",
                              return_value={"name": "test", "ip": "127.0.0.1"})
        self.identity.start()
        self.addCleanup(self.identity.stop)

    def session(self, task="detect"):
        session = TrainingSession(FakeApp())
        session.activate(str(self.photos), str(self.results), task, "new")
        session.set_classes(["test"])
        return session

    def delete(self, session, name="first.png", task="detect", **overrides):
        values = dict(image_path=name, project_key=session._inspection.paths.project_key,
                      confirmed=True, task_type=task)
        values.update(overrides)
        return session.delete_labeling_image(**values)

    def test_detection_image_and_own_label_deleted_other_assets_preserved(self):
        session = self.session()
        saved = session.save_box_labels("first.png", [])
        original_label = self.photos / "first.txt"
        original_label.write_text("0 0.5 0.5 0.5 0.5\n")
        duplicate = self.results / "previous_training_copy.png"
        duplicate.write_bytes((self.photos / "first.png").read_bytes())
        model = self.results / "best.pt"
        model.write_bytes(b"fixture model, not a real checkpoint")
        self.delete(session)
        self.assertFalse((self.photos / "first.png").exists())
        self.assertFalse(Path(saved["label_path"]).exists())
        self.assertTrue((self.photos / "second.png").exists())
        self.assertTrue(original_label.exists())
        self.assertTrue(duplicate.exists())
        self.assertTrue(model.exists())
        self.assertEqual(session.list_box_images()["image_count"], 1)
        for key in ("validation", "dataset", "external_dataset"):
            self.assertIsNone(session._inspection.manifest[key])
        with self.assertRaises(BoxLabelError):
            session.save_box_labels("first.png", [])
        self.assertFalse(Path(saved["label_path"]).exists())

    def test_polygon_image_and_project_label_deleted(self):
        session = self.session("segment")
        saved = session.save_polygon_labels("first.png", [])
        response = self.delete(session, task="segment")
        self.assertEqual(response["image_count"], 1)
        self.assertTrue(response["deleted_project_label"])
        self.assertFalse(Path(saved["label_path"]).exists())
        with self.assertRaises(BoxLabelError):
            session.save_polygon_labels("first.png", [])

    def test_unlabeled_image_can_be_deleted_and_empty_list_is_returned(self):
        session = self.session()
        self.delete(session)
        result = self.delete(session, "second.png")
        self.assertEqual(result["images"], [])
        self.assertEqual(result["image_count"], 0)

    def test_confirmation_and_project_identity_are_required(self):
        session = self.session()
        for overrides in ({"confirmed": False}, {"confirmed": "true"},
                          {"project_key": "previous-project"}):
            with self.subTest(overrides=overrides), self.assertRaises(BoxLabelError):
                self.delete(session, **overrides)
        self.assertTrue((self.photos / "first.png").exists())

    def test_training_in_progress_blocks_deletion(self):
        session = self.session()
        for state in ({"status": "running"}, {"status": "queued"}, {"process_alive": True}):
            with patch.object(session, "get_training_process_status", return_value=state):
                with self.assertRaisesRegex(BoxLabelError, "학습 중"):
                    self.delete(session)
        self.assertTrue((self.photos / "first.png").exists())

    def test_traversal_absolute_paths_and_image_links_cannot_delete(self):
        session = self.session()
        outside = self.root / "outside.png"
        outside.write_bytes((self.photos / "first.png").read_bytes())
        (self.photos / "linked.png").symlink_to(outside)
        (self.photos / "inside-linked.png").symlink_to(self.photos / "first.png")
        (self.photos / "linked-folder").symlink_to(self.root, target_is_directory=True)
        for path in ("../outside.png", str(outside), "linked.png", "inside-linked.png",
                     "linked-folder/outside.png", "second.png/../first.png"):
            with self.subTest(path=path), self.assertRaises(BoxLabelError):
                self.delete(session, path)
        self.assertTrue(outside.exists())
        self.assertTrue((self.photos / "first.png").exists())

    def test_project_label_link_is_rejected_before_image_deletion(self):
        session = self.session()
        label = session._inspection.paths.annotations_directory / "detect" / "first.txt"
        label.parent.mkdir(parents=True, exist_ok=True)
        outside = self.root / "outside.txt"
        outside.write_text("must remain")
        label.symlink_to(outside)
        with self.assertRaises(BoxLabelError):
            self.delete(session)
        self.assertTrue((self.photos / "first.png").exists())
        self.assertEqual(outside.read_text(), "must remain")

    def test_shared_project_label_is_preserved_for_other_image_extension(self):
        session = self.session()
        saved = session.save_box_labels("first.png", [])
        (self.photos / "first.jpg").write_bytes((self.photos / "first.png").read_bytes())
        response = self.delete(session)
        self.assertTrue(response["shared_project_label_preserved"])
        self.assertTrue(Path(saved["label_path"]).exists())
        self.assertTrue((self.photos / "first.jpg").exists())

    def test_inflight_autosave_finishes_before_deletion_without_orphan_label(self):
        session = self.session()
        entered, release, deleted = Event(), Event(), Event()
        original_save = session._box_labels.save
        errors = []

        def delayed_save(*args, **kwargs):
            entered.set()
            if not release.wait(3):
                raise RuntimeError("test autosave timeout")
            return original_save(*args, **kwargs)

        def run_save():
            try:
                session.save_box_labels("first.png", [])
            except Exception as error:
                errors.append(error)

        def run_delete():
            try:
                self.delete(session)
                deleted.set()
            except Exception as error:
                errors.append(error)

        with patch.object(session._box_labels, "save", side_effect=delayed_save):
            saving = Thread(target=run_save)
            saving.start()
            self.assertTrue(entered.wait(2))
            deleting = Thread(target=run_delete)
            deleting.start()
            self.assertFalse(deleted.wait(0.05))
            release.set()
            saving.join(3)
            deleting.join(3)
        self.assertEqual(errors, [])
        self.assertTrue(deleted.is_set())
        self.assertFalse((self.photos / "first.png").exists())
        self.assertFalse((session._inspection.paths.annotations_directory / "detect" / "first.txt").exists())

    def test_delete_api_requires_json_same_origin_and_explicit_confirmation(self):
        # The production listener is untouched; this test binds loopback only.
        with patch("my_supervised._internal.web_server.ThreadingHTTPServer",
                   side_effect=lambda address, handler: ThreadingHTTPServer(("127.0.0.1", 0), handler)):
            server = TrainingWebServer(FakeApp(), 0)
        server.session.activate(str(self.photos), str(self.results), "detect", "new")
        server.session.set_classes(["test"])
        server.start()
        self.addCleanup(server.stop)
        base = f"http://127.0.0.1:{server.port}"
        payload = {"image_path": "first.png", "project_key": server.session._inspection.paths.project_key,
                   "confirmed": True}

        def request(data, headers):
            return urlopen(Request(base + "/api/labels/delete-image", data=json.dumps(data).encode(),
                                   headers=headers), timeout=3)

        for data, headers in (
            (payload, {"Content-Type": "text/plain"}),
            (payload, {"Content-Type": "application/json", "Origin": "http://untrusted.example"}),
            ({**payload, "confirmed": False}, {"Content-Type": "application/json"}),
        ):
            with self.assertRaises(HTTPError) as raised:
                request(data, headers)
            self.assertEqual(raised.exception.code, 400)
            self.assertTrue((self.photos / "first.png").exists())
        with request(payload, {"Content-Type": "application/json", "Origin": base}) as response:
            result = json.load(response)
        self.assertTrue(result["ok"])
        self.assertEqual(result["image_count"], 1)
        self.assertFalse((self.photos / "first.png").exists())

    def test_embedded_javascript_remains_parseable(self):
        node = shutil.which("node")
        if not node:
            self.skipTest("Node.js is not installed")
        for index, source in enumerate(re.findall(r"<script[^>]*>(.*?)</script>", HTML, re.S)):
            result = subprocess.run([node, "--check"], input=source, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, f"script {index}: {result.stderr}")


if __name__ == "__main__":
    unittest.main()
