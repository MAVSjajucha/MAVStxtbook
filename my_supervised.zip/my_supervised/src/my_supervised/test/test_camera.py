"""Tests for camera selection and one-frame capture."""

import cv2
import numpy as np
import pytest

from my_supervised._internal.camera import (
    CameraError,
    CameraFrameBuffer,
    NUWA_MODE,
    USB_MODE,
    choose_camera_mode,
    normalize_camera_mode,
)


def test_camera_mode_aliases_and_auto_choice():
    assert normalize_camera_mode("hp60c") == NUWA_MODE
    assert normalize_camera_mode("ascamera") == NUWA_MODE
    assert normalize_camera_mode("usb") == USB_MODE
    assert choose_camera_mode("auto", "nuwa") == NUWA_MODE


def test_invalid_camera_mode_is_rejected():
    with pytest.raises(CameraError):
        normalize_camera_mode("not-a-camera")


def test_capture_requires_selected_absolute_directory(tmp_path):
    buffer = CameraFrameBuffer()
    buffer.update(np.zeros((24, 32, 3), dtype=np.uint8))

    with pytest.raises(CameraError):
        buffer.capture(None)
    with pytest.raises(CameraError):
        buffer.capture("relative/photos")


def test_capture_requires_received_rgb_frame(tmp_path):
    buffer = CameraFrameBuffer()

    with pytest.raises(CameraError):
        buffer.capture(str(tmp_path))


def test_frame_validation_and_copy_isolation():
    buffer = CameraFrameBuffer()

    with pytest.raises(CameraError):
        buffer.update(np.zeros((10, 10, 3), dtype=np.float32))
    with pytest.raises(CameraError):
        buffer.update(np.zeros((10, 10), dtype=np.uint8))

    original = np.zeros((10, 12, 3), dtype=np.uint8)
    original[2, 3] = (10, 20, 30)
    buffer.update(original)
    copied = buffer.latest()

    assert copied is not None
    assert copied.shape == (10, 12, 3)
    copied[2, 3] = (0, 0, 0)
    assert tuple(buffer.latest()[2, 3]) == (10, 20, 30)


def test_capture_writes_valid_unique_jpegs(tmp_path):
    buffer = CameraFrameBuffer()
    image = np.full((48, 64, 3), 127, dtype=np.uint8)
    buffer.update(image)

    first = buffer.capture(str(tmp_path))
    second = buffer.capture(str(tmp_path))

    assert first != second
    assert first.parent == tmp_path
    assert second.parent == tmp_path
    assert first.suffix.lower() == ".jpg"
    assert second.suffix.lower() == ".jpg"
    assert cv2.imread(str(first)).shape == image.shape
    assert cv2.imread(str(second)).shape == image.shape


def test_process_scanner_ignores_shell_text_that_mentions_camera(monkeypatch):
    from my_supervised._internal import camera as camera_module

    fake_processes = [
        (
            12345,
            'bash -lc pgrep -af "ascamera_node|usb_cam_node_exe"',
        )
    ]
    monkeypatch.setattr(camera_module, "_processes", lambda: iter(fake_processes))

    assert camera_module.detect_running_cameras() == []
