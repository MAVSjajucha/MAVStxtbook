from glob import glob
import os

from setuptools import find_packages, setup


package_name = "my_supervised"

setup(
    name=package_name,
    version="2.1.1",
    packages=find_packages(exclude=["test"]),
    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + package_name],
        ),
        ("share/" + package_name, ["package.xml"]),
        (
            os.path.join("share", package_name, "launch"),
            glob("launch/*.launch.py"),
        ),
        (os.path.join("share", package_name, "config"), glob("config/*.yaml")),
        (os.path.join("share", package_name, "models"), glob("models/*.pt")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="jetson",
    maintainer_email="jetson@yahboom.local",
    description="YOLO obstacle driving and classification/regression lane learning.",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "decision_node = my_supervised.decision_node:main",
            "training_app = my_supervised._internal.train_app:main",
            "lane_processor = my_supervised._internal.lane_node:main",
        ],
    },
)
