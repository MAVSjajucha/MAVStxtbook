
**이 파일은 my_supervised 패키지의 디렉터리 구조입니다.**
**패키지 사용 설명은 `사용 가이드(my_supervised).md`에서 확인할 수 있습니다.**
**실습 관련 자료는 `https://github.com/MAVSjajucha/MAVStxtbook`에서 다운로드할 수 있습니다.**
**SSH 관련 설명은 'MAVS 사용 가이드'를 참고하세요.**


`========================================================================================================================================================`

**주요 실습과 관련된 파일/폴더는 `** 문자로 강조` 표시되어 있습니다.**

my_supervised/                         # 작업 공간: /home/jetson/my_supervised
├── src/
│   └── my_supervised/                 # ROS 2 패키지
│       ├── package.xml                # 패키지 정보 및 의존성
│       ├── setup.py                   # Python 패키지 설치 및 실행 항목 설정
│       ├── setup.cfg                  # 설치 경로 설정
│       ├── LICENSE
│       ├── resource/
│       │   └── my_supervised          # ROS 2 패키지 등록 파일
│       ├── launch/
│       │   ├── train.launch.py        # 데이터 수집·모델 학습 실행
│       │   └── drive.launch.py        # 장애물 회피·차선 주행 실행
│       ├── config/
│       │   └── grid.yaml              # 격자 특징 추출 기본 설정
│       ├── models/
│       │   ├── yolo11n.pt             # YOLO 객체 탐지 기본 모델
│       │   └── yolo11n-seg.pt         # YOLO 세그멘테이션 기본 모델
│       ├── my_supervised/             # Python 소스 코드
│       │   ├── __init__.py
│       │   ├── **decision_node.py**   # 실습용 주행 판단 함수
│       │   └── _internal/             # 내부 실행 코드
│       │       ├── __init__.py
│       │       ├── drive_runtime.py   # 추론·판단 함수 호출·주행 명령 발행
│       │       ├── lane_node.py       # 차선 특징 추출·모델 예측 노드
│       │       ├── grid_features.py   # 격자 기반 V·L·R 특징 추출
│       │       ├── csv_recorder.py    # 주행 데이터 CSV 기록
│       │       ├── tree_app.py        # 차선 데이터 수집·학습 앱
│       │       ├── tree_web.py        # 차선 학습 웹 GUI·API
│       │       ├── tree_learning.py   # 의사결정트리 학습 모델
│       │       ├── train_app.py       # YOLO 학습 앱
│       │       ├── web_server.py      # YOLO 학습·라벨링 웹 GUI·API
│       │       ├── training_settings.py  # YOLO 학습 설정
│       │       ├── training_runner.py    # YOLO 학습 작업 관리
│       │       ├── training_worker.py    # YOLO 학습 실행
│       │       ├── dataset_builder.py    # YOLO 학습 데이터셋 생성
│       │       ├── dataset_import.py     # 데이터셋 가져오기
│       │       ├── project_store.py      # 프로젝트 정보 저장·불러오기
│       │       ├── project_validator.py  # 프로젝트 데이터 검사
│       │       ├── box_label_store.py    # 박스 라벨 저장
│       │       ├── image_deletion.py     # 확인한 이미지 파일 삭제
│       │       ├── polygon_label_store.py # 다각형 라벨 저장
│       │       ├── camera.py          # 카메라 선택·실행 설정
│       │       ├── live_video.py      # 실시간 영상 처리·전송
│       │       ├── joy_control.py     # 리모컨 제어 프로세스 전환
│       │       ├── environment.py     # 차량의 ROS 환경 확인
│       │       ├── model_paths.py     # 모델 파일 경로 확인
│       │       └── browser.py         # 브라우저 실행 지원
│       └── test/                      # 패키지 기능 검사 코드
├── my_yolo_data/                      # YOLO 실습 데이터
│   ├── COLCON_IGNORE                 # colcon의 패키지 탐색 제외 표시
│   ├── **example_pictures/**         # 예시 사진
│   ├── **pictures/**                 # 직접 촬영한 사진 저장 위치
│   └── **results/**                  # 프로젝트·라벨·학습 결과 저장 위치
├── my_lane_data/                      # 차선 주행 실습 데이터
│   ├── COLCON_IGNORE
│   ├── example_dataset/
│   │   └── **recording_example.csv** # 예시 학습 데이터
│   ├── **dataset/**                  # 수집한 CSV 저장 위치
│   └── **results/**                  # 학습 모델·평가 결과 저장 위치
├── docs/
│   └── examples/
│       └── decision_node_example.py  # 주행 판단 함수 예제
├── tools/
│   ├── check_vehicle.py              # 차량 실행 환경 검사
│   ├── verify_release.py             # 배포 파일 무결성 검사
│   └── demo_models.py                # 모델 학습·예측 데모 도구
├── .gitignore
├── RELEASE_VERSION                   # 배포 버전 정보
├── **사용 가이드(my_supervised).md**
├── **디렉터리 구조(my_supervised).md**
└── MANIFEST.sha256                    # 배포 파일 체크섬 목록
