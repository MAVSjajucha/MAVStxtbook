"""Train/export/reload lane models offline. No ROS node or motor command is used."""

import argparse
import json
from pathlib import Path

from my_supervised._internal.tree_learning import inspect_csv, load_model, train_csv


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', default=str(root / 'my_lane_data/example_dataset/recording_example.csv'))
    parser.add_argument('--output', required=True, help='An existing result folder')
    parser.add_argument('--model', choices=('all', 'decision_tree_classification',
                                          'decision_tree_regression', 'linear_regression'),
                        default='all')
    args = parser.parse_args()
    output = Path(args.output).expanduser()
    if not output.is_absolute() or not output.is_dir():
        parser.error('--output에는 미리 만든 폴더의 절대경로를 지정하세요.')
    models = (['decision_tree_classification', 'decision_tree_regression', 'linear_regression']
              if args.model == 'all' else [args.model])
    for model_type in models:
        summary = inspect_csv(args.csv, model_type=model_type)
        print('\n===', model_type, '===')
        print('CSV 행:', summary['row_count'])
        result = train_csv(args.csv, str(output), {
            'model_type': model_type, 'split_mode': 'row', 'train_percent': 80,
        })
        model = load_model(result['model_path'])
        if model['model_type'] != model_type:
            raise RuntimeError('저장/재로드 모델 유형이 다릅니다.')
        print(json.dumps(result['metrics'], ensure_ascii=False, indent=2))
        print('MODEL:', result['model_path'])
        print('REPORT:', result['report_path'])
    print('\n완료: 학습과 JSON 재로드만 확인했습니다. 모터 명령을 발행하지 않았습니다.')


if __name__ == '__main__':
    main()
