"""Inspect prerequisites; never publish a ROS message or start a process."""

import importlib
import importlib.metadata
from pathlib import Path
import platform
import shutil
import sys


def main():
    root = Path(__file__).resolve().parents[1]
    failures = []
    print("작업 폴더:", root)
    print("운영체제:", platform.platform())
    print("Python:", sys.executable, platform.python_version())
    if platform.system() != "Linux":
        failures.append("실행 대상은 차량의 Linux입니다. SSH로 차량에 접속하세요.")
    for name in ("ros2", "colcon"):
        found = shutil.which(name)
        print(name + ":", found or "NOT FOUND")
        if not found:
            failures.append(name + " 또는 ROS 환경 설정을 확인하세요.")
    for module in ("rclpy", "geometry_msgs.msg", "sensor_msgs.msg", "cv_bridge",
                   "numpy", "cv2", "yaml", "sklearn", "torch", "ultralytics"):
        try:
            imported = importlib.import_module(module)
            print(module + ": OK", getattr(imported, "__version__", ""))
        except Exception as error:
            failures.append(module + ": " + str(error))
            print(module + ": FAIL", str(error))
    try:
        import torch
        print("CUDA 사용 가능:", torch.cuda.is_available())
        if not torch.cuda.is_available():
            failures.append("YOLO GPU 주행에 필요한 CUDA를 확인하세요.")
    except ImportError:
        pass
    paths = (
        "/home/jetson/yahboomcar_ros2_ws/software/library_ws/install/setup.bash",
        "/home/jetson/yahboomcar_ros2_ws/yahboomcar_ws/install/setup.bash",
        "/home/jetson/yahboomcar_ros2_ws/software/library_ws/src/ascamera/launch/hp60c.launch.py",
        "/home/jetson/yahboomcar_ros2_ws/yahboomcar_ws/install/yahboomcar_ctrl/lib/yahboomcar_ctrl/yahboom_joy_A1",
    )
    for raw in paths:
        present = Path(raw).is_file()
        print("OK" if present else "MISSING", raw)
        if not present:
            failures.append("차량 기본 파일 누락: " + raw)
    free = shutil.disk_usage(root).free / (1024 ** 3)
    print(f"남은 저장 공간: {free:.2f} GiB")
    if free < 5:
        print("주의: 학습 전 5 GiB 이상 여유 공간을 권장합니다.")
    if failures:
        print("\n확인할 항목:")
        print("\n".join("- " + item for item in failures))
        print("자동 설치나 기존 드라이버 변경은 하지 않았습니다.")
        return 1
    print("\n환경 검사 PASS. 실제 카메라·조이스틱·모터 시험은 별도입니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
