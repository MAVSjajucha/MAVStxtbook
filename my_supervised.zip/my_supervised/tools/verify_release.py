"""Check the download without importing ROS or operating the vehicle."""

import hashlib
from pathlib import Path
import sys


def main():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "MANIFEST.sha256"
    if not manifest.is_file():
        print("FAIL: MANIFEST.sha256 파일이 없습니다.")
        return 1
    failures = []
    checked = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = root / relative
        if not path.resolve().is_relative_to(root):
            failures.append(relative + " (잘못된 경로)")
            continue
        if not path.is_file():
            failures.append(relative + " (파일 없음)")
            continue
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        checked += 1
        if digest.hexdigest() != expected:
            failures.append(relative + " (내용 변경)")
    print(f"검사 파일: {checked}개")
    if failures:
        print("FAIL: 원래 배포본과 다른 파일")
        print("\n".join(failures))
        print("학생이 직접 수정한 파일은 불일치가 정상입니다.")
        return 1
    print("PASS: 배포 파일의 내용이 일치합니다. 모터 명령은 발행하지 않았습니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
