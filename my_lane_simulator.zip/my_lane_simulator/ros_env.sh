#!/usr/bin/env bash
export PYTHONNOUSERSITE=1
# ROS setup scripts are not nounset-safe. Restore the caller's option afterward.
LAB_HAD_NOUNSET=0
case "$-" in *u*) LAB_HAD_NOUNSET=1; set +u;; esac
if [[ ! -f /opt/ros/humble/setup.bash ]]; then
  echo 'ROS 2 Humble이 없습니다. bash install.sh를 먼저 실행하세요.' >&2
  return 1
fi
source /opt/ros/humble/setup.bash
source "$LAB_ROOT/ros_ws/install/setup.bash"
if (( LAB_HAD_NOUNSET )); then set -u; fi
