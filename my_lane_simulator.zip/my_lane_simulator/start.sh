#!/usr/bin/env bash
export PYTHONNOUSERSITE=1
set -euo pipefail
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$LAB_ROOT"
source "$LAB_ROOT/ros_env.sh"
if [[ ! -x .venv/bin/python || ! -x build/native/lane_lab_bridge || ! -f build/gui/libLaneLab.so || ! -f build/native/liblane_lab_a1_controller.so ]]; then
  echo '먼저 이 폴더에서 bash install.sh를 실행하세요.'; exit 1
fi
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo 'Ubuntu 그래픽 데스크톱의 터미널에서 실행하세요. RGB 센서에는 그래픽 렌더링이 필요합니다.'; exit 1
fi
export PYTHONUNBUFFERED=1
export PYTHONFAULTHANDLER=1
export OMP_NUM_THREADS=2
export QT_AUTO_SCREEN_SCALE_FACTOR=1
export MPLCONFIGDIR="$LAB_ROOT/runtime/matplotlib"
mkdir -p runtime
exec .venv/bin/python -m lane_lab.supervisor "$@"
