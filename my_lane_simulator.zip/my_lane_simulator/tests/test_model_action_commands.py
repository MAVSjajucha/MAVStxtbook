"""GUI dispatch must use the selected snapshot without changing source runs."""
import json
import shutil
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import test_model_selection as fixtures
from lane_lab import runner
from lane_lab.checkpoints import checkpoint_info
from lane_lab.configuration import read_settings
from lane_lab.model_selection import prepare_resume


class ModelActionCommandTests(unittest.TestCase):
    setUp = fixtures.ModelSelectionTests.setUp

    def app(self):
        app = runner.App(self.root, headless=True)
        app.launch_work = Mock()
        app.configure_sim = Mock()
        return app

    def compatible_current(self):
        shutil.copy2(self.run / 'lesson.py', self.root / 'design/agent.py')
        return read_settings(self.root, json.loads((self.run / 'settings.json').read_text()))

    def test_bad_selections_do_not_save_settings_or_start_work(self):
        app = self.app()
        original = (self.root / 'runtime/settings.json').read_bytes()
        for action in ('resume_file', 'export_file'):
            for value in ('', str(self.actor.parent / 'model.zip')):
                with self.subTest(action=action, value=value), self.assertRaises(ValueError):
                    app.command({'action': action, 'model_path': value, 'settings': {'friction': 1.4}})
                self.assertEqual((self.root / 'runtime/settings.json').read_bytes(), original)
        app.launch_work.assert_not_called()
        app.configure_sim.assert_not_called()

    def test_resume_dispatch_restores_exact_older_best_checkpoint(self):
        settings = self.compatible_current()
        settings.update(friction_mu1=.73, friction_mu2=.3)
        app = self.app()
        original = (self.root / 'runtime/settings.json').read_bytes()
        app.command({'action': 'resume_file', 'model_path': str(self.actor), 'settings': settings})
        self.assertEqual((self.root / 'runtime/settings.json').read_bytes(), original)
        launch = app.launch_work.call_args.args[0]
        model = SimpleNamespace(num_timesteps=70152, _n_updates=1370, gamma=.995)
        # Use the actual selected counters, not the root experiment's last counter.
        prepared = prepare_resume(self.root, self.actor, settings)
        model._n_updates = prepared.candidate['ppo_updates']
        loader = Mock(return_value=model)
        app.train = Mock()
        with patch.dict(sys.modules, {'stable_baselines3': SimpleNamespace(PPO=SimpleNamespace(load=loader))}):
            launch()
        self.assertEqual(loader.call_args.args[0], self.actor.parent / 'model.zip')
        candidate = app.train.call_args.args[0]
        self.assertEqual(candidate['actor'], self.actor)
        self.assertEqual(candidate['timesteps'], 70152)
        self.assertIs(app.train.call_args.kwargs['loaded_model'], model)
        self.assertEqual(app.cfg['friction_mu1'], .73)
        self.assertEqual(app.cfg['friction_mu2'], .3)
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)
        app.configure_sim.assert_not_called()

    def test_failed_ppo_load_does_not_change_settings_or_create_run(self):
        current = self.compatible_current()
        app = self.app()
        prepared = prepare_resume(self.root, self.actor, current)
        original = (self.root / 'runtime/settings.json').read_bytes()
        before_runs = set((self.root / 'runs').iterdir())
        app.train = Mock()
        loader = Mock(side_effect=ValueError('bad policy tensor'))
        with patch.dict(sys.modules, {'stable_baselines3': SimpleNamespace(PPO=SimpleNamespace(load=loader))}):
            with self.assertRaisesRegex(ValueError, 'bad policy tensor'):
                app.resume(prepared=prepared)
        self.assertEqual((self.root / 'runtime/settings.json').read_bytes(), original)
        self.assertEqual(set((self.root / 'runs').iterdir()), before_runs)
        app.train.assert_not_called()

    def test_recovery_dispatch_loads_root_checkpoint_without_actor_or_training_record(self):
        current = self.compatible_current()
        checkpoint = self.run / 'checkpoint.zip'
        shutil.copy2(self.actor.parent / 'model.zip', checkpoint)
        (self.run / 'training.json').unlink()
        shutil.rmtree(self.run / 'models')
        app = self.app()
        app.command({'action': 'resume', 'settings': current})
        info = checkpoint_info(checkpoint)
        model = SimpleNamespace(num_timesteps=info['timesteps'],
                                _n_updates=info['ppo_updates'], gamma=info['gamma'])
        loader = Mock(return_value=model)
        app.train = Mock()
        with patch.dict(sys.modules, {'stable_baselines3': SimpleNamespace(PPO=SimpleNamespace(load=loader))}):
            app.launch_work.call_args.args[0]()
        self.assertEqual(loader.call_args.args[0], checkpoint)
        self.assertEqual(app.train.call_args.args[0]['path'], checkpoint)
        self.assertEqual(app.train.call_args.args[0]['run'], self.run)
        self.assertFalse((self.run / 'training.json').exists())
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)
        app.configure_sim.assert_not_called()

    def test_export_dispatch_uses_prepared_choice_and_ignores_pending_gui_changes(self):
        app = self.app()
        original = (self.root / 'runtime/settings.json').read_bytes()
        prepared = SimpleNamespace(actor=self.actor, run=self.run, label='best')
        target = self.root / 'exports/selected'
        with patch.object(runner, 'prepare_export', return_value=prepared) as preflight:
            app.command({'action': 'export_file', 'model_path': str(self.actor),
                         'settings': {'friction': 1.4, 'camera_pitch_deg': 55}})
        preflight.assert_called_once_with(self.root, str(self.actor))
        with patch.object(runner, 'export_selected_model', return_value=target) as export:
            app.launch_work.call_args.args[0]()
        export.assert_called_once_with(self.root, self.actor, prepared=prepared)
        self.assertEqual((self.root / 'runtime/settings.json').read_bytes(), original)
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)
        self.assertEqual(app.status['export_directory'], str(target))
        app.configure_sim.assert_not_called()


if __name__ == '__main__':
    unittest.main()
