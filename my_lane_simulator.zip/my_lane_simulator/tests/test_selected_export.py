"""A file export keeps the chosen historical model and its saved deployment context."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import numpy as np

from lane_lab import best_last_export as exporter
from lane_lab.configuration import atomic_json, sha256


PACKAGE = Path(__file__).resolve().parents[1]


class SelectedExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        for folder in ('deploy', 'ros_ws/src'):
            shutil.copytree(PACKAGE / folder, self.root / folder,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        (self.root / 'lane_lab').mkdir()
        shutil.copy2(PACKAGE / 'lane_lab/ros_nodes.py', self.root / 'lane_lab/ros_nodes.py')
        self.run = self.root / 'runs/old_experiment'
        self.run.mkdir(parents=True)
        example = PACKAGE / 'runs/example_model'
        for name in ('lesson.py', 'settings.json', 'training.json', 'vehicle_base.json',
                     'model_selection.json'):
            shutil.copy2(example / name, self.run / name)
        for folder in ('shared_code', 'models/best', 'models/last'):
            shutil.copytree(example / folder, self.run / folder,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        atomic_json(self.root / 'runtime/latest_run.json', {'run': 'runs/new_experiment'})
        atomic_json(self.root / 'runtime/settings.json', {'grid_rows': 20, 'grid_cols': 20})
        self.runtime = {path.name: path.read_bytes() for path in (self.root / 'runtime').iterdir()}
        self.actor = self.run / 'models/best/actor.npz'

    def read_json(self, path):
        return json.loads(path.read_text(encoding='utf-8'))

    def historical(self):
        folder = self.run / 'models/best_000070152_old'
        shutil.copytree(self.actor.parent, folder)
        record = self.read_json(self.run / 'model_selection.json')['best']
        atomic_json(folder / 'metadata.json', {key: record[key]
                    for key in ('timesteps', 'ppo_updates', 'metrics', 'protocol')})
        return folder / 'actor.npz'

    def assert_runtime_unchanged(self):
        self.assertEqual({path.name: path.read_bytes() for path in (self.root / 'runtime').iterdir()},
                         self.runtime)

    def test_exact_historical_model_ignores_current_best_and_latest_run(self):
        actor = self.historical()
        index = self.read_json(self.run / 'model_selection.json')
        index['best'] = index['last']
        atomic_json(self.run / 'model_selection.json', index)
        selection_before = (self.run / 'model_selection.json').read_bytes()
        group = exporter.export_selected_model(self.root, actor)
        self.assertEqual([path.name for path in group.iterdir()], [actor.parent.name])
        bundle = group / actor.parent.name
        self.assertEqual((bundle / 'actor.npz').read_bytes(), actor.read_bytes())
        choice = self.read_json(bundle / 'model_selection.json')
        self.assertEqual(choice['choice'], actor.parent.name)
        self.assertEqual(choice['timesteps'], 70152)
        self.assertEqual(choice['model_path'], str(actor))
        self.assertEqual(choice['model_sha256'], sha256(actor))
        self.assertEqual(choice['checkpoint_sha256'], sha256(actor.parent / 'model.zip'))
        training = self.read_json(bundle / 'training.json')
        self.assertEqual(training['timesteps'], 70152)
        self.assertEqual(training['source_run_last_timesteps'], 70167)
        self.assertEqual((self.run / 'model_selection.json').read_bytes(), selection_before)
        with zipfile.ZipFile(group.with_suffix('.zip')) as archive:
            self.assertEqual(archive.read(f'{group.name}/{actor.parent.name}/actor.npz'), actor.read_bytes())
            self.assertTrue(all(name.startswith(f'{group.name}/{actor.parent.name}/')
                                for name in archive.namelist()))
        self.assert_runtime_unchanged()

    def test_saved_settings_lesson_and_preprocessing_are_copied_byte_for_byte(self):
        for name in ('vision.py', 'policy_io.py'):
            # Existing saved versions are valid even after the working version changes.
            (self.root / 'lane_lab' / name).write_text('raise RuntimeError("new version")\n')
            with (self.run / 'shared_code' / name).open('a') as stream:
                stream.write('\n# saved experiment version\n')
        (self.root / 'design').mkdir()
        (self.root / 'design/agent.py').write_text('invalid current design (\n')
        group = exporter.export_selected_model(self.root, self.actor)
        bundle = group / 'best'
        for name in ('settings.json', 'lesson.py', 'vehicle_base.json'):
            self.assertEqual((bundle / name).read_bytes(), (self.run / name).read_bytes())
        for name in ('vision.py', 'policy_io.py'):
            self.assertEqual((bundle / 'lane_lab' / name).read_bytes(),
                             (self.run / 'shared_code' / name).read_bytes())
        self.assertTrue((bundle / 'run_real.sh').is_file())
        self.assertTrue((bundle / 'ros_ws/src').is_dir())
        manifest = self.read_json(bundle / 'manifest.json')['sha256']
        for relative, expected in manifest.items():
            self.assertEqual(sha256(bundle / relative), expected, relative)
        # Loading the exported runtime needs neither the source run nor current design.
        shutil.rmtree(self.root / 'runs')
        script = '''
import importlib.util, sys
from pathlib import Path
import numpy as np
root = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location('exported_drive', root / 'drive_real.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
policy, lesson, settings, grid = module.load_bundle(root)
from lane_lab.vision import extract_features
features = extract_features(np.zeros((grid.height, grid.width, 3), np.uint8), grid)
assert np.isfinite(policy.predict(lesson.observe(features, 0))).all()
'''
        result = subprocess.run([sys.executable, '-B', '-c', script, str(bundle)],
                                cwd=self.root, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assert_runtime_unchanged()

    def test_prepare_has_no_filesystem_side_effects_and_preserves_known_labels(self):
        before = {path.relative_to(self.root): sha256(path)
                  for path in self.root.rglob('*') if path.is_file()}
        for label in ('best', 'last'):
            chosen = exporter.prepare_export(self.root, self.run / 'models' / label / 'actor.npz')
            self.assertEqual(chosen.label, label)
        after = {path.relative_to(self.root): sha256(path)
                 for path in self.root.rglob('*') if path.is_file()}
        self.assertEqual(after, before)

    def test_prepared_selection_survives_best_pointer_change(self):
        chosen = exporter.prepare_export(self.root, self.actor)
        index = self.read_json(self.run / 'model_selection.json')
        index['best'] = index['last']
        atomic_json(self.run / 'model_selection.json', index)
        group = exporter.export_selected_model(self.root, self.actor, prepared=chosen)
        self.assertEqual(self.read_json(group / 'best/model_selection.json')['timesteps'], 70152)

    def test_rejects_invalid_paths_without_publishing_or_changing_runtime(self):
        alone = self.root / 'runs/actor.npz'
        shutil.copy2(self.actor, alone)
        for path in ('', self.actor.parent, self.actor.with_name('model.zip'),
                     self.root / 'runs/missing/actor.npz', alone, PACKAGE / 'runs/example_model/models/best/actor.npz'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                exporter.export_selected_model(self.root, path)
        self.assertFalse((self.root / 'exports').exists())
        self.assert_runtime_unchanged()

    def test_rejects_missing_dependencies_and_modified_saved_settings(self):
        for name in ('lesson.py', 'settings.json', 'training.json', 'vehicle_base.json',
                     'shared_code/vision.py', 'shared_code/policy_io.py', 'models/best/model.zip'):
            path = self.run / name
            original = path.read_bytes()
            path.unlink()
            with self.subTest(name=name), self.assertRaises(ValueError):
                exporter.prepare_export(self.root, self.actor)
            path.write_bytes(original)
        settings = self.run / 'settings.json'
        settings.write_bytes(settings.read_bytes() + b'\n')
        with self.assertRaisesRegex(ValueError, '학습 후 변경'):
            exporter.export_selected_model(self.root, self.actor)
        self.assertFalse((self.root / 'exports').exists())
        self.assert_runtime_unchanged()

    def test_historical_snapshot_requires_its_own_valid_metadata_and_actor(self):
        actor = self.historical()
        metadata = actor.parent / 'metadata.json'
        original = metadata.read_bytes()
        metadata.unlink()
        with self.assertRaisesRegex(ValueError, 'metadata.json'):
            exporter.prepare_export(self.root, actor)
        metadata.write_bytes(original)
        record = self.read_json(metadata)
        atomic_json(metadata, {**record, 'timesteps': 99999})
        with self.assertRaisesRegex(ValueError, '스텝 정보'):
            exporter.prepare_export(self.root, actor)
        metadata.write_bytes(original)
        with np.load(actor) as archive:
            values = {key: archive[key].copy() for key in archive.files}
        values['W0'][0, 0] = np.nan
        np.savez_compressed(actor, **values)
        with self.assertRaisesRegex(ValueError, 'NaN'):
            exporter.export_selected_model(self.root, actor)
        self.assertFalse((self.root / 'exports').exists())

    def test_source_changes_after_preflight_are_rejected(self):
        chosen = exporter.prepare_export(self.root, self.actor)
        self.actor.write_bytes(self.actor.read_bytes() + b'changed')
        with self.assertRaisesRegex(ValueError, '검사 후 변경'):
            exporter.export_selected_model(self.root, self.actor, prepared=chosen)
        self.assertFalse((self.root / 'exports').exists())
        self.assert_runtime_unchanged()

    def test_copy_corruption_leaves_no_published_export_and_preserves_export_pointer(self):
        chosen = exporter.prepare_export(self.root, self.actor)
        pointer = self.root / 'exports/latest_models.json'
        atomic_json(pointer, {'path': 'exports/previous'})
        before = pointer.read_bytes()
        copy = shutil.copy2

        def corrupt_actor(source, destination, *args, **kwargs):
            result = copy(source, destination, *args, **kwargs)
            if Path(source) == self.actor:
                Path(destination).write_bytes(b'incomplete copied actor')
            return result

        with patch.object(exporter.shutil, 'copy2', side_effect=corrupt_actor):
            with self.assertRaisesRegex(ValueError, '내보내는 동안'):
                exporter.export_selected_model(self.root, self.actor, prepared=chosen)
        self.assertEqual(pointer.read_bytes(), before)
        self.assertEqual(list((self.root / 'exports').iterdir()), [pointer])
        self.assert_runtime_unchanged()

    def test_default_export_models_api_still_exports_both_choices(self):
        group = exporter.export_models(self.root, self.run)
        self.assertEqual({path.name for path in group.iterdir()}, {'best', 'last'})
        self.assert_runtime_unchanged()


if __name__ == '__main__':
    unittest.main()
