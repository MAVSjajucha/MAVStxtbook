"""End-to-end evaluator logging with deterministic simulated transitions."""
import csv
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch

import numpy as np

from lane_lab.runner import App
from lane_lab.environment import StopRequested
from lane_lab.vision import GridConfig, GridFeatures


class FakeTrack:
    route=np.array([[-5.,0.],[5.,0.],[5.,5.],[-5.,5.]])
    wheelbase=.194
    wheel_track=.1737
    wheel_width=.0277
    contact_length=.012
    length_m=30.

    def new_tracker(self,**kwargs):
        return self

    def reset(self,*args):
        self.count=0

    def update(self,*args):
        self.count+=1
        return SimpleNamespace(new_progress_m=.01,progress_m=.01*self.count,lap_completed=self.count==2)

    def evaluate_pose(self,*args,**kwargs):
        return {'wheel_clearance_m':.02, **{name+'_clearance_m':.02 for name in
            ('front_left','front_right','rear_left','rear_right')}}

    def wheel_centers(self,x,y,yaw,steer_rad=0.,front_angles=None):
        rotation=np.array([[np.cos(yaw),-np.sin(yaw)],[np.sin(yaw),np.cos(yaw)]])
        return {name+'_wheel_xy':tuple(np.array([x,y])+rotation@np.array(offset))
            for name,offset in (
                ('front_left',(self.wheelbase/2,self.wheel_track/2)),
                ('front_right',(self.wheelbase/2,-self.wheel_track/2)),
                ('rear_left',(-self.wheelbase/2,self.wheel_track/2)),
                ('rear_right',(-self.wheelbase/2,-self.wheel_track/2)))}


class FakeSim:
    def __init__(self,mode='normal'):
        self.info={'track_metadata_path':'unused','wheelbase_m':.194}
        self.time=0.;self.calls=0;self.mode=mode
        self.config=GridConfig(rows=2,cols=3,roi_bottom_px=0,roi_top_px=250)

    def reset(self):
        self.x=0.;self.calls=0
        return self.result()

    def result(self):
        values=np.array([10+self.calls,20,250],dtype=np.int32)
        features=GridFeatures(values,np.array([4,5]),np.array([8,9]),
            np.array([1,1,0]),np.ones(2),np.ones(2),self.config)
        return {'sim_time':self.time,'image_time':self.time,'pose':[self.x,.2,0.],
            'front_angles':[.1,.08],'rear_wheel_rad_s':[1.,1.1],'features':features}

    def step(self,speed,steer):
        # The first call is the neutral reset frame.
        if self.calls==2 and self.mode!='normal':
            if self.mode=='stop':raise StopRequested()
            raise RuntimeError('injected simulator failure')
        self.time+=.1;self.x+=speed*.1;self.calls+=1
        return self.result()

    def stop(self):pass


class Lesson:
    def __init__(self):self.reward_calls=0

    def observe(self,features,previous):
        # Deliberately nonstandard observe: verify actual values, not rebuilt ones.
        return np.concatenate([features.V/100.,features.L/10.,features.R/10.,[previous*2]])

    def act(self,action,settings):
        return {'normalized_steer':float(action[0]),'steering_rad':.12,'speed_m_s':.1}

    def calculate_reward(self,state):
        self.reward_calls+=1
        progress=state.new_progress_m/.2
        near_line=.731
        touched_line=False
        finished=state.lap_completed
        return progress-near_line+float(finished),bool(finished)


class EvaluationCSVTests(unittest.TestCase):
    def execute(self,mode='normal'):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name)
        run=root/'runs/model';actor=run/'models/best/actor.npz'
        actor.parent.mkdir(parents=True)
        (run/'lesson.py').write_text('# saved lesson fixture\n')
        settings={'vision':{'rows':2,'cols':3,'roi_bottom_px':0,'roi_top_px':250},
            'steer_max_rad':.5,'max_episode_seconds':100.,'speed_mode':'auto','seed':123,
            'evaluation_episodes':99}
        lesson=Lesson();inputs=[]
        def predict(obs):
            inputs.append(obs.copy())
            return np.array([.25],dtype=np.float32)
        prepared=SimpleNamespace(run=run,actor=actor,record={'timesteps':1024},
            settings=settings,lesson=lesson,size=8,policy=SimpleNamespace(predict=predict),
            label='best',actor_sha256='testhash')
        app=App.__new__(App);app.root=root;app.stop_event=threading.Event()
        app.configure_sim=lambda *args:FakeSim(mode)
        app.report_progress=lambda *args:None
        app.model_status=lambda:{}
        app.write_status=lambda **kwargs:None
        with patch('lane_lab.environment.TrackGeometry.from_metadata',return_value=FakeTrack()):
            if mode=='error':
                with self.assertRaisesRegex(RuntimeError,'injected simulator failure'):
                    app.evaluate(prepared=prepared)
            else:app.evaluate(prepared=prepared)
        folder=next((root/'evaluation').iterdir())
        with (folder/'driving.csv').open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        metadata=json.loads((folder/'metadata.json').read_text())
        result=json.loads((folder/'result.json').read_text())
        return folder,rows,metadata,result,lesson,inputs,settings

    def test_single_drive_every_step_and_exact_before_input(self):
        folder,rows,meta,result,lesson,inputs,original=self.execute()
        self.assertEqual(len(rows),2)
        self.assertEqual([r['episode'] for r in rows],['1','1'])
        self.assertEqual([r['step'] for r in rows],['1','2'])
        self.assertEqual(result['total_episodes'],1)
        self.assertEqual(json.loads((folder/'settings.json').read_text())['evaluation_episodes'],1)
        self.assertEqual(original['evaluation_episodes'],99)  # caller settings untouched
        self.assertEqual(lesson.reward_calls,2)
        self.assertEqual(meta['status'],'complete')
        self.assertEqual(set(meta['columns']),set(rows[0]))
        self.assertFalse((folder.parent.parent/'runs/model/evaluations').exists())
        for i,row in enumerate(rows):
            np.testing.assert_allclose([float(row[f'input_{j+1:03d}']) for j in range(8)],inputs[i])
            self.assertEqual(int(row['before_v1_raw_px']),11+i%2)
            self.assertEqual(int(row['after_v1_raw_px']),12+i%2)
            self.assertAlmostEqual(float(row['near_line']),.731)
            self.assertAlmostEqual(float(row['progress']),.05)
            self.assertAlmostEqual(float(row['dt_s']),.1)
            self.assertAlmostEqual(float(row['elapsed_s']),.1*(i%2+1))
            self.assertAlmostEqual(float(row['lateral_error_m']),.2)
            self.assertAlmostEqual(float(row['heading_error_rad']),0.)
            self.assertAlmostEqual(float(row['actual_speed_m_s']),.1)
            self.assertAlmostEqual(float(row['distance_total_m']),.01*(i%2+1))
            self.assertAlmostEqual(float(row['rear_x_m']),float(row['x_m'])-.097)
            self.assertEqual(row['terminated'],str(i%2))
        self.assertEqual(rows[1]['input_008'],'0.5')
        self.assertEqual(rows[1]['previous_steering_command_normalized'],'0.25')

    def test_stop_keeps_completed_rows_and_marks_partial_evaluation(self):
        folder,rows,meta,result,lesson,*_=self.execute('stop')
        self.assertEqual(len(rows),1)
        self.assertEqual(lesson.reward_calls,1)
        self.assertEqual(meta['status'],'stopped')
        self.assertEqual(meta['rows_written'],1)
        self.assertTrue(result['stopped'])
        self.assertEqual(result['total_episodes'],0)

    def test_simulator_failure_closes_csv_and_preserves_error_metadata(self):
        folder,rows,meta,result,lesson,*_=self.execute('error')
        self.assertEqual(len(rows),1)
        self.assertEqual(meta['status'],'error')
        self.assertIn('injected',meta['error'])
        self.assertEqual(result['rows_written'],1)
        self.assertEqual(result['status'],'error')


if __name__=='__main__':unittest.main()
