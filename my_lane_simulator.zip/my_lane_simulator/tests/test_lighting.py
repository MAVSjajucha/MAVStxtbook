"""Editable scene values, saved-world replay, and lighting recovery contracts."""
import copy
import json
import math
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

from lane_lab.configuration import atomic_json, read_settings
from lane_lab.checkpoints import resume_settings
from lane_lab.lighting import (directional_sdf, directional_vector, load_lighting,
                               validate_environment_settings, validate_lighting)
from lane_lab.settings_store import SettingsStore
from lane_lab import worlds

PACKAGE = Path(__file__).resolve().parents[1]


class LightingContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for directory in ('config', 'design', 'track_img'):
            shutil.copytree(PACKAGE / directory, self.root / directory)
        # Tests mutate known defaults inside their temporary workspace only.
        # A student's edited live lighting file must not change test fixtures.
        shutil.copy2(PACKAGE / 'tests/fixtures/lighting.py', self.root / 'design/lighting.py')
        self.source = self.root / 'design/lighting.py'
        self.original = self.source.read_text()
        self.settings = read_settings(self.root)

    def edit(self, *replacements):
        source = self.source.read_text()
        for old, new in replacements:
            self.assertIn(old, source)
            source = source.replace(old, new)
        self.source.write_text(source)

    def test_native_sun_defaults_match_the_original_scene(self):
        sun = ET.fromstring(directional_sdf(self.settings))
        self.assertEqual(sun.attrib['type'], 'directional')
        self.assertEqual(float(sun.findtext('intensity')), 1.)
        self.assertEqual([float(x) for x in sun.findtext('diffuse').split()], [1., 1., 1., 1.])
        self.assertEqual([float(x) for x in sun.findtext('specular').split()], [.1, .1, .1, 1.])
        norm = math.sqrt(.3**2 + .3**2 + 1)
        for actual, expected in zip(map(float, sun.findtext('direction').split()), (-.3, .3, -1.)):
            self.assertAlmostEqual(actual, expected / norm)

    def test_direction_angles_use_source_position_not_ray_heading(self):
        for azimuth, elevation, expected in (
            (0., 0., [-1., 0., 0.]), (90., 0., [0., -1., 0.]),
            (0., 90., [0., 0., -1.]), (180., 45., [math.sqrt(.5), 0., -math.sqrt(.5)]),
            (360., -90., [0., 0., 1.])):
            for actual, target in zip(directional_vector(azimuth, elevation), expected):
                self.assertAlmostEqual(actual, target)
        self.assertEqual(directional_vector(1080., 450.), [0., 0., -1.])

    def test_design_values_override_stale_gui_fields_but_keep_checkboxes(self):
        stale = copy.deepcopy(self.settings)
        stale.update(light_level=999, track_specular=.99)
        stale['extra_lights'][0].update(enabled=True, x=111, y=222, z=333)
        self.edit(('light1 = (-0.9, -0.9, 2.0)', 'light1 = (-8.0, 19.0, 3.0)'),
                  ('TRACK_SPECULAR = 0.0', 'TRACK_SPECULAR = 0.7'),
                  ('SUN_INTENSITY = 1.0', 'SUN_INTENSITY = 2.75'),
                  ('SUN_AZIMUTH_DEG = 315.0', 'SUN_AZIMUTH_DEG = 90.0'))
        actual = read_settings(self.root, stale)
        self.assertEqual(actual['extra_lights'][0], {'enabled': True, 'x': -8., 'y': 19., 'z': 3.})
        self.assertEqual(actual['track_specular'], .7)
        self.assertEqual(actual['lighting']['directional']['intensity'], 2.75)
        self.assertEqual(actual['lighting']['directional']['azimuth_deg'], 90.)
        self.assertEqual(stale['extra_lights'][0]['x'], 111)

    def test_snapshot_replay_never_rereads_live_design(self):
        saved = copy.deepcopy(self.settings)
        self.edit(('light1 = (-0.9, -0.9, 2.0)', 'light1 = (50.0, 60.0, 70.0)'),
                  ('TRACK_SPECULAR = 0.0', 'TRACK_SPECULAR = 0.9'),
                  ('SUN_INTENSITY = 1.0', 'SUN_INTENSITY = 20.0'))
        restored = read_settings(self.root, saved, read_design=False)
        self.assertEqual(restored['lighting'], saved['lighting'])
        self.assertEqual(restored['extra_lights'], saved['extra_lights'])
        self.assertEqual(restored['track_specular'], saved['track_specular'])

    def test_old_snapshot_keeps_its_positions_specular_and_diffuse(self):
        old = copy.deepcopy(self.settings)
        for key in ('positions', 'directional', 'track_specular'):
            del old['lighting'][key]
        old.update(light_level=1.7, track_specular=.4)
        old['extra_lights'][0].update(enabled=True, x=7., y=-9., z=2.3)
        before = copy.deepcopy(old)
        migrated = read_settings(self.root, old, read_design=False)
        self.assertEqual(migrated['lighting']['positions'][0], [7., -9., 2.3])
        self.assertEqual(migrated['lighting']['track_specular'], .4)
        self.assertEqual(migrated['lighting']['directional']['diffuse'], [1.7, 1.7, 1.7, 1.])
        self.assertEqual(migrated['lighting']['directional']['intensity'], 1.)
        self.assertEqual(old, before)

    def test_world_serializes_saved_native_intensity_and_keeps_ambient_fixed(self):
        saved = copy.deepcopy(self.settings)
        saved['lighting']['directional'].update(intensity=4.5, azimuth_deg=0., elevation_deg=90.,
                                                specular=[.7, .4, .1, 1.])
        saved['lighting']['positions'][0] = [-3., 4., 2.]
        saved['lighting']['track_specular'] = .6
        saved['extra_lights'][0]['enabled'] = True
        # A broken current file must not prevent rendering a valid saved model.
        self.source.write_text('broken syntax =')
        metadata = {'spawn': [1., 1., 0.], 'width_m': 3.6, 'height_m': 2.7}
        with patch.object(worlds, 'build_track', return_value=metadata), \
                patch.object(worlds, 'load_lighting', side_effect=AssertionError('snapshot must not read design')):
            info = worlds.generate(PACKAGE, saved, self.root / 'world')
        document = ET.parse(info['world_path']).getroot()
        sun = document.find(".//light[@name='sun']")
        self.assertEqual(float(sun.findtext('intensity')), 4.5)
        self.assertEqual(sun.findtext('direction'), '0 0 -1')
        self.assertEqual(document.findtext('.//scene/ambient'), '0.35 0.35 0.35 1')
        position = list(map(float, document.findtext(".//light[@name='extra_light_1']/pose").split()))[:3]
        for actual, target in zip(position, [-1.2, 5.35, 2.001]):
            self.assertAlmostEqual(actual, target)
        self.assertEqual(info['track_specular'], .6)

    def test_invalid_edit_recovers_all_nested_fields_and_preserves_source(self):
        store = SettingsStore(self.root)
        good = copy.deepcopy(self.settings)
        good['lighting']['directional']['intensity'] = .6
        good['lighting']['track_specular'] = .8
        good['lighting']['positions'][0] = [2., 3., 4.]
        store.accept(good)
        self.edit(('SUN_SPECULAR = (0.1, 0.1, 0.1, 1.0)', 'SUN_SPECULAR = (2.0, 0.1, 0.1, 1.0)'))
        source = self.source.read_bytes()
        restored = SettingsStore(self.root).load()
        self.assertEqual(restored['lighting']['directional']['intensity'], .6)
        self.assertEqual(restored['track_specular'], .8)
        self.assertEqual(restored['extra_lights'][0]['x'], 2.)
        self.assertEqual(self.source.read_bytes(), source)
        with self.assertRaisesRegex(ValueError, 'sun.specular'):
            read_settings(self.root, restored)

    def test_failed_scene_restores_complete_previous_environment(self):
        store = SettingsStore(self.root)
        store.accept(self.settings)
        self.edit(('SUN_INTENSITY = 1.0', 'SUN_INTENSITY = 17.0'),
                  ('TRACK_SPECULAR = 0.0', 'TRACK_SPECULAR = 1.0'),
                  ('light1 = (-0.9, -0.9, 2.0)', 'light1 = (8.0, 9.0, 10.0)'))
        changed = read_settings(self.root, self.settings)
        store.save(changed)
        store.begin_apply(changed)
        restored = store.reject(RuntimeError('renderer failed'))
        self.assertEqual(restored['lighting'], self.settings['lighting'])
        self.assertEqual(SettingsStore(self.root).load()['lighting'], self.settings['lighting'])
        self.assertIn('SUN_INTENSITY = 17.0', self.source.read_text())

    def test_changed_lighting_resumes_without_changing_policy_inputs(self):
        run = self.root / 'runs' / 'old'
        (run / 'shared_code').mkdir(parents=True)
        shutil.copy2(self.root / 'design/agent.py', run / 'lesson.py')
        shutil.copy2(self.root / 'config/vehicle.json', run / 'vehicle_base.json')
        (self.root / 'lane_lab').mkdir()
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(PACKAGE / 'lane_lab' / name, run / 'shared_code' / name)
            shutil.copy2(PACKAGE / 'lane_lab' / name, self.root / 'lane_lab' / name)
        atomic_json(run / 'settings.json', self.settings)
        self.edit(('SUN_INTENSITY = 1.0', 'SUN_INTENSITY = 3.0'),
                  ('SUN_AZIMUTH_DEG = 315.0', 'SUN_AZIMUTH_DEG = 180.0'),
                  ('TRACK_SPECULAR = 0.0', 'TRACK_SPECULAR = 0.75'),
                  ('light1 = (-0.9, -0.9, 2.0)', 'light1 = (3.0, 2.0, 1.0)'))
        current = read_settings(self.root, self.settings)
        resumed = resume_settings(self.root, {'run': run, 'timesteps': 512}, current)
        self.assertEqual(resumed['lighting'], current['lighting'])
        self.assertEqual(resumed['extra_lights'], current['extra_lights'])
        self.assertEqual(resumed['track_specular'], .75)
        self.assertEqual(resumed['vision'], self.settings['vision'])

    def test_invalid_scene_values_fail_without_arbitrary_intensity_angle_caps(self):
        group = load_lighting(self.root)
        for field, value in (('intensity', float('nan')), ('azimuth_deg', float('inf')),
                             ('elevation_deg', True), ('specular', [1., 2., 1., 1.])):
            with self.subTest(field=field):
                bad = copy.deepcopy(group)
                bad['directional'][field] = value
                with self.assertRaises(ValueError):
                    validate_lighting(bad)
        for position in ([0., 1.], [0., float('inf'), 2.], [0., True, 2.]):
            bad = copy.deepcopy(group)
            bad['positions'][0] = position
            with self.assertRaises(ValueError):
                validate_environment_settings({**self.settings, 'lighting': bad})
        group['directional'].update(intensity=1e9, azimuth_deg=720., elevation_deg=-360.)
        self.assertEqual(validate_lighting(group)['directional']['intensity'], 1e9)
        self.assertEqual(directional_vector(720., -360.), [-1., 0., 0.])


if __name__ == '__main__':
    unittest.main()
