"""Selected actor resume preflight is exact, compatible and side-effect free."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import zipfile

import numpy as np

from lane_lab.configuration import atomic_json, read_settings, sha256
from lane_lab.model_selection import prepare_resume, validate_resume_selection


PACKAGE = Path(__file__).resolve().parents[1]


class SelectedResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        for folder in ('config', 'design', 'track_img'):
            shutil.copytree(PACKAGE / folder, self.root / folder)
        (self.root / 'lane_lab').mkdir()
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(PACKAGE / 'lane_lab' / name, self.root / 'lane_lab' / name)
        self.run = self.root / 'runs/older_selected'
        shutil.copytree(PACKAGE / 'runs/example_model', self.run)
        # Resume requires the student's current code/input contract to match.
        shutil.copy2(self.run / 'lesson.py', self.root / 'design/agent.py')
        self.saved = self.read_json(self.run / 'settings.json')
        self.current = read_settings(self.root, self.saved)
        self.actor = self.run / 'models/best/actor.npz'
        self.newer = self.root / 'runs/newer_unselected'
        shutil.copytree(self.run, self.newer)
        atomic_json(self.root / 'runtime/latest_run.json', {'run': 'runs/newer_unselected'})
        atomic_json(self.root / 'runtime/settings.json', self.current)

    @staticmethod
    def read_json(path):
        return json.loads(path.read_text())

    def update_index_hash(self, path):
        index = self.read_json(self.run / 'model_selection.json')
        index['best']['sha256'][path.name] = sha256(path)
        atomic_json(self.run / 'model_selection.json', index)

    def update_checkpoint(self, change):
        path = self.actor.parent / 'model.zip'
        with zipfile.ZipFile(path) as archive:
            contents = {name: archive.read(name) for name in archive.namelist()}
        data = json.loads(contents['data'])
        change(data)
        contents['data'] = json.dumps(data).encode()
        with zipfile.ZipFile(path, 'w') as archive:
            for name, value in contents.items():
                archive.writestr(name, value)
        self.update_index_hash(path)

    def update_actor(self, change):
        with np.load(self.actor) as archive:
            values = {key: archive[key].copy() for key in archive.files}
        change(values)
        np.savez_compressed(self.actor, **values)
        self.update_index_hash(self.actor)

    def test_best_uses_exact_sibling_with_counters_and_hashes(self):
        selected = prepare_resume(self.root, self.actor, self.current)
        self.assertEqual(selected.run, self.run)
        self.assertEqual(selected.actor, self.actor)
        self.assertEqual(selected.label, 'best')
        self.assertEqual(selected.candidate['path'], self.actor.parent / 'model.zip')
        self.assertEqual(selected.candidate['timesteps'], 70152)
        self.assertEqual(selected.candidate['ppo_updates'], 1370)
        self.assertEqual(selected.candidate['n_steps'], 512)
        self.assertEqual(selected.candidate['checkpoint_sha256'], sha256(self.actor.parent / 'model.zip'))
        self.assertEqual(selected.candidate['actor_sha256'], sha256(self.actor))
        self.assertEqual(selected.size, 11)

    def test_last_historical_and_legacy_root_select_their_own_zip(self):
        historical = self.run / 'models/best_000070152_old'
        shutil.copytree(self.actor.parent, historical)
        record = self.read_json(self.run / 'model_selection.json')['best']
        atomic_json(historical / 'metadata.json', record)
        for name in ('actor.npz', 'model.zip'):
            shutil.copy2(self.run / 'models/last' / name, self.run / name)
        for folder, steps, label in ((self.run / 'models/last', 70167, 'last'),
                                     (historical, 70152, historical.name),
                                     (self.run, 70167, 'last')):
            with self.subTest(folder=folder.name):
                selected = prepare_resume(self.root, folder / 'actor.npz', self.current)
                self.assertEqual(selected.candidate['path'], folder / 'model.zip')
                self.assertEqual(selected.candidate['timesteps'], steps)
                self.assertEqual(selected.label, label)

    def test_preflight_leaves_all_files_and_pending_settings_unchanged(self):
        before = {p: sha256(p) for p in self.root.rglob('*') if p.is_file()}
        pending = copy.deepcopy(self.current)
        prepare_resume(self.root, self.actor, self.current)
        self.assertEqual(self.current, pending)
        self.assertEqual({p: sha256(p) for p in self.root.rglob('*') if p.is_file()}, before)

    def test_current_environment_is_kept_with_saved_policy_context(self):
        current = copy.deepcopy(self.current)
        current.update(track='track2', friction_mu1=1.7, friction_mu2=.9, mass_kg=3.1,
                       speed_mode='manual', speed_factor=2., train_steps=125000)
        selected = prepare_resume(self.root, self.actor, current)
        for key in ('track', 'friction_mu1', 'friction_mu2', 'mass_kg', 'speed_mode', 'speed_factor', 'train_steps'):
            self.assertEqual(selected.settings[key], current[key], key)
        for key in ('vision', 'grid_rows', 'grid_cols', 'speed_m_s', 'steer_max_rad', 'seed'):
            self.assertEqual(selected.settings[key], self.saved[key], key)

    def test_target_keeps_existing_max_saved_current_semantics(self):
        current = {**self.current, 'train_steps': 80000}
        selected = prepare_resume(self.root, self.actor, current)
        self.assertEqual(selected.settings['train_steps'], 100000)
        self.saved['train_steps'] = 60000
        atomic_json(self.run / 'settings.json', self.saved)
        training = self.read_json(self.run / 'training.json')
        training['settings_sha256'] = sha256(self.run / 'settings.json')
        atomic_json(self.run / 'training.json', training)
        with self.assertRaisesRegex(ValueError, '큰 목표 스텝'):
            prepare_resume(self.root, self.actor, {**self.current, 'train_steps': 70152})
        selected = prepare_resume(self.root, self.actor, {**self.current, 'train_steps': 70153})
        self.assertEqual(selected.settings['train_steps'], 70153)

    def test_grid_camera_action_and_lesson_mismatches_block(self):
        for key in ('grid_rows', 'grid_cols', 'roi_max', 'camera_pitch_deg', 'camera_hfov_deg'):
            with self.subTest(key=key):
                current = copy.deepcopy(self.current)
                current[key] += 1
                with self.assertRaisesRegex(ValueError, '새 학습'):
                    prepare_resume(self.root, self.actor, current)
        with self.assertRaisesRegex(ValueError, '조향 범위'):
            prepare_resume(self.root, self.actor, {**self.current, 'steer_max_rad': .3})
        path = self.root / 'design/agent.py'
        path.write_text(path.read_text() + '\nUNEXPECTED_CHANGE = 1\n')
        with self.assertRaisesRegex(ValueError, '입력·보상·액션'):
            prepare_resume(self.root, self.actor, self.current)

    def test_missing_or_tampered_selected_zip_never_falls_back(self):
        path = self.actor.parent / 'model.zip'
        original = path.read_bytes()
        path.unlink()
        with self.assertRaisesRegex(ValueError, '필요한'):
            prepare_resume(self.root, self.actor, self.current)
        path.write_bytes(original + b'tampered')
        with self.assertRaisesRegex(ValueError, '무결성'):
            prepare_resume(self.root, self.actor, self.current)

    def test_actor_dimension_and_nonfinite_weights_are_rejected(self):
        original = self.actor.read_bytes()
        def wrong_dimensions(values):
            values['observation_size'] = np.array(12)
            values['W0'] = np.zeros((64, 12), np.float32)
        self.update_actor(wrong_dimensions)
        with self.assertRaisesRegex(ValueError, '입력 개수'):
            prepare_resume(self.root, self.actor, self.current)
        self.actor.write_bytes(original)
        self.update_actor(lambda values: values['W0'].__setitem__((0, 0), np.nan))
        with self.assertRaisesRegex(ValueError, 'NaN'):
            prepare_resume(self.root, self.actor, self.current)

    def test_ppo_space_architecture_and_rollout_metadata_are_rejected(self):
        path = self.actor.parent / 'model.zip'
        original = path.read_bytes()
        mutations = (
            lambda data: data['observation_space'].update(_shape=[12]),
            lambda data: data['action_space'].update(_shape=[2]),
            lambda data: data['action_space'].update(low_repr='-2.0'),
            lambda data: data['policy_kwargs']['net_arch'].update(pi=[32, 32]),
            lambda data: data['policy_kwargs'].update(activation_fn="<class 'torch.nn.modules.activation.ReLU'>"),
            lambda data: data.update(n_steps=0),
            lambda data: data.update(n_envs=2),
        )
        for change in mutations:
            with self.subTest(change=change):
                path.write_bytes(original)
                self.update_checkpoint(change)
                with self.assertRaisesRegex(ValueError, 'model.zip'):
                    prepare_resume(self.root, self.actor, self.current)

    def test_worker_guard_rejects_changed_actor_checkpoint_or_context(self):
        selected = prepare_resume(self.root, self.actor, self.current)
        for path in (self.actor, self.actor.parent / 'model.zip', self.run / 'lesson.py',
                     self.run / 'model_selection.json', self.root / 'design/agent.py'):
            with self.subTest(path=path):
                original = path.read_bytes()
                path.write_bytes(original + b'\n')
                with self.assertRaisesRegex(ValueError, '검사 후 변경'):
                    validate_resume_selection(selected)
                path.write_bytes(original)
        validate_resume_selection(selected)


if __name__ == '__main__':
    unittest.main()
