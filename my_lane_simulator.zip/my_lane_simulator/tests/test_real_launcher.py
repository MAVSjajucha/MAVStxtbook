"""Vehicle launch/stop preparation with fake process and ROS interfaces only."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import os
from pathlib import Path
import sys
from types import ModuleType
import unittest
from unittest.mock import Mock, patch


DEPLOY = Path(__file__).resolve().parents[1] / 'deploy'


def load_script(name):
    spec = importlib.util.spec_from_file_location('audited_' + name, DEPLOY / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


drive = load_script('drive_real')
launcher = load_script('vehicle_launcher')
with patch.dict(sys.modules, {'vehicle_launcher': launcher}):
    stop = load_script('stop_real')


class ReachedDevicePreparation(Exception):
    pass


class RealLauncherTests(unittest.TestCase):
    def test_invalid_options_exit_before_any_device_preparation(self):
        for options in (
                ['--drive', '--duration0'], ['--drive', '--duration'],
                ['--drive', '--duration', 'no'], ['--drive', '--duration', '-1'],
                ['--drive', '--duration', 'nan'], ['--drive', '--duration', 'inf'],
                ['--unknown']):
            with self.subTest(options=options), \
                    patch.dict(sys.modules, {'drive_real': drive}), \
                    patch.object(sys, 'argv', ['vehicle_launcher.py', *options]), \
                    patch.object(launcher.os, 'open') as lock, \
                    patch.object(launcher, 'processes') as processes, \
                    patch.object(launcher, 'background') as background, \
                    patch.object(launcher.os, 'execv') as execute, \
                    redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    launcher.main()
                self.assertEqual(error.exception.code, 2)
                lock.assert_not_called()
                processes.assert_not_called()
                background.assert_not_called()
                execute.assert_not_called()

    def test_help_exits_before_device_preparation(self):
        with patch.dict(sys.modules, {'drive_real': drive}), \
                patch.object(sys, 'argv', ['vehicle_launcher.py', '--help']), \
                patch.object(launcher.os, 'open') as lock, \
                patch.object(launcher, 'processes') as processes, \
                redirect_stdout(io.StringIO()) as output:
            with self.assertRaises(SystemExit) as error:
                launcher.main()
            self.assertEqual(error.exception.code, 0)
            self.assertIn('--duration', output.getvalue())
            lock.assert_not_called()
            processes.assert_not_called()

    def test_valid_observe_and_drive_options_reach_preparation(self):
        for options in ([], ['--duration', '5'], ['--drive', '--duration', '0']):
            with self.subTest(options=options), \
                    patch.dict(sys.modules, {'drive_real': drive}), \
                    patch.object(sys, 'argv', ['vehicle_launcher.py', *options]), \
                    patch.object(launcher.os, 'open', side_effect=ReachedDevicePreparation):
                with self.assertRaises(ReachedDevicePreparation):
                    launcher.main()

    def test_stop_uses_driver_dds_profiles_without_stale_shell_profiles(self):
        for profiles in ({}, {'CYCLONEDDS_URI': 'driver-cyclone.xml'},
                         {'FASTRTPS_DEFAULT_PROFILES_FILE': 'driver-fastdds.xml'}):
            with self.subTest(profiles=profiles):
                driver_env = {'ROS_DOMAIN_ID': '42', 'RMW_IMPLEMENTATION': 'rmw_fastrtps_cpp',
                              'ROS_LOCALHOST_ONLY': '0', **profiles}
                publisher = Mock()
                publisher.get_subscription_count.return_value = 1
                node = Mock()
                node.create_publisher.return_value = publisher
                rclpy = ModuleType('rclpy')

                def check_environment():
                    self.assertEqual(os.environ['ROS_DOMAIN_ID'], '42')
                    for name in ('CYCLONEDDS_URI', 'FASTRTPS_DEFAULT_PROFILES_FILE'):
                        self.assertEqual(os.environ.get(name), profiles.get(name))

                rclpy.init = Mock(side_effect=check_environment)
                rclpy.spin_once = Mock()
                rclpy.shutdown = Mock()
                ros_node = ModuleType('rclpy.node')
                ros_node.Node = Mock(return_value=node)
                geometry = ModuleType('geometry_msgs.msg')
                geometry.Twist = Mock(side_effect=object)
                with patch.object(stop.Path, 'iterdir', return_value=iter(())), \
                        patch.object(stop, 'processes', return_value=[object()]), \
                        patch.object(stop, 'ros_environment', return_value=driver_env), \
                        patch.dict(os.environ, {'ROS_DOMAIN_ID': '99',
                                                'CYCLONEDDS_URI': 'stale-cyclone.xml',
                                                'FASTRTPS_DEFAULT_PROFILES_FILE': 'stale-fastdds.xml'}), \
                        patch.dict(sys.modules, {'rclpy': rclpy, 'rclpy.node': ros_node,
                                                'geometry_msgs.msg': geometry}), \
                        redirect_stdout(io.StringIO()):
                    stop.main()
                rclpy.init.assert_called_once()
                self.assertEqual(publisher.publish.call_count, 15)
                rclpy.shutdown.assert_called_once()


if __name__ == '__main__':
    unittest.main()
