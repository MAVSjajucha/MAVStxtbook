"""Per-wheel truth keeps tire identity, steering geometry, and swept contact."""
import math
import unittest
from unittest.mock import patch

import numpy as np

from lane_lab.geometry import TrackGeometry


WHEELS = ('front_left', 'front_right', 'rear_left', 'rear_right')


def make_track(kingpin_width=.16):
    metadata = {
        'resolution_m': .001, 'spawn': [.5, .5, 0],
        'vehicle': {
            'wheelbase_m': .2, 'wheel_track_m': .2,
            'wheel_width_m': .012, 'wheel_contact_length_m': .02,
        },
    }
    if kingpin_width is not None:
        metadata['vehicle']['kingpin_width_m'] = kingpin_width
    xy = (np.arange(1000) + .5) * .001
    distance = .3 - abs(xy[None, :] - .5) - .25 * abs(xy[::-1, None] - .5)
    return TrackGeometry(distance, [(.2, .2), (.8, .2), (.8, .8), (.2, .8)], metadata)


def legacy_patch_points(track, x, y, yaw, steer_rad, front_angles=None):
    """Frozen pre-per-wheel transform: a regression oracle for bitmap rounding."""
    out = []
    for front in (-1, 1):
        for left in (-1, 1):
            angle = 0.0
            if front == 1 and front_angles is not None:
                angle = float(front_angles[0 if left == 1 else 1])
            elif front == 1 and abs(steer_rad) > 1e-9:
                radius = track.wheelbase / math.tan(steer_rad)
                angle = math.atan(track.wheelbase / (radius-left*track.kingpin_width/2))
            ca, sa = math.cos(angle), math.sin(angle)
            rotation = np.array([[ca, sa], [-sa, ca]])
            if front == 1:
                offset = left*(track.wheel_track-track.kingpin_width)/2
                local = (track.patch + (0, offset)) @ rotation
                local += (track.wheelbase/2, left*track.kingpin_width/2)
            else:
                local = track.patch + (-track.wheelbase/2, left*track.wheel_track/2)
            c, s = math.cos(yaw), math.sin(yaw)
            out.append(local @ np.array([[c, s], [-s, c]]) + (x, y))
    return np.concatenate(out)


def legacy_evaluate(track, pose, previous_pose=None, steer_rad=0.0,
                    previous_steer_rad=0.0, front_angles=None, previous_front_angles=None):
    """Frozen legacy aggregate sampling, including its direct current-pose sample."""
    x, y, yaw = pose

    def clearance(x, y, yaw, steer, angles):
        return float(track.clearance_at_points(
            legacy_patch_points(track, x, y, yaw, steer, angles)).min())

    result = clearance(x, y, yaw, steer_rad, front_angles)
    if previous_pose is not None:
        px, py, pa = previous_pose
        angle = (yaw-pa+math.pi) % (2*math.pi)-math.pi
        travel = math.hypot(x-px, y-py) + math.hypot(track.wheelbase/2, track.wheel_track/2)*abs(angle)
        if front_angles is not None:
            front_angles, previous_front_angles = np.asarray(front_angles), np.asarray(previous_front_angles)
        angular_travel = (float(np.max(np.abs(front_angles-previous_front_angles)))
                          if front_angles is not None else abs(steer_rad-previous_steer_rad))
        sweep_radius = math.hypot(track.contact_length/2,
            track.wheel_width/2+abs(track.wheel_track-track.kingpin_width)/2)
        travel += max(track.wheel_width, track.contact_length, sweep_radius)*angular_travel
        count = max(1, int(math.ceil(travel/.002)))
        for a in np.linspace(0.0, 1.0, count+1):
            angles = (previous_front_angles+(front_angles-previous_front_angles)*a
                      if front_angles is not None else None)
            result = min(result, clearance(px+(x-px)*a, py+(y-py)*a,
                pa+angle*a, previous_steer_rad+(steer_rad-previous_steer_rad)*a, angles))
    return result


class RewardWheelGeometryTests(unittest.TestCase):
    def setUp(self):
        self.track = make_track()

    def test_named_centers_are_vehicle_left_and_right_after_yaw_rotation(self):
        centers = self.track.wheel_centers(.5, .5, math.pi/2)
        expected = {'front_left': (.4, .6), 'front_right': (.6, .6),
                    'rear_left': (.4, .4), 'rear_right': (.6, .4)}
        self.assertEqual(set(centers), {f'{name}_wheel_xy' for name in WHEELS})
        for name, xy in expected.items():
            with self.subTest(wheel=name):
                self.assertIsInstance(centers[f'{name}_wheel_xy'], tuple)
                np.testing.assert_allclose(centers[f'{name}_wheel_xy'], xy, atol=1e-15)

    def test_measured_steering_rotates_tire_centers_around_kingpins(self):
        left_angle, right_angle = .6, -.3
        centers = self.track.wheel_centers(.5, .5, 0, steer_rad=-.8,
                                          front_angles=(left_angle, right_angle))
        offset = .02
        np.testing.assert_allclose(centers['front_left_wheel_xy'],
            (.6-offset*math.sin(left_angle), .58+offset*math.cos(left_angle)), atol=1e-15)
        np.testing.assert_allclose(centers['front_right_wheel_xy'],
            (.6+offset*math.sin(right_angle), .42-offset*math.cos(right_angle)), atol=1e-15)
        np.testing.assert_allclose(centers['rear_left_wheel_xy'], (.4, .6), atol=1e-15)
        np.testing.assert_allclose(centers['rear_right_wheel_xy'], (.4, .4), atol=1e-15)
        self.assertEqual(centers, self.track.wheel_centers(.5, .5, 0, .7,
                                                        (left_angle, right_angle)))

    def test_command_steering_uses_distinct_ackermann_angles(self):
        for steer in (-.6, .6):
            radius = .2 / math.tan(steer)
            left = math.atan(.2/(radius-.08))
            right = math.atan(.2/(radius+.08))
            with self.subTest(steer=steer):
                self.assertNotEqual(left, right)
                self.assertEqual(self.track.wheel_centers(.5, .5, .8, steer),
                                 self.track.wheel_centers(.5, .5, .8, front_angles=(left, right)))

    def test_older_metadata_preserves_coincident_kingpins(self):
        track = make_track(kingpin_width=None)
        self.assertEqual(track.wheel_centers(.5, .5, .7, front_angles=(.6, -.4)),
                         track.wheel_centers(.5, .5, .7))

    def test_each_clearance_uses_its_full_patch_and_single_shared_lookup(self):
        # A linear distance field gives an analytic minimum at each lower-left
        # contact-patch corner and a different answer for all four wheels.
        distance = lambda points: points[:, 0] + 3*points[:, 1]
        with patch.object(self.track, 'clearance_at_points', side_effect=distance) as lookup:
            values = self.track.wheel_clearances(.5, .5, 0)
        lookup.assert_called_once()
        self.assertEqual(lookup.call_args.args[0].shape, (4*len(self.track.patch), 2))
        centers = {'front_left': (.6, .6), 'front_right': (.6, .4),
                   'rear_left': (.4, .6), 'rear_right': (.4, .4)}
        for name, (x, y) in centers.items():
            self.assertAlmostEqual(values[f'{name}_clearance_m'], x+3*y-.01-3*.006)

    def test_sweep_detects_contact_only_between_endpoints_and_keeps_wheel_identity(self):
        # Only the front-left patch crosses this obstacle. Its endpoint is clear,
        # while the rear-left patch has not yet reached the obstacle.
        obstacle = np.array([.8, .6])
        distance = lambda points: np.linalg.norm(points-obstacle, axis=1) - .01
        with patch.object(self.track, 'clearance_at_points', side_effect=distance):
            before = self.track.wheel_clearances(.5, .5, 0)
            after = self.track.wheel_clearances(.8, .5, 0)
            swept = self.track.evaluate_pose(.8, .5, 0, previous_pose=(.5, .5, 0))
        self.assertGreater(min(before.values()), 0)
        self.assertGreater(min(after.values()), 0)
        # The 2 mm sweep spacing places a sample within 1 mm of the center.
        self.assertGreaterEqual(swept['front_left_clearance_m'], -.01)
        self.assertLess(swept['front_left_clearance_m'], -.009)
        for name in ('front_right', 'rear_left', 'rear_right'):
            self.assertGreater(swept[f'{name}_clearance_m'], 0)
        self.assertEqual(swept['wheel_clearance_m'], swept['front_left_clearance_m'])
        self.assertTrue(swept['touched_line'])

    def test_legacy_patch_order_and_aggregate_are_exact_for_instant_and_swept_poses(self):
        cases = [
            ((.5, .5, .3), {}),
            ((.1, .1, 1.3), {'steer_rad': -.6}),
            ((.57, .53, .5), {'previous_pose': (.46, .49, -.2),
                             'steer_rad': .6, 'previous_steer_rad': -.4}),
            ((.49, .55, -3.13), {'previous_pose': (.48, .52, 3.12),
                                 'front_angles': (.6, -.2),
                                 'previous_front_angles': (-.3, .4)}),
        ]
        for pose, kwargs in cases:
            with self.subTest(pose=pose, kwargs=kwargs):
                steer, angles = kwargs.get('steer_rad', 0), kwargs.get('front_angles')
                old_points = legacy_patch_points(self.track, *pose, steer, angles)
                np.testing.assert_array_equal(self.track._patch_points(*pose, steer, angles), old_points)
                self.assertEqual(self.track.wheel_clearance(*pose, steer, angles),
                                 float(self.track.clearance_at_points(old_points).min()))
                expected = legacy_evaluate(self.track, pose, **kwargs)
                actual = self.track.evaluate_pose(*pose, **kwargs)
                self.assertEqual(actual['wheel_clearance_m'], expected)
                self.assertEqual(actual['wheel_clearance_m'],
                                 min(actual[f'{name}_clearance_m'] for name in WHEELS))
                self.assertEqual(actual['touched_line'], expected <= 0)

    def test_measured_sweep_validation_is_preserved(self):
        with self.assertRaisesRegex(ValueError, 'previous_front_angles'):
            self.track.evaluate_pose(.5, .5, 0, previous_pose=(.4, .5, 0), front_angles=(.2, .3))
        for angles in ((.2,), (.2, float('nan'))):
            with self.subTest(angles=angles), self.assertRaises(ValueError):
                self.track.evaluate_pose(.5, .5, 0, front_angles=angles)


if __name__ == '__main__':
    unittest.main()
