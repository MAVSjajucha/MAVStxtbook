"""Student discount-factor validation, resume gates and real PPO wiring."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import re
import shutil
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import zipfile

import numpy as np

from lane_lab.checkpoints import (checkpoint_info, require_checkpoint_gamma,
                                  require_compatible, resume_settings)
from lane_lab.configuration import (atomic_json, check_lesson, checked_gamma,
                                    lesson_gamma, read_settings)


PACKAGE = Path(__file__).resolve().parents[1]


class GammaTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        for folder in ('config', 'design', 'track_img'):
            shutil.copytree(PACKAGE / folder, self.root / folder)
        (self.root / 'lane_lab').mkdir()
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(PACKAGE / 'lane_lab' / name, self.root / 'lane_lab' / name)
        self.current = read_settings(self.root)
        self.agent = self.root / 'design/agent.py'
        self.source = self.agent.read_text(encoding='utf-8')
        self.run = self.root / 'runs/saved'
        (self.run / 'shared_code').mkdir(parents=True)
        shutil.copy2(self.agent, self.run / 'lesson.py')
        shutil.copy2(self.root / 'config/vehicle.json', self.run / 'vehicle_base.json')
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(self.root / 'lane_lab' / name, self.run / 'shared_code' / name)
        atomic_json(self.run / 'settings.json', self.current)

    def source_with_gamma(self, expression):
        replacement = '' if expression is None else f'gamma = {expression}\n'
        updated, count = re.subn(r'^gamma\s*=.*\n', replacement, self.source, flags=re.M)
        self.assertEqual(count, 1, '학생 파일의 실제 gamma 선언을 수정해야 합니다.')
        return updated

    def checkpoint(self, gamma, *, include_gamma=True):
        path = self.run / 'model.zip'
        data = {'num_timesteps': 512, '_n_updates': 10, 'n_steps': 512}
        if include_gamma:
            data['gamma'] = gamma
        with zipfile.ZipFile(path, 'w') as archive:
            archive.writestr('data', json.dumps(data))
            archive.writestr('policy.pth', b'test fixture')
            archive.writestr('policy.optimizer.pth', b'test fixture')
        return path

    def test_gamma_accepts_finite_numeric_endpoints_and_intermediate_values(self):
        for value in (0, 1, 0.87, 0.995, np.float64(0.95)):
            with self.subTest(value=value):
                self.assertEqual(checked_gamma(value), float(value))

    def test_gamma_rejects_non_numeric_boolean_nonfinite_and_out_of_range(self):
        for value in (True, False, np.bool_(True), None, '0.995', [], {}, 1j,
                      np.array([0.995]), float('nan'), float('inf'),
                      -float('inf'), -0.001, 1.001):
            with self.subTest(value=repr(value)):
                with self.assertRaisesRegex(ValueError, 'gamma'):
                    checked_gamma(value)

    def test_old_lesson_without_gamma_keeps_historical_default(self):
        self.assertEqual(lesson_gamma(SimpleNamespace()), 0.995)
        self.agent.write_text(self.source_with_gamma(None), encoding='utf-8')
        lesson, size = check_lesson(self.agent, self.current)
        self.assertGreater(size, 0)
        self.assertFalse(hasattr(lesson, 'gamma'))
        self.assertEqual(lesson_gamma(lesson), 0.995)

    def test_code_checker_reads_student_gamma_without_changing_observation_size(self):
        _, expected_size = check_lesson(self.agent, self.current)
        for value in (0, 0.87, 1):
            with self.subTest(gamma=value):
                self.agent.write_text(self.source_with_gamma(repr(value)), encoding='utf-8')
                lesson, size = check_lesson(self.agent, self.current)
                self.assertEqual(size, expected_size)
                self.assertEqual(lesson_gamma(lesson), value)

    def test_code_checker_rejects_invalid_gamma(self):
        for expression in ('True', 'None', "'0.9'", '1.01', '-0.01',
                           "float('nan')", "float('inf')", '[0.9]'):
            with self.subTest(expression=expression):
                self.agent.write_text(self.source_with_gamma(expression), encoding='utf-8')
                with self.assertRaisesRegex(ValueError, 'gamma'):
                    check_lesson(self.agent, self.current)

    def test_old_lesson_and_new_default_declaration_are_resume_compatible(self):
        (self.run / 'lesson.py').write_text(self.source_with_gamma(None), encoding='utf-8')
        require_compatible(self.root, self.run, self.current)
        candidate = checkpoint_info(self.checkpoint(0.995))
        candidate['run'] = self.run
        resume_settings(self.root, candidate, self.current)

    def test_changed_gamma_blocks_resume_with_specific_explanation(self):
        self.agent.write_text(self.source_with_gamma('0.87'), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'gamma.*새 학습'):
            require_compatible(self.root, self.run, self.current)

    def test_matching_nondefault_gamma_can_resume(self):
        changed = self.source_with_gamma('0.87')
        self.agent.write_text(changed, encoding='utf-8')
        (self.run / 'lesson.py').write_text(changed, encoding='utf-8')
        candidate = checkpoint_info(self.checkpoint(0.87))
        candidate['run'] = self.run
        resume_settings(self.root, candidate, self.current)

    def test_archive_gamma_must_match_saved_lesson(self):
        candidate = checkpoint_info(self.checkpoint(0.87))
        with self.assertRaisesRegex(ValueError, 'gamma'):
            require_checkpoint_gamma(candidate, self.run)

    def test_archive_missing_gamma_is_not_assumed_to_be_legacy_default(self):
        candidate = checkpoint_info(self.checkpoint(None, include_gamma=False))
        candidate['run'] = self.run
        with self.assertRaisesRegex(ValueError, 'gamma'):
            resume_settings(self.root, candidate, self.current)

    def test_archive_nonfinite_or_invalid_gamma_is_rejected(self):
        for value in (float('nan'), float('inf'), -0.1, 1.1, None, True, '0.995'):
            with self.subTest(value=repr(value)):
                with self.assertRaisesRegex(ValueError, 'gamma'):
                    info = checkpoint_info(self.checkpoint(value))
                    require_checkpoint_gamma(info, self.run)

    def test_gamma_addition_does_not_weaken_reward_change_gate(self):
        old = self.source_with_gamma(None)
        (self.run / 'lesson.py').write_text(old, encoding='utf-8')
        changed = self.source.replace('return float(score), bool(end_episode)',
                                      'return float(score) + 1.0, bool(end_episode)')
        self.assertNotEqual(changed, self.source)
        self.agent.write_text(changed, encoding='utf-8')
        with self.assertRaisesRegex(ValueError, '입력·보상·액션'):
            require_compatible(self.root, self.run, self.current)


@unittest.skipUnless(importlib.util.find_spec('stable_baselines3') is not None,
                     '실제 PPO 연동 검증에는 패키지의 stable_baselines3가 필요합니다.')
class GammaPPOIntegrationTests(unittest.TestCase):
    def test_app_train_uses_student_gamma_and_persists_actual_ppo_setting(self):
        import gymnasium as gym
        from stable_baselines3 import PPO
        from lane_lab.runner import App

        observed = []
        captured = []
        discarded = []

        class TinyLaneEnv(gym.Env):
            """Only Gazebo I/O is replaced; the App and PPO training are real."""
            def __init__(self, sim, settings, lesson, size, stop_event, report):
                self.observation_space = gym.spaces.Box(-1.1, 1.1, (size,), dtype=np.float32)
                self.action_space = gym.spaces.Box(-1., 1., (1,), dtype=np.float32)
                self.episode_steps = 0
                self.total_steps = 0

            def reset(self, *, seed=None, options=None):
                super().reset(seed=seed)
                self.episode_steps = 0
                return np.zeros(self.observation_space.shape, np.float32), {}

            def step(self, action):
                self.episode_steps += 1
                self.total_steps += 1
                obs = np.full(self.observation_space.shape,
                              self.episode_steps / 16., np.float32)
                return obs, float(0.5 - abs(action[0])), self.episode_steps >= 16, False, {}

        class NoEvaluation:
            def __init__(self, *args, **kwargs):
                pass

            def capture(self, model):
                captured.append((model.num_timesteps, model._n_updates, model.gamma))

            def maybe_evaluate(self, model, *, final=False):
                observed.append((model.gamma, model.rollout_buffer.gamma,
                                 model.gae_lambda, model.rollout_buffer.gae_lambda))

            def discard_pending(self, reason):
                discarded.append(reason)

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for folder in ('config', 'design', 'track_img'):
                shutil.copytree(PACKAGE / folder, root / folder)
            (root / 'lane_lab').mkdir()
            for name in ('vision.py', 'policy_io.py'):
                shutil.copy2(PACKAGE / 'lane_lab' / name, root / 'lane_lab' / name)
            agent = root / 'design/agent.py'
            source, count = re.subn(r'^gamma\s*=.*$', 'gamma = 0.87',
                                    agent.read_text(encoding='utf-8'), flags=re.M)
            self.assertEqual(count, 1)
            agent.write_text(source, encoding='utf-8')
            app = App.__new__(App)
            app.root = root
            app.runtime = root / 'runtime'
            app.runtime.mkdir()
            app.cfg = read_settings(root, {'train_steps': 512, 'torch_threads': 1})
            app.stop_event = threading.Event()
            app.configure_sim = Mock(return_value=object())
            app.write_status = Mock()
            app.model_status = Mock(return_value={})
            app.report = Mock()

            with patch('lane_lab.runner.LaneEnv', TinyLaneEnv), \
                    patch('lane_lab.runner.BestLastSelector', NoEvaluation):
                app.train()

            runs = list((root / 'runs').iterdir())
            self.assertEqual(len(runs), 1)
            run = runs[0]
            record = json.loads((run / 'training.json').read_text())
            self.assertIsNone(record['failed'])
            self.assertEqual(record['timesteps'], 512)
            self.assertGreater(record['ppo_updates'], 0)
            self.assertEqual(record['gamma'], 0.87)
            self.assertEqual(record['gae_lambda'], 0.95)
            self.assertEqual(captured, [(512, record['ppo_updates'], 0.87)])
            self.assertEqual(discarded, ['finished'])
            self.assertTrue(observed)
            self.assertTrue(all(values == (0.87, 0.87, 0.95, 0.95) for values in observed))
            for path in (run / 'model.zip', run / 'checkpoint.zip'):
                self.assertEqual(checkpoint_info(path)['gamma'], 0.87)
            restored = PPO.load(run / 'model.zip', device='cpu')
            self.assertEqual(restored.gamma, 0.87)
            self.assertEqual(restored.rollout_buffer.gamma, 0.87)
            self.assertEqual(restored.gae_lambda, 0.95)
            self.assertEqual(restored.rollout_buffer.gae_lambda, 0.95)


if __name__ == '__main__':
    unittest.main()
