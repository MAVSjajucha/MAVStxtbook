"""Editable-setting recovery without launching ROS, Gazebo or subprocesses."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import Mock, patch

from lane_lab import runner
from lane_lab.configuration import atomic_json, read_settings
from lane_lab.lighting import load_lighting


PACKAGE = Path(__file__).resolve().parents[1]


class FakeSimulator:
    def __init__(self, root, runtime, info, settings):
        self.info = info
        self.settings = copy.deepcopy(settings)
        self.closed = False

    def start(self):
        pass

    def reset(self):
        return {}

    def close(self):
        self.closed = True

    def stop(self):
        pass

    def is_alive(self):
        return not self.closed

    def update_settings(self, settings):
        self.settings = copy.deepcopy(settings)


class SettingsRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for directory in ('config', 'design', 'track_img'):
            shutil.copytree(PACKAGE / directory, self.root / directory)
        # Tests mutate known defaults inside their temporary workspace only.
        # A student's edited live lighting file must not change test fixtures.
        shutil.copy2(PACKAGE / 'tests/fixtures/lighting.py', self.root / 'design/lighting.py')
        self.runtime = self.root / 'runtime'
        self.runtime.mkdir()
        self.settings_path = self.runtime / 'settings.json'
        self.initial = read_settings(self.root)
        self.lighting = self.root / 'design/lighting.py'
        self.light_source = self.lighting.read_bytes()
        # Any accidental external command is an immediate test failure.
        self.addCleanup(patch.stopall)
        patch.object(runner.subprocess, 'Popen', side_effect=AssertionError('external process')).start()
        patch.object(runner.subprocess, 'run', side_effect=AssertionError('external process')).start()
        self.simulator = patch.object(runner, 'Simulator', side_effect=FakeSimulator).start()
        self.gui = patch.object(runner.App, 'start_gui').start()
        self.generate = patch.object(runner, 'generate', side_effect=lambda root, cfg, out:
                                     {'world_path': str(Path(out) / 'world.sdf')}).start()

    def app(self):
        return runner.App(self.root, headless=False)

    def saved(self):
        return json.loads(self.settings_path.read_text())

    def invalid_track(self):
        cells = copy.deepcopy(self.initial['custom_tiles'])
        cells[0][0] = 'Background'
        return cells

    def preserve_contains(self, data):
        return any(p.read_bytes() == data for p in (self.runtime / 'recovery').glob('*.json')
                   if not p.name.endswith('.reason.json'))

    def test_bundled_recovery_values_equal_editable_defaults(self):
        bundled = read_settings(self.root, read_design=False)
        self.assertEqual(bundled['lighting'], load_lighting(self.root))
        self.assertEqual(bundled['friction_mu1'], .5)
        self.assertEqual(bundled['friction_mu2'], .5)
        self.assertNotIn('motor_randomization', bundled)
        self.assertNotIn('track_friction', bundled)

    def test_successful_check_clears_error_after_worker_finishes(self):
        app = self.app()
        app.preflight = Mock(return_value=11)
        app.worker = Mock()
        app.worker.is_alive.return_value = False
        app.write_status(status='training')
        app.error(ValueError('입력·보상·액션 코드가 변경되었습니다.'))
        app.command({'action': 'check'})
        self.assertEqual(app.status['status'], 'ready')
        self.assertTrue(app.status['message'].startswith('코드 검사 통과'))

    def test_successful_check_preserves_active_work_and_stopping(self):
        for phase in ('preview', 'training', 'evaluating', 'exporting', 'starting', 'stopping'):
            with self.subTest(phase=phase):
                app = self.app()
                app.preflight = Mock(return_value=11)
                app.worker = Mock()
                app.worker.is_alive.return_value = True
                app.write_status(status=phase)
                app.error(ValueError('잘못된 설정 요청'))
                app.command({'action': 'check'})
                self.assertEqual(app.status['status'], phase)
        app.write_status(status='training')
        app.error(ValueError('잘못된 설정 요청'))
        app.stop_event.set()
        app.command({'action': 'check'})
        self.assertEqual(app.status['status'], 'stopping')

    def test_successful_check_keeps_normal_state_and_failed_check_keeps_error(self):
        app = self.app()
        app.preflight = Mock(return_value=11)
        for phase in ('preview', 'training', 'evaluating', 'exporting', 'complete', 'stopped'):
            with self.subTest(phase=phase):
                app.write_status(status=phase)
                app.command({'action': 'check'})
                self.assertEqual(app.status['status'], phase)
        app.error(ValueError('수정 전 오류'))
        app.preflight.side_effect = ValueError('아직 코드 오류')
        with self.assertRaisesRegex(ValueError, '아직 코드 오류'):
            app.command({'action': 'check'})
        self.assertEqual(app.status['status'], 'error')

    def test_check_does_not_hide_a_new_runtime_error_during_preflight(self):
        app = self.app()
        app.write_status(status='training')
        app.error(ValueError('이전 설정 오류'))
        def preflight(settings):
            app.error(RuntimeError('새 Gazebo 연결 오류'))
            return 11
        app.preflight = preflight
        app.command({'action': 'check'})
        self.assertEqual(app.status['status'], 'error')
        self.assertEqual(app.status['message'], '새 Gazebo 연결 오류')

    def test_bad_lighting_opens_gui_using_last_good_and_keeps_source(self):
        good = copy.deepcopy(self.initial)
        good['lighting']['point']['constant'] = .75
        atomic_json(self.runtime / 'settings.last_good.json', good)
        self.lighting.write_text(self.light_source.decode().replace('POINT_CONSTANT = 0.5', 'POINT_CONSTANT = 2.0'))
        bad_source = self.lighting.read_bytes()
        app = self.app()
        self.assertEqual(app.cfg['lighting']['point']['constant'], .75)
        self.assertIn('design/lighting.py', app.status['settings_warning'])
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()
        self.assertEqual(self.lighting.read_bytes(), bad_source)
        with self.assertRaisesRegex(ValueError, 'design/lighting.py'):
            app.command({'action': 'apply'})
        self.assertEqual(self.lighting.read_bytes(), bad_source)

    def test_obsolete_motor_file_and_saved_values_do_not_block_startup(self):
        motor = self.root / 'design/motor_randomization.py'
        motor.write_text('REAR_ERROR_PERCENT = (\n')
        bad_source = motor.read_bytes()
        legacy = {**self.initial, 'rear_random_enabled': True,
                  'servo_random_enabled': True, 'motor_randomization': 'obsolete',
                  'track_friction': 'obsolete', 'friction': 1.25}
        legacy.pop('friction_mu1')
        legacy.pop('friction_mu2')
        atomic_json(self.settings_path, legacy)
        app = self.app()
        self.assertEqual(app.cfg['friction_mu1'], 1.25)
        self.assertEqual(app.cfg['friction_mu2'], 1.25)
        for key in ('motor_randomization', 'rear_random_enabled', 'servo_random_enabled', 'track_friction'):
            self.assertNotIn(key, app.cfg)
            self.assertNotIn(key, self.saved())
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()
        self.assertEqual(app.status['settings_warning'], '')
        self.assertEqual(motor.read_bytes(), bad_source)

    def test_legacy_last_good_recovers_friction_without_obsolete_motor_values(self):
        good = {**self.initial, 'friction': 3.25, 'track_friction': .1,
                'rear_random_enabled': True, 'servo_random_enabled': True,
                'motor_randomization': {'REAR_ERROR_PERCENT': 99.}}
        good.pop('friction_mu1')
        good.pop('friction_mu2')
        atomic_json(self.runtime / 'settings.last_good.json', good)
        atomic_json(self.settings_path, {**good, 'friction': -1})
        bad = self.settings_path.read_bytes()
        app = self.app()
        self.assertEqual(app.cfg['friction_mu1'], 3.25)
        self.assertEqual(app.cfg['friction_mu2'], 3.25)
        self.assertEqual(self.saved()['friction_mu1'], 3.25)
        self.assertEqual(self.saved()['friction_mu2'], 3.25)
        self.assertTrue(self.preserve_contains(bad))
        for key in ('motor_randomization', 'rear_random_enabled', 'servo_random_enabled', 'track_friction'):
            self.assertNotIn(key, app.cfg)
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()

    def test_invalid_friction_cannot_replace_saved_settings_or_start_work(self):
        app = self.app()
        app.preflight = Mock(side_effect=AssertionError('preflight must not run'))
        app.launch_work = Mock(side_effect=AssertionError('work must not start'))
        before = self.settings_path.read_bytes()
        for value in (-.1, float('nan'), float('inf'), True, 'not a number'):
            with self.subTest(value=value):
                with self.assertRaisesRegex(ValueError, 'friction'):
                    app.command({'action': 'apply', 'settings': {'friction': value}})
                self.assertEqual(self.settings_path.read_bytes(), before)
                self.assertEqual(app.cfg, self.initial)
        app.preflight.assert_not_called()
        app.launch_work.assert_not_called()
        self.generate.assert_not_called()

    def test_changing_either_friction_coefficient_reloads_the_physical_scene(self):
        app = self.app()
        app.configure_sim(app.cfg)
        original = app.sim
        first = read_settings(self.root, {**app.cfg, 'friction_mu1': .8})
        self.assertNotEqual(app.world_key(app.cfg), app.world_key(first))
        app.configure_sim(first)
        self.assertTrue(original.closed)
        after_first = app.sim
        second = read_settings(self.root, {**first, 'friction_mu2': .2})
        self.assertNotEqual(app.world_key(first), app.world_key(second))
        app.configure_sim(second)
        self.assertTrue(after_first.closed)
        self.assertEqual(app.sim.settings['friction_mu1'], .8)
        self.assertEqual(app.sim.settings['friction_mu2'], .2)

    def test_bad_pair_does_not_replace_saved_settings_or_start_work(self):
        app = self.app()
        app.launch_work = Mock(side_effect=AssertionError('work must not start'))
        before = self.settings_path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'friction_mu2'):
            app.command({'action': 'apply', 'settings': {
                'friction_mu1': .3, 'friction_mu2': -0.7}})
        self.assertEqual(self.settings_path.read_bytes(), before)
        app.launch_work.assert_not_called()

    def test_legacy_command_updates_both_coefficients_before_merging_current(self):
        app = self.app()
        app.preflight = Mock(return_value=11)
        app.command({'action': 'check', 'settings': {'friction': .9}})
        self.assertEqual((app.cfg['friction_mu1'], app.cfg['friction_mu2']), (.9, .9))
        self.assertNotIn('friction', self.saved())

    def test_repaired_code_check_clears_warning_and_uses_new_values(self):
        self.lighting.write_text(self.light_source.decode().replace('POINT_CONSTANT = 0.5', 'POINT_CONSTANT = 2.0'))
        app = self.app()
        self.assertTrue(app.status['settings_warning'])
        self.lighting.write_text(self.light_source.decode().replace('POINT_CONSTANT = 0.5', 'POINT_CONSTANT = 0.8'))
        app.preflight = Mock(return_value=11)
        app.command({'action': 'check'})
        self.assertEqual(app.cfg['lighting']['point']['constant'], .8)
        self.assertEqual(app.status['settings_warning'], '')
        self.assertEqual(self.saved(), app.cfg)

    def test_invalid_selected_custom_track_never_reaches_persistence_or_work(self):
        app = self.app()
        app.preflight = Mock(side_effect=AssertionError('preflight must not run'))
        app.launch_work = Mock(side_effect=AssertionError('work must not start'))
        before = self.settings_path.read_bytes()
        for action in ('apply', 'preview', 'check', 'train', 'resume', 'evaluate_best', 'save_track'):
            with self.subTest(action=action):
                with self.assertRaisesRegex(ValueError, '주행 구역이 열려'):
                    app.command({'action': action, 'settings': {'track': 'custom',
                                 'custom_tiles': self.invalid_track()}})
                self.assertEqual(self.settings_path.read_bytes(), before)
                self.assertEqual(app.cfg, self.initial)
        app.preflight.assert_not_called()
        app.launch_work.assert_not_called()
        self.generate.assert_not_called()

    def test_incomplete_custom_draft_does_not_block_a_preset(self):
        app = self.app()
        app.preflight = Mock(return_value=11)
        app.launch_work = Mock()
        app.command({'action': 'train', 'settings': {'track': 'track1',
                     'custom_tiles': self.invalid_track()}})
        self.assertEqual(self.saved()['track'], 'track1')
        app.launch_work.assert_called_once_with(app.train)
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()
        with self.assertRaisesRegex(ValueError, '주행 구역이 열려'):
            app.command({'action': 'apply', 'settings': {'track': 'custom'}})
        self.assertEqual(self.saved()['track'], 'track1')

    def test_legacy_bad_track_is_preserved_and_recovered_to_last_good(self):
        good = {**self.initial, 'track': 'track2'}
        atomic_json(self.runtime / 'settings.last_good.json', good)
        atomic_json(self.settings_path, {**self.initial, 'track': 'custom', 'custom_tiles': self.invalid_track()})
        bad = self.settings_path.read_bytes()
        app = self.app()
        self.assertEqual(app.cfg['track'], 'track2')
        self.assertTrue(self.preserve_contains(bad))
        self.assertIn('저장 설정 오류', app.status['settings_warning'])
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()

    def test_broken_json_recovers_to_defaults_without_losing_original_bytes(self):
        bad = b'{"track": "custom", BROKEN'
        self.settings_path.write_bytes(bad)
        app = self.app()
        self.assertEqual(app.cfg, self.initial)
        self.assertTrue(self.preserve_contains(bad))
        app.configure_sim(app.cfg)
        self.gui.assert_called_once()

    def test_scene_failure_rolls_back_persisted_settings_and_does_not_reapply_bad_file(self):
        app = self.app()
        gui_settings = []
        self.gui.side_effect = lambda settings: gui_settings.append(self.saved())
        app.configure_sim(app.cfg)
        good = copy.deepcopy(app.cfg)
        self.lighting.write_text(self.light_source.decode().replace('POINT_INTENSITY = 1.0', 'POINT_INTENSITY = 9.0'))
        candidate = read_settings(self.root, app.cfg)
        app.cfg = app.settings_store.save(candidate)

        def factory(root, runtime, info, settings):
            sim = FakeSimulator(root, runtime, info, settings)
            if settings['lighting']['point']['intensity'] == 9.:
                sim.start = Mock(side_effect=RuntimeError('simulated renderer failure'))
            return sim

        self.simulator.side_effect = factory
        with self.assertRaisesRegex(RuntimeError, '이전 화면을 복구'):
            app.configure_sim(candidate)
        self.assertEqual(app.cfg, good)
        self.assertEqual(self.saved(), good)
        self.assertEqual(json.loads((self.runtime / 'settings.last_good.json').read_text()), good)
        self.assertIsNotNone(app.sim)
        self.assertFalse(app.sim.closed)
        # QML's savedSettings is loaded when the replacement GUI is constructed.
        # The rollback window must never initialize its fields from the failed 9.0.
        self.assertEqual(len(gui_settings), 2)
        self.assertEqual(gui_settings[-1], good)
        self.assertTrue((self.runtime / 'settings.recovery.json').exists())
        restarted = self.app()
        self.assertEqual(restarted.cfg, good)
        restarted.configure_sim(restarted.cfg)
        self.assertEqual(restarted.cfg, good)
        self.assertIn('POINT_INTENSITY = 9.0', self.lighting.read_text())
        # Successful fallback preview does not silently approve the rejected file.
        self.assertTrue((self.runtime / 'settings.recovery.json').exists())
        self.lighting.write_bytes(self.light_source)
        restarted.preflight = Mock(return_value=11)
        restarted.command({'action': 'check'})
        self.assertFalse((self.runtime / 'settings.recovery.json').exists())
        self.assertEqual(restarted.status['settings_warning'], '')

    def test_interrupted_apply_uses_last_good_even_if_file_is_valid_python(self):
        app = self.app()
        app.configure_sim(app.cfg)
        good = copy.deepcopy(app.cfg)
        self.lighting.write_text(self.light_source.decode().replace('POINT_INTENSITY = 1.0', 'POINT_INTENSITY = 9.0'))
        candidate = read_settings(self.root, good)
        app.settings_store.save(candidate)
        app.settings_store.begin_apply(candidate)  # Process interruption before accept().
        restarted = self.app()
        self.assertEqual(restarted.cfg, good)
        self.assertIn('지난 환경 적용', restarted.status['settings_warning'])
        restarted.configure_sim(restarted.cfg)
        self.assertFalse((self.runtime / 'settings.pending.json').exists())
        self.assertTrue((self.runtime / 'settings.recovery.json').exists())

    def test_apply_and_rollback_failure_still_keep_next_launch_recoverable(self):
        app = self.app()
        app.configure_sim(app.cfg)
        good = copy.deepcopy(app.cfg)
        candidate = read_settings(self.root, {**good, 'light_level': 1.5})
        app.cfg = app.settings_store.save(candidate)

        def factory(root, runtime, info, settings):
            sim = FakeSimulator(root, runtime, info, settings)
            sim.start = Mock(side_effect=RuntimeError('simulated renderer unavailable'))
            return sim

        self.simulator.side_effect = factory
        with self.assertRaisesRegex(RuntimeError, '이전 환경 복구 실패'):
            app.configure_sim(candidate)
        self.assertEqual(self.saved(), good)
        self.simulator.side_effect = FakeSimulator
        restarted = self.app()
        restarted.configure_sim(restarted.cfg)
        self.assertEqual(restarted.cfg, good)


if __name__ == '__main__':
    unittest.main()
