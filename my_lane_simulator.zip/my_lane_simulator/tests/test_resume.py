"""Resume contract tests. No ROS, Gazebo, Torch or model unpickling is needed."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import zipfile

from lane_lab.checkpoints import (atomic_save_model, checkpoint_info, require_compatible,
                                  resume_candidate, resume_settings, resume_status)
from lane_lab.configuration import atomic_json, read_settings

PACKAGE = Path(__file__).resolve().parents[1]

# Keep compatibility mutations independent of the student's editable lesson.
# This fixture intentionally includes removable guidance and an unused offset;
# the tests below verify exactly when those changes do or do not matter.
LESSON_FIXTURE = '''"""Resume contract fixture."""
import numpy as np
from lane_lab.vision import normalized_distances

gamma = 0.995

"""
① 입력: 신경망에 입력되는 값입니다.
"""

def observe(features, previous_steer):
    distances = normalized_distances(features)
    distances = np.where(features.valid_mask > 0, distances, 1.1)
    return np.concatenate([distances, [previous_steer]]).astype(np.float32)

\'\'\'
# ============================================================
# calculate_reward(state)에서 보상 설계에 사용 가능한 정보
# state.new_progress_m: 이번 스텝의 새 경로 진행량
\'\'\'

def calculate_reward(state):
    """Reward fixture for compatibility checks."""
    path_offset_m = 0.05
    safe_gap_m = 0.06
    touch_gap_m = 0.01
    progress_unit_m = 0.04
    progress = np.clip(state.new_progress_m / progress_unit_m, 0.0, 1.0)
    near_line = np.clip((safe_gap_m - state.wheel_clearance_m) / safe_gap_m, 0.0, 1.0)
    touched_line = state.wheel_clearance_m <= touch_gap_m
    finished = state.lap_completed and not touched_line
    score = 10.0 * progress - 10.0 * near_line - 30.0 * touched_line + 20.0 * finished
    end_episode = touched_line or finished
    return float(score), bool(end_episode)

def act(action, settings):
    steer = float(np.clip(np.asarray(action).reshape(-1)[0], -1.0, 1.0))
    steering_rad = steer * float(settings["steer_max_rad"])
    speed_m_s = float(settings.get("speed_m_s", 0.10))
    return {"normalized_steer": steer, "steering_rad": steering_rad, "speed_m_s": speed_m_s}
'''


class ResumeContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for relative in ('config/defaults.json', 'config/vehicle.json',
                         'design/lighting.py',
                         'lane_lab/vision.py', 'lane_lab/policy_io.py'):
            destination = self.root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(PACKAGE / relative, destination)
        shutil.copy2(PACKAGE / 'tests/fixtures/lighting.py', self.root / 'design/lighting.py')
        (self.root / 'design/agent.py').write_text(LESSON_FIXTURE, encoding='utf-8')
        shutil.copytree(PACKAGE / 'track_img', self.root / 'track_img')
        self.current = read_settings(self.root)
        self.run = self.root / 'runs' / '20260101_000000'
        self.run.mkdir(parents=True)
        shutil.copy2(self.root / 'design/agent.py', self.run / 'lesson.py')
        shutil.copy2(self.root / 'config/vehicle.json', self.run / 'vehicle_base.json')
        (self.run / 'shared_code').mkdir()
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(self.root / 'lane_lab' / name, self.run / 'shared_code' / name)
        atomic_json(self.run / 'settings.json', self.current)
        self.candidate = {'run': self.run, 'timesteps': 512, 'ppo_updates': 10}

    def replace_once(self, source, before, after):
        self.assertEqual(source.count(before), 1,
                         f'테스트 수정 대상이 정확히 한 번 있어야 합니다: {before!r}')
        changed = source.replace(before, after, 1)
        self.assertNotEqual(source, changed, '테스트 변형이 실제 코드를 변경해야 합니다.')
        return changed

    def make_checkpoint(self, path, steps=512, updates=10):
        with zipfile.ZipFile(path, 'w') as archive:
            archive.writestr('data', json.dumps({'num_timesteps': steps, '_n_updates': updates, 'n_steps': 512, 'gamma': .995}))
            archive.writestr('policy.pth', b'fixture only')
            archive.writestr('policy.optimizer.pth', b'fixture only')

    def test_environment_changes_resume_with_current_scene(self):
        changed = copy.deepcopy(self.current)
        changed.update(track='track2', light_level=1.7, track_specular=.8,
                       extra_light_type='spot', speed_mode='manual', speed_factor=2,
                       mass_kg=2., friction_mu1=3.25, friction_mu2=1.5, train_steps=200000)
        changed['extra_lights'][0].update(enabled=True, x=-8., y=19., z=3.)
        # File values are intentionally reloaded by read_settings, so change the
        # actual student's configuration rather than injecting a stale snapshot.
        p=self.root/'design/lighting.py'
        p.write_text(self.replace_once(p.read_text(), 'POINT_INTENSITY = 1.0', 'POINT_INTENSITY = 4.0'))
        changed=read_settings(self.root,changed)
        require_compatible(self.root,self.run,changed)
        merged=resume_settings(self.root,self.candidate,changed)
        for key in ('track','light_level','track_specular','extra_light_type','extra_lights',
                    'lighting','friction_mu1','friction_mu2','speed_mode','speed_factor','mass_kg','train_steps'):
            self.assertEqual(merged[key],changed[key],key)
        self.assertEqual(merged['vision'],self.current['vision'])
        self.assertEqual(merged['seed'],self.current['seed'])

    def test_legacy_saved_friction_cannot_override_current_pair(self):
        saved = copy.deepcopy(self.current)
        saved.pop('friction_mu1')
        saved.pop('friction_mu2')
        saved['friction'] = 2.5
        atomic_json(self.run / 'settings.json', saved)
        current = read_settings(self.root, {**self.current,
                               'friction_mu1': .7, 'friction_mu2': .3})
        resumed = resume_settings(self.root, self.candidate, current)
        self.assertEqual((resumed['friction_mu1'], resumed['friction_mu2']), (.7, .3))
        self.assertNotIn('friction', resumed)
        self.assertEqual(json.loads((self.run / 'settings.json').read_text()), saved)

    def test_grid_roi_camera_changes_block_before_saved_settings_restore(self):
        for key in ('grid_rows','grid_cols','roi_min','roi_max','camera_pitch_deg','camera_hfov_deg'):
            with self.subTest(key=key):
                changed=copy.deepcopy(self.current);changed[key]+=1
                with self.assertRaisesRegex(ValueError,'새 학습'):
                    resume_settings(self.root,self.candidate,changed)
        changed=copy.deepcopy(self.current);changed['vision']['canny_low']+=1
        with self.assertRaisesRegex(ValueError,'vision'):
            require_compatible(self.root,self.run,changed)

    def test_action_scale_change_blocks(self):
        changed=copy.deepcopy(self.current);changed['steer_max_rad']*=.9
        with self.assertRaisesRegex(ValueError,'조향 범위'):
            require_compatible(self.root,self.run,changed)

    def test_changed_reward_is_not_silently_replaced_with_saved_code(self):
        p=self.root/'design/agent.py'
        original=p.read_text()
        changed=self.replace_once(original, 'return float(score), bool(end_episode)',
                                 'return float(score) + 1.0, bool(end_episode)')
        self.assertNotEqual(original,changed,'보상 수정 테스트가 실제 코드를 변경해야 합니다.')
        p.write_text(changed)
        with self.assertRaisesRegex(ValueError,'입력·보상·액션'):
            resume_settings(self.root,self.candidate,self.current)

    def test_comment_and_blank_line_edits_are_allowed(self):
        p=self.root/'design/agent.py';p.write_text('# Student note\n\n'+p.read_text()+'\n')
        require_compatible(self.root,self.run,self.current)

    def test_reward_state_guide_and_unused_offset_preserve_old_lesson_compatibility(self):
        p=self.root/'design/agent.py';current=p.read_text()
        start=current.index('\n# ============================================================\n# calculate_reward(state)')
        end=current.index("\n'''",start)
        old=current[:start]+current[end:]
        self.assertNotEqual(current, old, '보상 안내문을 실제로 제거해야 합니다.')
        old=self.replace_once(old, '    path_offset_m = 0.05\n', '')
        (self.run/'lesson.py').write_text(old)
        require_compatible(self.root,self.run,self.current)
        p.write_text(self.replace_once(current, 'path_offset_m = 0.05','path_offset_m = 0.08'))
        require_compatible(self.root,self.run,self.current)

    def test_module_guide_text_edits_are_allowed(self):
        p=self.root/'design/agent.py'
        p.write_text(self.replace_once(p.read_text(), '① 입력: 신경망에 입력되는 값입니다.','① 입력: 설명만 수정합니다.'))
        require_compatible(self.root,self.run,self.current)

    def test_offset_value_is_significant_once_reward_uses_it(self):
        p=self.root/'design/agent.py'
        source=self.replace_once(p.read_text(), 'return float(score), bool(end_episode)',
                                    'return float(score) + path_offset_m, bool(end_episode)')
        (self.run/'lesson.py').write_text(source)
        p.write_text(self.replace_once(source, 'path_offset_m = 0.05','path_offset_m = 0.08'))
        with self.assertRaisesRegex(ValueError,'입력·보상·액션'):
            require_compatible(self.root,self.run,self.current)

    def test_reflection_preserves_unused_offset_and_documentation(self):
        p=self.root/'design/agent.py';original=p.read_text()
        for lookup in ('locals()', 'vars()', 'globals()', '__doc__', 'calculate_reward.__doc__'):
            with self.subTest(lookup=lookup):
                source=self.replace_once(original, '    progress = np.clip',
                                        '    observed = '+lookup+'\n    progress = np.clip')
                (self.run/'lesson.py').write_text(source)
                for changed in (self.replace_once(source, 'path_offset_m = 0.05','path_offset_m = 0.08'),
                                self.replace_once(source, '① 입력: 신경망에 입력되는 값입니다.','① 입력: 설명 변경')):
                    p.write_text(changed)
                    with self.assertRaisesRegex(ValueError,'입력·보상·액션'):
                        require_compatible(self.root,self.run,self.current)

    def test_normalization_keeps_reward_threshold_action_and_other_assignments(self):
        p=self.root/'design/agent.py';original=p.read_text()
        edits=(('safe_gap_m = 0.06','safe_gap_m = 0.05'),
               ('return float(score), bool(end_episode)','return float(score) + 1.0, bool(end_episode)'),
               ('steering_rad = steer *','steering_rad = 0.5 * steer *'),
               ('path_offset_m = 0.05','path_offset_m = float(0.05)'),
               ('    progress = np.clip','    unrelated_unused = 1\n    progress = np.clip'))
        for before,after in edits:
            with self.subTest(change=after):
                changed=self.replace_once(original, before, after)
                self.assertNotEqual(original,changed)
                p.write_text(changed)
                with self.assertRaisesRegex(ValueError,'입력·보상·액션'):
                    require_compatible(self.root,self.run,self.current)

    def test_shared_extraction_change_blocks(self):
        p=self.root/'lane_lab/vision.py';p.write_text(p.read_text()+'\n# changed shared file\n')
        with self.assertRaisesRegex(ValueError,'vision.py'):
            require_compatible(self.root,self.run,self.current)

    def test_camera_mount_override_cannot_evade_gate(self):
        changed=copy.deepcopy(self.current);changed['vehicle']={'camera_x_m':.2}
        with self.assertRaisesRegex(ValueError,'camera_x_m'):
            require_compatible(self.root,self.run,changed)
        changed=copy.deepcopy(self.current);changed['vehicle']={'camera_width':800}
        with self.assertRaisesRegex(ValueError,'camera_width'):
            require_compatible(self.root,self.run,changed)

    def test_saved_vehicle_override_is_checked_before_removal(self):
        saved=copy.deepcopy(self.current);saved['vehicle']={'camera_height_m':.3}
        atomic_json(self.run/'settings.json',saved)
        with self.assertRaisesRegex(ValueError,'camera_height_m'):
            resume_settings(self.root,self.candidate,self.current)
        unchanged=copy.deepcopy(self.current);unchanged['vehicle']={'camera_height_m':.3}
        self.assertEqual(resume_settings(self.root,self.candidate,unchanged)['vehicle'],unchanged['vehicle'])

    def test_gui_and_execution_report_same_block(self):
        self.make_checkpoint(self.run/'checkpoint.zip')
        atomic_json(self.root/'runtime/settings.json',self.current)
        self.assertTrue(resume_status(self.root)['resume_available'])
        changed=copy.deepcopy(self.current);changed['camera_pitch_deg']+=1
        atomic_json(self.root/'runtime/settings.json',changed)
        status=resume_status(self.root)
        self.assertFalse(status['resume_available'])
        with self.assertRaises(ValueError) as caught:
            require_compatible(self.root,self.run,changed)
        self.assertEqual(status['resume_reason'],str(caught.exception))

    def test_interrupted_run_exposes_automatic_checkpoint_without_actor_or_training_record(self):
        self.make_checkpoint(self.run/'checkpoint.zip')
        status=resume_status(self.root)
        self.assertTrue(status['resume_available'])
        self.assertTrue(status['resume_checkpoint_only'])
        self.assertEqual(status['resume_checkpoint'],'runs/20260101_000000/checkpoint.zip')
        self.assertEqual(status['resume_steps'],512)
        self.assertFalse((self.run/'actor.npz').exists())
        self.assertFalse((self.run/'training.json').exists())
        # A normally finalized run keeps the explicit actor selection workflow.
        atomic_json(self.run/'training.json',{'timesteps':512,'ppo_updates':10})
        self.assertFalse(resume_status(self.root)['resume_checkpoint_only'])

    def test_incompatible_recovery_keeps_candidate_and_explains_disabled_button(self):
        self.make_checkpoint(self.run/'checkpoint.zip')
        changed=copy.deepcopy(self.current);changed['camera_pitch_deg']+=1
        atomic_json(self.root/'runtime/settings.json',changed)
        status=resume_status(self.root)
        self.assertFalse(status['resume_available'])
        self.assertTrue(status['resume_checkpoint_only'])
        self.assertEqual(status['resume_steps'],512)
        self.assertEqual(status['resume_run'],str(self.run))
        self.assertIn('camera_pitch_deg',status['resume_reason'])

    def test_recovery_status_checks_target_and_uses_previous_complete_checkpoint(self):
        steps=int(self.current['train_steps'])
        self.make_checkpoint(self.run/'checkpoint.previous.zip',steps=steps)
        (self.run/'checkpoint.zip').write_bytes(b'interrupted write')
        status=resume_status(self.root)
        self.assertTrue(status['resume_checkpoint_only'])
        self.assertTrue(status['resume_checkpoint'].endswith('/checkpoint.previous.zip'))
        self.assertFalse(status['resume_available'])
        self.assertIn('큰 목표 스텝',status['resume_reason'])
        atomic_json(self.root/'runtime/settings.json',{**self.current,'train_steps':steps+512})
        status=resume_status(self.root)
        self.assertTrue(status['resume_available'])
        self.assertEqual(status['resume_target_steps'],steps+512)

    def test_target_is_cumulative_and_completed_target_cannot_resume(self):
        self.candidate['timesteps']=int(self.current['train_steps'])
        with self.assertRaisesRegex(ValueError,'큰 목표 스텝'):
            resume_settings(self.root,self.candidate,self.current)
        changed=copy.deepcopy(self.current);changed['train_steps']+=512
        self.assertEqual(resume_settings(self.root,self.candidate,changed)['train_steps'],changed['train_steps'])

    def test_corrupt_latest_checkpoint_falls_back_to_previous_complete_update(self):
        self.make_checkpoint(self.run/'checkpoint.previous.zip',steps=512,updates=10)
        (self.run/'checkpoint.zip').write_bytes(b'incomplete write')
        chosen=resume_candidate(self.root)
        self.assertEqual(chosen['path'].name,'checkpoint.previous.zip')
        self.assertEqual(chosen['timesteps'],512)

    def test_legacy_saved_lesson_resumes_when_the_student_restores_that_lesson(self):
        example=PACKAGE/'runs/example_model'
        for name in ('lesson.py','settings.json','vehicle_base.json'):
            shutil.copy2(example/name,self.run/name)
        shutil.copy2(example/'lesson.py',self.root/'design/agent.py')
        for name in ('vision.py','policy_io.py'):
            shutil.copy2(example/'shared_code'/name,self.run/'shared_code'/name)
        old=json.loads((self.run/'settings.json').read_text())
        self.assertNotIn('motor_randomization',old)
        current=read_settings(self.root,old)
        require_compatible(self.root,self.run,current)
        resumed=resume_settings(self.root,self.candidate,current)
        self.assertEqual(resumed['vision'],old['vision'])
        self.assertEqual(resumed['steer_max_rad'],old['steer_max_rad'])
        self.assertNotIn('motor_randomization',resumed)
        self.assertNotIn('track_friction',resumed)
        self.assertEqual(resumed['render_engine'],'ogre')

    def test_legacy_motor_settings_do_not_return_when_resuming(self):
        saved=copy.deepcopy(self.current)
        saved.update(rear_random_enabled=True,servo_random_enabled=True,
                     motor_randomization={'REAR_ERROR_PERCENT':100.,'SERVO_ERROR_RAD':1.},
                     track_friction=1.9)
        atomic_json(self.run/'settings.json',saved)
        current=read_settings(self.root,{**self.current,'friction_mu1':0.0,'friction_mu2':0.0})
        resumed=resume_settings(self.root,self.candidate,current)
        self.assertEqual(resumed['friction_mu1'],0.0)
        self.assertEqual(resumed['friction_mu2'],0.0)
        for key in ('rear_random_enabled','servo_random_enabled','motor_randomization','track_friction'):
            self.assertNotIn(key,resumed)
        # The source experiment is immutable even when obsolete values are ignored.
        self.assertEqual(json.loads((self.run/'settings.json').read_text()),saved)

    def test_atomic_model_publication_discards_legacy_motor_state(self):
        case=self
        class Model:
            def __init__(self):
                self.num_timesteps=51
                self._n_updates=10
                self.n_steps=512
                self.lane_random_state={'rear_gains':[.9,1.1],'servo_bias_rad':.1}
            def get_env(self):
                case.fail('Checkpoint saving must not request a removed motor RNG interface')
            def save(self,path):
                with zipfile.ZipFile(path,'w') as archive:
                    archive.writestr('data',json.dumps(vars(self)))
                    archive.writestr('policy.pth',b'fixture only')
                    archive.writestr('policy.optimizer.pth',b'fixture only')
        target=self.run/'checkpoint.zip'
        model=Model()
        atomic_save_model(model,target)
        with zipfile.ZipFile(target) as archive:saved=json.loads(archive.read('data'))
        self.assertNotIn('lane_random_state',saved)
        self.assertEqual(checkpoint_info(target)['timesteps'],51)
        # Saving it again must also work after the legacy attribute is gone.
        atomic_save_model(model,target,keep_previous=True)
        self.assertEqual(checkpoint_info(self.run/'checkpoint.previous.zip')['timesteps'],51)

    def test_failed_atomic_model_publication_preserves_complete_checkpoint(self):
        target=self.run/'checkpoint.zip'
        self.make_checkpoint(target)
        original=target.read_bytes()
        class Model:
            def save(self,path):
                Path(path).write_bytes(b'partial ZIP')
                raise OSError('interrupted save')
        with self.assertRaisesRegex(OSError,'interrupted save'):
            atomic_save_model(Model(),target,keep_previous=True)
        self.assertEqual(target.read_bytes(),original)
        self.assertFalse((self.run/'checkpoint.previous.zip').exists())
        self.assertEqual(list(self.run.glob('.checkpoint.*.zip')),[])


if __name__=='__main__':unittest.main()
