"""Analytic cases for global rear-axle closest-point evaluation geometry."""
import math
import unittest

import numpy as np

from lane_lab.evaluation_geometry import RearAxleProjection


def midpoint_pose(rear_xy, yaw=0.0, wheelbase=.194):
    return (rear_xy[0] + wheelbase / 2 * math.cos(yaw),
            rear_xy[1] + wheelbase / 2 * math.sin(yaw), yaw)


class RearAxleProjectionTests(unittest.TestCase):
    def setUp(self):
        self.rectangle = RearAxleProjection(
            [(0, 0), (10, 0), (10, 10), (0, 10)], .194)

    def test_rotated_vehicle_uses_global_shortest_not_vehicle_lateral_axis(self):
        result = self.rectangle.measure(midpoint_pose((4, .3), math.pi / 4))
        self.assertAlmostEqual(result['rear_x_m'], 4)
        self.assertAlmostEqual(result['rear_y_m'], .3)
        self.assertAlmostEqual(result['path_x_m'], 4)
        self.assertAlmostEqual(result['path_y_m'], 0)
        self.assertAlmostEqual(result['lateral_error_m'], .3)
        self.assertAlmostEqual(result['heading_error_rad'], math.pi / 4)
        self.assertTrue(result['projection_normal_valid'])
        # The lateral vehicle-axis intersection would be (4.3, 0), and
        # closest-vertex selection would be (0,0); neither is correct here.

    def test_right_side_is_negative_and_forward_pose_moves_rear_back(self):
        result = self.rectangle.measure((4.097, -.3, 0))
        self.assertAlmostEqual(result['rear_x_m'], 4)
        self.assertAlmostEqual(result['lateral_error_m'], -.3)
        self.assertAlmostEqual(result['projection_distance_m'], .3)

    def test_heading_wrap_at_pi_boundary(self):
        # Top edge runs west (pi); yaw -179 degrees differs by +1 degree.
        result = self.rectangle.measure(midpoint_pose((4, 9.7), math.radians(-179)))
        self.assertAlmostEqual(result['path_heading_rad'], math.pi)
        self.assertAlmostEqual(result['heading_error_rad'], math.radians(1))

    def test_closed_last_to_first_segment_is_searched(self):
        result = self.rectangle.measure(midpoint_pose((.2, 4)))
        self.assertEqual(result['path_segment'], 3)
        self.assertAlmostEqual(result['path_x_m'], 0)
        self.assertAlmostEqual(result['path_y_m'], 4)
        self.assertAlmostEqual(result['lateral_error_m'], .2)

    def test_circle_polyline_distance_and_heading_approach_analytic_values(self):
        angles = np.linspace(0, 2 * math.pi, 720, endpoint=False)
        route = 2 * np.column_stack((np.cos(angles), np.sin(angles)))
        # Midpoint of a chord has a unique closest segment (avoids a corner).
        phi = (angles[80] + angles[81]) / 2
        rear = 2.2 * np.array([math.cos(phi), math.sin(phi)])
        result = RearAxleProjection(route, .194).measure(
            midpoint_pose(rear, phi + math.pi / 2))
        expected_distance = 2.2 - 2 * math.cos(math.pi / 720)
        self.assertAlmostEqual(result['lateral_error_m'], -expected_distance, places=10)
        self.assertAlmostEqual(result['heading_error_rad'], 0, places=10)
        self.assertTrue(result['projection_normal_valid'])

    def test_nearby_branches_choose_global_minimum(self):
        route = [(0, 0), (10, 0), (10, 1), (0, 1)]
        result = RearAxleProjection(route, .194).measure(midpoint_pose((4, .8)))
        self.assertEqual(result['path_segment'], 2)
        self.assertAlmostEqual(result['path_y_m'], 1)
        self.assertAlmostEqual(result['projection_distance_m'], .2)
        self.assertFalse(result['projection_ambiguous'])

    def test_equally_near_branches_are_flagged(self):
        route = [(0, 0), (10, 0), (10, 1), (0, 1)]
        result = RearAxleProjection(route, .194).measure(midpoint_pose((4, .5)))
        self.assertTrue(result['projection_ambiguous'])
        self.assertFalse(result['projection_normal_valid'])
        self.assertAlmostEqual(result['projection_distance_m'], .5)

    def test_corner_preserves_true_distance_instead_of_normal_dot_product(self):
        result = self.rectangle.measure(midpoint_pose((-1, -1)))
        self.assertEqual((result['path_x_m'], result['path_y_m']), (0, 0))
        self.assertAlmostEqual(result['lateral_error_m'], -math.sqrt(2))
        self.assertAlmostEqual(result['projection_tangential_residual_m'], -1)
        self.assertTrue(result['projection_vertex'])
        self.assertTrue(result['projection_ambiguous'])
        self.assertFalse(result['projection_normal_valid'])

    def test_collinear_vertex_is_not_heading_ambiguous(self):
        route = [(0, 0), (4, 0), (10, 0), (10, 10), (0, 10)]
        result = RearAxleProjection(route, .194).measure(midpoint_pose((4, .3)))
        self.assertTrue(result['projection_vertex'])
        self.assertFalse(result['projection_ambiguous'])
        self.assertTrue(result['projection_normal_valid'])

    def test_duplicate_points_and_explicit_closed_endpoint_are_ignored(self):
        route = [(0, 0), (0, 0), (10, 0), (10, 10), (0, 10), (0, 0)]
        result = RearAxleProjection(route, .194).measure(midpoint_pose((4, .3)))
        self.assertEqual(result['path_segment'], 1)
        self.assertAlmostEqual(result['lateral_error_m'], .3)
        self.assertTrue(result['projection_normal_valid'])

    def test_invalid_inputs_are_rejected(self):
        for route in ([(0, 0)] * 3, [(0, 0), (1, 0)],
                      [(0, 0), (1, float('nan')), (1, 1)]):
            with self.subTest(route=route), self.assertRaises(ValueError):
                RearAxleProjection(route, .194)
        with self.assertRaises(ValueError):
            RearAxleProjection([(0, 0), (1, 0), (1, 1)], 0)
        with self.assertRaises(ValueError):
            self.rectangle.measure((0, 0, float('nan')))


if __name__ == '__main__':
    unittest.main()
