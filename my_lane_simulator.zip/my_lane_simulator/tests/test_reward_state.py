"""Reward truth geometry and history with no Gazebo dependency."""
import math
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from lane_lab.evaluation_geometry import RearAxleProjection
from lane_lab.geometry import TrackGeometry
from lane_lab.reward_state import RewardStateBuilder, make_sample_state


REFERENCES = ("front", "center", "rear")
WHEELS = ("front_left", "front_right", "rear_left", "rear_right")
VEHICLE = {"wheelbase_m": 0.194, "wheel_track_m": 0.1737,
           "kingpin_width_m": 0.11, "wheel_width_m": 0.0277,
           "wheel_contact_length_m": 0.012}


def make_track(route=None):
    if route is None:
        route = [(0, 0), (10, 0), (10, 10), (0, 10)]
    return TrackGeometry(np.ones((1, 1), dtype=np.float32), route,
                         {"spawn": (5, 0.3, 0), "vehicle": VEHICLE})


class RewardStateTests(unittest.TestCase):
    def setUp(self):
        self.settings = {"steer_max_rad": 0.6, "speed_m_s": 0.2}
        self.track = make_track()
        self.builder = RewardStateBuilder(self.track, self.settings)
        self.previous_pose = (5.0, 0.3, 0.0)
        self.builder.reset(self.previous_pose, 12.0)
        self.features = SimpleNamespace(V=np.array([2, 3]))

    def build(self, pose=(5.02, 0.3, 0), *, previous_pose=None,
              gap=0.02, sim_time=12.1, **overrides):
        truth = {f"{wheel}_clearance_m": gap + i * 0.01 for i, wheel in enumerate(WHEELS)}
        truth["wheel_clearance_m"] = gap
        args = dict(
            pose=pose, front_angles=(0.2, 0.18),
            previous_pose=self.previous_pose if previous_pose is None else previous_pose,
            previous_front_angles=(0.1, 0.09), truth=truth,
            progress=SimpleNamespace(new_progress_m=0.01, progress_m=1.5, lap_completed=False),
            features=self.features,
            command={"normalized_steer": 0.3, "speed_m_s": 0.2}, previous_steer=0.1,
            sim_time=sim_time, dt=0.1, episode_index=4, episode_step=7, total_steps=89,
        )
        args.update(overrides)
        return self.builder.build(**args)

    def test_straight_motion_has_distinct_world_reference_points_and_previous_values(self):
        state = self.build()
        for reference, shift in (("front", 0.097), ("center", 0.0), ("rear", -0.097)):
            np.testing.assert_allclose(getattr(state, f"{reference}_xy"), (5.02 + shift, 0.3))
            np.testing.assert_allclose(getattr(state, f"previous_{reference}_xy"), (5.0 + shift, 0.3))
            np.testing.assert_allclose(getattr(state, f"{reference}_path_xy"), (5.02 + shift, 0.0))
            np.testing.assert_allclose(getattr(state, f"previous_{reference}_path_xy"), (5.0 + shift, 0.0))
            self.assertAlmostEqual(getattr(state, f"{reference}_lateral_error_m"), 0.3)
            self.assertAlmostEqual(getattr(state, f"previous_{reference}_lateral_error_m"), 0.3)
            self.assertAlmostEqual(getattr(state, f"{reference}_heading_error_rad"), 0.0)
            self.assertAlmostEqual(getattr(state, f"previous_{reference}_heading_error_rad"), 0.0)
            self.assertAlmostEqual(getattr(state, f"{reference}_distance_step_m"), 0.02)
            self.assertAlmostEqual(getattr(state, f"{reference}_distance_total_m"), 0.02)
        self.assertAlmostEqual(state.actual_longitudinal_speed_m_s, 0.2)
        self.assertAlmostEqual(state.actual_lateral_speed_m_s, 0.0)
        self.assertAlmostEqual(state.actual_yaw_rate_rad_s, 0.0)

    def test_legacy_fields_dimensions_and_counters_are_available(self):
        state = self.build()
        expected = dict(wheel_clearance_m=0.02, new_progress_m=0.01,
                        progress_m=1.5, lap_completed=False, steer=0.3,
                        previous_steer=0.1, speed_m_s=0.2, sim_time=12.1, dt=0.1,
                        episode_index=4, episode_step=7, total_steps=89,
                        track_length_m=40.0, wheelbase_m=0.194,
                        wheel_track_m=0.1737, wheel_width_m=0.0277,
                        wheel_contact_length_m=0.012, max_center_steering_rad=0.6)
        for name, value in expected.items():
            self.assertEqual(getattr(state, name), value, name)
        self.assertAlmostEqual(state.episode_elapsed_s, 0.1)
        self.assertIs(state.features, self.features)
        centers = self.track.wheel_centers(5.02, 0.3, 0, front_angles=(0.2, 0.18))
        for index, wheel in enumerate(WHEELS):
            self.assertEqual(getattr(state, f"{wheel}_wheel_xy"), centers[f"{wheel}_wheel_xy"])
            self.assertAlmostEqual(getattr(state, f"{wheel}_clearance_m"), 0.02 + 0.01 * index)

    def test_velocity_uses_body_frame_and_reverse_is_signed(self):
        yaw = 0.73
        previous = (5.0, 0.3, yaw)
        self.builder.reset(previous, 12.0)
        forward, left = -0.02, 0.007
        pose = (previous[0] + forward * math.cos(yaw) - left * math.sin(yaw),
                previous[1] + forward * math.sin(yaw) + left * math.cos(yaw), yaw)
        state = self.build(pose, previous_pose=previous)
        self.assertAlmostEqual(state.actual_longitudinal_speed_m_s, -0.2)
        self.assertAlmostEqual(state.actual_lateral_speed_m_s, 0.07)
        self.assertAlmostEqual(state.rear_distance_step_m, math.hypot(forward, left))
        self.assertEqual(state.speed_m_s, 0.2)

    def test_wrapped_rotation_tracks_rear_motion_and_mid_heading(self):
        previous = (5.0, 0.3, math.radians(179))
        self.builder.reset(previous, 12.0)
        state = self.build((5.0, 0.3, math.radians(-179)), previous_pose=previous)
        delta = math.radians(2)
        chord = self.track.wheelbase * math.sin(delta / 2)
        self.assertAlmostEqual(state.actual_yaw_rate_rad_s, delta / 0.1)
        self.assertAlmostEqual(state.actual_longitudinal_speed_m_s, 0.0)
        self.assertAlmostEqual(state.actual_lateral_speed_m_s, -chord / 0.1)
        self.assertAlmostEqual(state.center_distance_step_m, 0.0)
        self.assertAlmostEqual(state.front_distance_step_m, chord)
        self.assertAlmostEqual(state.rear_distance_step_m, chord)

    def test_curved_route_projects_each_reference_independently(self):
        angles = np.linspace(0.0, 2 * math.pi, 720, endpoint=False)
        self.track = make_track(2 * np.column_stack((np.cos(angles), np.sin(angles))))
        self.builder = RewardStateBuilder(self.track, self.settings)
        pose = (2.1, 0.0, math.pi / 2)
        self.builder.reset(pose, 12.0)
        state = self.build(pose, previous_pose=pose)
        self.assertGreater(state.front_path_xy[1], state.center_path_xy[1])
        self.assertLess(state.rear_path_xy[1], state.center_path_xy[1])
        self.assertNotAlmostEqual(state.front_heading_error_rad, state.rear_heading_error_rad)
        rear = RearAxleProjection(self.track.route, self.track.wheelbase).measure(pose)
        self.assertEqual(state.rear_path_xy, (rear["path_x_m"], rear["path_y_m"]))
        self.assertEqual(state.rear_lateral_error_m, rear["lateral_error_m"])
        self.assertEqual(state.rear_heading_error_rad, rear["heading_error_rad"])

    def test_polyline_corner_keeps_shortest_distance_and_selected_tangent(self):
        pose = (-0.903, -1.0, 0.0)
        self.builder.reset(pose, 12.0)
        state = self.build(pose, previous_pose=pose)
        self.assertEqual(state.rear_path_xy, (0.0, 0.0))
        self.assertAlmostEqual(state.rear_lateral_error_m, -math.sqrt(2))
        self.assertEqual(state.rear_heading_error_rad, 0.0)

    def test_distance_totals_accumulate_reverse_and_reset_without_resetting_global_count(self):
        self.build()
        state = self.build((5.01, 0.3, 0), previous_pose=(5.02, 0.3, 0), sim_time=12.2)
        for reference in REFERENCES:
            self.assertAlmostEqual(getattr(state, f"{reference}_distance_step_m"), 0.01)
            self.assertAlmostEqual(getattr(state, f"{reference}_distance_total_m"), 0.03)
        self.builder.reset((5.01, 0.3, 0), 50.0)
        reset = self.build((5.01, 0.3, 0), previous_pose=(5.01, 0.3, 0), sim_time=50.1,
                           episode_index=5, episode_step=1, total_steps=90)
        self.assertEqual(reset.rear_distance_total_m, 0.0)
        self.assertAlmostEqual(reset.episode_elapsed_s, 0.1)
        self.assertEqual(reset.total_steps, 90)

    def test_swept_physical_contact_latches_until_reset(self):
        self.assertFalse(self.build().ever_touched_line)
        contact = self.build(gap=0.0)
        self.assertTrue(contact.physical_touched_line)
        self.assertTrue(contact.ever_touched_line)
        clear = self.build(gap=0.1)
        self.assertFalse(clear.physical_touched_line)
        self.assertTrue(clear.ever_touched_line)
        self.builder.reset(self.previous_pose, 20.0)
        self.assertFalse(self.build(sim_time=20.1).ever_touched_line)
        self.assertTrue(self.build(gap=-0.001).physical_touched_line)

    def test_path_offsets_interpolate_segments_wrap_and_stay_bound_to_snapshot(self):
        pose = (1.0, 0.2, 0.0)
        self.builder.reset(pose, 12.0)
        state = self.build(pose, previous_pose=pose)
        for reference in REFERENCES:
            self.assertEqual(state.path_point(reference, 0), getattr(state, f"{reference}_path_xy"))
        np.testing.assert_allclose(state.path_point("center", 2.5), (3.5, 0.0))
        np.testing.assert_allclose(state.path_point("center", 10.0), (10.0, 1.0))
        np.testing.assert_allclose(state.path_point("center", -2.0), (0.0, 1.0))
        np.testing.assert_allclose(state.path_point("center", 40.0 * 3 + 10.0), (10.0, 1.0))
        np.testing.assert_allclose(state.path_point("center", -40.0 * 2 - 2.0), (0.0, 1.0))
        self.build((2.0, 0.2, 0), previous_pose=pose)
        np.testing.assert_allclose(state.path_point("center", 2.5), (3.5, 0.0))
        with self.assertRaises(ValueError):
            state.path_point("wheel", 0)
        with self.assertRaises(ValueError):
            state.path_point("rear", float("nan"))

    def test_path_offsets_ignore_duplicate_route_points(self):
        self.track = make_track([(0, 0), (0, 0), (10, 0), (10, 10), (0, 10), (0, 0)])
        self.builder = RewardStateBuilder(self.track, self.settings)
        pose = (1.0, 0.2, 0)
        self.builder.reset(pose, 12.0)
        state = self.build(pose, previous_pose=pose)
        np.testing.assert_allclose(state.path_point("center", -2.0), (0.0, 1.0))
        np.testing.assert_allclose(state.path_point("center", 19.0), (10.0, 10.0))

    def test_previous_projection_cache_cannot_be_changed_through_returned_state(self):
        with patch.object(self.builder.projection, "measure", wraps=self.builder.projection.measure) as measured:
            first = self.build()
            self.assertEqual(measured.call_count, 3)
            original = first.front_path_xy
            first.front_path_xy = (999, 999)
            first.front_xy = (999, 999)
            first.front_distance_total_m = 999
            second = self.build((5.04, 0.3, 0), previous_pose=(5.02, 0.3, 0))
            self.assertEqual(measured.call_count, 6)
        self.assertEqual(second.previous_front_path_xy, original)
        np.testing.assert_allclose(second.previous_front_xy, (5.117, 0.3))
        self.assertAlmostEqual(second.front_distance_total_m, 0.04)
        self.assertIsInstance(second.front_xy, tuple)

    def test_sample_factory_supplies_every_runtime_field_and_dimensions_override(self):
        runtime = self.build()
        settings = dict(self.settings, vehicle=dict(VEHICLE, wheelbase_m=0.25))
        sample = make_sample_state(settings, self.features, -0.01, 0.02, True)
        self.assertEqual(set(vars(sample)), set(vars(runtime)))
        self.assertTrue(sample.physical_touched_line)
        self.assertTrue(sample.ever_touched_line)
        self.assertTrue(sample.lap_completed)
        self.assertEqual(sample.new_progress_m, 0.02)
        self.assertEqual(sample.wheelbase_m, 0.25)
        self.assertEqual(sample.front_xy[0] - sample.rear_xy[0], 0.25)
        self.assertAlmostEqual(sample.actual_longitudinal_speed_m_s, 0.2)
        self.assertIs(sample.features, self.features)
        self.assertEqual(len(sample.path_point("rear", -0.1)), 2)

    def test_invalid_dt_and_build_without_reset_are_rejected(self):
        for dt in (0.0, -0.1, float("nan")):
            with self.subTest(dt=dt), self.assertRaises(ValueError):
                self.build(dt=dt)
        self.builder = RewardStateBuilder(self.track, self.settings)
        with self.assertRaises(RuntimeError):
            self.build()


if __name__ == "__main__":
    unittest.main()
