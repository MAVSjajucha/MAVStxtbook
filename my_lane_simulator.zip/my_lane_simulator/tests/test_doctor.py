"""A failed external diagnostic must never report installation success."""
import contextlib
import io
import json
from pathlib import Path
from subprocess import CompletedProcess
import tempfile
import unittest
from unittest.mock import patch

from lane_lab.doctor import diagnose


class DoctorTests(unittest.TestCase):
    def run_diagnosis(self, failed=None, missing=None):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            for binary in ('build/native/lane_lab_bridge', 'build/gui/libLaneLab.so',
                           'build/native/liblane_lab_a1_controller.so'):
                path=root/binary
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch()
            def command(args, **kwargs):
                if args[0]==missing:
                    raise FileNotFoundError(args[0])
                return CompletedProcess(args, 1 if args[0]==failed else 0,
                                        'diagnostic output', 'unavailable' if args[0]==failed else '')
            with patch('lane_lab.doctor.subprocess.run', side_effect=command), \
                 patch('lane_lab.doctor.read_settings', return_value={}), \
                 patch('lane_lab.doctor.check_lesson', return_value=(None,11)), \
                 contextlib.redirect_stdout(io.StringIO()):
                result=diagnose(root)
            return result,json.loads((root/'runtime/doctor.json').read_text())

    def test_success_has_zero_exit_status(self):
        result,report=self.run_diagnosis()
        self.assertEqual(result,0)
        self.assertEqual(report['errors'],[])

    def test_failed_external_commands_are_reported_as_failure(self):
        for executable,key in (('ign','gazebo'),('glxinfo','opengl'),('free','memory')):
            with self.subTest(executable=executable):
                result,report=self.run_diagnosis(failed=executable)
                self.assertEqual(result,1)
                self.assertIn(key,report['errors'][0])
                self.assertEqual(report['checks'][key]['returncode'],1)

    def test_missing_executable_is_reported_as_failure(self):
        result,report=self.run_diagnosis(missing='ign')
        self.assertEqual(result,1)
        self.assertIn('gazebo',report['errors'][0])
        self.assertIn('error',report['checks']['gazebo'])
