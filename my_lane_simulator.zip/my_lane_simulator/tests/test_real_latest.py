"""Real-policy latest-frame contract. Fake ROS only; no network or motor I/O."""
import importlib.util
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

from lane_lab.vision import GridConfig
from lane_lab import ros_nodes


PACKAGE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('audited_drive_real', PACKAGE / 'deploy/drive_real.py')
drive = importlib.util.module_from_spec(spec)
spec.loader.exec_module(drive)


class Twist:
    def __init__(self):
        self.linear = SimpleNamespace(x=0., y=0., z=0.)
        self.angular = SimpleNamespace(x=0., y=0., z=0.)


class LaneFeatures:
    def __init__(self):
        self.header = SimpleNamespace(stamp=SimpleNamespace(sec=0, nanosec=0))
        self.v, self.l, self.r = [], [], []


def module(name, **attributes):
    result = ModuleType(name)
    result.__dict__.update(attributes)
    return result


class FakeRos:
    def __init__(self):
        self.now = 100.
        self.alive = True
        self.nodes = {}
        self.commands = []
        self.observations = []
        self.publisher_count = 1
        self.subscriber_count = 1
        self.steps = []
        self.drained = False
        self.config = GridConfig.from_mapping({'rows': 1, 'cols': 1,
                                              'roi_top_px': 250, 'roi_bottom_px': 0})
        harness = self

        class Publisher:
            def __init__(self, kind, topic, qos):
                self.kind, self.topic, self.qos = kind, topic, qos

            def publish(self, message):
                if self.kind is Twist:
                    harness.commands.append((message.linear.x, message.linear.y, message.angular.z))

            def get_subscription_count(self):
                return harness.subscriber_count

        class Node:
            def __init__(self, name, **kwargs):
                self.name = name
                self.publishers, self.subscriptions = [], []
                harness.nodes[name] = self

            def create_publisher(self, kind, topic, qos):
                publisher = Publisher(kind, topic, qos)
                self.publishers.append(publisher)
                return publisher

            def create_subscription(self, kind, topic, callback, qos):
                subscription = SimpleNamespace(kind=kind, topic=topic, callback=callback, qos=qos)
                self.subscriptions.append(subscription)
                return subscription

            def create_timer(self, interval, callback):
                return SimpleNamespace(interval=interval, callback=callback, cancel=lambda: None)

            def count_publishers(self, topic):
                return harness.publisher_count

            def get_logger(self):
                return SimpleNamespace(info=lambda *_: None, warning=lambda *_: None,
                                       error=lambda *_: None)

            def get_clock(self):
                raise AssertionError('The real policy must not compare camera and wall clocks')

            def destroy_node(self):
                pass

        class Executor:
            def add_node(self, node):
                pass

            def remove_node(self, node):
                pass

            def spin_once(self, **kwargs):
                # Cleanup must not execute another scenario after an error.
                if harness.nodes.get('DRL_node') and harness.nodes['DRL_node'].failure:
                    return
                if harness.steps:
                    harness.now += .1
                    harness.steps.pop(0)(harness.nodes['DRL_node'])
                elif not harness.drained:
                    harness.drained = True
                    raise KeyboardInterrupt

            def shutdown(self):
                pass

        class CvBridge:
            def imgmsg_to_cv2(self, message, **kwargs):
                return message.image

        class Parameter:
            def __init__(self, name, value):
                self.name, self.value = name, value

        qos = SimpleNamespace
        self.modules = {
            'rclpy': module('rclpy', init=lambda **_: None, ok=lambda: self.alive,
                           shutdown=lambda: setattr(self, 'alive', False)),
            'rclpy.node': module('rclpy.node', Node=Node),
            'rclpy.signals': module('rclpy.signals', SignalHandlerOptions=SimpleNamespace(NO=0)),
            'rclpy.parameter': module('rclpy.parameter', Parameter=Parameter),
            'rclpy.qos': module('rclpy.qos', QoSProfile=qos,
                               ReliabilityPolicy=SimpleNamespace(RELIABLE='reliable', BEST_EFFORT='best_effort'),
                               HistoryPolicy=SimpleNamespace(KEEP_LAST='keep_last'),
                               DurabilityPolicy=SimpleNamespace(VOLATILE='volatile')),
            'rclpy.executors': module('rclpy.executors', SingleThreadedExecutor=Executor),
            'geometry_msgs.msg': module('geometry_msgs.msg', Twist=Twist),
            'sensor_msgs.msg': module('sensor_msgs.msg', Image=type('Image', (), {})),
            'my_lane_simulator_interfaces.msg': module('my_lane_simulator_interfaces.msg', LaneFeatures=LaneFeatures),
            'cv_bridge': module('cv_bridge', CvBridge=CvBridge),
        }

    def message(self, value, stamp):
        result = LaneFeatures()
        result.v, result.l, result.r = [float(value)], [10.], [20.]
        result.header.stamp.sec = stamp
        return result

    def run(self, steps):
        self.steps = list(steps)

        def observe(features, previous):
            self.observations.append((int(features.V[0]), previous))
            return np.array([previous], dtype=np.float32)

        lesson = SimpleNamespace(observe=observe, act=lambda *_: {
            'speed_m_s': .1, 'steering_rad': .1, 'normalized_steer': .25})
        policy = SimpleNamespace(predict=lambda _: np.array([.25], np.float32))
        # A legacy timeout key remains load-compatible and is no longer read.
        settings = {'real': {'calibration_confirmed': True, 'angular_mode': 'yaw_rate',
                            'angular_limit': 1., 'max_speed_m_s': .1, 'wheelbase_m': .194,
                            'image_timeout_s': 'legacy-unused'}}
        with patch.dict(sys.modules, self.modules), \
                patch.object(drive, 'load_bundle', return_value=(policy, lesson, settings, self.config)), \
                patch.object(drive.time, 'monotonic', side_effect=lambda: self.now), \
                patch.object(drive.signal, 'signal'), \
                patch.object(sys, 'argv', ['drive_real.py', '--drive']):
            return drive.main()


class LatestRealPolicyTests(unittest.TestCase):
    def test_latest_pending_observation_is_consumed_once(self):
        ros = FakeRos()

        def before_cleanup(node):
            self.assertEqual(len(ros.commands), 2)
            self.assertEqual([v for v, _ in ros.observations], [3, 4])
            self.assertAlmostEqual(ros.observations[-1][1], .25)
            self.assertEqual(node.sub.qos.depth, 1)

        self.assertEqual(ros.run([
            lambda n: n.tick(),
            lambda n: n.on_features(ros.message(1, 1)),
            lambda n: n.on_features(ros.message(2, 2)),
            lambda n: n.on_features(ros.message(3, 3)),
            lambda n: n.tick(), lambda n: n.tick(), lambda n: n.tick(),
            lambda n: n.on_features(ros.message(4, 4)), lambda n: n.tick(), before_cleanup,
        ]), 0)
        self.assertEqual(ros.commands[-3:], [(0., 0., 0.)] * 3)

    def test_header_only_rejects_duplicates_and_reverse_order(self):
        ros = FakeRos()
        ros.run([
            lambda n: n.on_features(ros.message(1, 5)),
            lambda n: n.on_features(ros.message(2, 5)),
            lambda n: n.on_features(ros.message(3, 4)),
            lambda n: n.tick(),
            lambda n: n.on_features(ros.message(4, 2_000_000_000)),
            lambda n: n.tick(),
            lambda n: n.on_features(ros.message(5, 0)), lambda n: n.tick(),
            lambda n: n.on_features(ros.message(6, 5)), lambda n: n.tick(),
        ])
        self.assertEqual([v for v, _ in ros.observations], [1, 4, 5])

    def test_no_image_wait_has_no_timeout_or_repeated_command(self):
        ros = FakeRos()

        def pause(node):
            ros.now += 1000.
            node.tick()

        def check(node):
            self.assertEqual(len(ros.commands), 1)
            self.assertEqual(len(ros.observations), 1)
            self.assertAlmostEqual(node.previous_steer, .25)

        self.assertEqual(ros.run([
            pause, lambda n: n.on_features(ros.message(1, 1)), lambda n: n.tick(),
            pause, pause, check,
        ]), 0)

    def test_malformed_feature_still_stops_and_fails(self):
        ros = FakeRos()
        bad = ros.message(1, 1)
        bad.v = [1., 2.]
        self.assertEqual(ros.run([lambda n: n.on_features(bad)]), 1)
        self.assertTrue(ros.commands)
        self.assertTrue(all(command == (0., 0., 0.) for command in ros.commands))
        self.assertEqual(ros.observations, [])

    def test_competing_publisher_still_stops_without_new_frame(self):
        ros = FakeRos()

        def conflict(node):
            ros.publisher_count = 2
            node.tick()

        self.assertEqual(ros.run([
            lambda n: n.on_features(ros.message(1, 1)), lambda n: n.tick(), conflict,
        ]), 1)
        self.assertEqual(len(ros.observations), 1)
        self.assertEqual(ros.commands[-1], (0., 0., 0.))

    def test_real_and_simulation_qos_remain_distinct(self):
        for simulation, depth, reliability, output_depth in (
                (False, 1, 'best_effort', 1), (True, 8, 'reliable', 64)):
            with self.subTest(simulation=simulation):
                ros = FakeRos()
                with patch.dict(sys.modules, ros.modules):
                    node = ros_nodes.make_grid_node(ros.config, use_sim_time=simulation)
                self.assertEqual(node.subscription.qos.depth, depth)
                self.assertEqual(node.subscription.qos.history, 'keep_last')
                self.assertEqual(node.subscription.qos.reliability, reliability)
                self.assertEqual(node.publisher.qos, output_depth)


if __name__ == '__main__':
    unittest.main()
