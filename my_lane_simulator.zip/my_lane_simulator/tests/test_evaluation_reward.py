"""Evaluation records the actual saved formula without an extra execution."""
import sys
from types import SimpleNamespace
import unittest

import numpy as np

from lane_lab.evaluation_reward import REWARD_TERMS, RewardCapture


class EvaluationRewardTests(unittest.TestCase):
    def test_calls_saved_formula_once_and_delegates_the_lesson(self):
        calls = []
        returned = (4.2, False)

        def calculate_reward(state):
            calls.append(state)
            progress = np.float32(.25)
            near_line = np.float64(.75)
            touched_line = np.bool_(False)
            finished = True
            return returned

        observe = lambda *args: args
        act = lambda *args: args
        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward,
                                             observe=observe, act=act, label='saved'))
        state = object()
        self.assertIs(proxy.calculate_reward(state), returned)
        self.assertEqual(calls, [state])
        self.assertIs(proxy.observe, observe)
        self.assertIs(proxy.act, act)
        self.assertEqual(proxy.label, 'saved')
        self.assertEqual(proxy.last_terms, {'progress': .25, 'near_line': .75,
                                          'touched_line': False, 'finished': True})
        self.assertIsInstance(proxy.last_terms['touched_line'], bool)

    def test_custom_thresholds_are_taken_from_actual_local_values(self):
        def calculate_reward(state):
            progress = np.clip(state.new_progress_m / .2, 0., 1.)
            near_line = np.clip((.4 - state.wheel_clearance_m) / .4, 0., 1.)
            touched_line = state.wheel_clearance_m <= .15
            finished = state.lap_completed and not touched_line
            return float(progress - 5 * near_line), bool(touched_line or finished)

        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        state = SimpleNamespace(new_progress_m=.1, wheel_clearance_m=.1,
                                lap_completed=True)
        score, ended = proxy.calculate_reward(state)
        self.assertAlmostEqual(score, -3.25)
        self.assertTrue(ended)
        self.assertAlmostEqual(proxy.last_terms['progress'], .5)
        self.assertAlmostEqual(proxy.last_terms['near_line'], .75)
        self.assertTrue(proxy.last_terms['touched_line'])
        self.assertFalse(proxy.last_terms['finished'])

    def test_missing_terms_are_not_reconstructed_or_reused(self):
        def calculate_reward(state):
            if state:
                progress = 1
                near_line = .3
            return 0., False

        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        proxy.calculate_reward(True)
        self.assertEqual(proxy.last_terms, {'progress': 1., 'near_line': .3,
                                          'touched_line': None, 'finished': None})
        proxy.calculate_reward(False)
        self.assertEqual(proxy.last_terms, dict.fromkeys(REWARD_TERMS))

    def test_non_scalar_non_finite_and_strings_are_unavailable(self):
        def calculate_reward(state):
            progress = np.array(.5)
            near_line = np.array([.1, .2])
            touched_line = 'False'
            finished = float('nan')
            return 0., False

        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        proxy.calculate_reward(None)
        self.assertEqual(proxy.last_terms, dict.fromkeys(REWARD_TERMS))

    def test_only_the_top_reward_frame_is_captured(self):
        def helper():
            progress = 999
            return progress

        def calculate_reward(state):
            progress = .125
            helper()
            if state:
                calculate_reward(False)
                progress = .5
            return progress, False

        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        self.assertEqual(proxy.calculate_reward(True), (.5, False))
        self.assertEqual(proxy.last_terms['progress'], .5)

    def test_restores_and_chains_existing_python_profiler(self):
        events = []

        def calculate_reward(state):
            progress = .1
            return progress, False

        def previous(frame, event, arg):
            if frame.f_code is calculate_reward.__code__:
                events.append(event)

        original = sys.getprofile()
        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        try:
            sys.setprofile(previous)
            proxy.calculate_reward(None)
            restored = sys.getprofile()
        finally:
            sys.setprofile(original)
        self.assertIs(restored, previous)
        self.assertEqual(events, ['call', 'return'])
        self.assertEqual(proxy.last_terms['progress'], .1)

    def test_exception_is_not_swallowed_and_profiler_is_restored(self):
        def calculate_reward(state):
            progress = 1.
            if state:
                raise RuntimeError('student formula failure')
            return progress, False

        previous = lambda frame, event, arg: None
        original = sys.getprofile()
        proxy = RewardCapture(SimpleNamespace(calculate_reward=calculate_reward))
        proxy.calculate_reward(False)
        try:
            sys.setprofile(previous)
            with self.assertRaisesRegex(RuntimeError, 'student formula failure'):
                proxy.calculate_reward(True)
            restored = sys.getprofile()
        finally:
            sys.setprofile(original)
        self.assertIs(restored, previous)
        self.assertEqual(proxy.last_terms, dict.fromkeys(REWARD_TERMS))

    def test_bound_reward_method_is_supported(self):
        class Lesson:
            def calculate_reward(self, state):
                near_line = np.int64(1)
                return 0., False

        proxy = RewardCapture(Lesson())
        proxy.calculate_reward(None)
        self.assertEqual(proxy.last_terms['near_line'], 1.)


if __name__ == '__main__':
    unittest.main()
