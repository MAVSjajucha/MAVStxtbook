"""Actual artwork boundaries, enclosed references, and flat tunnel geometry."""
import json
import math
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image

from lane_lab import worlds
from lane_lab.enclosure import analyze_layout, tile_mask
from lane_lab.enclosed_route import generate_reference
from lane_lab.tunnels import drivable_mask, tunnel_sdf


ROOT = Path(__file__).resolve().parents[1]
PLAZA = [['P90', 'P180'], ['P0', 'P270']]
ENCLOSURES = {
    'L': [['Background', 'F90', 'F180'], ['F90', 'L0', 'L270'], ['F0', 'A0', 'F270']],
    'M': [['P90', 'N180', 'F180'], ['M90', 'M0', 'L270'], ['F0', 'A0', 'F270']],
    'N': [['Background', 'P90', 'P180'], ['F90', 'N0', 'N270'], ['F0', 'A0', 'F270']],
    'O': [['P90', 'O180', 'P180'], ['M90', 'O0', 'N270'], ['F0', 'A0', 'F270']],
    'P': PLAZA,
}


def rotate_layout(cells):
    result = []
    for row in np.rot90(np.asarray(cells, dtype=object), -1):
        new_row = []
        for token in row:
            letter, turns = worlds.parse_tile(token)
            new_row.append('Background' if letter == 'Background' else f'{letter}{((turns + 1) % 4) * 90}')
        result.append(new_row)
    return result


class EnclosureTests(unittest.TestCase):
    def test_l_to_p_enclosures_validate_at_every_rotation(self):
        for letter, initial in ENCLOSURES.items():
            cells = initial
            for turns in range(4):
                with self.subTest(letter=letter, turns=turns):
                    self.assertEqual(worlds.validate_layout(cells, root=ROOT), [])
                cells = rotate_layout(cells)
            self.assertEqual(cells, initial)

    def test_exposed_edge_and_partial_wide_join_are_rejected(self):
        with self.assertRaisesRegex(ValueError, '열려 있습니다'):
            worlds.validate_layout([['P90', 'Background'], ['P0', 'P270']])
        cells = [row[:] for row in ENCLOSURES['M']]
        cells[1][1] = 'L0'
        with self.assertRaisesRegex(ValueError, '폭이나 위치'):
            worlds.validate_layout(cells)

    def test_empty_and_oversized_grids_are_rejected(self):
        for cells in ([], [['Background']], [['Background'] * 9], [['A0'], ['A0', 'A0']]):
            with self.subTest(cells=cells), self.assertRaises(ValueError):
                worlds.validate_layout(cells)

    def test_separate_closed_regions_do_not_require_one_tile_loop(self):
        cells = [['F90', 'F180', 'Background', 'F90', 'F180'],
                 ['F0', 'F270', 'Background', 'F0', 'F270']]
        self.assertEqual(worlds.validate_layout(cells), [])
        analysis = analyze_layout(cells, worlds.parse_tile, ROOT)
        self.assertEqual(len(analysis['components']), 2)

    def test_legacy_tiles_keep_their_original_interior_masks(self):
        import cv2
        for letter in 'ABCDEFGHIJK':
            with Image.open(ROOT / 'track_img' / f'Track-{letter}.png') as artwork:
                rgb = np.asarray(artwork.convert('RGB'))
            dark = ((np.max(rgb, axis=2) < 80) & (np.ptp(rgb.astype(np.int16), axis=2) < 12)).astype(np.uint8)
            cv2.floodFill(dark, None, (450, 450) if letter in 'ABCDE' else (580, 320), 2)
            np.testing.assert_array_equal(tile_mask(rgb, letter), (dark == 2).astype(np.uint8))

    def test_generated_reference_is_repeatable_and_inside_the_plaza(self):
        analysis = analyze_layout(PLAZA, worlds.parse_tile, ROOT)
        mask = np.block([[analysis['rotated_masks'][worlds.parse_tile(token)] for token in row] for row in PLAZA])
        vehicle = json.loads((ROOT / 'config' / 'vehicle.json').read_text())
        route, info = generate_reference(mask, vehicle)
        other_route, other_info = generate_reference(mask, vehicle)
        np.testing.assert_array_equal(route, other_route)
        self.assertEqual(info, other_info)
        self.assertTrue(info['completion_enabled'])
        self.assertEqual(info['reference_route_kind'], 'generated_circuit')
        self.assertTrue(np.isfinite(route).all())
        row = np.floor((1.8 - route[:, 1]) / .001).astype(int)
        col = np.floor(route[:, 0] / .001).astype(int)
        self.assertTrue(mask[row, col].all())

    def test_small_closed_region_keeps_reference_without_a_false_lap(self):
        mask = np.zeros((600, 600), np.uint8)
        mask[40:560, 40:560] = 1
        vehicle = json.loads((ROOT / 'config' / 'vehicle.json').read_text())
        route, info = generate_reference(mask, vehicle)
        self.assertGreaterEqual(len(route), 12)
        self.assertFalse(info['completion_enabled'])
        self.assertEqual(info['reference_route_kind'], 'enclosure_reference')


class TunnelTests(unittest.TestCase):
    def test_mixed_tunnels_form_a_closed_route_at_every_rotation(self):
        cells = [['TC90', 'A0', 'F180'], ['F0', 'TS0', 'TC270']]
        for turns in range(4):
            with self.subTest(turns=turns):
                self.assertEqual(len(worlds.validate_layout(cells)), 6)
            cells = rotate_layout(cells)
        self.assertEqual(worlds.parse_tile({'tile': 'TC', 'rotation': 270}), ('TC', 3))

    def test_straight_tunnel_has_clear_width_and_roof_height(self):
        model = ET.fromstring(tunnel_sdf(0, 0, 'TS', 0, 1, .7, .8))
        collisions = model.findall('link/collision')
        self.assertEqual(len(collisions), 3)
        for collision in collisions:
            pose = [float(v) for v in collision.findtext('pose').split()]
            size = [float(v) for v in collision.findtext('geometry/box/size').split()]
            if collision.attrib['name'].startswith('wall'):
                self.assertAlmostEqual(abs(pose[1]) - size[1] / 2, .195)
                self.assertAlmostEqual(size[1], .005)
                self.assertAlmostEqual(size[2], .220)
            else:
                self.assertAlmostEqual(pose[2] - size[2] / 2, .220)

    def test_curved_mask_follows_the_generated_wall_faces(self):
        mask = drivable_mask('TC')
        rr, cc = np.nonzero(mask)
        points = np.column_stack(((cc + .5) * .001 - .45, .45 - (rr + .5) * .001))
        angles = np.arctan2((rr + .5) * .001, .9 - (cc + .5) * .001)
        center = np.array([.45, .45])
        with tempfile.TemporaryDirectory() as directory:
            document = ET.fromstring(tunnel_sdf(0, 0, 'TC', 0, 1, .7, .8, directory))
            self.assertEqual(len(document.findall('link/collision')), 12)
            for segment in range(4):
                bounds = []
                for wall in ('inner', 'outer'):
                    path = Path(directory) / f'tunnel_0_0_wall_{wall}_{segment}.stl'
                    vertices = np.unique(np.array([[float(value) for value in line.split()[1:3]]
                                                  for line in path.read_text().splitlines()
                                                  if line.strip().startswith('vertex ')]), axis=0)
                    order = np.argsort(np.linalg.norm(vertices - center, axis=1))
                    face = vertices[order[-2:] if wall == 'inner' else order[:2]]
                    normal = face.mean(axis=0) - center
                    normal /= np.linalg.norm(normal)
                    bounds.append(float((face @ normal).mean()))
                selected = points[(angles >= segment * math.pi / 8) & (angles < (segment + 1) * math.pi / 8)]
                projected = selected @ normal
                self.assertGreater(float(projected.min()), bounds[0])
                self.assertLess(float(projected.max()), bounds[1])

    def test_generated_tunnel_floor_is_unpainted_and_metadata_lists_tunnels(self):
        cells = [['TC90', 'A0', 'F180'], ['F0', 'TS0', 'TC270']]
        with tempfile.TemporaryDirectory() as directory:
            result = worlds.generate(ROOT, {'track': 'custom', 'custom_tiles': cells}, directory)
            output = Path(directory)
            with Image.open(output / 'tunnel_floor.png') as floor:
                self.assertEqual(np.unique(np.asarray(floor)).tolist(), [33])
            metadata = json.loads((output / 'track.json').read_text())
            self.assertEqual(metadata['tunnel_cells'], [[0, 0], [1, 1], [1, 2]])
            self.assertTrue(result['completion_enabled'])
            self.assertEqual(result['reference_route_kind'], 'legacy_centerline')
            world = ET.parse(result['world_path'])
            structures = [model for model in world.findall('world/model')
                          if model.attrib['name'].startswith('tunnel_')]
            self.assertEqual(len(structures), 3)


if __name__ == '__main__':
    unittest.main()
