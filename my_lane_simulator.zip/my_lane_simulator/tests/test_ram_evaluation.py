"""RAM candidate ownership, batch scheduling and complete PPO state selection."""
from __future__ import annotations

import copy
from dataclasses import FrozenInstanceError
import importlib.util
import io
import json
from pathlib import Path
import random
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from lane_lab import best_last
from lane_lab.environment import StopRequested


def make_selector(case, *, start_steps=0, episodes=1):
    temporary = tempfile.TemporaryDirectory()
    case.addCleanup(temporary.cleanup)
    app = SimpleNamespace(root=Path(temporary.name),
        cfg={'max_episode_seconds': 100.0}, stop_event=threading.Event(),
        update_image=Mock(), write_status=Mock())
    training_env = SimpleNamespace(sim=object(), settings={'seed': 123})
    options = {'eval_every_steps': 10000, 'eval_episodes': episodes,
               'criterion': 'mean_reward'}
    with patch.dict(sys.modules, {'stable_baselines3': SimpleNamespace(__version__='2.4.1')}), \
            patch.object(best_last, 'scenario_fingerprint', return_value='test-scenario'):
        return best_last.BestLastSelector(app, temporary.name, training_env,
            object(), 3, options, start_steps=start_steps)


class CandidateSnapshotTests(unittest.TestCase):
    def test_capture_owns_immutable_bytes_and_excludes_legacy_rng_without_mutating_model(self):
        legacy = object()
        model = SimpleNamespace(num_timesteps=512, _n_updates=10,
                                lane_random_state=legacy)

        def save(destination, *, exclude):
            self.assertIsInstance(destination, io.BytesIO)
            self.assertIn('lane_random_state', exclude)
            destination.write(b'complete-policy-and-optimizer')

        model.save = Mock(side_effect=save)
        candidate = best_last.capture_candidate(model)
        self.assertEqual(candidate.payload, b'complete-policy-and-optimizer')
        self.assertIsInstance(candidate.payload, bytes)
        self.assertEqual((candidate.timesteps, candidate.ppo_updates), (512, 10))
        self.assertIs(model.lane_random_state, legacy)
        model.num_timesteps, model._n_updates = 1024, 20
        self.assertEqual((candidate.timesteps, candidate.ppo_updates), (512, 10))
        with self.assertRaises(FrozenInstanceError):
            candidate.timesteps = 1024
        model.save.assert_called_once()

    def test_load_uses_in_memory_cpu_archive_and_checks_both_saved_counters(self):
        candidate = best_last.CandidateSnapshot(b'archive', 512, 10)
        restored = SimpleNamespace(num_timesteps=512, _n_updates=10)

        def load(source, *, device):
            self.assertIsInstance(source, io.BytesIO)
            self.assertEqual(source.getvalue(), candidate.payload)
            self.assertEqual(device, 'cpu')
            return restored

        loader = Mock(side_effect=load)
        with patch.dict(sys.modules, {'stable_baselines3': SimpleNamespace(PPO=SimpleNamespace(load=loader))}):
            self.assertIs(best_last.load_candidate(candidate), restored)
            for steps, updates in ((513, 10), (512, 11)):
                with self.subTest(steps=steps, updates=updates):
                    restored.num_timesteps, restored._n_updates = steps, updates
                    with self.assertRaises(ValueError):
                        best_last.load_candidate(candidate)


class CandidateQueueTests(unittest.TestCase):
    def setUp(self):
        self.selector = make_selector(self)
        self.model = SimpleNamespace(num_timesteps=0, _n_updates=0)

        def capture(model):
            return best_last.CandidateSnapshot(bytes(model._n_updates),
                                               model.num_timesteps, model._n_updates)

        capture_patch = patch.object(best_last, 'capture_candidate', side_effect=capture)
        self.capture_mock = capture_patch.start()
        self.addCleanup(capture_patch.stop)

    def capture(self, steps, updates):
        self.model.num_timesteps, self.model._n_updates = steps, updates
        self.selector.capture(self.model)

    def test_queue_deduplicates_completed_updates_and_tracks_owned_bytes(self):
        self.selector.capture(self.model)
        self.capture_mock.assert_not_called()
        self.capture(512, 10)
        self.capture(1024, 10)
        self.capture(1024, 20)
        self.assertEqual(self.capture_mock.call_count, 2)
        self.assertEqual([(item.timesteps, item.ppo_updates) for item in self.selector.pending],
                         [(512, 10), (1024, 20)])
        self.assertEqual(self.selector.pending_bytes, 30)
        self.assertEqual(self.selector.peak_pending_bytes, 30)
        self.selector.discard_pending('test cleanup')
        self.assertEqual(self.selector.pending, [])
        self.assertEqual(self.selector.pending_bytes, 0)
        self.assertEqual(self.selector.peak_pending_bytes, 30)
        self.selector.capture(self.model)
        self.assertEqual(self.selector.pending, [])
        self.assertEqual(self.capture_mock.call_count, 2)

    def test_first_batch_waits_for_ten_thousand_steps_and_next_batch_for_twenty_thousand(self):
        with patch.object(self.selector, 'evaluate') as evaluate:
            for update in range(1, 20):
                self.capture(update * 512, update * 10)
                self.selector.maybe_evaluate(self.model)
            evaluate.assert_not_called()
            self.capture(10240, 200)
            self.selector.maybe_evaluate(self.model)
            evaluate.assert_called_once_with(self.model, restore_training=True)
            self.assertEqual(self.selector.next_eval_step, 20000)
            evaluate.reset_mock()
            self.capture(10752, 210)
            self.selector.maybe_evaluate(self.model)
            evaluate.assert_not_called()

    def test_resume_waits_for_next_global_boundary(self):
        selector = make_selector(self, start_steps=24576)
        self.assertEqual(selector.next_eval_step, 30000)
        self.model.num_timesteps, self.model._n_updates = 25088, 490
        selector.capture(self.model)
        with patch.object(selector, 'evaluate') as evaluate:
            selector.maybe_evaluate(self.model)
            evaluate.assert_not_called()
            self.model.num_timesteps, self.model._n_updates = 30208, 590
            selector.capture(self.model)
            selector.maybe_evaluate(self.model)
            evaluate.assert_called_once_with(self.model, restore_training=True)

    def test_normal_final_flushes_short_batch_but_stop_skips_evaluation(self):
        self.capture(512, 10)
        with patch.object(self.selector, 'evaluate') as evaluate:
            self.selector.maybe_evaluate(self.model, final=True)
            evaluate.assert_called_once_with(self.model, restore_training=False)
        self.capture(1024, 20)
        self.selector.app.stop_event.set()
        with patch.object(self.selector, 'evaluate') as evaluate:
            self.selector.maybe_evaluate(self.model, final=True)
            evaluate.assert_not_called()


@unittest.skipUnless(importlib.util.find_spec('stable_baselines3') is not None,
                     '실제 PPO RAM 검증에는 패키지의 stable_baselines3가 필요합니다.')
class RAMBatchPPOTests(unittest.TestCase):
    def setUp(self):
        import gymnasium as gym
        import torch
        from stable_baselines3 import PPO

        self.torch = torch
        self.PPO = PPO
        self.selector = make_selector(self)
        self.scores = {512: 3.0, 1024: 9.0, 1536: 5.0}
        self.interrupt_step = None
        self.interrupt_episode = 1
        self.eval_contexts = []
        self.eval_seeds = []
        self.eval_closes = []

        class TinyTrainingEnv(gym.Env):
            def __init__(self):
                self.observation_space = gym.spaces.Box(-1, 1, (3,), dtype=np.float32)
                self.action_space = gym.spaces.Box(-1, 1, (1,), dtype=np.float32)
                self.steps = 0

            def reset(self, *, seed=None, options=None):
                super().reset(seed=seed)
                self.steps = 0
                return np.zeros(3, np.float32), {}

            def step(self, action):
                self.steps += 1
                return np.full(3, self.steps / 8, np.float32), \
                    float(1 - abs(action[0])), self.steps == 8, False, {}

        self.model = PPO('MlpPolicy', TinyTrainingEnv(), n_steps=8, batch_size=8,
            n_epochs=1, seed=123, policy_kwargs={'net_arch': [8]}, device='cpu')
        self.addCleanup(self.model.get_env().close)
        self.saved_states = {}
        for steps, updates in ((512, 10), (1024, 20), (1536, 30)):
            self.model.learn(8, reset_num_timesteps=False)
            self.model.num_timesteps, self.model._n_updates = steps, updates
            self.model.lane_random_state = {'legacy': 'must stay out of archive'}
            self.selector.capture(self.model)
            self.saved_states[steps] = self.model_state(self.model)

        case = self

        class EvaluationEnv:
            def __init__(self, sim, settings, lesson, size, stop_event, report,
                         *, training_step_context):
                self.steps = training_step_context
                self.stop_event = stop_event
                self.episode = 0
                case.eval_contexts.append(self.steps)

            def reset(self, *, seed=None):
                self.episode += 1
                case.eval_seeds.append((self.steps, seed))
                # PPO.load also reseeds these generators; every RNG is checked.
                random.random()
                np.random.random()
                torch.rand(1)
                return np.zeros(3, np.float32), {}

            def step(self, action):
                if self.steps == case.interrupt_step and self.episode == case.interrupt_episode:
                    self.stop_event.set()
                    raise StopRequested()
                return np.zeros(3, np.float32), 0.0, True, False, {
                    'successful_lap': False, 'progress_m': 1.0, 'track_length_m': 10.0,
                    'episode_return': case.scores[self.steps]}

            def close(self):
                case.eval_closes.append(self.steps)

        environment_patch = patch.object(best_last, 'LaneEnv', EvaluationEnv)
        environment_patch.start()
        self.addCleanup(environment_patch.stop)

    def model_state(self, model):
        return copy.deepcopy({'policy': model.policy.state_dict(),
                              'optimizer': model.policy.optimizer.state_dict(),
                              'steps': model.num_timesteps, 'updates': model._n_updates})

    def assert_nested_equal(self, expected, actual):
        if self.torch.is_tensor(expected):
            self.assertTrue(self.torch.equal(expected, actual))
        elif isinstance(expected, dict):
            self.assertEqual(expected.keys(), actual.keys())
            for key in expected:
                self.assert_nested_equal(expected[key], actual[key])
        elif isinstance(expected, (tuple, list)):
            self.assertEqual(len(expected), len(actual))
            for left, right in zip(expected, actual):
                self.assert_nested_equal(left, right)
        else:
            self.assertEqual(expected, actual)

    def records(self):
        return [json.loads(line) for line in
                (self.selector.run / 'best_evaluations.jsonl').read_text().splitlines()]

    def test_older_winner_saves_full_state_once_and_live_training_remains_unchanged(self):
        self.assertTrue(self.saved_states[512]['optimizer']['state'])
        self.assertFalse(self.torch.equal(self.saved_states[512]['policy']['action_net.weight'],
                                         self.saved_states[1536]['policy']['action_net.weight']))
        live = self.model_state(self.model)
        prior_mode = self.model.policy.training
        vector = self.model.get_env()
        with patch.object(best_last, 'save_snapshot', wraps=best_last.save_snapshot) as save, \
                patch.object(best_last, 'save_last_snapshot', wraps=best_last.save_last_snapshot) as last, \
                patch.object(vector, 'reset', wraps=vector.reset) as reset:
            self.selector.evaluate(self.model, restore_training=True)
        self.assertEqual(last.call_count, 1)
        self.assertIs(last.call_args.args[0], self.model)
        self.assertEqual(sum(call.args[2] == 'best' for call in save.call_args_list), 1)
        reset.assert_called_once()
        self.assertEqual(self.eval_contexts, [512, 1024, 1536])
        self.assertEqual(self.eval_closes, self.eval_contexts)
        self.assertEqual(self.eval_seeds, [(512, 0), (1024, 0), (1536, 0)])
        self.assert_nested_equal(live, self.model_state(self.model))
        self.assertEqual(self.model.policy.training, prior_mode)
        self.assertTrue(self.model._last_episode_starts.all())
        self.assertEqual(self.selector.pending, [])
        self.assertEqual(self.selector.pending_bytes, 0)
        folder, record = best_last.load_choice(self.selector.run, 'best')
        self.assertEqual((record['timesteps'], record['ppo_updates']), (1024, 20))
        winner = self.PPO.load(folder / 'model.zip', device='cpu')
        self.assert_nested_equal(self.saved_states[1024], self.model_state(winner))
        self.assertFalse(hasattr(winner, 'lane_random_state'))
        _, latest = best_last.load_choice(self.selector.run, 'last')
        self.assertEqual((latest['timesteps'], latest['ppo_updates']), (1536, 30))
        rows = self.records()
        self.assertEqual([row['training_steps'] for row in rows], [512, 1024, 1536])
        self.assertEqual([row['ppo_updates'] for row in rows], [10, 20, 30])
        self.assertEqual([row['candidate_index'] for row in rows], [1, 2, 3])
        self.assertEqual([row['candidate_count'] for row in rows], [3, 3, 3])
        self.assertEqual([row['batch_training_steps'] for row in rows], [1536] * 3)
        self.assertEqual(len({row['batch_id'] for row in rows}), 1)

    def test_existing_best_wins_ties_and_each_candidate_runs_configured_episodes(self):
        incumbent = {'timesteps': 100, 'ppo_updates': 2, 'metrics': {'rank': [9.0]}}
        self.selector.best = incumbent
        self.selector.options['eval_episodes'] = 2
        with patch.object(best_last, 'save_last_snapshot'), \
                patch.object(best_last, 'save_snapshot') as save:
            self.selector.evaluate(self.model, restore_training=False)
        save.assert_not_called()
        self.assertIs(self.selector.best, incumbent)
        self.assertEqual(self.eval_seeds,
                         [(steps, seed) for steps in (512, 1024, 1536) for seed in (0, 1)])

    def test_interrupted_candidate_cannot_win_but_completed_earlier_candidate_is_saved(self):
        self.interrupt_step = 1024
        self.interrupt_episode = 2
        self.selector.options['eval_episodes'] = 2
        self.scores[1024] = 100.0
        vector = self.model.get_env()
        with patch.object(best_last, 'save_snapshot', wraps=best_last.save_snapshot) as save, \
                patch.object(best_last, 'save_last_snapshot') as last, \
                patch.object(vector, 'reset', wraps=vector.reset) as reset:
            with self.assertRaises(StopRequested):
                self.selector.evaluate(self.model, restore_training=True)
        self.assertEqual(last.call_count, 1)
        self.assertEqual(sum(call.args[2] == 'best' for call in save.call_args_list), 1)
        reset.assert_not_called()
        self.assertEqual(self.eval_contexts, [512, 1024])
        self.assertEqual(self.eval_closes, self.eval_contexts)
        self.assertEqual(self.selector.best['timesteps'], 512)
        rows = self.records()
        self.assertEqual([row['complete'] for row in rows], [True, False])
        self.assertEqual(rows[-1]['training_steps'], 1024)
        self.assertEqual(rows[-1]['completed_episodes'], 1)
        self.assertEqual([item.timesteps for item in self.selector.pending], [1024, 1536])
        self.selector.discard_pending('stopped')
        self.assertEqual(self.selector.pending_bytes, 0)

    def test_all_rng_states_survive_candidate_loading_and_evaluation(self):
        random.seed(497)
        np.random.seed(498)
        self.torch.manual_seed(499)
        expected = (random.getstate(), np.random.get_state(), self.torch.get_rng_state().clone())
        with patch.object(best_last, 'save_last_snapshot'), \
                patch.object(best_last, 'save_snapshot', return_value={'timesteps': 1024}):
            self.selector.evaluate(self.model, restore_training=False)
        self.assertEqual(random.getstate(), expected[0])
        actual_np = np.random.get_state()
        self.assertEqual(actual_np[0], expected[1][0])
        np.testing.assert_array_equal(actual_np[1], expected[1][1])
        self.assertEqual(actual_np[2:], expected[1][2:])
        self.assertTrue(self.torch.equal(self.torch.get_rng_state(), expected[2]))


if __name__ == '__main__':
    unittest.main()
