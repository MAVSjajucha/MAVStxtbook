# Fixed test fixture; never copy this over the student's design/lighting.py.
"""광원·트랙 재질 설정: 변수 오른쪽의 숫자를 수정하고 '변경 설정 적용'을 누르세요.

광원 종류(점광원/스포트라이트)와 켜고 끄기는 Gazebo 환경 메뉴에서 선택합니다.
DIFFUSE / SPECULAR는 (빨강, 초록, 파랑, 알파)이며 각 성분은 0~1입니다.
정반사 값은 반짝임의 색상·강도이며, 입사광 중 반사되는 비율(%)이 아닙니다.
INTENSITY는 Gazebo의 광원 세기 배율입니다. 1이 기준이며 %가 아닙니다.
거리 단위는 m, 스포트라이트 각도 단위는 rad입니다.
CONSTANT / LINEAR는 0~1, RANGE_M / QUADRATIC / 각도 / FALLOFF는 0 이상입니다.
INTENSITY·위치·방향광 각도에는 임의의 상한을 두지 않고 유한한 숫자를 사용합니다.
"""

# 1. 추가 광원 위치: (X, Y, Z), 생성된 트랙 바닥 중심이 (0, 0, 0)입니다.
# light1~light4는 환경 메뉴의 광원 1~4 체크박스에 각각 대응합니다.
light1 = (-0.9, -0.9, 2.0)
light2 = (0.9, -0.9, 2.0)
light3 = (-0.9, 0.9, 2.0)
light4 = (0.9, 0.9, 2.0)

# 2. 트랙 정반사 강도: 0~1, 같은 값을 빨강·초록·파랑 성분에 적용합니다.
TRACK_SPECULAR = 0.0

# 3. 기본 방향광: 광원 위치에 해당하는 방위각·고도각을 도(°) 단위로 입력합니다.
# 방위각: +X 방향 0°, +Y 방향 90°이며, 위에서 볼 때 반시계 방향으로 증가합니다.
# 고도각: 수평선 0°, 머리 위 90°입니다. 높이(m)가 아닌 각도입니다.
# 아래 기본 각도는 기존 빛 진행 방향 (-0.3, 0.3, -1)과 같습니다.
SUN_INTENSITY = 1.0
SUN_SPECULAR = (0.1, 0.1, 0.1, 1.0)
SUN_AZIMUTH_DEG = 315.0
SUN_ELEVATION_DEG = 67.01023222639115

# 점광원: 켜 놓은 모든 점광원에 공통으로 적용합니다.
POINT_INTENSITY = 1.0
POINT_DIFFUSE = (1.0, 1.0, 1.0, 1.0)
POINT_SPECULAR = (1.0, 1.0, 1.0, 1.0)
POINT_RANGE_M = 10.0
POINT_CONSTANT = 0.5
POINT_LINEAR = 0.1
POINT_QUADRATIC = 0.01

# 스포트라이트: 켜 놓은 모든 스포트라이트에 공통으로 적용합니다.
SPOT_INTENSITY = 1.0
SPOT_DIFFUSE = (1.0, 1.0, 1.0, 1.0)
SPOT_SPECULAR = (1.0, 1.0, 1.0, 1.0)
SPOT_RANGE_M = 10.0
SPOT_CONSTANT = 0.5
SPOT_LINEAR = 0.1
SPOT_QUADRATIC = 0.01
SPOT_DIRECTION = (0.0, 0.0, -1.0)  # 아래쪽을 향합니다. (0, 0, 0)은 사용할 수 없습니다.
SPOT_INNER_ANGLE_RAD = 0.35
SPOT_OUTER_ANGLE_RAD = 0.70
SPOT_FALLOFF = 1.0
