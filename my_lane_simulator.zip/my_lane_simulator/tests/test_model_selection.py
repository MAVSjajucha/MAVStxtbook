"""Exact model selection, saved policy context, and no side effects on bad files."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import Mock, patch

import numpy as np

from lane_lab import runner
from lane_lab.configuration import atomic_json, read_settings, sha256
from lane_lab.model_selection import prepare_evaluation

PACKAGE = Path(__file__).resolve().parents[1]


class ModelSelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        for folder in ('config', 'design', 'track_img'):
            shutil.copytree(PACKAGE / folder, self.root / folder)
        (self.root / 'lane_lab').mkdir()
        for name in ('vision.py', 'policy_io.py'):
            shutil.copy2(PACKAGE / 'lane_lab' / name, self.root / 'lane_lab' / name)
        self.run = self.root / 'runs/old_experiment'
        shutil.copytree(PACKAGE / 'runs/example_model', self.run)
        self.newer = self.root / 'runs/new_experiment'
        shutil.copytree(self.run, self.newer)
        atomic_json(self.root / 'runtime/latest_run.json', {'run': 'runs/new_experiment'})
        self.pointer = (self.root / 'runtime/latest_run.json').read_bytes()
        self.current = read_settings(self.root, {'track': 'track2', 'camera_pitch_deg': 40,
            'camera_hfov_deg': 100, 'grid_cols': 2, 'grid_rows': 2, 'roi_max': 200,
            'speed_m_s': .2, 'steer_max_rad': .3, 'friction_mu1': .8, 'friction_mu2': .35, 'mass_kg': 3})
        self.actor = self.run / 'models/best/actor.npz'

    def read_json(self, path):
        return json.loads(path.read_text())

    def update_actor(self, path, change):
        with np.load(path) as archive:
            values = {key: archive[key].copy() for key in archive.files}
        change(values)
        np.savez_compressed(path, **values)
        index = self.read_json(self.run / 'model_selection.json')
        index['best']['sha256']['actor.npz'] = sha256(path)
        atomic_json(self.run / 'model_selection.json', index)

    def test_selects_exact_older_experiment_without_touching_latest(self):
        selected = prepare_evaluation(self.root, str(self.actor), self.current)
        self.assertEqual(selected.actor, self.actor)
        self.assertEqual(selected.run, self.run)
        self.assertEqual(selected.record['timesteps'], 70152)
        self.assertEqual(selected.size, 11)
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)

    def test_restores_saved_observation_camera_action_and_keeps_current_scenario(self):
        self.current['lighting']['point']['intensity'] = 2.5
        selected = prepare_evaluation(self.root, str(self.actor), self.current)
        saved = self.read_json(self.run / 'settings.json')
        for key in ('vision', 'grid_rows', 'grid_cols', 'roi_min', 'roi_max',
                    'camera_pitch_deg', 'camera_hfov_deg', 'speed_m_s', 'steer_max_rad', 'control_hz'):
            self.assertEqual(selected.settings[key], saved[key], key)
        for key in ('track', 'custom_tiles', 'lighting', 'friction_mu1', 'friction_mu2', 'mass_kg',
                    'speed_mode', 'speed_factor', 'evaluation_episodes'):
            self.assertEqual(selected.settings[key], self.current[key], key)
        self.assertEqual(selected.settings['vehicle']['wheelbase_m'],
                         self.read_json(self.run / 'vehicle_base.json')['wheelbase_m'])
        # Reading old configuration must not mutate pending GUI configuration.
        self.assertEqual(self.current['camera_pitch_deg'], 40)
        self.assertEqual(self.current['grid_cols'], 2)

    def test_unselected_snapshot_uses_its_own_metadata_not_latest_record(self):
        folder = self.run / 'models/best_000070152_old'
        shutil.copytree(self.actor.parent, folder)
        record = self.read_json(self.run / 'model_selection.json')['best']
        atomic_json(folder / 'metadata.json', {key: record[key] for key in ('timesteps', 'ppo_updates', 'metrics', 'protocol')})
        actor = folder / 'actor.npz'
        selected = prepare_evaluation(self.root, str(actor), self.current)
        self.assertEqual(selected.actor, actor)
        self.assertEqual(selected.record['timesteps'], 70152)
        self.assertEqual(selected.label, folder.name)
        atomic_json(folder / 'metadata.json', {**selected.record, 'timesteps': 99999})
        with self.assertRaisesRegex(ValueError, '스텝 정보'):
            prepare_evaluation(self.root, str(actor), self.current)

    def test_legacy_last_at_run_root_is_supported(self):
        for name in ('model.zip', 'actor.npz'):
            shutil.copy2(self.run / 'models/last' / name, self.run / name)
        selected = prepare_evaluation(self.root, str(self.run / 'actor.npz'), self.current)
        self.assertEqual(selected.actor, self.run / 'actor.npz')
        self.assertEqual(selected.record['timesteps'], 70167)

    def test_missing_bundle_dependencies_are_rejected_before_work(self):
        for name in ('settings.json', 'lesson.py', 'training.json', 'vehicle_base.json',
                     'shared_code/vision.py', 'shared_code/policy_io.py', 'models/best/model.zip'):
            with self.subTest(name=name):
                path = self.run / name
                contents = path.read_bytes()
                path.unlink()
                with self.assertRaisesRegex(ValueError, '필요한'):
                    prepare_evaluation(self.root, str(self.actor), self.current)
                path.write_bytes(contents)

    def test_rejects_modified_saved_code_or_settings(self):
        for name in ('lesson.py', 'settings.json'):
            with self.subTest(name=name):
                path = self.run / name
                contents = path.read_bytes()
                path.write_bytes(contents + b'\n')
                with self.assertRaisesRegex(ValueError, '학습 후 변경'):
                    prepare_evaluation(self.root, str(self.actor), self.current)
                path.write_bytes(contents)
        for name in ('vision.py', 'policy_io.py'):
            with self.subTest(name=name):
                path = self.run / 'shared_code' / name
                contents = path.read_bytes()
                path.write_bytes(contents + b'\n')
                with self.assertRaisesRegex(ValueError, '학습 당시와 다릅니다'):
                    prepare_evaluation(self.root, str(self.actor), self.current)
                path.write_bytes(contents)

    def test_rejects_dimension_mismatch_and_nonfinite_actor(self):
        original = self.actor.read_bytes()
        index = (self.run / 'model_selection.json').read_bytes()
        def change_dimension(values):
            values['observation_size'] = np.array(12)
            values['W0'] = np.zeros((values['W0'].shape[0], 12), np.float32)
        self.update_actor(self.actor, change_dimension)
        with self.assertRaisesRegex(ValueError, '입력 개수'):
            prepare_evaluation(self.root, str(self.actor), self.current)
        self.actor.write_bytes(original)
        (self.run / 'model_selection.json').write_bytes(index)
        self.update_actor(self.actor, lambda values: values['W0'].__setitem__((0, 0), np.nan))
        with self.assertRaisesRegex(ValueError, 'NaN'):
            prepare_evaluation(self.root, str(self.actor), self.current)

    def test_bad_file_selection_never_changes_settings_or_launches_work(self):
        app = runner.App(self.root, headless=True)
        app.launch_work = Mock()
        app.configure_sim = Mock()
        settings_before = (self.root / 'runtime/settings.json').read_bytes()
        for path in ('', str(self.actor.parent), str(self.actor.parent / 'model.zip'),
                     str(self.root / 'runs/missing/actor.npz')):
            with self.subTest(path=path):
                with self.assertRaises(ValueError):
                    app.command({'action': 'evaluate_file', 'model_path': path,
                                 'settings': {'friction': 1.2}})
                self.assertEqual((self.root / 'runtime/settings.json').read_bytes(), settings_before)
        app.launch_work.assert_not_called()
        app.configure_sim.assert_not_called()
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)

    def test_export_or_actor_copied_alone_is_rejected(self):
        exported = self.root / 'exports/example/best/actor.npz'
        exported.parent.mkdir(parents=True)
        shutil.copy2(self.actor, exported)
        with self.assertRaisesRegex(ValueError, 'exports'):
            prepare_evaluation(self.root, str(exported), self.current)
        alone = self.root / 'runs/actor.npz'
        shutil.copy2(self.actor, alone)
        with self.assertRaisesRegex(ValueError, '따로 복사'):
            prepare_evaluation(self.root, str(alone), self.current)

    def test_command_holds_exact_policy_and_evaluation_identifies_it(self):
        app = runner.App(self.root, headless=True)
        app.launch_work = Mock()
        app.configure_sim = Mock(return_value=Mock())
        app.command({'action': 'evaluate_file', 'model_path': str(self.actor),
                     'settings': {'track': 'track2', 'friction': .8, 'evaluation_episodes': 1}})
        launch = app.launch_work.call_args.args[0]
        # Updating a saved actor after validation cannot switch the in-memory policy.
        expected = prepare_evaluation(self.root, self.actor, self.current).actor_sha256
        self.actor.write_bytes(b'changed after preflight')
        env = Mock()
        env.reset.return_value = (np.zeros(11, np.float32), {})
        env.step.return_value = (None, 0., True, False, {'successful_lap': True})
        recorder=Mock(rows=1)
        with patch.object(runner, 'LaneEnv', return_value=env), patch.object(runner,'EvaluationCSV',return_value=recorder):
            launch()
        result_path = next((self.root / 'evaluation').glob('*/result.json'))
        result = self.read_json(result_path)
        self.assertEqual(result['model_path'], str(self.actor))
        self.assertEqual(result['model_timesteps'], 70152)
        self.assertEqual(result['model_sha256'], expected)
        self.assertEqual(result['clean_laps'], 1)
        self.assertEqual(env.reset.call_count,1)
        self.assertEqual(app.status['evaluated_model_path'], str(self.actor))
        self.assertEqual(app.status['evaluation_run'], str(self.run))
        self.assertEqual((self.root / 'runtime/latest_run.json').read_bytes(), self.pointer)
        env.close.assert_called_once()


if __name__ == '__main__':
    unittest.main()
