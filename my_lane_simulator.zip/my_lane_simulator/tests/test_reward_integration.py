"""Reward state transition contracts across training and evaluation entry points."""
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

import numpy as np

from lane_lab.best_last import BestLastSelector, CandidateSnapshot
from lane_lab.configuration import check_lesson
from lane_lab.environment import LaneEnv
from tests import test_evaluation_csv as evaluation_fixtures
from tests.test_evaluation_csv import FakeSim, FakeTrack, Lesson


class RecordingLesson(Lesson):
    def __init__(self):
        super().__init__()
        self.states = []

    def calculate_reward(self, state):
        self.states.append(state)
        return super().calculate_reward(state)


class ImageFakeSim(FakeSim):
    def result(self):
        result = super().result()
        result["image"] = np.zeros((2, 2, 3), dtype=np.uint8)
        return result


class RewardIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.settings = {
            "vision": {"rows": 2, "cols": 3, "roi_bottom_px": 0, "roi_top_px": 250},
            "steer_max_rad": 0.5, "speed_m_s": 0.1, "max_episode_seconds": 100.0,
            "speed_mode": "auto", "seed": 123,
        }
        self.lesson = RecordingLesson()
        self.sim = ImageFakeSim()
        self.stop_event = threading.Event()
        geometry = patch("lane_lab.environment.TrackGeometry.from_metadata",
                         side_effect=lambda _: FakeTrack())
        geometry.start()
        self.addCleanup(geometry.stop)

    def environment(self, **kwargs):
        env = LaneEnv(self.sim, self.settings, self.lesson, 8, self.stop_event, **kwargs)
        self.addCleanup(env.close)
        return env

    def test_resumed_counter_and_episode_reset_match_completed_transitions(self):
        env = self.environment()
        env.total_steps = 512
        observation, _ = env.reset()
        self.assertEqual(self.lesson.states, [])
        self.assertEqual(observation.shape, (8,))
        env.step(np.array([0.25]))
        first = self.lesson.states[-1]
        self.assertEqual((first.total_steps, first.episode_index, first.episode_step), (513, 1, 1))
        self.assertAlmostEqual(first.episode_elapsed_s, 0.1)
        self.assertAlmostEqual(first.rear_distance_total_m, 0.01)
        self.assertEqual(first.previous_center_xy, (0.0, 0.2))
        self.assertEqual(first.previous_steer, 0.0)
        env.step(np.array([-0.25]))
        second = self.lesson.states[-1]
        self.assertEqual((second.total_steps, second.episode_index, second.episode_step), (514, 1, 2))
        self.assertAlmostEqual(second.episode_elapsed_s, 0.2)
        self.assertAlmostEqual(second.rear_distance_total_m, 0.02)
        self.assertEqual(second.previous_front_xy, first.front_xy)
        self.assertEqual(second.previous_front_path_xy, first.front_path_xy)
        self.assertEqual(second.previous_steer, 0.25)
        env.reset()
        env.step(np.array([0.0]))
        reset = self.lesson.states[-1]
        self.assertEqual((reset.total_steps, reset.episode_index, reset.episode_step), (515, 2, 1))
        self.assertEqual(reset.previous_center_xy, (0.0, 0.2))
        self.assertAlmostEqual(reset.rear_distance_total_m, 0.01)
        self.assertAlmostEqual(reset.episode_elapsed_s, 0.1)
        self.assertEqual(reset.previous_steer, 0.0)
        self.assertEqual(env.total_steps, 515)

    def test_reward_and_environment_contact_history_agree_and_reset(self):
        env = self.environment()
        env.reset()
        original = env.track.evaluate_pose
        gap = [0.0]

        def truth(*args, **kwargs):
            values = original(*args, **kwargs)
            values["wheel_clearance_m"] = gap[0]
            values["front_left_clearance_m"] = gap[0]
            return values

        env.track.evaluate_pose = truth
        _, _, _, _, info = env.step(np.array([0.0]))
        self.assertTrue(self.lesson.states[-1].physical_touched_line)
        self.assertEqual(self.lesson.states[-1].ever_touched_line, info["ever_touched_line"])
        gap[0] = 0.02
        _, _, _, _, info = env.step(np.array([0.0]))
        self.assertFalse(self.lesson.states[-1].physical_touched_line)
        self.assertTrue(self.lesson.states[-1].ever_touched_line)
        self.assertEqual(self.lesson.states[-1].ever_touched_line, info["ever_touched_line"])
        env.reset()
        _, _, _, _, info = env.step(np.array([0.0]))
        self.assertFalse(self.lesson.states[-1].ever_touched_line)
        self.assertFalse(info["ever_touched_line"])

    def test_evaluation_context_stays_fixed_while_driving_counters_advance(self):
        env = self.environment(training_step_context=1024)
        for _ in range(2):
            env.reset()
            env.step(np.array([0.0]))
            env.step(np.array([0.0]))
        self.assertEqual([state.total_steps for state in self.lesson.states], [1024] * 4)
        self.assertEqual([state.episode_index for state in self.lesson.states], [1, 1, 2, 2])
        self.assertEqual([state.episode_step for state in self.lesson.states], [1, 2, 1, 2])
        self.assertEqual(env.total_steps, 4)

    def test_standalone_evaluation_supplies_selected_checkpoint_counter(self):
        case = evaluation_fixtures.EvaluationCSVTests()
        self.addCleanup(case.doCleanups)
        states = []
        calculate = Lesson.calculate_reward

        def record(lesson, state):
            states.append(state)
            return calculate(lesson, state)

        with patch.object(Lesson, "calculate_reward", record):
            case.execute()
        self.assertEqual(len(states), 2)
        self.assertEqual([state.total_steps for state in states], [1024] * 2)
        self.assertEqual([state.episode_index for state in states], [1, 1])
        np.testing.assert_allclose([state.episode_elapsed_s for state in states], [0.1, 0.2])

    def test_periodic_evaluation_preserves_training_count_and_resets_training_geometry(self):
        env = self.environment()
        env.total_steps = 1023
        env.reset()
        env.step(np.array([0.25]))
        self.lesson.states.clear()
        with tempfile.TemporaryDirectory() as temporary:
            app = SimpleNamespace(root=Path(temporary), cfg=self.settings,
                stop_event=self.stop_event,
                update_image=lambda *args: None, write_status=lambda **kwargs: None)
            options = {"eval_every_steps": 10000, "eval_episodes": 2,
                       "criterion": "success_progress_reward"}
            with patch("lane_lab.best_last.scenario_fingerprint", return_value="reward-state-fixture"):
                selector = BestLastSelector(app, temporary, env, self.lesson, 8, options)
            policy = SimpleNamespace(training=True)
            policy.set_training_mode = lambda value: setattr(policy, "training", value)
            vector = SimpleNamespace(num_envs=1, reset=Mock(side_effect=lambda: env.reset()[0][None, :]))
            model = SimpleNamespace(num_timesteps=512, _n_updates=1, policy=policy,
                predict=Mock(side_effect=AssertionError("평가에는 보관한 후보 정책을 사용해야 합니다.")),
                get_env=lambda: vector)
            snapshot = CandidateSnapshot(b"reward-state-fixture", 512, 1)
            with patch("lane_lab.best_last.capture_candidate", return_value=snapshot):
                selector.capture(model)
            # The queued candidate is older than the learner. Reward state must
            # use its saved step count, then resume the learner's current count.
            model.num_timesteps, model._n_updates = 1024, 2
            candidate = SimpleNamespace(num_timesteps=512, _n_updates=1,
                predict=Mock(return_value=(np.array([0.0]), None)))
            with patch("lane_lab.best_last.load_candidate", return_value=candidate) as load, \
                    patch("lane_lab.best_last.save_last_snapshot") as last, \
                    patch("lane_lab.best_last.save_snapshot", return_value={"timesteps": 512}) as best:
                selector.evaluate(model, restore_training=True)
            self.assertEqual([call.args for call in load.call_args_list], [(snapshot,), (snapshot,)])
            last.assert_called_once_with(model, selector.run, 8)
            self.assertIs(best.call_args.args[0], candidate)
            self.assertEqual(best.call_args.args[2], 'best')
            self.assertEqual(candidate.predict.call_count, 4)
            model.predict.assert_not_called()
            vector.reset.assert_called_once()
            self.assertEqual(selector.pending, [])
            self.assertEqual(selector.pending_bytes, 0)
            self.assertEqual(selector.evaluated_candidates, 1)
        self.assertEqual([state.total_steps for state in self.lesson.states], [512] * 4)
        self.assertEqual(env.total_steps, 1024)
        self.assertEqual(env.episodes, 2)
        self.assertTrue(model._last_episode_starts[0])
        env.step(np.array([0.0]))
        resumed = self.lesson.states[-1]
        self.assertEqual((resumed.total_steps, resumed.episode_index, resumed.episode_step), (1025, 2, 1))
        self.assertAlmostEqual(resumed.rear_distance_total_m, 0.01)
        self.assertAlmostEqual(resumed.episode_elapsed_s, 0.1)
        self.assertEqual(resumed.previous_center_xy, (0.0, 0.2))

    def test_lesson_checker_exercises_added_geometry_and_curriculum_fields(self):
        source = '''
import numpy as np
states = []
def observe(features, previous):
    return np.array([previous])
def act(action, settings):
    return dict(normalized_steer=float(action[0]), steering_rad=0.0, speed_m_s=0.1)
def calculate_reward(state):
    states.append(state)
    for reference in ('front', 'center', 'rear'):
        assert len(getattr(state, reference + '_xy')) == 2
        assert len(getattr(state, 'previous_' + reference + '_path_xy')) == 2
        assert len(state.path_point(reference, -0.15)) == 2
        assert np.isfinite(getattr(state, reference + '_heading_error_rad'))
        assert np.isfinite(getattr(state, 'previous_' + reference + '_lateral_error_m'))
        assert getattr(state, reference + '_distance_total_m') >= 0
    assert state.episode_index == state.episode_step == state.total_steps == 1
    assert state.episode_elapsed_s > 0
    assert state.physical_touched_line == (state.wheel_clearance_m <= 0)
    return state.new_progress_m, bool(state.lap_completed)
'''
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "lesson.py"
            path.write_text(source)
            lesson, size = check_lesson(path, self.settings)
        self.assertEqual(size, 1)
        self.assertEqual(len(lesson.states), 5)
        self.assertEqual([state.physical_touched_line for state in lesson.states],
                         [False, False, True, True, False])


if __name__ == "__main__":
    unittest.main()
