"""Enclosed layouts retain policy settings and explicit lap semantics."""
import json
from pathlib import Path
import shutil
from types import SimpleNamespace
import tempfile
import unittest

import numpy as np

from lane_lab.configuration import read_settings
from lane_lab.evaluation_csv import EvaluationCSV
from lane_lab.geometry import TrackGeometry
from lane_lab.worlds import build_track


PACKAGE = Path(__file__).resolve().parents[1]
PLAZA = [['P90', 'P180'], ['P0', 'P270']]
TUNNELS = [['TC90', 'TS0', 'TC180'], ['TC0', 'TS0', 'TC270']]


def drive_reference(track, reverse=False):
    tracker = track.new_tracker()
    direction = -1 if reverse else 1
    return [tracker.update(*track.route[(direction * i) % len(track.route)], .05)
            for i in range(1, len(track.route) + 1)]


class EnclosureIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.output = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.output.cleanup)
        vehicle = json.loads((PACKAGE / 'config/vehicle.json').read_text())
        build_track(PACKAGE, PLAZA, vehicle, Path(cls.output.name))
        cls.track = TrackGeometry.from_metadata(Path(cls.output.name) / 'track.json')

    def test_custom_settings_use_assets_from_the_requested_package(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            shutil.copytree(PACKAGE / 'config', root / 'config')
            with self.assertRaises(FileNotFoundError):
                read_settings(root, {'track': 'custom', 'custom_tiles': PLAZA},
                              read_design=False)
            shutil.copytree(PACKAGE / 'track_img', root / 'track_img')
            for cells in (PLAZA, TUNNELS):
                with self.subTest(cells=cells):
                    settings = read_settings(root, {'track': 'custom', 'custom_tiles': cells},
                                             read_design=False)
                    self.assertEqual(settings['custom_tiles'], cells)
            with self.assertRaisesRegex(ValueError, '8×8'):
                read_settings(root, {'track': 'custom', 'custom_tiles': [['Background'] * 9]},
                              read_design=False)

    def test_generated_circuit_completes_and_reverse_motion_does_not(self):
        self.assertEqual(self.track.reference_route_kind, 'generated_circuit')
        self.assertTrue(self.track.completion_enabled)
        forward = drive_reference(self.track)
        self.assertTrue(forward[-1].lap_completed)
        self.assertAlmostEqual(forward[-1].progress_m, self.track.length_m, delta=.002)
        self.assertFalse(any(item.lap_completed for item in forward[:len(forward) // 2]))
        reverse = drive_reference(self.track, reverse=True)
        self.assertFalse(any(item.lap_completed for item in reverse))
        self.assertLess(max(item.progress_m for item in reverse), .001)

    def test_diagnostic_route_retains_progress_without_claiming_a_lap(self):
        metadata = dict(self.track.metadata, completion_enabled=False,
                        reference_route_kind='enclosure_reference')
        diagnostic = TrackGeometry(self.track.signed_distance, self.track.route, metadata)
        normal = drive_reference(self.track)
        progress = drive_reference(diagnostic)
        self.assertFalse(any(item.lap_completed for item in progress))
        np.testing.assert_allclose([item.progress_m for item in progress],
                                   [item.progress_m for item in normal])
        np.testing.assert_allclose([item.new_progress_m for item in progress],
                                   [item.new_progress_m for item in normal])

    def test_old_saved_geometry_keeps_legacy_completion_defaults(self):
        metadata = {name: value for name, value in self.track.metadata.items()
                    if name not in ('reference_route_kind', 'completion_enabled')}
        legacy = TrackGeometry(self.track.signed_distance, self.track.route, metadata)
        self.assertEqual(legacy.reference_route_kind, 'legacy_centerline')
        self.assertTrue(legacy.completion_enabled)

    def test_evaluation_metadata_identifies_generated_and_diagnostic_routes(self):
        for kind, completion in (('generated_circuit', True), ('enclosure_reference', False)):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary:
                track = TrackGeometry(self.track.signed_distance, self.track.route,
                                      dict(self.track.metadata, reference_route_kind=kind,
                                           completion_enabled=completion))
                env = SimpleNamespace(track=track, lesson=None, grid=SimpleNamespace(rows=1, cols=1),
                                      observation_size=4, settings={})
                output = EvaluationCSV(temporary, env, {})
                output.finish('complete')
                metadata = json.loads((Path(temporary) / 'metadata.json').read_text())
                definition = metadata['coordinate_definition']
                self.assertEqual(definition['reference_route_kind'], kind)
                self.assertEqual(definition['completion_enabled'], completion)


if __name__ == '__main__':
    unittest.main()
