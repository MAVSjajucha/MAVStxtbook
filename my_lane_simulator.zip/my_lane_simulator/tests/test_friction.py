"""Directional settings, legacy migration and physical-world boundaries."""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

from lane_lab.configuration import read_settings
from lane_lab.lighting import migrate_friction_settings, validate_environment_settings
from lane_lab import worlds


PACKAGE = Path(__file__).resolve().parents[1]


class FrictionContractTests(unittest.TestCase):
    def test_zero_values_above_one_and_either_direction_larger_are_accepted(self):
        for mu1, mu2 in ((0, 0), (.2, .8), (.8, .2), (0, 2.5), (100., 1e12)):
            with self.subTest(mu1=mu1, mu2=mu2):
                result = read_settings(PACKAGE, {'friction_mu1': mu1, 'friction_mu2': mu2})
                self.assertEqual((result['friction_mu1'], result['friction_mu2']), (mu1, mu2))
                for retired in ('friction', 'static_friction', 'kinetic_friction'):
                    self.assertNotIn(retired, result)

    def test_negative_nonfinite_and_nonnumeric_values_are_rejected(self):
        for field in ('friction_mu1', 'friction_mu2', 'friction', 'static_friction'):
            for value in (-.001, float('nan'), float('inf'), -float('inf'), True, None, '0.5'):
                with self.subTest(field=field, value=value):
                    with self.assertRaisesRegex(ValueError, 'friction'):
                        read_settings(PACKAGE, {field: value})

    def test_legacy_fields_migrate_without_mutating_the_input(self):
        old = {'friction': .75, 'track_friction': 50., 'tire_friction': 60.,
               'rear_random_enabled': True, 'servo_random_enabled': 'obsolete',
               'motor_randomization': {'REAR_ERROR_PERCENT': 100., 'SERVO_BASE_DEG': 90.}}
        original = copy.deepcopy(old)
        settings = read_settings(PACKAGE, old)
        self.assertEqual((settings['friction_mu1'], settings['friction_mu2']), (.75, .75))
        for key in old:
            self.assertNotIn(key, settings)
        self.assertEqual(old, original)
        defaults = read_settings(PACKAGE, {'track_friction': 50.})
        self.assertEqual((defaults['friction_mu1'], defaults['friction_mu2']), (.5, .5))

    def test_old_static_kinetic_pair_migrates_isotropically_not_to_two_directions(self):
        for old, expected in (({'static_friction': .8, 'kinetic_friction': .2}, .8),
                              ({'static_friction': 0., 'kinetic_friction': .2, 'friction': .9}, 0.),
                              ({'friction': .7, 'kinetic_friction': .3}, .7),
                              ({'kinetic_friction': .3}, .5)):
            with self.subTest(old=old):
                result = read_settings(PACKAGE, old)
                self.assertEqual((result['friction_mu1'], result['friction_mu2']), (expected, expected))
                for key in ('static_friction', 'kinetic_friction', 'friction'):
                    self.assertNotIn(key, result)

    def test_explicit_pair_wins_over_stale_legacy_values(self):
        mixed = {'friction': 'obsolete', 'static_friction': None, 'kinetic_friction': 'obsolete',
                 'friction_mu1': .3, 'friction_mu2': .8}
        expected = {'friction_mu1': .3, 'friction_mu2': .8}
        self.assertEqual(migrate_friction_settings(mixed), expected)
        for normalize in (lambda value: read_settings(PACKAGE, value), validate_environment_settings):
            result = normalize(mixed)
            self.assertEqual((result['friction_mu1'], result['friction_mu2']), (.3, .8))
            for retired in ('friction', 'static_friction', 'kinetic_friction'):
                self.assertNotIn(retired, result)

    def test_partial_explicit_pair_preserves_legacy_fallback(self):
        settings = read_settings(PACKAGE, {'static_friction': .7, 'kinetic_friction': .1,
                                         'friction_mu2': .9})
        self.assertEqual((settings['friction_mu1'], settings['friction_mu2']), (.7, .9))
        self.assertEqual(migrate_friction_settings({'mass_kg': 2.5}), {'mass_kg': 2.5})

    def test_generated_sdf_passes_both_directions_and_removes_old_plugin(self):
        # Keep real vehicle/world generation; only expensive track distance
        # maps are unrelated to this contact contract.
        metadata = {'spawn': [1., 1., 0.], 'width_m': 3.6, 'height_m': 2.7}
        for mu1, mu2 in ((0., 0.), (.4, .75), (3.25, 1.2)):
            with self.subTest(mu1=mu1, mu2=mu2), tempfile.TemporaryDirectory() as directory:
                settings = read_settings(PACKAGE, {'friction_mu1': mu1, 'friction_mu2': mu2})
                settings.update(friction=55., static_friction=44., kinetic_friction=22.,
                                track_friction=99., tire_friction=88., vehicle={'tire_friction': 77.})
                with patch.object(worlds, 'build_track', return_value=metadata):
                    info = worlds.generate(PACKAGE, settings, directory)
                document = ET.parse(info['world_path']).getroot()
                tires = document.findall(".//model[@name='a1']/link/collision[@name='tire_collision']")
                floor = document.find(".//model[@name='floor']/link/collision")
                self.assertEqual(len(tires), 4)
                self.assertIsNotNone(floor)
                for contact in [*tires, floor]:
                    self.assertEqual(float(contact.findtext('surface/friction/ode/mu')), mu1)
                    self.assertEqual(float(contact.findtext('surface/friction/ode/mu2')), mu2)
                for values in (info, info['vehicle']):
                    self.assertEqual(values['friction_mu1'], mu1)
                    self.assertEqual(values['friction_mu2'], mu2)
                    for retired in ('static_friction', 'kinetic_friction', 'tire_friction'):
                        self.assertNotIn(retired, values)
                self.assertNotIn('lane_lab_dart_friction', Path(info['world_path']).read_text())
                controller = document.find(".//model[@name='a1']/plugin[@name='lane_lab::A1Controller']")
                self.assertIsNotNone(controller)
                self.assertIsNone(controller.find('static_friction'))
                self.assertIsNone(controller.find('kinetic_friction'))


if __name__ == '__main__':
    unittest.main()
