#!/usr/bin/env bash
export PYTHONNOUSERSITE=1
# Keep installation memory use low on student PCs. This does not limit training.
export CMAKE_BUILD_PARALLEL_LEVEL=1
# Ubuntu PC with Gazebo Fortress already installed; Python stays in .venv.
set -euo pipefail
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$LAB_ROOT"
if [[ ! -r /etc/os-release ]]; then echo 'Ubuntu 22.04 PC에서 실행하세요.'; exit 1; fi
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 22.04 || "$(uname -m)" != x86_64 ]]; then
  echo '이 설치 파일의 대상은 Ubuntu 22.04 x86_64 PC입니다. Jetson에는 exports의 차량용 폴더를 넣으세요.'; exit 1
fi
LAB_SUDO=(sudo)
if [[ "$EUID" == 0 ]]; then LAB_SUDO=(); fi
mkdir -p runtime
exec > >(tee -a runtime/install.log) 2>&1
if ! command -v ign >/dev/null 2>&1; then
  echo 'Gazebo Fortress를 찾을 수 없습니다. Ubuntu 22.04용 Fortress를 먼저 설치한 뒤 다시 실행하세요.' >&2
  exit 1
fi
if ! LAB_GAZEBO_VERSIONS="$(ign gazebo --versions 2>&1)"; then
  printf '%s\n' 'Gazebo 버전을 확인하지 못했습니다. ign gazebo --versions가 정상 실행되는지 확인하세요.' "$LAB_GAZEBO_VERSIONS" >&2
  exit 1
fi
# The unqualified ign gazebo command selects the newest installed version.
LAB_GAZEBO_VERSION="$(printf '%s\n' "$LAB_GAZEBO_VERSIONS" | sed -nE 's/^[[:space:]]*([0-9]+\.[0-9]+\.[0-9]+)[[:space:]]*$/\1/p' | sort -V | tail -n 1)"
if [[ "$LAB_GAZEBO_VERSION" != 6.* ]]; then
  printf '%s\n' '이 프로그램은 Gazebo Fortress(gazebo 6.x)가 필요합니다. ign gazebo의 기본 버전이 6.x인지 확인하세요.' "확인된 버전: ${LAB_GAZEBO_VERSIONS:-없음}" >&2
  exit 1
fi
printf 'Gazebo Fortress %s 확인 완료. Python 패키지 설치에는 인터넷이 필요합니다.\n' "$LAB_GAZEBO_VERSION"
# A fresh Fortress-only PC also needs ROS Humble and its official repository.
if ! apt-cache show ros-humble-ros-base >/dev/null 2>&1; then
  "${LAB_SUDO[@]}" apt-get update
  "${LAB_SUDO[@]}" apt-get install -y ca-certificates curl
  "${LAB_SUDO[@]}" mkdir -p /usr/share/keyrings
  "${LAB_SUDO[@]}" curl -fsSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
  printf 'deb [arch=%s signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu jammy main\n' "$(dpkg --print-architecture)" | "${LAB_SUDO[@]}" tee /etc/apt/sources.list.d/ros2.list >/dev/null
  "${LAB_SUDO[@]}" apt-get update
fi
mapfile -t LAB_PACKAGES < system_packages.txt
LAB_MISSING_PACKAGES=()
for LAB_PACKAGE in "${LAB_PACKAGES[@]}"; do
  if [[ "$(dpkg-query -W -f='${Status}' "$LAB_PACKAGE" 2>/dev/null || true)" != 'install ok installed' ]]; then
    LAB_MISSING_PACKAGES+=("$LAB_PACKAGE")
  fi
done
if (( ${#LAB_MISSING_PACKAGES[@]} )); then
  printf '%s\n' '빌드·화면 표시에 필요한 추가 패키지를 설치합니다. Ubuntu 관리자 암호가 필요할 수 있습니다.'
  "${LAB_SUDO[@]}" apt-get update
  if ! "${LAB_SUDO[@]}" apt-get install -y "${LAB_MISSING_PACKAGES[@]}"; then
    echo '추가 패키지 설치에 실패했습니다. 인터넷 연결과 기존 Ubuntu·Gazebo Fortress 패키지 저장소 설정을 확인하세요.' >&2
    exit 1
  fi
else
  printf '%s\n' '빌드·화면 표시용 시스템 패키지가 모두 설치되어 있습니다.'
fi
if [[ ! -x .venv/bin/python ]]; then
  /usr/bin/python3 -m venv --system-site-packages .venv
fi
.venv/bin/python -m pip install --upgrade 'pip<26'
.venv/bin/python -m pip install 'torch==2.5.1' --index-url https://download.pytorch.org/whl/cpu
.venv/bin/python -m pip install -r requirements.txt
# Build architecture-specific custom interfaces locally; no x86 binaries in exports.
set +u
source /opt/ros/humble/setup.bash
set -u
# CMake and ROS setup files contain absolute paths. Rebuild generated workspace
# files when installing again, including after the student moves this folder.
rm -rf -- "$LAB_ROOT/ros_ws/build" "$LAB_ROOT/ros_ws/install" "$LAB_ROOT/ros_ws/log"
(cd ros_ws && /usr/bin/python3 -m colcon build --executor sequential --merge-install --cmake-args -DPython3_EXECUTABLE=/usr/bin/python3 -DPYTHON_EXECUTABLE=/usr/bin/python3)
source "$LAB_ROOT/ros_env.sh"
rm -rf -- build/native build/gui
cmake -S native -B build/native -DCMAKE_BUILD_TYPE=Release
cmake --build build/native -j1
ctest --test-dir build/native --output-on-failure
cmake -S gui -B build/gui -DCMAKE_BUILD_TYPE=Release
cmake --build build/gui -j1
.venv/bin/python -m lane_lab check
printf '\n%s\n' '설치 완료. 다음: bash check.sh --gazebo (실제 카메라·물리 검사), 그다음 bash start.sh'
