// Gazebo Fortress transport adapter. JSON lines on stdin/stdout; binary RGB file.
// Physics and camera clocks stay in simulation time, independently of wall speed.
#include <ignition/transport/Node.hh>
#include <ignition/msgs/image.pb.h>
#include <ignition/msgs/model.pb.h>
#include <ignition/msgs/world_control.pb.h>
#include <ignition/msgs/boolean.pb.h>
#include <ignition/msgs/twist.pb.h>
#include <ignition/msgs/stringmsg.pb.h>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <stdexcept>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <fstream>
#include <iostream>
#include <mutex>
#include <memory>
#include <functional>
#include <string>
#include <thread>
#include <filesystem>
using json = nlohmann::json;
using namespace std::chrono_literals;
namespace msgs = ignition::msgs;

class Bridge {
  struct State {
    std::mutex mutex;
    std::condition_variable changed;
    msgs::Image frame;
    msgs::Pose pose;
    double poseTime = -1, frameTime = -1;
    double frontLeft = 0, frontRight = 0;
    double rearLeft = 0, rearRight = 0;
    json actuator = json::object();
  };
  // Transport callbacks own their state, never a raw Bridge pointer. On stdin
  // EOF, an in-flight callback must not access a destroyed protobuf or mutex.
  std::shared_ptr<State> state = std::make_shared<State>();
  std::string output;
  ignition::transport::Node node;
  ignition::transport::Node::Publisher cmd;
  static double Stamp(const msgs::Time &t) { return t.sec() + t.nsec()*1e-9; }
 public:
  explicit Bridge(const std::string &path) : output(path) {
    cmd = node.Advertise<msgs::Twist>("/lane_lab/cmd_vel");
    std::function<void(const msgs::Image &)> imageCallback =
      [s=state](const msgs::Image &msg) { OnImage(*s, msg); };
    std::function<void(const msgs::Model &)> stateCallback =
      [s=state](const msgs::Model &msg) { OnState(*s, msg); };
    node.Subscribe("/lane_lab/camera", imageCallback);
    node.Subscribe("/world/lane_lab/model/a1/joint_state", stateCallback);
    std::function<void(const msgs::StringMsg &)> actuatorCallback =
      [s=state](const msgs::StringMsg &msg) {
        auto value=json::parse(msg.data(),nullptr,false);
        if (!value.is_object()) return;
        std::lock_guard<std::mutex> guard(s->mutex); s->actuator=std::move(value);
      };
    node.Subscribe("/lane_lab/controller/state", actuatorCallback);
  }
  static void OnImage(State &s, const msgs::Image &msg) {
    std::lock_guard<std::mutex> guard(s.mutex);
    s.frame = msg; s.frameTime = Stamp(msg.header().stamp()); s.changed.notify_all();
  }
  static void OnState(State &s, const msgs::Model &msg) {
    std::lock_guard<std::mutex> guard(s.mutex);
    bool left=false,right=false;
    for (const auto &j : msg.joint()) {
      if (j.name()=="front_left_steering_joint") { s.frontLeft=j.axis1().position(); left=true; }
      if (j.name()=="front_right_steering_joint") { s.frontRight=j.axis1().position(); right=true; }
      if (j.name()=="rear_left_wheel_joint") s.rearLeft=j.axis1().velocity();
      if (j.name()=="rear_right_wheel_joint") s.rearRight=j.axis1().velocity();
    }
    if (left && right) {
      s.pose=msg.pose(); s.poseTime=Stamp(msg.header().stamp()); s.changed.notify_all();
    }
  }
  template<class T> void Request(const std::string &service, const T &request) {
    msgs::Boolean reply; bool result=false;
    if (!node.Request(service, request, 5000u, reply, result) || !result || !reply.data())
      throw std::runtime_error("Gazebo service failed: " + service);
  }
  void Velocity(double v, double w) {
    auto deadline = std::chrono::steady_clock::now()+15s;
    while (!cmd.HasConnections()) {
      if (std::chrono::steady_clock::now() > deadline)
        throw std::runtime_error("No Ackermann command subscriber; inspect server.log");
      std::this_thread::sleep_for(20ms);
    }
    msgs::Twist t; t.mutable_linear()->set_x(v); t.mutable_angular()->set_z(w);
    cmd.Publish(t);
    // Transport is asynchronous. The physics server is paused during delivery.
    std::this_thread::sleep_for(4ms);
  }
  void Pause() { msgs::WorldControl c; c.set_pause(true); Request("/world/lane_lab/control", c); }
  void AwaitCommand(double speed,double yawrate) {
    auto deadline=std::chrono::steady_clock::now()+10s;
    while(std::chrono::steady_clock::now()<deadline) {
      msgs::StringMsg query,answer;bool ok=false;
      if(node.Request("/lane_lab/controller/command_state",query,1000u,answer,ok)&&ok) {
        auto j=json::parse(answer.data(),nullptr,false);
        if(j.is_object()&&std::abs(j.value("speed",1e9)-speed)<1e-6&&std::abs(j.value("yawrate",1e9)-yawrate)<1e-6)return;
      }
      std::this_thread::sleep_for(1ms);
    }
    throw std::runtime_error("ROS cmd_vel delivery timeout: no matching controller command");
  }
  json Step(int count, double speed, double yawrate, bool ros=false) {
    auto &s = *state;
    if (count < 1 || count > 5000 || !std::isfinite(speed) || !std::isfinite(yawrate))
      throw std::runtime_error("Invalid step command");
    Pause();
    if (ros) AwaitCommand(speed,yawrate); else {Velocity(speed,yawrate);AwaitCommand(speed,yawrate);}
    double before;
    { std::lock_guard<std::mutex> guard(s.mutex); before = std::max(0.0, s.poseTime); }
    msgs::WorldControl c; c.set_pause(true); c.set_multi_step(count);
    Request("/world/lane_lab/control", c);
    const double expected = before + count*.001;
    std::unique_lock<std::mutex> lock(s.mutex);
    // 10 Hz control ends on a 20 Hz camera boundary. Wait for that final frame,
    // rather than racing two subscriptions and accepting the previous period.
    // A deadline reports failure instead of substituting an old observation.
    if (!s.changed.wait_for(lock, 30s, [&]{
          return s.poseTime >= expected-1e-7 && s.frameTime >= expected-.0031 && s.frameTime > before;
        })) throw std::runtime_error("Fresh camera/pose timeout: expected="+std::to_string(expected)+
               " pose="+std::to_string(s.poseTime)+" image="+std::to_string(s.frameTime));
    if (s.poseTime > expected+.0011)
      throw std::runtime_error("Physics ran beyond requested step. Pause Gazebo World Control and retry.");
    msgs::Image img=s.frame; msgs::Pose p=s.pose;
    double pt=s.poseTime, ft=s.frameTime, fl=s.frontLeft, fr=s.frontRight;
    double rl=s.rearLeft, rr=s.rearRight;
    auto actuator=s.actuator;
    lock.unlock();
    // Gazebo sensor image requested R8G8B8, explicitly check it before Python reads.
    if (img.pixel_format_type()!=msgs::RGB_INT8 || img.width()!=640 || img.height()!=480 || img.step()!=640*3 || img.data().size()!=640*480*3)
      throw std::runtime_error("Expected tightly packed RGB 640x480; check camera SDF");
    auto temporary=output+".tmp";
    { std::ofstream f(temporary, std::ios::binary); f.write(img.data().data(), img.data().size());
      if (!f) throw std::runtime_error("Cannot write camera frame"); }
    std::filesystem::rename(temporary, output);
    const auto &q=p.orientation();
    double yaw=std::atan2(2*(q.w()*q.z()+q.x()*q.y()),1-2*(q.y()*q.y()+q.z()*q.z()));
    return {{"ok",true},{"sim_time",pt},{"image_time",ft},{"pose",{p.position().x(),p.position().y(),yaw}},
            {"z",p.position().z()},{"front_angles",{fl,fr}},
            {"rear_wheel_rad_s",{rl,rr}},{"actuator",actuator},{"frame",output}};
  }
  json Reset(const json &j) {
    // Do not rewind the world clock (sensor schedules and plugins remain monotonic).
    msgs::Boolean reset; reset.set_data(true);
    Request("/lane_lab/controller/reset",reset);
    auto settled=Step(100,0,0);
    for (int i=0; i<60; ++i) {
      auto angles=settled.at("front_angles");
      auto rear=settled.at("rear_wheel_rad_s");
      if (std::abs(angles[0].get<double>())<.003 && std::abs(angles[1].get<double>())<.003 &&
          std::abs(rear[0].get<double>())<.05 && std::abs(rear[1].get<double>())<.05) break;
      settled=Step(100,0,0);
    }
    if (std::abs(settled["front_angles"][0].get<double>())>=.003 ||
        std::abs(settled["front_angles"][1].get<double>())>=.003)
      throw std::runtime_error("Steering did not return to neutral before reset");
    if (std::abs(settled["rear_wheel_rad_s"][0].get<double>())>=.05 ||
        std::abs(settled["rear_wheel_rad_s"][1].get<double>())>=.05)
      throw std::runtime_error("Rear wheels did not stop before reset");
    Request("/lane_lab/controller/reset",reset);
    msgs::Pose p; p.set_name("a1");
    p.mutable_position()->set_x(j.at("x")); p.mutable_position()->set_y(j.at("y"));
    p.mutable_position()->set_z(j.at("z"));
    double yaw=j.at("yaw");
    p.mutable_orientation()->set_w(std::cos(yaw/2));
    p.mutable_orientation()->set_z(std::sin(yaw/2));
    Request("/world/lane_lab/set_pose",p);
    return Step(200,0,0);
  }
  void Stop() { try { Velocity(0,0); Pause(); } catch (...) {} }
  json Process(const json &j) {
    std::string action=j.at("action");
    if (action=="step") return Step(j.value("steps",100),j.value("speed",0.0),j.value("yawrate",0.0));
    if (action=="ros_step") return Step(j.value("steps",100),j.value("speed",0.0),j.value("yawrate",0.0),true);
    if (action=="reset") return Reset(j);
    if (action=="stop") { Stop(); return {{"ok",true}}; }
    throw std::runtime_error("Unknown transport action");
  }
};
int main(int argc,char **argv) {
  if (argc!=2) { std::cerr << "Usage: lane_lab_bridge frame.rgb\n"; return 2; }
  Bridge b(argv[1]); std::string line;
  while (std::getline(std::cin,line)) {
    try { std::cout << b.Process(json::parse(line)).dump() << std::endl; }
    catch (const std::exception &e) { b.Stop(); std::cout << json({{"ok",false},{"error",e.what()}}).dump() << std::endl; }
  }
  b.Stop(); return 0;
}
