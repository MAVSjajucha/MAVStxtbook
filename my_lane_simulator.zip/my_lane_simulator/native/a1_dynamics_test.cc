#include "a1_dynamics.hh"
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string>
using namespace lane_lab;
void Check(bool ok, const std::string &message) {
  if (!ok) { std::cerr << message << '\n'; std::exit(1); }
}
void Near(double actual, double expected, double tolerance, const std::string &message) {
  Check(std::abs(actual - expected) <= tolerance, message);
}
void Settle(A1Dynamics &model, double v, double w, int count = 5000) {
  for (int i = 0; i < count; ++i) model.Step(v, w, .001);
}
void CheckFullSteeringRange() {
  A1Dynamics model;
  const auto &p = model.Parameters();
  // Independent reference for the A1 geometry: wheelbase 194 mm,
  // steering-pivot spacing 110 mm, and inner knuckle travel 45 degrees.
  constexpr double minimumRadius = .249;
  constexpr double centerLimit = .6618767335367579;
  constexpr double outerLimit = 32.54430468780468 * kPi / 180;
  Near(p.maxCenterAngle, centerLimit, 1e-12, "Default center limit corresponds to inner 45 degrees");
  for (double speed : {.1, .15, .2}) {
    for (double sign : {1., -1.}) {
      double yaw = sign * speed / minimumRadius;
      for (double requestScale : {1., 10.}) {
        // The maximum action must reach full travel, and an oversized yaw
        // command must saturate there rather than exceed either knuckle stop.
        model.Reset();
        Settle(model, speed, requestScale * yaw);
        const auto &target = model.Targets();
        int inner = sign > 0 ? 0 : 1, outer = 1 - inner;
        Near(target.linear, speed, 1e-12, "Full steering preserves requested teaching speed");
        Near(target.yaw, yaw, 1e-12, "Full steering yaw follows 249 mm radius");
        Near(target.centerAngle, sign * centerLimit, 1e-10, "Full center steering angle");
        Near(target.frontAngle[inner], sign * kPi / 4, 1e-10, "Inner front knuckle reaches 45 degrees");
        Near(target.frontAngle[outer], sign * outerLimit, 1e-10, "Outer front knuckle reaches 32.544 degrees");
        Near(target.rearSpeed[0], (speed - yaw * p.rearTrack / 2) / p.radius,
             1e-10, "Left rear motor follows full-steering curvature");
        Near(target.rearSpeed[1], (speed + yaw * p.rearTrack / 2) / p.radius,
             1e-10, "Right rear motor follows full-steering curvature");
        Check(target.rearSpeed[inner] < target.rearSpeed[outer], "Inner rear motor runs slower at full travel");
        Check(std::max(target.rearSpeed[0], target.rearSpeed[1]) < p.motorMaxRpm * 2 * kPi / 60,
              "Full steering at teaching speeds remains within motor RPM cap");
      }
    }
  }
}
int main() {
  CheckFullSteeringRange();
  A1Dynamics d;
  const auto &p = d.Parameters();
  Settle(d, .1, 0);
  Near(d.Targets().rearSpeed[0], .1 / p.radius, 1e-10, "Straight left speed");
  Near(d.Targets().rearSpeed[1], .1 / p.radius, 1e-10, "Straight right speed");
  double w = .1 * std::tan(.35) / p.wheelbase;
  Settle(d, .1, w);
  auto left = d.Targets();
  Check(left.rearSpeed[0] < left.rearSpeed[1], "Left turn must slow left rear");
  Near((left.rearSpeed[1] - left.rearSpeed[0]) * p.radius / p.rearTrack, w, 1e-10, "Twist angular.z is preserved");
  Near(std::tan(left.frontAngle[0]) / (1 + p.kingpinWidth / (2*p.wheelbase) * std::tan(left.frontAngle[0])),
       std::tan(left.centerAngle), 1e-10, "Common front Ackermann linkage");
  Settle(d, .1, -w);
  Near(d.Targets().rearSpeed[0], left.rearSpeed[1], 1e-10, "Turn symmetry rear");
  Near(d.Targets().frontAngle[0], -left.frontAngle[1], 1e-9, "Turn symmetry front");
  Settle(d, -.1, w);
  Check(d.Targets().centerAngle < 0, "Reverse positive yaw requires right steering");
  Check(d.Targets().rearSpeed[0] < d.Targets().rearSpeed[1], "Reverse rear yaw sign");
  Settle(d, 2, 2);
  auto capped = d.Targets();
  double cap = p.motorMaxRpm * 2 * kPi / 60;
  Near(std::max(std::abs(capped.rearSpeed[0]), std::abs(capped.rearSpeed[1])), cap, 1e-9, "Outer wheel operational RPM cap");
  Near(capped.yaw / capped.linear, 1, 1e-10, "RPM saturation preserves curvature");
  Settle(d, 0, 2);
  Near(d.Targets().linear, 0, 1e-12, "No Ackermann in-place spin v");
  Near(d.Targets().yaw, 0, 1e-12, "No Ackermann in-place spin w");
  Near(d.Targets().frontAngle[0], 0, 1e-10, "Stop returns linkage to neutral");
  d.Reset();
  auto first = d.Step(.1, w, .001);
  Near(first.linear, .001, 1e-12, "Linear acceleration limit");
  Check(first.yaw <= .001 + 1e-12, "Yaw acceleration limit");
  Check(first.centerAngle > 0 && first.centerAngle < std::atan(first.yaw*p.wheelbase/first.linear), "Finite steering time constant");
  auto old = first;
  for (int i = 0; i < 2000; ++i) {
    auto next = d.Step(.1, i < 1000 ? w : -w, .001);
    for (int j = 0; j < 2; ++j)
      Check(std::abs(next.frontAngle[j] - old.frontAngle[j]) <= .001 * p.steeringJointRate + 1e-10, "Both knuckles obey rate cap");
    old = next;
  }
  auto before = d.Targets();
  d.Step(2, 2, 0); d.Step(2, 2, -.001);
  Near(d.Targets().linear, before.linear, 0, "Paused/negative dt does not advance state");
  for (int i = 0; i < 10000; ++i) {
    double torque = d.MotorTorque(0, 1000, .001);
    Check(std::isfinite(torque) && std::abs(torque) <= p.motorTorque, "Bounded torque on overspeed");
  }
  Check(d.MotorTorque(0, 1000, .001) < 0, "Overspeed brakes instead of adding torque");
  d.Reset();
  Near(d.MotorTorque(0, 0, .001), 0, 0, "Episode reset clears PI integral");
  Settle(d, .1, 0);
  for (int i = 0; i < 20000; ++i) d.MotorTorque(0, -1000, .001);
  d.Reset();
  Near(d.Targets().frontAngle[0], 0, 0, "Reset common steering");
  Settle(d, .1, 0);
  double speed = 0;
  // Free rotor with deliberately small inertia catches overly stiff PI gains.
  for (int i = 0; i < 5000; ++i)
    speed += .001 * d.MotorTorque(0, speed, .001) / .000015;
  Near(speed, .1 / p.radius, .001, "Rear speed PI stable for small free-wheel inertia");
  // Two dt choices over the same simulated time should give the same servo state.
  A1Parameters free = p; free.linearAcceleration = free.yawAcceleration = 1e6;
  A1Dynamics fast(free), slow(free);
  for (int i = 0; i < 200; ++i) fast.Step(.1, w, .001);
  for (int i = 0; i < 100; ++i) slow.Step(.1, w, .002);
  Near(fast.Targets().centerAngle, slow.Targets().centerAngle, .001, "Dynamics independent of wall-clock speed");
  std::cout << "A1 dynamics: command mapping, independent motors, limits, 45-degree inner steering, reset, PI passed\n";
}
