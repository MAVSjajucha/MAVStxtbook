// Exercise the installed public Fortress DART plugin. No private ABI, custom
// contact adapter, ROS, rendering, or hardware commands are involved.
#include <ignition/plugin/Loader.hh>
#include <ignition/physics/RequestEngine.hh>
#include <ignition/physics/ForwardStep.hh>
#include <ignition/physics/GetEntities.hh>
#include <ignition/physics/sdf/ConstructWorld.hh>
#include <ignition/physics/dartsim/World.hh>
#include <dart/dynamics/BodyNode.hpp>
#include <dart/dynamics/ShapeNode.hpp>
#include <dart/dynamics/Skeleton.hpp>
#include <sdf/Root.hh>
#include <sdf/World.hh>
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace p = ignition::physics;
struct Features : p::FeatureList<p::GetEntities, p::ForwardStep,
    p::sdf::ConstructSdfWorld, p::dartsim::RetrieveWorld> {};
using World = p::World3dPtr<Features>;
using Engine = p::Engine3dPtr<Features>;

void Check(bool value, const std::string &message) {
  if (!value) throw std::runtime_error(message);
}

World MakeWorld(const Engine &engine, double mu1, double mu2, double yaw) {
  std::ostringstream xml;
  xml.precision(17);
  xml << "<sdf version='1.8' xmlns:ignition='http://gazebosim.org/schemas'>"
      << "<world name='friction_test'><gravity>0 0 -9.81</gravity>"
      << "<model name='floor'><static>true</static><link name='floor'>"
      << "<collision name='floor'><geometry><plane><normal>0 0 1</normal><size>100 100</size>"
      << "</plane></geometry><surface><friction><ode><mu>" << mu1 << "</mu><mu2>"
      << mu2 << "</mu2><fdir1>0 0 0</fdir1></ode></friction></surface>"
      << "</collision></link></model>"
      << "<model name='slider'><pose>0 0 0.1 0 0 " << yaw << "</pose>"
      << "<link name='direction_frame'><inertial><mass>1</mass>"
      << "<inertia><ixx>0.3366666667</ixx><iyy>0.3366666667</iyy>"
      << "<izz>0.6666666667</izz></inertia></inertial>"
      // The collision frame deliberately differs from the direction frame.
      // An ignored expressed_in attribute would swap the two friction axes.
      << "<collision name='contact'><pose>0 0 0 0 0 1.5707963267948966</pose>"
      << "<geometry><box><size>2 2 0.2</size></box></geometry>"
      << "<surface><friction><ode><mu>" << mu1 << "</mu><mu2>" << mu2
      << "</mu2><fdir1 ignition:expressed_in='direction_frame'>1 0 0</fdir1>"
      << "</ode></friction></surface></collision></link></model></world></sdf>";
  sdf::Root root;
  const auto errors = root.LoadSdfString(xml.str());
  for (const auto &error : errors) std::cerr << error << '\n';
  Check(errors.empty(), "valid directional friction SDF");
  auto world = engine->ConstructWorld(*root.WorldByIndex(0));
  Check(bool(world), "create physics world");
  world->GetDartsimWorld()->setTimeStep(.001);
  return world;
}

auto Body(const World &world) {
  return world->GetDartsimWorld()->getSkeleton("slider")->getBodyNode(0);
}
void Step(const World &world, const Eigen::Vector3d &force = Eigen::Vector3d::Zero()) {
  Body(world)->addExtForce(force, Eigen::Vector3d::Zero(), false, false);
  p::ForwardStep::Output output;
  p::ForwardStep::State state;
  p::ForwardStep::Input input;
  world->Step(output, state, input);
}

void CheckAxis(const Engine &engine, double mu1, double mu2,
               double yaw, bool secondary) {
  auto world = MakeWorld(engine, mu1, mu2, yaw);
  const auto body = Body(world);
  const auto shape = body->getShapeNodesWith<dart::dynamics::CollisionAspect>()[0];
  const auto aspect = shape->getDynamicsAspect();
  Check(std::abs(aspect->getPrimaryFrictionCoeff()-mu1) < 1e-12,
        "SDF mu must set primary coefficient independently");
  Check(std::abs(aspect->getSecondaryFrictionCoeff()-mu2) < 1e-12,
        "SDF mu2 must set secondary coefficient independently");
  Check(aspect->getFirstFrictionDirectionFrame() == body,
        "expressed_in must resolve to the non-spinning direction link");
  Check((aspect->getFirstFrictionDirection()-Eigen::Vector3d::UnitX()).norm() < 1e-12,
        "primary direction is the direction link's X axis");
  for (int i=0; i<300; ++i) Step(world);
  const double angle = yaw + (secondary ? std::acos(-1.)/2 : 0);
  const Eigen::Vector3d direction(std::cos(angle), std::sin(angle), 0);
  const double expectedMu = secondary ? mu2 : mu1;
  // A sub-limit force must be held; this coefficient is not sliding-only.
  if (expectedMu > 0) {
    const auto start = body->getWorldTransform().translation().eval();
    for (int i=0; i<200; ++i) Step(world, direction*(expectedMu*9.81*.5));
    const double moved = (body->getWorldTransform().translation()-start).head<2>().norm();
    Check(moved < .0001, "sub-limit force must not produce sliding");
  }
  for (int i=0; i<300; ++i) Step(world, direction*12.);
  const double before = body->getLinearVelocity().dot(direction);
  Check(before > .3, "super-limit force must start sliding");
  for (int i=0; i<50; ++i) Step(world);
  const double deceleration = (before-body->getLinearVelocity().dot(direction))/.05;
  Check(std::abs(deceleration-expectedMu*9.81) < .12,
        "axis-specific deceleration must match its coefficient times gravity");
  std::cout << "mu1=" << mu1 << ", mu2=" << mu2 << ", yaw=" << yaw
            << ", axis=" << (secondary ? 2 : 1)
            << ", deceleration=" << deceleration << '\n';
}

int main(int argc, char **argv) {
  Check(argc == 2, "expected the installed stock DART plugin path");
  ignition::plugin::Loader loader;
  loader.LoadLib(argv[1]);
  const auto engine = p::RequestEngine3d<Features>::From(
      loader.Instantiate("ignition::physics::dartsim::Plugin"));
  Check(bool(engine), "load stock DART adapter with public APIs");
  for (const double yaw : {0., .73}) {
    for (const bool secondary : {false, true}) {
      // Deliberately test mu2 > mu1 as well as the reverse: there is no
      // kinetic <= static ordering constraint on directional coefficients.
      CheckAxis(engine, .2, .6, yaw, secondary);
      CheckAxis(engine, .8, .3, yaw, secondary);
      CheckAxis(engine, 0., 0., yaw, secondary);
    }
  }
  std::cout << "stock DART independent-direction/rotated-frame/zero friction passed\n";
}
