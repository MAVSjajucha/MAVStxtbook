// Lane Lab A1 actuator approximation. SI units throughout; simulation time only.
// This is not Yahboom firmware or an identified motor torque-speed curve.
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <stdexcept>

namespace lane_lab {
constexpr double kPi = 3.14159265358979323846;
struct A1Parameters {
  double wheelbase = .194, rearTrack = .1737, kingpinWidth = .11;
  double radius = .033945;
  // Default inner knuckle travel is 45 degrees. The virtual center wheel
  // turns less; derive its limit from the steering-pivot geometry.
  double maxCenterAngle = std::atan(wheelbase /
      (wheelbase / std::tan(kPi / 4) + kingpinWidth / 2));
  double motorMaxRpm = 205, motorTorque = .81395195;
  double linearAcceleration = 1, yawAcceleration = 1;
  double steeringTimeConstant = .1, steeringJointRate = 3;
  double motorKp = .01, motorKi = .05;
  void Validate() const {
    for (double x : {wheelbase, rearTrack, kingpinWidth, radius, maxCenterAngle,
        motorMaxRpm, motorTorque, linearAcceleration, yawAcceleration,
        steeringTimeConstant, steeringJointRate, motorKp})
      if (!std::isfinite(x) || x <= 0) throw std::invalid_argument("A1 parameters must be finite and positive");
    if (!std::isfinite(motorKi) || motorKi < 0 || maxCenterAngle >= kPi / 2 ||
        kingpinWidth > rearTrack || kingpinWidth * std::tan(maxCenterAngle) >= 2 * wheelbase)
      throw std::invalid_argument("Invalid A1 steering geometry or PI gain");
  }
};
struct A1Targets {
  double linear = 0, yaw = 0, centerAngle = 0, saturationScale = 1;
  std::array<double, 2> rearSpeed{0, 0}, frontAngle{0, 0};
};
inline double Approach(double current, double goal, double delta) {
  return current + std::clamp(goal - current, -delta, delta);
}
inline std::array<double, 2> AckermannAngles(double center, const A1Parameters &p) {
  double t = std::tan(center), k = p.kingpinWidth / (2 * p.wheelbase);
  return {std::atan(t / (1 - k * t)), std::atan(t / (1 + k * t))};
}
class A1Dynamics {
 public:
  explicit A1Dynamics(A1Parameters parameters = {}) : p(parameters) { p.Validate(); }
  const A1Parameters &Parameters() const { return p; }
  const A1Targets &Targets() const { return out; }
  void Reset() { out = {}; integral = {0, 0}; }
  const A1Targets &Step(double requestV, double requestW, double dt) {
    if (!std::isfinite(dt) || dt <= 0) return out;
    if (!std::isfinite(requestV) || !std::isfinite(requestW)) requestV = requestW = 0;
    // Bound impossible requests *before* ramping. An Ackermann car cannot spin
    // in place, and reverse with positive yaw must steer to the right.
    const double maxW = std::abs(requestV) * std::tan(p.maxCenterAngle) / p.wheelbase;
    requestW = std::clamp(requestW, -maxW, maxW);
    ScaleAtMotorLimit(requestV, requestW);
    double v = Approach(out.linear, requestV, p.linearAcceleration * dt);
    double w = Approach(out.yaw, requestW, p.yawAcceleration * dt);
    const double allowedW = std::abs(v) * std::tan(p.maxCenterAngle) / p.wheelbase;
    w = std::clamp(w, -allowedW, allowedW);
    out.saturationScale = ScaleAtMotorLimit(v, w);
    out.linear = v; out.yaw = w;
    out.rearSpeed = {(v - w * p.rearTrack / 2) / p.radius,
                     (v + w * p.rearTrack / 2) / p.radius};
    const double rpmLimit = p.motorMaxRpm * 2 * kPi / 60;
    for (double &speed : out.rearSpeed)
      speed = std::clamp(speed, -rpmLimit, rpmLimit);
    // One virtual actuator, not two independently commanded servo shafts.
    double desired = std::abs(v) < 1e-9 ? 0 : std::atan(w * p.wheelbase / v);
    desired = std::clamp(desired, -p.maxCenterAngle, p.maxCenterAngle);
    double candidate = out.centerAngle + (desired - out.centerAngle) *
                       (-std::expm1(-dt / p.steeringTimeConstant));
    auto next = AckermannAngles(candidate, p);
    // Restrict the shared actuator until BOTH knuckles obey the joint rate.
    // Bisection preserves Ackermann geometry, including a turn through zero.
    auto tooFast = [&](const std::array<double, 2> &angle) {
      return std::max(std::abs(angle[0] - out.frontAngle[0]),
                      std::abs(angle[1] - out.frontAngle[1])) > p.steeringJointRate * dt;
    };
    if (tooFast(next)) {
      double lo = 0, hi = 1;
      for (int i = 0; i < 32; ++i) {
        double fraction = (lo + hi) / 2;
        auto angles = AckermannAngles(out.centerAngle + (candidate - out.centerAngle) * fraction, p);
        if (tooFast(angles)) hi = fraction; else lo = fraction;
      }
      candidate = out.centerAngle + (candidate - out.centerAngle) * lo;
      next = AckermannAngles(candidate, p);
    }
    out.centerAngle = candidate; out.frontAngle = next;
    return out;
  }
  double MotorTorque(int side, double measuredSpeed, double dt) {
    if (side < 0 || side > 1 || !std::isfinite(measuredSpeed) || !std::isfinite(dt) || dt <= 0) return 0;
    double error = out.rearSpeed[side] - measuredSpeed;
    // Reset residual integral once stopped, before teleporting to a new episode.
    if (std::abs(out.rearSpeed[side]) < 1e-9 && std::abs(measuredSpeed) < .02)
      integral[side] = 0;
    double candidate = std::clamp(integral[side] + p.motorKi * error * dt,
                                  -p.motorTorque, p.motorTorque);
    double raw = p.motorKp * error + candidate;
    // Conditional integration: retain only updates which do not increase saturation.
    if (std::abs(raw) <= p.motorTorque || raw * error <= 0) integral[side] = candidate;
    return std::clamp(p.motorKp * error + integral[side], -p.motorTorque, p.motorTorque);
  }
 private:
  double ScaleAtMotorLimit(double &v, double &w) const {
    double peak = std::max(std::abs(v - w * p.rearTrack / 2),
                           std::abs(v + w * p.rearTrack / 2));
    double limit = p.motorMaxRpm * 2 * kPi / 60 * p.radius;
    double factor = peak > limit ? limit / peak : 1;
    v *= factor; w *= factor;
    return factor;
  }
  A1Parameters p;
  A1Targets out;
  std::array<double, 2> integral{0, 0};
};
}  // namespace lane_lab
