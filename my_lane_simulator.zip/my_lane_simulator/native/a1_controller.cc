// Gazebo Fortress adapter for the Lane Lab A1 dynamics approximation.
#include "a1_dynamics.hh"
#include <ignition/gazebo/System.hh>
#include <ignition/gazebo/Model.hh>
#include <ignition/gazebo/components/JointPosition.hh>
#include <ignition/gazebo/components/JointVelocity.hh>
#include <ignition/gazebo/components/JointVelocityReset.hh>
#include <ignition/gazebo/components/LinearVelocityCmd.hh>
#include <ignition/gazebo/components/AngularVelocityCmd.hh>
#include <ignition/math/Vector3.hh>
#include <ignition/gazebo/components/JointForceCmd.hh>
#include <ignition/gazebo/components/JointVelocityCmd.hh>
#include <ignition/plugin/Register.hh>
#include <ignition/transport/Node.hh>
#include <ignition/msgs/boolean.pb.h>
#include <ignition/msgs/twist.pb.h>
#include <ignition/msgs/stringmsg.pb.h>
#include <nlohmann/json.hpp>
#include <ignition/common/Console.hh>
#include <sdf/Element.hh>
#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace lane_lab {
namespace sim = ignition::gazebo;
namespace components = ignition::gazebo::components;
class A1Controller final : public sim::System, public sim::ISystemConfigure,
                           public sim::ISystemPreUpdate {
 public:
  void Configure(const sim::Entity &entity, const std::shared_ptr<const sdf::Element> &sdf,
                 sim::EntityComponentManager &ecm, sim::EventManager &) override {
    sim::Model model(entity);
    modelEntity = entity;
    if (!model.Valid(ecm)) { ignerr << "A1Controller requires a model\n"; return; }
    A1Parameters p;
#define READ(field, tag) p.field = sdf->Get<double>(tag, p.field).first
    READ(wheelbase, "wheel_base"); READ(rearTrack, "wheel_separation");
    READ(kingpinWidth, "kingpin_width"); READ(radius, "wheel_radius");
    READ(maxCenterAngle, "max_center_angle"); READ(motorMaxRpm, "motor_max_rpm");
    READ(motorTorque, "motor_torque_limit"); READ(linearAcceleration, "linear_acceleration");
    READ(yawAcceleration, "yaw_acceleration"); READ(steeringTimeConstant, "steering_response_time");
    READ(steeringJointRate, "steering_joint_rate"); READ(motorKp, "motor_kp"); READ(motorKi, "motor_ki");
#undef READ
    try { dynamics = std::make_unique<A1Dynamics>(p); }
    catch (const std::exception &e) { ignerr << "A1Controller: " << e.what() << '\n'; return; }
    const std::array<std::string, 4> tags{
      "left_joint", "right_joint", "left_steering_joint", "right_steering_joint"};
    for (size_t i = 0; i < joints.size(); ++i) {
      joints[i] = model.JointByName(ecm, sdf->Get<std::string>(tags[i]));
      if (joints[i] == sim::kNullEntity) { ignerr << "A1Controller missing " << tags[i] << '\n'; dynamics.reset(); return; }
      if (!ecm.Component<components::JointPosition>(joints[i]))
        ecm.CreateComponent(joints[i], components::JointPosition());
      if (!ecm.Component<components::JointVelocity>(joints[i]))
        ecm.CreateComponent(joints[i], components::JointVelocity());
    }
    resetJoints.assign(joints.begin(), joints.end());
    // Passive front wheels also carry momentum between episodes.
    for (const auto &name : {"front_left_wheel_joint", "front_right_wheel_joint"}) {
      auto joint = model.JointByName(ecm, name);
      if (joint != sim::kNullEntity) resetJoints.push_back(joint);
    }
    node.Subscribe(sdf->Get<std::string>("topic", "/lane_lab/cmd_vel").first,
                   &A1Controller::OnCommand, this);
    node.Advertise("/lane_lab/controller/reset", &A1Controller::OnReset, this);
    node.Advertise("/lane_lab/controller/command_state", &A1Controller::OnCommandState, this);
    statePublisher = node.Advertise<ignition::msgs::StringMsg>("/lane_lab/controller/state");
  }
  void PreUpdate(const sim::UpdateInfo &info, sim::EntityComponentManager &ecm) override {
    if (!dynamics) return;
    double v, w;
    {
      std::lock_guard<std::mutex> lock(mutex);
      if (resetPending || info.simTime < previousTime) {
        dynamics->Reset(); commandV = commandW = 0; resetPending = false;
        physicsResetPending = true;
      }
      v = commandV; w = commandW;
    }
    previousTime = info.simTime;
    if (info.paused) return;
    double dt = std::chrono::duration<double>(info.dt).count();
    if (!std::isfinite(dt) || dt <= 0) return;
    if (velocityResetActive) {
      // Fortress leaves model velocity command components in place; retaining
      // zero values would freeze the vehicle forever. Remove after ONE step.
      ecm.RemoveComponent<components::LinearVelocityCmd>(modelEntity);
      ecm.RemoveComponent<components::AngularVelocityCmd>(modelEntity);
      velocityResetActive = false;
    }
    if (physicsResetPending) {
      // A pose teleport does not clear sliding at zero/low friction. Fortress
      // model velocity commands reset the free-group/root-link world velocity.
      // Zero has the same value in the world and model frames.
      SetZeroVector<components::LinearVelocityCmd>(ecm, modelEntity);
      SetZeroVector<components::AngularVelocityCmd>(ecm, modelEntity);
      for (auto joint : resetJoints)
        SetCommand<components::JointVelocityReset>(ecm, joint, 0);
      for (size_t i = 0; i < 2; ++i) {
        SetCommand<components::JointForceCmd>(ecm, joints[i], 0);
        // Do not simultaneously apply a steering velocity command and reset.
        ecm.RemoveComponent<components::JointVelocityCmd>(joints[i + 2]);
      }
      physicsResetPending = false; velocityResetActive = true;
      // Measured velocities still describe the previous physics iteration.
      // Do not reapply braking PI forces using these stale measurements.
      return;
    }
    const auto &goal = dynamics->Step(v, w, dt);
    std::array<double, 2> measuredRear{}, appliedTorque{};
    bool rearReady = true;
    for (size_t i = 0; i < joints.size(); ++i) {
      const auto *position = ecm.Component<components::JointPosition>(joints[i]);
      const auto *velocity = ecm.Component<components::JointVelocity>(joints[i]);
      // Physics fills these components after the first iteration.
      if (!position || position->Data().empty() || !velocity || velocity->Data().empty()) {
        if (i < 2) rearReady = false;
        continue;
      }
      if (i < 2) {
        // No JointVelocityCmd on the rear wheels: force-limited speed tracking.
        measuredRear[i] = velocity->Data()[0];
        appliedTorque[i] = dynamics->MotorTorque(i, measuredRear[i], dt);
        SetCommand<components::JointForceCmd>(ecm, joints[i], appliedTorque[i]);
      } else {
        // Follow a shared virtual linkage. The 3 rad/s limit is a provisional
        // KNUCKLE rate, not the manufacturer's 5.24 rad/s servo-shaft speed.
        double speed = (goal.frontAngle[i - 2] - position->Data()[0]) / dt;
        speed = std::clamp(speed, -dynamics->Parameters().steeringJointRate,
                                   dynamics->Parameters().steeringJointRate);
        SetCommand<components::JointVelocityCmd>(ecm, joints[i], speed);
      }
    }
    const double simTime = std::chrono::duration<double>(info.simTime).count();
    if (rearReady && (simTime - lastStateTime >= .05 - 1e-9 || simTime < lastStateTime)) {
      nlohmann::json state = {{"sim_time", simTime}, {"measured_speed_time", simTime - dt},
        {"requested_twist", {v, w}}, {"limited_twist", {goal.linear, goal.yaw}},
        {"target_rear_rad_s", goal.rearSpeed}, {"measured_rear_rad_s", measuredRear},
        {"applied_rear_torque_nm", appliedTorque}, {"target_front_rad", goal.frontAngle},
        {"center_angle_rad", goal.centerAngle}};
      ignition::msgs::StringMsg message;
      message.set_data(state.dump()); statePublisher.Publish(message); lastStateTime = simTime;
    }
  }
 private:
  template<typename Component>
  static void SetZeroVector(sim::EntityComponentManager &ecm, sim::Entity entity) {
    auto *command = ecm.Component<Component>(entity);
    if (!command) ecm.CreateComponent(entity, Component(ignition::math::Vector3d::Zero));
    else command->Data() = ignition::math::Vector3d::Zero;
  }
  template<typename Component>
  static void SetCommand(sim::EntityComponentManager &ecm, sim::Entity joint, double value) {
    auto *command = ecm.Component<Component>(joint);
    if (!command) ecm.CreateComponent(joint, Component({value}));
    else command->Data() = {value};
  }
  void OnCommand(const ignition::msgs::Twist &msg) {
    std::lock_guard<std::mutex> lock(mutex);
    commandV = msg.linear().x(); commandW = msg.angular().z();
    if (!std::isfinite(commandV) || !std::isfinite(commandW)) commandV = commandW = 0;
  }
  bool OnCommandState(const ignition::msgs::StringMsg &, ignition::msgs::StringMsg &response) {
    std::lock_guard<std::mutex> lock(mutex);
    response.set_data(nlohmann::json({{"speed",commandV},{"yawrate",commandW}}).dump());
    return true;
  }
  bool OnReset(const ignition::msgs::Boolean &request, ignition::msgs::Boolean &response) {
    std::lock_guard<std::mutex> lock(mutex);
    resetPending = request.data();
    if (resetPending) commandV = commandW = 0;
    response.set_data(request.data());
    return true;
  }
  ignition::transport::Node::Publisher statePublisher;
  double lastStateTime = -1;
  sim::Entity modelEntity = sim::kNullEntity;
  std::array<sim::Entity, 4> joints{};
  std::vector<sim::Entity> resetJoints;
  bool physicsResetPending = false, velocityResetActive = false;
  std::unique_ptr<A1Dynamics> dynamics;
  std::mutex mutex;
  double commandV = 0, commandW = 0;
  bool resetPending = false;
  std::chrono::steady_clock::duration previousTime{0};
  // Destroy transport subscriptions before the mutex/state they access.
  ignition::transport::Node node;
};
}  // namespace lane_lab
IGNITION_ADD_PLUGIN(lane_lab::A1Controller, ignition::gazebo::System,
                    lane_lab::A1Controller::ISystemConfigure,
                    lane_lab::A1Controller::ISystemPreUpdate)
IGNITION_ADD_PLUGIN_ALIAS(lane_lab::A1Controller, "lane_lab::A1Controller")
