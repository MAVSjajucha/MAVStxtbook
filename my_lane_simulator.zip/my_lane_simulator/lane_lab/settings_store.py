"""Recover editable settings without changing any student source file.

The last-good snapshot is advanced only after a live scene is ready. A pending
marker also survives process interruption while Gazebo is changing scenes.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import shutil
import time
import uuid

from .configuration import atomic_json, read_settings


class SettingsStore:
    def __init__(self, root):
        self.root = Path(root)
        self.runtime = self.root / 'runtime'
        self.current = self.runtime / 'settings.json'
        self.good = self.runtime / 'settings.last_good.json'
        self.pending = self.runtime / 'settings.pending.json'
        self.recovery = self.runtime / 'settings.recovery.json'
        self.warning = ''
        self.last_good = None

    def validate_snapshot(self, settings):
        return read_settings(self.root, settings, read_design=False)

    def _read(self, path):
        value = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(value, dict):
            raise ValueError('설정 파일은 JSON 객체여야 합니다.')
        return self.validate_snapshot(value)

    def _preserve(self, path, reason):
        if not path.exists():
            return None
        directory = self.runtime / 'recovery'
        directory.mkdir(parents=True, exist_ok=True)
        name = time.strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8]
        saved = directory / (name + '_' + path.name)
        shutil.copy2(path, saved)  # Preserve the original bytes, including broken JSON.
        atomic_json(saved.with_name(saved.name + '.reason.json'), {'reason': str(reason)})
        return str(saved.relative_to(self.root))

    def load(self):
        """Use saved/default values to open the editor when student files fail."""
        defaults = self.validate_snapshot(None)
        fallback = defaults
        warnings = []
        had_good = False
        if self.good.exists():
            try:
                fallback = self._read(self.good)
                had_good = True
            except Exception as exc:
                saved = self._preserve(self.good, exc)
                warnings.append(f'정상 설정 기록을 읽지 못해 기본값을 사용합니다. 보존: {saved}')
        self.last_good = copy.deepcopy(fallback)
        hold_saved_values = self.recovery.exists()
        if self.pending.exists():
            saved = self._preserve(self.pending, '지난 환경 적용이 완료되지 않았습니다.')
            self._preserve(self.current, '지난 환경 적용이 완료되지 않았습니다.')
            settings = copy.deepcopy(fallback)
            warnings.append(f'지난 환경 적용이 완료되지 않아 마지막 정상 설정(없으면 기본값)으로 복구했습니다. 보존: {saved}')
            atomic_json(self.recovery, {'reason': warnings[-1]})
            hold_saved_values = True
            # Keep this marker until the recovery itself reaches a ready scene.
            # A second interruption must not reload the unverified draft.
        elif hold_saved_values:
            settings = copy.deepcopy(fallback)
            warnings.append('이전 환경 적용 실패로 마지막 정상 설정(없으면 기본값)을 사용합니다. '
                            '환경 메뉴에서 설정을 확인하고 변경 설정 적용을 누르세요.')
        elif self.current.exists():
            try:
                settings = self._read(self.current)
            except Exception as exc:
                saved = self._preserve(self.current, exc)
                settings = copy.deepcopy(fallback)
                warnings.append(f'저장 설정 오류: {exc} 마지막 정상 설정(없으면 기본값)으로 복구했습니다. 보존: {saved}')
        else:
            settings = copy.deepcopy(fallback)

        # If an editable file is invalid, prefer the actually applied values.
        # Older distributions have no last-good file, so their valid saved values
        # are the best available fallback until the first successful scene.
        if had_good:
            for key in ('lighting',):
                settings[key] = copy.deepcopy(fallback[key])
        errors = []
        requested = read_settings(self.root, settings, design_errors=errors)
        # A syntactically valid file can still make a renderer fail. Do not
        # automatically reapply that file on every restart after a failed scene.
        if not hold_saved_values:
            settings = requested
        if errors:
            warnings.append('설정 코드 오류: ' + ' / '.join(errors) +
                            ' 파일은 그대로 보존했습니다. 저장된 정상 값 또는 기본값으로 화면을 엽니다. '
                            '환경 메뉴의 해당 설정 코드 수정 버튼으로 고친 뒤 학습 코드 검사 또는 변경 설정 적용을 누르세요.')
        self.warning = '\n'.join(warnings)
        atomic_json(self.current, settings)
        return settings

    def save(self, settings):
        """Validate before every runtime-settings write, including code checks."""
        settings = self.validate_snapshot(settings)
        atomic_json(self.current, settings)
        return settings

    def begin_apply(self, settings):
        settings = self.validate_snapshot(settings)
        atomic_json(self.pending, settings)

    def confirm_edit(self):
        """A successful explicit check/apply releases startup recovery mode."""
        self.recovery.unlink(missing_ok=True)
        self.warning = ''

    def accept(self, settings):
        settings = self.validate_snapshot(settings)
        atomic_json(self.good, settings)
        atomic_json(self.current, settings)
        self.last_good = copy.deepcopy(settings)
        self.pending.unlink(missing_ok=True)

    def reject(self, error):
        saved = self._preserve(self.pending, error)
        self._preserve(self.current, error)
        restored = self.validate_snapshot(self.last_good)
        atomic_json(self.current, restored)
        self.pending.unlink(missing_ok=True)
        self.warning = ('환경 적용에 실패하여 마지막 정상 설정(없으면 기본값)을 복구했습니다. '
                        f'적용하지 못한 설정 보존: {saved}. 원인: {error}')
        atomic_json(self.recovery, {'reason': self.warning})
        return restored
