"""Synchronous Gazebo Gymnasium environment. No teacher truth enters observation."""
import time

import gymnasium as gym
from gymnasium import spaces
import numpy as np

from .configuration import checked_action,checked_observation,checked_reward
from .geometry import TrackGeometry
from .vision import GridConfig,extract_features
from .reward_state import RewardStateBuilder


class StopRequested(Exception):
    pass


class LaneEnv(gym.Env):
    metadata={'render_modes':[]}
    def __init__(self,sim,settings,lesson,observation_size,stop_event,report=None,transition_report=None,
                 training_step_context=None):
        self.sim,self.settings,self.lesson=sim,settings,lesson
        self.observation_size=observation_size
        self.stop_event,self.report=stop_event,report
        # 평가에서만 사용한다. 학습 관측/보상/종료 조건에는 기록값을 넣지 않는다.
        self.transition_report=transition_report
        self.observation_space=spaces.Box(-np.inf,np.inf,shape=(observation_size,),dtype=np.float32)
        self.action_space=spaces.Box(-1.,1.,shape=(1,),dtype=np.float32)
        self.track=TrackGeometry.from_metadata(sim.info['track_metadata_path'])
        self.tracker=self.track.new_tracker(max_speed_mps=.25)
        self.grid=GridConfig.from_mapping(settings['vision'])
        self.reward_state=RewardStateBuilder(self.track,settings)
        # Evaluation has its own driving steps; the saved training counter stays fixed.
        self.training_step_context=training_step_context
        self.episodes=0; self.total_steps=0
        self.last_result=None; self.previous_steer=0.; self.previous_angle=0.
        self.wall_start=time.monotonic(); self.sim_advanced=0.

    def reset(self,*,seed=None,options=None):
        super().reset(seed=seed)
        if self.stop_event.is_set(): raise StopRequested()
        result=self.sim.reset()
        # Obtain one neutral frame after reset before the policy starts.
        result=self.sim.step(0.,0.)
        self.previous_steer=0.; self.previous_angle=0.
        self.previous_pose=result['pose']
        self.previous_front_angles=result['front_angles']
        self.last_result=result; self.step_count=0; self.return_sum=0.
        self.episode_touches=0; self.ever_touched=False
        self.tracker.reset(*result['pose'][:2])
        self.reward_state.reset(result['pose'],result['sim_time'])
        features=result['features']
        self.episodes+=1
        self.last_observation=checked_observation(self.lesson,features,0.,self.observation_size)
        return self.last_observation,{}

    def step(self,action):
        if self.stop_event.is_set(): raise StopRequested()
        start=time.monotonic()
        before_result=self.last_result
        # 학생 act가 action을 직접 수정하거나 observe가 같은 버퍼를 재사용해도
        # 평가 CSV에는 정책에 전달된 값과 원래 정책 출력을 남긴다.
        before_observation=(self.last_observation.copy() if self.transition_report else self.last_observation)
        recorded_action=(np.array(action,copy=True) if self.transition_report else action)
        command=checked_action(self.lesson,action,self.settings)
        result=self.sim.step(command['speed_m_s'],command['steering_rad'])
        dt=float(result['sim_time']-self.last_result['sim_time'])
        if not .095<=dt<=.105:
            raise RuntimeError(f'제어 시간 간격 오류: {dt:.4f}s. Gazebo 재생 버튼은 학습 중 사용하지 마세요.')
        features=result['features']
        truth=self.track.evaluate_pose(*result['pose'],previous_pose=self.previous_pose,
                    front_angles=result['front_angles'],previous_front_angles=self.previous_front_angles)
        progress=self.tracker.update(*result['pose'][:2],dt)
        state=self.reward_state.build(pose=result['pose'],front_angles=result['front_angles'],
              previous_pose=self.previous_pose,previous_front_angles=self.previous_front_angles,
              truth=truth,progress=progress,features=features,command=command,
              previous_steer=self.previous_steer,sim_time=result['sim_time'],dt=dt,
              episode_index=self.episodes,episode_step=self.step_count+1,
              total_steps=(self.total_steps+1 if self.training_step_context is None
                           else int(self.training_step_context)))
        self.last_reward_state=state
        score,terminated=checked_reward(self.lesson,state)
        self.step_count+=1; self.total_steps+=1; self.return_sum+=score
        touched=truth['wheel_clearance_m']<=0
        if touched and not self.ever_touched: self.episode_touches+=1
        self.ever_touched=self.ever_touched or touched
        truncated=self.step_count*.1>=float(self.settings['max_episode_seconds'])
        self.previous_pose=result['pose']; self.previous_steer=command['normalized_steer']
        self.previous_angle=command['steering_rad']; self.last_result=result
        self.previous_front_angles=result['front_angles']
        obs=checked_observation(self.lesson,features,self.previous_steer,self.observation_size)
        self.last_observation=obs
        # Speed limits wall time per control step, never enlarge physics dt.
        if self.settings['speed_mode']=='manual':
            self.stop_event.wait(max(0.,.1/self.settings['speed_factor']-(time.monotonic()-start)))
        self.sim_advanced+=dt
        info={'progress_m':progress.progress_m,'track_length_m':self.track.length_m,
              'wheel_clearance_m':truth['wheel_clearance_m'],'touched_line':touched,
              'ever_touched_line':self.ever_touched,'lap_completed':progress.lap_completed,
              'successful_lap':progress.lap_completed and not self.ever_touched,
              'reward':score,'episode_return':self.return_sum,'episode_steps':self.step_count,
              'rtf':self.sim_advanced/max(1e-6,time.monotonic()-self.wall_start)}
        if self.transition_report:
            self.transition_report(self,before_result,before_observation,recorded_action,command,result,
                                   state,info,terminated,truncated)
        if self.report: self.report(result,features,info,self)
        if terminated or truncated: self.sim.stop()
        return obs,score,terminated,truncated,info

    def close(self):
        self.sim.stop()
