"""Write local diagnostics and optionally exercise the actual installed Gazebo."""
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import uuid

from .configuration import atomic_json,check_lesson,read_settings


def diagnose(root,smoke=False):
    root=Path(root);runtime=root/'runtime';runtime.mkdir(exist_ok=True)
    report={'platform':platform.platform(),'python':platform.python_version(),'checks':{},'errors':[]}
    for key,args in {'gazebo':['ign','gazebo','--versions'],
                     'opengl':['glxinfo','-B'],
                     'memory':['free','-h']}.items():
        try:
            p=subprocess.run(args,capture_output=True,text=True,timeout=15)
            report['checks'][key]={'returncode':p.returncode,'output':p.stdout.strip(),'stderr':p.stderr.strip()}
            if p.returncode:
                detail=p.stderr.strip() or p.stdout.strip() or '출력 없음'
                report['errors'].append(f'{key} 진단 실패 (종료 코드 {p.returncode}): {detail}')
        except Exception as exc:
            report['checks'][key]={'error':str(exc)}
            report['errors'].append(f'{key} 진단 실행 실패: {exc}')
    try:
        settings=read_settings(root);_,n=check_lesson(root/'design/agent.py',settings)
        report['checks']['lesson']={'observation_size':n,'ok':True}
        for binary in ('build/native/lane_lab_bridge','build/gui/libLaneLab.so','build/native/liblane_lab_a1_controller.so'):
            if not (root/binary).exists():raise FileNotFoundError('설치되지 않았습니다: '+binary)
        if smoke:
            from .worlds import generate
            from .transport import Simulator
            from .vision import extract_features,draw_grid,GridConfig
            import cv2
            import numpy as np
            os.environ['ROS_LOCALHOST_ONLY']='1'
            os.environ['ROS_DOMAIN_ID']=str(100+(os.getpid()%100))
            os.environ['IGN_PARTITION']='lane_lab_diagnostic_'+uuid.uuid4().hex[:10]
            info=generate(root,settings,runtime/'diagnostic_world')
            sim=Simulator(root,runtime,info,settings)
            try:
                sim.start();first=sim.reset();result=first
                times=[];started=time.monotonic()
                for i in range(20):
                    before=result['sim_time'];result=sim.step(.1,0)
                    dt=result['sim_time']-before
                    if not .099<=dt<=.101:raise RuntimeError(f'시뮬레이션 시간 간격 오류 {dt}')
                    if result['image_time']<result['sim_time']-.0521:raise RuntimeError('카메라 영상 지연')
                    times.append(dt)
                distance=float(np.linalg.norm(np.array(result['pose'][:2])-np.array(first['pose'][:2])))
                if not .08<distance<.35:raise RuntimeError(f'직진 거리 오류: 2초 명령으로 {distance:.3f} m 이동')
                grid=GridConfig.from_mapping(settings['vision']);features=extract_features(result['image'],grid)
                if np.std(result['image'])<3:raise RuntimeError('카메라 영상이 거의 단색입니다. 렌더링을 확인하세요.')
                cv2.imwrite(str(runtime/'diagnostic_camera.jpg'),draw_grid(result['image'],features,grid))
                report['checks']['gazebo_smoke']={'ok':True,'steps':20,'distance_m':distance,
                      'actual_rtf':2/max(1e-6,time.monotonic()-started),
                      'camera_shape':list(result['image'].shape),'detected_features':int(features.valid_mask.sum())}
            finally:sim.close()
    except Exception as exc:
        report['errors'].append(str(exc))
    atomic_json(runtime/'doctor.json',report)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    print('진단 저장:',runtime/'doctor.json')
    return 1 if report['errors'] else 0
