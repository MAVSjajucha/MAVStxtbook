"""One configuration is shared by simulator, display, PPO and export."""
import copy
import hashlib
import importlib.util
import json
import math
from numbers import Real
from pathlib import Path

import numpy as np
from .vision import GridConfig, extract_features
from .lighting import load_lighting,validate_environment_settings,migrate_friction_settings

DEFAULT_GAMMA = 0.995


def checked_gamma(value):
    if (isinstance(value, (bool, np.bool_)) or not isinstance(value, Real)
            or not 0.0 <= value <= 1.0 or not math.isfinite(value)):
        raise ValueError('gamma: 0~1 사이의 유한한 숫자를 입력하세요. 예: gamma = 0.995')
    return float(value)


def lesson_gamma(lesson):
    # Lessons saved before this control was introduced used the fixed default.
    return checked_gamma(getattr(lesson, 'gamma', DEFAULT_GAMMA))


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def read_settings(root, changes=None, *, read_design=True, design_errors=None):
    """Validate a complete snapshot; normal commands always read student files.

    Startup recovery alone may supply ``design_errors`` to retain the already
    validated snapshot when an editable file is broken. ``read_design=False``
    validates saved/default values without touching the student's source files.
    """
    cfg = migrate_friction_settings(json.loads((Path(root)/'config/defaults.json').read_text()))
    if changes is not None:
        if not isinstance(changes, dict):
            raise ValueError('저장된 설정은 JSON 객체여야 합니다.')
        cfg.update(migrate_friction_settings(changes))
    if read_design:
        for key, name, load in (
            ('lighting', 'lighting.py', lambda: load_lighting(root)),
        ):
            try:
                cfg[key] = load()
            except (OSError, ValueError, TypeError, SyntaxError) as exc:
                message = f'design/{name}: {exc}'
                if design_errors is None:
                    raise ValueError(message) from exc
                design_errors.append(message)
    cfg=validate_environment_settings(cfg)
    # Ogre1 honors all native point/spot attenuation controls, including constant.
    cfg['render_engine']='ogre'
    # These fields are the GUI's single source of truth for extraction and display.
    cfg['vision'].update(rows=int(cfg['grid_rows']), cols=int(cfg['grid_cols']),
                         roi_bottom_px=int(cfg['roi_min']), roi_top_px=int(cfg['roi_max']))
    GridConfig.from_mapping(cfg['vision'])
    if cfg['track'] not in ('track1','track2','track3','custom'):
        raise ValueError('track은 track1, track2, track3, custom 중 하나입니다.')
    # Every persistence path validates the track that will actually be opened.
    # An unfinished custom draft must not prevent using a built-in track.
    if cfg['track'] == 'custom':
        from .worlds import validate_layout
        cells = cfg.get('custom_tiles')
        if not isinstance(cells, list) or any(not isinstance(row, list) for row in cells):
            raise ValueError('custom_tiles: 트랙 타일을 행과 열로 배열하세요.')
        validate_layout(cells, root=root)
    if cfg['speed_mode'] not in ('auto','manual'):
        raise ValueError('배속 모드는 auto 또는 manual입니다.')
    vehicle_path = Path(root)/'config/vehicle.json'
    vehicle = json.loads(vehicle_path.read_text())
    vehicle.update(cfg.get('vehicle', {}))
    wheelbase = float(vehicle['wheelbase_m'])
    kingpin = float(vehicle.get('kingpin_width_m', vehicle['wheel_track_m']))
    inner_limit = float(vehicle['max_steer_deg'])
    if not (math.isfinite(wheelbase) and wheelbase > 0 and
            math.isfinite(kingpin) and kingpin > 0 and 1 <= inner_limit <= 45):
        raise ValueError('축간거리·조향축 간격은 양수, 안쪽 최대 조향각은 1~45°여야 합니다.')
    center_limit = math.atan(wheelbase / (
        wheelbase / math.tan(math.radians(inner_limit)) + kingpin / 2))
    if not changes or 'steer_max_rad' not in changes:
        cfg['steer_max_rad'] = center_limit
    ranges = {'speed_factor':(.25,20), 'camera_pitch_deg':(-15,45),
              'mass_kg':(.5,4), 'speed_m_s':(.02,.2),
              'steer_max_rad':(.01,center_limit + 1e-10), 'camera_hfov_deg':(30,110),
              'max_episode_seconds':(10,1800), 'preview_hz':(1,10),
              'train_steps':(512,10_000_000), 'torch_threads':(1,8),
              'evaluation_episodes':(1,100), 'seed':(0,2**31-1)}
    for key,(lo,hi) in ranges.items():
        v=float(cfg[key])
        if not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'{key}: {lo}~{hi} 사이의 유한한 수를 입력하세요.')
    if float(cfg['control_hz']) != 10:
        raise ValueError('이 패키지의 제어 주기는 10 Hz입니다. 배속은 speed_factor로 바꾸세요.')
    for key in ('train_steps','seed','torch_threads','evaluation_episodes'):
        cfg[key]=int(cfg[key])
    return cfg


def load_lesson(path):
    path = Path(path)
    # compile source directly; never reuse a stale .pyc after a student edit.
    import types
    module = types.ModuleType('student_lesson')
    module.__file__ = str(path)
    exec(compile(path.read_text(encoding='utf-8'), str(path), 'exec'), module.__dict__)
    for name in ('observe','calculate_reward','act'):
        if not callable(getattr(module,name,None)):
            raise ValueError(f'{path.name}에 {name}() 함수가 필요합니다.')
    return module


def checked_observation(lesson, features, previous, expected=None):
    value=np.asarray(lesson.observe(features,previous),dtype=np.float32)
    if value.ndim!=1 or not 1<=len(value)<=1024 or not np.all(np.isfinite(value)):
        raise ValueError('observe(): 유한한 숫자로 된 1차원 배열을 반환해야 합니다.')
    if expected is not None and value.shape != (expected,):
        raise ValueError(f'입력 개수가 바뀌었습니다: 모델 {expected}, 현재 {value.size}. 새 학습을 시작하세요.')
    return value


def checked_action(lesson, action, settings):
    a=lesson.act(action,settings)
    for k in ('normalized_steer','steering_rad','speed_m_s'):
        if k not in a or not math.isfinite(float(a[k])):
            raise ValueError(f'act(): {k}에 유한한 숫자가 필요합니다.')
    if abs(a['steering_rad'])>settings['steer_max_rad']+1e-6 or abs(a['normalized_steer'])>1.000001:
        raise ValueError('act(): 차량 최대 조향 범위를 넘었습니다.')
    if not 0<=a['speed_m_s']<=.2:
        raise ValueError('act(): 실습 전진 속도는 0~0.2 m/s 범위입니다.')
    return a


def checked_reward(lesson, state):
    score,end=lesson.calculate_reward(state)
    if not np.isscalar(score) or not math.isfinite(float(score)):
        raise ValueError('calculate_reward(): 보상은 유한한 숫자 하나여야 합니다.')
    if not isinstance(end,(bool,np.bool_)):
        raise ValueError('calculate_reward(): 종료 여부는 True 또는 False여야 합니다.')
    return float(score),bool(end)


def check_lesson(path, settings):
    from .reward_state import make_sample_state
    lesson=load_lesson(path)
    lesson_gamma(lesson)
    features=extract_features(np.zeros((480,640,3),np.uint8),GridConfig.from_mapping(settings['vision']))
    size=len(checked_observation(lesson,features,0))
    for gap,progress,lap in ((.10,.01,False),(.02,0,False),(0,.01,False),(-.02,0,False),(.1,.01,True)):
        state=make_sample_state(settings,features,gap,progress,lap)
        with np.errstate(all='raise'):
            checked_reward(lesson,state)
    for a in (-1,0,1):
        checked_action(lesson,np.array([a],np.float32),settings)
    return lesson,size


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
