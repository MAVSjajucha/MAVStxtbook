"""Record the saved reward function's own intermediate values during evaluation.

평가할 때만 사용하는 래퍼입니다. 학생 보상 함수를 수정하거나 다시 실행하지 않고,
함수가 반환하는 순간의 지역 변수를 읽습니다. 기준값을 별도로 추정하지 않으므로
학생이 수식·임계값을 바꿨을 때도 실제 계산값을 기록할 수 있습니다. 삭제·개명된
변수나 배열 값은 None(CSV의 빈칸)으로 남깁니다.
"""
import math
import numbers
import sys

import numpy as np


REWARD_TERMS = ('progress', 'near_line', 'touched_line', 'finished')


def _scalar_or_none(value):
    """Keep a finite real scalar, without converting arrays or guessing values."""
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if not isinstance(value, numbers.Real):
        return None
    try:
        scalar = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return scalar if math.isfinite(scalar) else None


class RewardCapture:
    """Proxy a lesson; expose ``last_terms`` from its most recent successful call.

    ``observe`` / ``act`` and other attributes are forwarded unchanged. This
    wrapper belongs only to evaluation, never the training hot path. Profiling
    is thread-local and scoped to one reward invocation; an existing Python
    profiler receives the events too and is restored even if the lesson raises.
    """

    def __init__(self, lesson):
        self._lesson = lesson
        self.last_terms = dict.fromkeys(REWARD_TERMS)

    def __getattr__(self, name):
        return getattr(self._lesson, name)

    def calculate_reward(self, state):
        # Reset first: failures or a later branch must not reuse an earlier row.
        self.last_terms = dict.fromkeys(REWARD_TERMS)
        calculate = self._lesson.calculate_reward
        code = getattr(calculate, '__code__', None)
        if code is None:
            code = getattr(getattr(calculate, '__call__', None), '__code__', None)
        previous = sys.getprofile()
        if code is None or (previous is not None and not callable(previous)):
            # A native profiler / native callable cannot be safely inspected by
            # this Python callback. Preserve it and leave unavailable terms blank.
            return calculate(state)

        target_frame = None
        captured = {}

        def record(frame, event, arg):
            nonlocal target_frame, captured
            if target_frame is None and event == 'call' and frame.f_code is code:
                target_frame = frame
            elif frame is target_frame and event == 'return':
                captured = {key: frame.f_locals.get(key) for key in REWARD_TERMS}
            if previous is not None:
                previous(frame, event, arg)

        try:
            sys.setprofile(record)
            result = calculate(state)  # Exactly one call; its result is untouched.
        finally:
            sys.setprofile(previous)
            target_frame = None
        # This part is skipped on exceptions, so incomplete terms are not logged.
        self.last_terms = {key: _scalar_or_none(captured.get(key)) for key in REWARD_TERMS}
        return result
