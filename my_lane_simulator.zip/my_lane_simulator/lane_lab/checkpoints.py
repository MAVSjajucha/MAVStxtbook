"""Atomic PPO checkpoints and immutable experiment selection for resume."""
from __future__ import annotations

import ast
import json
import copy
import math
import os
from pathlib import Path
import uuid
import zipfile

from .configuration import (atomic_json, read_settings, sha256, DEFAULT_GAMMA,
                            checked_gamma, lesson_gamma, load_lesson)
from .lighting import migrate_friction_settings


def atomic_save_model(model, path, *, keep_previous=False):
    """Publish a complete ZIP; a failed save leaves the last good ZIP available."""
    # Old SB3 checkpoints may contain the removed actuator RNG state. It has
    # no role in the current environment and must not enter new snapshots.
    if hasattr(model, 'lane_random_state'):
        delattr(model, 'lane_random_state')
    path=Path(path)
    temporary=path.with_name('.'+path.stem+'.'+uuid.uuid4().hex+'.zip')
    try:
        model.save(temporary)
        with open(temporary,'rb') as stream:os.fsync(stream.fileno())
        # Validate before rotating: never replace the recovery file with a partial ZIP.
        checkpoint_info(temporary)
        if keep_previous and path.exists():
            path.replace(path.with_name(path.stem+'.previous.zip'))
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def checkpoint_info(path):
    """Read SB3 metadata without importing Torch or unpickling model data."""
    path=Path(path)
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:raise ValueError('손상된 PPO ZIP입니다.')
        data=json.loads(archive.read('data'))
        for name in ('policy.pth','policy.optimizer.pth'):
            if name not in archive.namelist():raise ValueError('PPO 정책 또는 옵티마이저가 없습니다.')
    return {'path':path,'timesteps':int(data['num_timesteps']),
            'ppo_updates':int(data.get('_n_updates',0)),'n_steps':int(data.get('n_steps',512)),
            'gamma':checked_gamma(data['gamma']) if 'gamma' in data else None}


def resumable_runs(root):
    """Newest experiment first; within an experiment prefer the most recent state."""
    for run in sorted((Path(root)/'runs').glob('*'),reverse=True):
        if not run.is_dir():continue
        if not all((run/name).is_file() for name in ('lesson.py','settings.json','shared_code/vision.py')):continue
        candidates=[]
        for name in ('model.zip','checkpoint.zip','checkpoint.previous.zip'):
            try:
                info=checkpoint_info(run/name)
                if info['timesteps']>0 and info['ppo_updates']>0:candidates.append(info)
            except (OSError,ValueError,KeyError,zipfile.BadZipFile,EOFError):continue
        if candidates:
            info=max(candidates,key=lambda c:(c['timesteps'],c['ppo_updates'],c['path'].name=='model.zip'))
            info['run']=run
            yield info


def resume_candidate(root):
    candidate=next(resumable_runs(root),None)
    if candidate is None:raise ValueError('이어 학습할 PPO 체크포인트가 없습니다. 먼저 새 학습을 실행하세요.')
    return candidate


def require_observation_format(root,run):
    """Do not silently resume an old input layout after the student migration."""
    defaults=json.loads((Path(root)/'config/defaults.json').read_text())
    saved=json.loads((Path(run)/'settings.json').read_text())
    legacy='grid_distances_mask_v1'
    if defaults.get('observation_format',legacy)!=saved.get('observation_format',legacy):
        raise ValueError('이 체크포인트는 이전 입력 방식입니다. 새 입력(미검출 1.1)으로 학습하려면 학습 진행을 누르세요. 기존 모델의 평가·내보내기는 가능합니다.')


def resume_status(root):
    status={'resume_available':False,'resume_steps':0,'resume_target_steps':0,
            'resume_run':'','resume_reason':'','resume_checkpoint_only':False,
            'resume_checkpoint':''}
    try:
        info=resume_candidate(root)
        # A hard interruption may leave only a complete automatic checkpoint;
        # actor selection requires training.json, which is written on shutdown.
        status.update(resume_steps=info['timesteps'],resume_run=str(info['run']),
                      resume_checkpoint_only=not (info['run']/'training.json').is_file(),
                      resume_checkpoint=str(info['path'].relative_to(Path(root))))
        path=Path(root)/'runtime/settings.json'
        current=read_settings(root,json.loads(path.read_text()) if path.exists() else None)
        settings=resume_settings(root,info,current)
        status.update(resume_available=True,resume_target_steps=int(settings['train_steps']))
    except (ValueError,OSError,KeyError,SyntaxError) as exc:
        status['resume_reason']=str(exc)
    return status


def _lesson_syntax(path):
    """Ignore guidance, unused path-offset and the legacy default gamma declaration."""
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    nodes=list(ast.walk(tree))
    doc_lookup=any((isinstance(n,ast.Name) and n.id=='__doc__') or
                   (isinstance(n,ast.Attribute) and n.attr=='__doc__') for n in nodes)
    reflective_names={'locals','vars','globals','eval','exec','__import__','inspect'}
    reflective_attrs={'currentframe','_getframe','f_locals','f_globals','__dict__',
                      '__code__','__closure__','stack','getouterframes',
                      'getinnerframes','getargvalues'}
    introspection=doc_lookup or any(
        (isinstance(n,ast.Name) and n.id in reflective_names) or
        (isinstance(n,ast.Attribute) and n.attr in reflective_attrs) for n in nodes)
    # These standalone module strings are the student's section guides. Keep
    # them significant when code can observe documentation at runtime.
    if not introspection:
        tree.body=[n for n in tree.body if not
                   (isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant)
                    and isinstance(n.value.value,str))]
        # Old lessons had no gamma declaration. Only an unused, simple default
        # declaration is equivalent; non-default values remain significant.
        gamma_names=[n for n in nodes if isinstance(n,ast.Name) and n.id=='gamma']
        gamma_binding=any((isinstance(n,ast.arg) and n.arg=='gamma') or
            (isinstance(n,(ast.Global,ast.Nonlocal)) and 'gamma' in n.names) or
            (isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name=='gamma')
            for n in nodes)
        if len(gamma_names)==1 and not gamma_binding:
            tree.body=[n for n in tree.body if not (
                isinstance(n,ast.Assign) and len(n.targets)==1 and n.targets[0] is gamma_names[0]
                and isinstance(n.value,ast.Constant) and type(n.value.value) in (int,float)
                and n.value.value==DEFAULT_GAMMA)]
    for function in tree.body:
        if not isinstance(function,ast.FunctionDef) or function.name!='calculate_reward':continue
        body_nodes=list(ast.walk(function))
        mentions=[n for n in body_nodes if isinstance(n,ast.Name) and n.id=='path_offset_m']
        other_binding=any(
            (isinstance(n,ast.arg) and n.arg=='path_offset_m') or
            (isinstance(n,(ast.Global,ast.Nonlocal)) and 'path_offset_m' in n.names) or
            (isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))
             and n.name=='path_offset_m') for n in body_nodes)
        if introspection or other_binding or len(mentions)!=1:continue
        for statement in function.body:
            if (isinstance(statement,ast.Assign) and len(statement.targets)==1
                    and statement.targets[0] is mentions[0]
                    and isinstance(statement.value,ast.Constant)
                    and type(statement.value.value) in (int,float)
                    and (type(statement.value.value) is int or math.isfinite(statement.value.value))):
                # No references, side effects, other bindings or reflection:
                # this specific starter value cannot affect the reward.
                function.body.remove(statement)
                break
    return ast.dump(tree,include_attributes=False)


def require_compatible(root,run,current):
    root,run=Path(root),Path(run)
    require_observation_format(root,run)
    saved=json.loads((run/'settings.json').read_text())
    require_action_scale(saved,current)
    for key in ('vision','grid_rows','grid_cols','roi_min','roi_max','camera_pitch_deg','camera_hfov_deg'):
        if saved.get(key)!=current.get(key):raise ValueError(f'{key} 변경: 새 학습을 시작하세요. 격자·카메라 설정 변경 후에는 이어 학습할 수 없습니다.')
    if lesson_gamma(load_lesson(run/'lesson.py'))!=lesson_gamma(load_lesson(root/'design/agent.py')):
        raise ValueError('gamma 변경: 저장된 모델과 할인율이 다릅니다. 새 학습을 시작하세요.')
    if _lesson_syntax(run/'lesson.py')!=_lesson_syntax(root/'design/agent.py'):
        raise ValueError('입력·보상·액션 코드가 변경되었습니다. 새 학습을 시작하세요.')
    for name in ('vision.py','policy_io.py'):
        if sha256(run/'shared_code'/name)!=sha256(root/'lane_lab'/name):
            raise ValueError(f'{name} 변경: 학습 당시 패키지를 사용하거나 새 학습을 시작하세요.')
    old_path=run/'vehicle_base.json'
    if old_path.exists():
        old=json.loads(old_path.read_text());old.update(saved.get('vehicle',{}))
        new=json.loads((root/'config/vehicle.json').read_text());new.update(current.get('vehicle',{}))
        for key in ('camera_width','camera_height','camera_x_m','camera_height_m','camera_pitch_deg','camera_hfov_deg'):
            if old.get(key)!=new.get(key):raise ValueError(f'차량 {key} 변경: 새 학습을 시작하세요.')


def require_action_scale(saved,current):
    if not math.isclose(float(saved['steer_max_rad']),float(current['steer_max_rad']),
                        rel_tol=0,abs_tol=1e-9):
        raise ValueError('이 체크포인트는 다른 조향 범위로 학습했습니다. 변경한 조향 범위를 적용하려면 학습 진행으로 새 학습을 시작하세요. 기존 모델의 평가·내보내기는 가능합니다.')


def require_checkpoint_gamma(candidate,run):
    # Test-only candidates may have no archive; real selections always include gamma.
    if 'gamma' in candidate and checked_gamma(candidate['gamma'])!=lesson_gamma(load_lesson(Path(run)/'lesson.py')):
        raise ValueError('선택한 model.zip의 gamma가 저장된 학습 코드와 다릅니다. 할인율을 변경하려면 새 학습을 시작하세요.')


def resume_settings(root,candidate,current):
    """Retain policy input/action semantics; train on the currently selected scene."""
    root=Path(root);run=candidate['run']
    require_compatible(root,run,current)
    require_checkpoint_gamma(candidate,run)
    saved=migrate_friction_settings(json.loads((run/'settings.json').read_text()))
    current=migrate_friction_settings(current)
    require_action_scale(saved,current)
    for key in ('track','custom_tiles','light_level','track_specular','extra_light_type','extra_lights','lighting',
                'mass_kg','friction_mu1','friction_mu2','render_engine',
                'speed_mode','speed_factor','preview_hz','torch_threads','evaluation_episodes'):
        if key in current:saved[key]=copy.deepcopy(current[key])
    # Old per-run overrides must not silently override the student's current world.
    saved.pop('vehicle',None)
    if 'vehicle' in current:saved['vehicle']=copy.deepcopy(current['vehicle'])
    saved['train_steps']=max(int(saved['train_steps']),int(current['train_steps']))
    if saved['train_steps']<=candidate['timesteps']:
        raise ValueError(f"저장된 {candidate['timesteps']:,}스텝보다 큰 목표 스텝을 입력한 뒤 이어 학습하세요.")
    return read_settings(root,saved)


def save_checkpoint(model,run):
    atomic_save_model(model,Path(run)/'checkpoint.zip',keep_previous=True)
    atomic_json(Path(run)/'checkpoint.json',{'timesteps':int(model.num_timesteps),
        'ppo_updates':int(model._n_updates),'complete_rollout_updates':True})
