"""Flat 900 mm straight and curved tunnel panels for Gazebo Fortress."""
from __future__ import annotations

import math
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np

TILE_M = 0.9
TUNNEL_WIDTH_M = 0.390
TUNNEL_HEIGHT_M = 0.220
PANEL_THICKNESS_M = 0.005
TUNNEL_RADIUS_M = 0.450


def drivable_mask(letter, pixels=900):
    """Rasterize the actual clear corridor between the tunnel wall faces.

    Image coordinates follow the track artwork: the curved panel joins north
    and east. Its four straight wall facets must also bound the driving mask;
    a circular annulus would incorrectly include pixels behind those walls.
    """
    yy, xx = (np.mgrid[:pixels, :pixels].astype(float) + .5) * (TILE_M / pixels)
    if letter == 'TS':
        inside = abs(yy - TILE_M / 2) < TUNNEL_WIDTH_M / 2
    elif letter == 'TC':
        west = TILE_M - xx
        angle = np.arctan2(yy, west)
        middle = (np.floor(angle / (math.pi / 8)) + .5) * (math.pi / 8)
        projected = west * np.cos(middle) + yy * np.sin(middle)
        factor = math.cos(math.pi / 16)
        inside = ((projected > (TUNNEL_RADIUS_M - TUNNEL_WIDTH_M / 2) * factor) &
                  (projected < (TUNNEL_RADIUS_M + TUNNEL_WIDTH_M / 2) * factor))
    else:
        raise ValueError(f'알 수 없는 터널 패널: {letter}')
    return inside.astype(np.uint8)


def friction_sdf(mu1, mu2):
    return f'<surface><friction><ode><mu>{mu1}</mu><mu2>{mu2}</mu2><fdir1>0 0 0</fdir1></ode></friction></surface>'


def _box(name, pose, size, color, mu1, mu2):
    pose = ' '.join(f'{v:.12g}' for v in pose)
    size = ' '.join(f'{v:.12g}' for v in size)
    geometry = f'<geometry><box><size>{size}</size></box></geometry>'
    return (f'<collision name="{name}"><pose>{pose}</pose>{geometry}{friction_sdf(mu1,mu2)}</collision>'
            f'<visual name="{name}"><pose>{pose}</pose>{geometry}<cast_shadows>true</cast_shadows>'
            f'<material><ambient>{color}</ambient><diffuse>{color}</diffuse><specular>0 0 0 1</specular>'
            '</material></visual>')


def _prism_mesh(path, polygon, bottom, top):
    """A convex XY polygon extruded in Z, with watertight outward faces."""
    polygon = np.asarray(polygon, dtype=float)
    area = np.sum(polygon[:, 0] * np.roll(polygon[:, 1], -1)
                  - polygon[:, 1] * np.roll(polygon[:, 0], -1))
    if area < 0:
        polygon = polygon[::-1]
    count = len(polygon)
    vertices = np.vstack((np.column_stack((polygon, np.full(count, bottom))),
                          np.column_stack((polygon, np.full(count, top)))))
    faces = []
    for index in range(1, count - 1):
        faces.extend(((0, index + 1, index), (count, count + index, count + index + 1)))
    for index in range(count):
        following = (index + 1) % count
        faces.extend(((index, following, count + following),
                      (index, count + following, count + index)))
    content = ['solid tunnel_panel']
    for face in faces:
        points = vertices[list(face)]
        normal = np.cross(points[1] - points[0], points[2] - points[0])
        normal /= np.linalg.norm(normal)
        content.append('facet normal ' + ' '.join(f'{value:.12g}' for value in normal))
        content.append(' outer loop')
        content.extend('  vertex ' + ' '.join(f'{value:.12g}' for value in point) for point in points)
        content.extend((' endloop', 'endfacet'))
    content.append('endsolid tunnel_panel')
    Path(path).write_text('\n'.join(content) + '\n')


def _mesh_panel(name, path, color, mu1, mu2):
    geometry = f'<geometry><mesh><uri>{escape(Path(path).resolve().as_uri())}</uri></mesh></geometry>'
    return (f'<collision name="{name}">{geometry}{friction_sdf(mu1, mu2)}</collision>'
            f'<visual name="{name}">{geometry}<cast_shadows>true</cast_shadows>'
            f'<material><ambient>{color}</ambient><diffuse>{color}</diffuse><specular>0 0 0 1</specular>'
            '</material></visual>')


def tunnel_sdf(row, col, letter, turns, rows, mu1, mu2, asset_dir=None):
    """Canonical curve follows the existing F corner: north to east.

    The drawing's 390 mm width is measured at the entrance/exit. Four facets
    approximate a 90° arc: the clear width normal to each wall is therefore
    390*cos(11.25°) = 382.506 mm in the curved tunnel. Meshes meet exactly at
    the entry planes, with no box corners protruding into adjacent panels.
    Every part has a separate collision name for tunnel impact detection.
    """
    if letter not in ('TS', 'TC'):
        raise ValueError(f'알 수 없는 터널 패널: {letter}')
    x, y = (col + .5) * TILE_M, (rows - row - .5) * TILE_M
    t, width, height = PANEL_THICKNESS_M, TUNNEL_WIDTH_M, TUNNEL_HEIGHT_M
    color = '0.145098039216 0.145098039216 0.145098039216 1'  # RGB37: road RGB33보다 조금 밝음.
    parts = []
    if letter == 'TS':
        for side in (-1, 1):
            parts.append(_box(f'wall_{side}', (0, side*(width+t)/2, height/2, 0, 0, 0),
                              (TILE_M, t, height), color, mu1, mu2))
        parts.append(_box('roof_0', (0, 0, height+t/2, 0, 0, 0), (TILE_M, width+2*t, t), color, mu1, mu2))
    else:
        # Arc centre is NE corner (+.45,+.45), north entry=(0,+.45), east exit=(+.45,0).
        if asset_dir is None:
            raise ValueError('곡선 터널 메시를 저장할 asset_dir가 필요합니다.')
        asset_dir = Path(asset_dir)
        asset_dir.mkdir(parents=True, exist_ok=True)
        half_angle = math.pi / 16
        inner, outer = TUNNEL_RADIUS_M - width/2, TUNNEL_RADIUS_M + width/2
        # Radial thickness is slightly larger so each flat wall is exactly 5 mm thick.
        inner_back = inner - t / math.cos(half_angle)
        outer_back = outer + t / math.cos(half_angle)
        for segment in range(4):
            angles = [math.pi + segment*math.pi/8, math.pi + (segment+1)*math.pi/8]
            def polygon(r1, r2):
                return [(.45+radius*math.cos(angle), .45+radius*math.sin(angle))
                        for radius, angle in ((r1,angles[0]),(r2,angles[0]),
                                              (r2,angles[1]),(r1,angles[1]))]
            panels = [(f'wall_inner_{segment}', polygon(inner_back,inner), 0., height),
                      (f'wall_outer_{segment}', polygon(outer,outer_back), 0., height),
                      (f'roof_{segment}', polygon(inner_back,outer_back), height, height+t)]
            for name, points, bottom, top in panels:
                path = asset_dir / f'tunnel_{row}_{col}_{name}.stl'
                _prism_mesh(path, points, bottom, top)
                parts.append(_mesh_panel(name, path, color, mu1, mu2))
    return (f'<model name="tunnel_{row}_{col}_{letter}"><static>true</static>'
            f'<pose>{x} {y} 0 0 0 {-turns*math.pi/2}</pose><link name="structure">'
            + ''.join(parts) + '</link></model>')
