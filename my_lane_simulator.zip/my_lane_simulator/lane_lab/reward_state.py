"""Simulator truth available to lesson rewards, separate from observations.

Each axle midpoint and the vehicle centre has its own global closest point on
the closed route. Distance signs and corner tangents are exactly those used by
``RearAxleProjection`` in evaluation. Travel is the sum of sampled displacement
lengths; it remains positive when reversing and is distinct from lap progress.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from .evaluation_geometry import RearAxleProjection


_REFERENCES = ("front", "center", "rear")
_WHEELS = ("front_left", "front_right", "rear_left", "rear_right")


def _pose_tuple(pose):
    values = np.asarray(pose, dtype=float)
    if values.ndim != 1 or len(values) < 3 or not np.isfinite(values[:3]).all():
        raise ValueError("pose must contain finite x, y, yaw")
    return tuple(float(value) for value in values[:3])


class RewardStateBuilder:
    """Build a reward snapshot for each transition after ``reset``.

    ``front_xy`` and ``rear_xy`` are nominal axle midpoints: the vehicle centre
    plus/minus half its wheelbase along its heading. Measured steering affects
    individual wheel centres through ``track.wheel_centers``. Body velocities
    use rear midpoint displacement and the heading halfway through the wrapped
    yaw change. All coordinates are immutable world XY tuples in metres.
    """

    def __init__(self, track, settings):
        self.track = track
        self.projection = RearAxleProjection(track.route, track.wheelbase)
        self.max_center_steering_rad = float(settings["steer_max_rad"])
        self._segment_starts = np.concatenate(
            ([0.0], np.cumsum(self.projection.lengths[:-1])))
        self._route_length = float(np.sum(self.projection.lengths))
        self._segment_positions = {
            int(original): position
            for position, original in enumerate(self.projection.segment_indices)
        }
        self._pose = None

    def _measure(self, pose):
        x, y, yaw = pose
        half = self.track.wheelbase / 2
        dx, dy = half * math.cos(yaw), half * math.sin(yaw)
        points = {"front": (x + dx, y + dy), "center": (x, y),
                  "rear": (x - dx, y - dy)}
        # Moving the synthetic midpoint forward makes its rear axle coincide
        # with the requested reference. Keep the actual rear call unchanged.
        measured = {
            "front": self.projection.measure((x + 2 * dx, y + 2 * dy, yaw)),
            "center": self.projection.measure((x + dx, y + dy, yaw)),
            "rear": self.projection.measure(pose),
        }
        return points, measured

    def reset(self, pose, sim_time):
        """Start a fresh episode at its neutral post-reset simulator sample."""
        self._pose = _pose_tuple(pose)
        self._points, self._measurements = self._measure(self._pose)
        self._reset_sim_time = float(sim_time)
        self._distance_totals = dict.fromkeys(_REFERENCES, 0.0)
        self._ever_touched_line = False

    def _path_sampler(self, measurements):
        positions = {}
        closest_points = {}
        for reference, measured in measurements.items():
            index = self._segment_positions[measured["path_segment"]]
            point = (measured["path_x_m"], measured["path_y_m"])
            closest_points[reference] = point
            along = float(np.dot(np.asarray(point) - self.projection.starts[index],
                                 self.projection.tangents[index]))
            positions[reference] = float(self._segment_starts[index] +
                np.clip(along, 0.0, self.projection.lengths[index]))

        def path_point(reference, offset_m):
            """Point offset along the route from this snapshot's projection.

            ``reference`` is ``'front'``, ``'center'`` or ``'rear'``. Positive
            offsets follow route order; negative offsets go backwards. Both
            wrap around the closed route, including offsets larger than a lap.
            """
            if reference not in positions:
                raise ValueError("reference must be 'front', 'center' or 'rear'")
            offset = float(offset_m)
            if not math.isfinite(offset):
                raise ValueError("offset_m must be finite")
            if offset == 0.0:
                return closest_points[reference]
            position = (positions[reference] + offset) % self._route_length
            index = int(np.searchsorted(self._segment_starts, position, side="right") - 1)
            point = (self.projection.starts[index] + self.projection.tangents[index] *
                     (position - self._segment_starts[index]))
            return (float(point[0]), float(point[1]))

        return path_point

    def build(self, *, pose, front_angles, previous_pose, previous_front_angles,
              truth, progress, features, command, previous_steer, sim_time, dt,
              episode_index, episode_step, total_steps):
        """Return a snapshot, then retain independent geometry for the next step.

        ``truth`` must contain the aggregate and four per-wheel swept minimum
        clearances from ``TrackGeometry.evaluate_pose``. Thus physical contact
        includes a line crossed between simulator samples. Counters describe
        the completed transition and are provided by the environment.
        """
        if self._pose is None:
            raise RuntimeError("RewardStateBuilder.reset must precede build")
        dt = float(dt)
        if not math.isfinite(dt) or dt <= 0:
            raise ValueError("dt must be finite and positive")
        current_pose = _pose_tuple(pose)
        prior_pose = _pose_tuple(previous_pose)
        points, measurements = self._measure(current_pose)
        if prior_pose == self._pose:
            previous_points, previous_measurements = self._points, self._measurements
        else:
            previous_points, previous_measurements = self._measure(prior_pose)

        values = {}
        for reference in _REFERENCES:
            values[f"{reference}_xy"] = points[reference]
            values[f"previous_{reference}_xy"] = previous_points[reference]
            for prefix, measured in (("", measurements[reference]),
                                     ("previous_", previous_measurements[reference])):
                values[f"{prefix}{reference}_path_xy"] = (
                    measured["path_x_m"], measured["path_y_m"])
                values[f"{prefix}{reference}_lateral_error_m"] = measured["lateral_error_m"]
                values[f"{prefix}{reference}_heading_error_rad"] = measured["heading_error_rad"]
            distance = math.dist(points[reference], previous_points[reference])
            self._distance_totals[reference] += distance
            values[f"{reference}_distance_step_m"] = distance
            values[f"{reference}_distance_total_m"] = self._distance_totals[reference]

        wheel_centers = self.track.wheel_centers(*current_pose, front_angles=front_angles)
        for wheel in _WHEELS:
            values[f"{wheel}_wheel_xy"] = tuple(
                float(value) for value in wheel_centers[f"{wheel}_wheel_xy"])
            values[f"{wheel}_clearance_m"] = float(truth[f"{wheel}_clearance_m"])

        yaw_delta = math.atan2(math.sin(current_pose[2] - prior_pose[2]),
                              math.cos(current_pose[2] - prior_pose[2]))
        mid_heading = prior_pose[2] + yaw_delta / 2
        dx = points["rear"][0] - previous_points["rear"][0]
        dy = points["rear"][1] - previous_points["rear"][1]
        gap = float(truth["wheel_clearance_m"])
        touched = gap <= 0.0
        self._ever_touched_line = self._ever_touched_line or touched
        values.update(
            wheel_clearance_m=gap, physical_touched_line=touched,
            ever_touched_line=self._ever_touched_line,
            new_progress_m=progress.new_progress_m, progress_m=progress.progress_m,
            lap_completed=progress.lap_completed, track_length_m=float(self.track.length_m),
            speed_m_s=float(command["speed_m_s"]),
            actual_longitudinal_speed_m_s=(dx * math.cos(mid_heading) + dy * math.sin(mid_heading)) / dt,
            actual_lateral_speed_m_s=(-dx * math.sin(mid_heading) + dy * math.cos(mid_heading)) / dt,
            actual_yaw_rate_rad_s=yaw_delta / dt,
            steer=command["normalized_steer"], previous_steer=previous_steer,
            dt=dt, sim_time=float(sim_time), episode_elapsed_s=float(sim_time) - self._reset_sim_time,
            episode_index=episode_index, episode_step=episode_step, total_steps=total_steps,
            features=features, wheelbase_m=float(self.track.wheelbase),
            wheel_track_m=float(self.track.wheel_track), wheel_width_m=float(self.track.wheel_width),
            wheel_contact_length_m=float(self.track.contact_length),
            max_center_steering_rad=self.max_center_steering_rad,
            path_point=self._path_sampler(measurements),
        )
        self._pose, self._points, self._measurements = current_pose, points, measurements
        return SimpleNamespace(**values)


def make_sample_state(settings, features, gap, progress, lap):
    """Provide every reward field to lesson validation without a simulator."""
    from .geometry import TrackGeometry

    vehicle_path = Path(__file__).resolve().parents[1] / "config" / "vehicle.json"
    vehicle = json.loads(vehicle_path.read_text(encoding="utf-8"))
    vehicle.update(settings.get("vehicle", {}))
    pose = (2.0, 0.2, 0.0)
    track = TrackGeometry(np.ones((1, 1), dtype=np.float32),
                          [(0, 0), (10, 0), (10, 10), (0, 10)],
                          {"spawn": pose, "vehicle": vehicle})
    builder = RewardStateBuilder(track, settings)
    previous_pose = (pose[0] - float(settings["speed_m_s"]) * 0.1, pose[1], pose[2])
    builder.reset(previous_pose, 0.9)
    truth = {f"{wheel}_clearance_m": float(gap) for wheel in _WHEELS}
    truth["wheel_clearance_m"] = float(gap)
    return builder.build(
        pose=pose, front_angles=(0.0, 0.0), previous_pose=previous_pose,
        previous_front_angles=(0.0, 0.0), truth=truth,
        progress=SimpleNamespace(new_progress_m=progress, progress_m=1.0, lap_completed=lap),
        features=features, command={"normalized_steer": 0.2, "speed_m_s": settings["speed_m_s"]},
        previous_steer=0.0, sim_time=1.0, dt=0.1,
        episode_index=1, episode_step=1, total_steps=1,
    )
