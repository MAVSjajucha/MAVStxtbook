"""Track truth used ONLY for simulator rewards, never policy observations.

World x points right and y up; image rows point down. Tile size is 0.9 m.
Distances use the actual road pixels between the printed white lines.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class Progress:
    new_progress_m: float
    progress_m: float
    lap_completed: bool


class ProgressTracker:
    """Project onto a LOCAL route window; only reward new furthest progress.

    The route is a closed, ordered polyline sampled at about 5 mm. Searching
    locally prevents a neighboring lane/branch from suddenly granting a lap.
    Large teleports never give progress; reset() is required after respawning.
    """

    def __init__(self, track: "TrackGeometry", max_speed_mps=0.25):
        self.track = track
        self.max_speed_mps = float(max_speed_mps)
        self.reset(*track.spawn[:2])

    def reset(self, x: float, y: float):
        p = np.array([x, y], dtype=float)
        i = int(np.argmin(np.sum((self.track.route - p) ** 2, axis=1)))
        self.index = i
        self.start_s = float(self.track.route_s[i])
        self.unwrapped_s = self.start_s
        self.furthest = self.start_s
        self.last_xy = p
        return Progress(0.0, 0.0, False)

    def update(self, x: float, y: float, dt: float) -> Progress:
        p = np.array([x, y], dtype=float)
        step_limit = self.max_speed_mps * max(float(dt), 0.0)
        displacement = float(np.linalg.norm(p - self.last_xy))
        if displacement > step_limit + 0.02:
            self.last_xy = p
            return Progress(0.0, max(0.0, self.furthest-self.start_s), False)
        # The minimum window covers several segments and low-speed physics jitter.
        window_m = max(0.05, step_limit * 2 + 0.02)
        n = len(self.track.route)
        k = min(n//4, int(math.ceil(window_m / self.track.route_step)) + 2)
        idx = (self.index + np.arange(-k, k+1)) % n
        starts = self.track.route[idx]
        vectors = self.track.route[(idx+1) % n] - starts
        lens = np.linalg.norm(vectors, axis=1)
        t = np.clip(np.sum((p-starts)*vectors, axis=1) / np.maximum(lens*lens, 1e-12), 0, 1)
        projected = starts + vectors*t[:, None]
        best = int(np.argmin(np.sum((p-projected)**2, axis=1)))
        new_index = int(idx[best])
        s = float(self.track.route_s[new_index] + t[best]*lens[best])
        old_mod = self.unwrapped_s % self.track.length_m
        delta = (s-old_mod+self.track.length_m/2) % self.track.length_m - self.track.length_m/2
        # Allow honest reverse movement to be tracked; it receives no new reward.
        if abs(delta) <= step_limit + 0.012 and np.linalg.norm(p-projected[best]) < 0.35:
            self.unwrapped_s += delta
            self.index = new_index
        old_furthest = self.furthest
        self.furthest = max(self.furthest, self.unwrapped_s)
        self.last_xy = p
        distance = max(0.0, self.furthest-self.start_s)
        return Progress(min(step_limit, max(0.0, self.furthest-old_furthest)),
                        distance, bool(getattr(self.track, 'completion_enabled', True)
                                       and distance >= self.track.length_m-0.02))


class TrackGeometry:
    """Signed distance + four tire contact patches, including swept movement.

    1 mm bitmap resolution, a half-pixel conservatism margin, and patch samples
    every 2 mm. Front patches use measured joint angles when provided; otherwise
    they use the ideal Ackermann angles derived from the steering command.
    Sweeps interpolate position, yaw and steering every <=2 mm of tire motion.
    """

    # Keep the historical concatenated patch order for existing callers.
    _wheel_names = ("rear_right", "rear_left", "front_right", "front_left")

    @classmethod
    def from_metadata(cls, path):
        path = Path(path)
        metadata = json.loads(path.read_text())
        data = np.load(path.parent / metadata["geometry_file"])
        return cls(data["signed_distance_m"], data["route"], metadata)

    def __init__(self, signed_distance_m, route, metadata):
        self.signed_distance = np.asarray(signed_distance_m, dtype=np.float32)
        self.route = np.asarray(route, dtype=np.float64)
        self.metadata = metadata
        self.reference_route_kind = metadata.get('reference_route_kind', 'legacy_centerline')
        self.completion_enabled = bool(metadata.get('completion_enabled', True))
        self.resolution = float(metadata.get("resolution_m", 0.001))
        self.height_m = self.signed_distance.shape[0] * self.resolution
        self.width_m = self.signed_distance.shape[1] * self.resolution
        self.spawn = tuple(metadata["spawn"])
        v = metadata["vehicle"]
        self.wheelbase = float(v["wheelbase_m"])
        self.wheel_track = float(v["wheel_track_m"])
        # The A1 URDF places the steering pivots inboard of the tire centres.
        # Older saved runs had coincident pivots; keep their recorded geometry.
        self.kingpin_width = float(v.get("kingpin_width_m", self.wheel_track))
        self.wheel_width = float(v["wheel_width_m"])
        self.contact_length = float(v["wheel_contact_length_m"])
        segment_lengths = np.linalg.norm(np.roll(self.route, -1, axis=0)-self.route, axis=1)
        self.route_s = np.concatenate([[0.0], np.cumsum(segment_lengths[:-1])])
        self.length_m = float(np.sum(segment_lengths))
        self.route_step = self.length_m/len(self.route)
        xx = np.linspace(-self.contact_length/2, self.contact_length/2,
                         int(math.ceil(self.contact_length/0.002))+1)
        yy = np.linspace(-self.wheel_width/2, self.wheel_width/2,
                         int(math.ceil(self.wheel_width/0.002))+1)
        self.patch = np.stack(np.meshgrid(xx, yy), -1).reshape(-1, 2)

    def new_tracker(self, max_speed_mps=0.25):
        return ProgressTracker(self, max_speed_mps)

    def clearance_at_points(self, points):
        p = np.asarray(points, dtype=float)
        # Pixel centers sit at (col+.5)*resolution, height-(row+.5)*resolution.
        col = np.rint(p[:, 0]/self.resolution-0.5).astype(int)
        row = np.rint((self.height_m-p[:, 1])/self.resolution-0.5).astype(int)
        inside = ((col >= 0) & (col < self.signed_distance.shape[1]) &
                  (row >= 0) & (row < self.signed_distance.shape[0]))
        result = np.full(len(p), -1.0, dtype=float)
        result[inside] = self.signed_distance[row[inside], col[inside]] - self.resolution*0.75
        return result

    def _wheel_points(self, points, x, y, yaw, steer_rad, front_angles=None):
        """Transform the same tire-local samples for each wheel, in patch order."""
        out = []
        c, s = math.cos(yaw), math.sin(yaw)
        world_rotation = np.array([[c, s], [-s, c]])
        for front in (-1, 1):
            for left in (-1, 1):
                # Ackermann tire angles differ at the inner and outer wheels.
                angle = 0.0
                if front == 1 and front_angles is not None:
                    angle = float(front_angles[0 if left == 1 else 1])
                elif front == 1 and abs(steer_rad) > 1e-9:
                    radius = self.wheelbase/math.tan(steer_rad)
                    angle = math.atan(self.wheelbase/(radius-left*self.kingpin_width/2))
                ca, sa = math.cos(angle), math.sin(angle)
                rotation = np.array([[ca, sa], [-sa, ca]])
                if front == 1:
                    offset = left*(self.wheel_track-self.kingpin_width)/2
                    local = (points + (0, offset)) @ rotation
                    local += (self.wheelbase/2, left*self.kingpin_width/2)
                else:
                    local = points + (-self.wheelbase/2, left*self.wheel_track/2)
                out.append(local @ world_rotation + (x, y))
        return np.stack(out)

    def _patch_points(self, x, y, yaw, steer_rad, front_angles=None):
        return self._wheel_points(self.patch, x, y, yaw, steer_rad, front_angles).reshape(-1, 2)

    def wheel_centers(self, x, y, yaw, steer_rad=0.0, front_angles=None):
        """World tire centers, including steering around the inboard kingpins.

        Measured ``front_angles`` are ordered (left, right), in radians, and
        override the Ackermann angles derived from ``steer_rad``.
        """
        centers = self._wheel_points(np.zeros((1, 2)), x, y, yaw, steer_rad, front_angles)[:, 0]
        return {f"{name}_wheel_xy": tuple(float(v) for v in center)
                for name, center in zip(self._wheel_names, centers)}

    def wheel_clearances(self, x, y, yaw, steer_rad=0.0, front_angles=None):
        """Instantaneous signed minimum clearance over each tire contact patch."""
        points = self._patch_points(x, y, yaw, steer_rad, front_angles)
        clearances = self.clearance_at_points(points).reshape(4, len(self.patch)).min(axis=1)
        return {f"{name}_clearance_m": float(value)
                for name, value in zip(self._wheel_names, clearances)}

    def wheel_clearance(self, x, y, yaw, steer_rad=0.0, front_angles=None):
        return float(np.min(list(self.wheel_clearances(x, y, yaw, steer_rad, front_angles).values())))

    def evaluate_pose(self, x, y, yaw, previous_pose=None, steer_rad=0.0,
                      previous_steer_rad=0.0, front_angles=None, previous_front_angles=None):
        """front_angles and previous_front_angles: measured (left, right), radians.

        When measured angles are supplied, the command angles are ignored. A
        caller evaluating a sweep must supply the previous measured angles too.
        Each wheel's clearance is its minimum over the same sweep samples as
        the aggregate ``wheel_clearance_m``. Use wheel_centers for current XY.
        """
        if front_angles is not None:
            front_angles = np.asarray(front_angles, dtype=float)
            if front_angles.shape != (2,) or not np.isfinite(front_angles).all():
                raise ValueError("front_angles must contain finite left/right radians")
            if previous_pose is not None and previous_front_angles is None:
                raise ValueError("A measured-angle sweep needs previous_front_angles")
            if previous_front_angles is not None:
                previous_front_angles = np.asarray(previous_front_angles, dtype=float)
                if previous_front_angles.shape != (2,) or not np.isfinite(previous_front_angles).all():
                    raise ValueError("previous_front_angles must contain finite left/right radians")
        clearances = self.wheel_clearances(x, y, yaw, steer_rad, front_angles)
        if previous_pose is not None:
            px, py, pa = previous_pose[:3]
            angle = (yaw-pa+math.pi) % (2*math.pi)-math.pi
            travel = math.hypot(x-px, y-py) + math.hypot(self.wheelbase/2, self.wheel_track/2)*abs(angle)
            angular_travel = (float(np.max(np.abs(front_angles-previous_front_angles)))
                              if front_angles is not None else abs(steer_rad-previous_steer_rad))
            sweep_radius = math.hypot(self.contact_length/2,
                self.wheel_width/2+abs(self.wheel_track-self.kingpin_width)/2)
            travel += max(self.wheel_width, self.contact_length, sweep_radius)*angular_travel
            count = max(1, int(math.ceil(travel/0.002)))
            for a in np.linspace(0.0, 1.0, count+1):
                angles = (previous_front_angles+(front_angles-previous_front_angles)*a
                          if front_angles is not None else None)
                sample = self.wheel_clearances(px+(x-px)*a, py+(y-py)*a,
                    pa+angle*a, previous_steer_rad+(steer_rad-previous_steer_rad)*a, angles)
                clearances = {name: min(value, sample[name])
                              for name, value in clearances.items()}
        result = float(np.min(list(clearances.values())))
        return {"wheel_clearance_m": result, "touched_line": result <= 0.0, **clearances}
