"""Validate white-line and tunnel-wall enclosures from the actual tile artwork.

An enclosure may contain junctions, wide internal seams or several independent
regions. Its reference driving route is chosen separately by ``worlds``.
"""
from __future__ import annotations

from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image

from .tunnels import drivable_mask

PIXELS = 900
OPENING_TOLERANCE_PX = 3
OPPOSITE = {'N': 'S', 'E': 'W', 'S': 'N', 'W': 'E'}
STEP = {'N': (-1, 0), 'E': (0, 1), 'S': (1, 0), 'W': (0, -1)}


def tile_mask(rgb, letter):
    """Return the lane interior, excluding paint, green and dark shoulders.

    A--K retain their original pixel geometry. L--P have one connected interior
    component with wider edge openings. Tunnel masks follow physical walls.
    """
    import cv2

    if letter == 'Background':
        return np.zeros((PIXELS, PIXELS), np.uint8)
    if letter in ('TS', 'TC'):
        return drivable_mask(letter, PIXELS)
    dark = ((np.max(rgb, axis=2) < 80) &
            (np.ptp(rgb.astype(np.int16), axis=2) < 12))
    seed = (450, 450) if letter in 'ABCDELMNOP' else (580, 320)
    flood = dark.astype(np.uint8)
    cv2.floodFill(flood, None, seed, 2)
    mask = (flood == 2).astype(np.uint8)
    if mask.sum() < 100000:
        raise ValueError(f'{letter} 타일에서 차선 내부를 찾지 못했습니다.')
    return mask


def _runs(values):
    """Inclusive pixel intervals in a binary edge, in image-axis order."""
    changes = np.flatnonzero(np.diff(np.pad(np.asarray(values, bool), (1, 1))))
    return tuple((int(start), int(stop - 1))
                 for start, stop in zip(changes[::2], changes[1::2]))


def _openings(mask):
    edges = {'N': mask[0], 'E': mask[:, -1], 'S': mask[-1], 'W': mask[:, 0]}
    return {edge: runs for edge, values in edges.items() if (runs := _runs(values))}


def analyze_layout(cells, parse_tile, root):
    """Validate enclosure boundaries and return masks, openings and components.

    The caller validates the rectangular grid and its size. Returned mappings:
    ``canonical_masks[letter]`` and ``rotated_masks[(letter, turns)]`` contain
    900×900 uint8 masks; ``tiles[(row, col)]`` includes Background tiles;
    ``openings[(row, col)][edge]`` holds inclusive (first, last) pixel intervals
    for each open edge of a road tile. Edge coordinates increase left to right
    on N/S and top to bottom on E/W. ``adjacency`` and ``components`` contain
    road coordinates only. Components and their members are deterministically
    sorted. Several independently enclosed components are valid.
    """
    if not cells or not cells[0]:
        raise ValueError('주행 구역을 만들 도로 타일을 배치하세요.')
    root = Path(root)
    tiles = {(r, c): parse_tile(token)
             for r, row in enumerate(cells) for c, token in enumerate(row)}
    road = {position for position, (letter, _) in tiles.items() if letter != 'Background'}
    if not road:
        raise ValueError('주행 구역을 만들 도로 타일을 배치하세요.')
    canonical_masks, rotated_masks, opening_cache, openings = {}, {}, {}, {}
    for position, (letter, turns) in tiles.items():
        if letter not in canonical_masks:
            if letter in ('Background', 'TS', 'TC'):
                rgb = np.full((PIXELS, PIXELS, 3), 33, np.uint8)
            else:
                with Image.open(root / 'track_img' / f'Track-{letter}.png') as artwork:
                    rgb = np.asarray(artwork.convert('RGB'))
            canonical_masks[letter] = tile_mask(rgb, letter)
        key = (letter, turns)
        if key not in rotated_masks:
            rotated_masks[key] = np.rot90(canonical_masks[letter], -turns)
            opening_cache[key] = _openings(rotated_masks[key])
        if position in road:
            openings[position] = opening_cache[key]

    adjacency = {position: set() for position in sorted(road)}
    for position in sorted(road):
        row, col = position
        for edge, own_runs in openings[position].items():
            dr, dc = STEP[edge]
            neighbor = (row + dr, col + dc)
            other_runs = openings.get(neighbor, {}).get(OPPOSITE[edge], ())
            if not other_runs:
                raise ValueError(f'{row + 1}행 {col + 1}열의 {edge} 방향 주행 구역이 열려 있습니다. '
                                 '이웃 타일과 연결하여 흰 차선 또는 터널 벽으로 둘러싸세요.')
            if (len(own_runs) != len(other_runs) or
                    any(abs(a - b) > OPENING_TOLERANCE_PX
                        for own_run, other_run in zip(own_runs, other_runs)
                        for a, b in zip(own_run, other_run))):
                raise ValueError(f'{row + 1}행 {col + 1}열의 {edge} 방향 출입구 폭이나 위치가 '
                                 '이웃 타일과 맞지 않습니다. 넓은 주행 구역의 경계까지 연결하세요.')
            adjacency[position].add(neighbor)

    components, unseen = [], set(road)
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        queue, component = deque([start]), []
        while queue:
            position = queue.popleft()
            component.append(position)
            for neighbor in sorted(adjacency[position] & unseen):
                unseen.remove(neighbor)
                queue.append(neighbor)
        components.append(tuple(sorted(component)))
    return {'canonical_masks': canonical_masks, 'rotated_masks': rotated_masks,
            'tiles': tiles, 'openings': openings,
            'adjacency': {position: tuple(sorted(neighbors))
                          for position, neighbors in adjacency.items()},
            'components': tuple(components)}
