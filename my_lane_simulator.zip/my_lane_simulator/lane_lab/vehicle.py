"""Manufacturer A1 URDF -> portable Fortress SDF, without ROS/xacro at run time.

The nine CAD visuals, colors, inertial origins and articulated link offsets come
from the shipped source URDF. Only collision shapes are simplified for speed.
The original file is kept byte-for-byte in assets/vehicle/urdf for inspection.
"""
from __future__ import annotations

import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

LINK_NAMES = {
    "left_steering_hinge_joint": "front_left_steering_link",
    "right_steering_hinge_joint": "front_right_steering_link",
    "left_front_wheel_joint": "front_left_wheel",
    "right_front_wheel_joint": "front_right_wheel",
    "left_rear_wheel_hinge": "rear_left_wheel",
    "right_rear_wheel_hinge": "rear_right_wheel",
}
JOINT_NAMES = {
    "left_steering_hinge_joint": "front_left_steering_joint",
    "right_steering_hinge_joint": "front_right_steering_joint",
    "left_front_wheel_joint": "front_left_wheel_joint",
    "right_front_wheel_joint": "front_right_wheel_joint",
    "left_rear_wheel_hinge": "rear_left_wheel_joint",
    "right_rear_wheel_hinge": "rear_right_wheel_joint",
    "camera_joint": "camera_hinge",
    "laser": "laser_mount",
}


def _numbers(value):
    return np.fromstring(value, sep=" ")


def _text(values):
    return " ".join(f"{float(x):.12g}" for x in values)


def _add(parent, tag, text=None, **attributes):
    node = ET.SubElement(parent, tag, attributes)
    if text is not None:
        node.text = str(text)
    return node


def _origin(node):
    origin = node.find("origin")
    if origin is None:
        return np.zeros(6)
    return np.r_[_numbers(origin.get("xyz", "0 0 0")),
                 _numbers(origin.get("rpy", "0 0 0"))]


def _transform(pose):
    x, y, z, r, p, a = pose
    cr, sr, cp, sp, ca, sa = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(a), math.sin(a)
    result = np.eye(4)
    result[:3, :3] = [[ca*cp, ca*sp*sr-sa*cr, ca*sp*cr+sa*sr],
                      [sa*cp, sa*sp*sr+ca*cr, sa*sp*cr-ca*sr],
                      [-sp, cp*sr, cp*cr]]
    result[:3, 3] = x, y, z
    return result


def _pose(transform):
    m = transform
    p = math.atan2(-m[2, 0], math.hypot(m[0, 0], m[1, 0]))
    r, a = math.atan2(m[2, 1], m[2, 2]), math.atan2(m[1, 0], m[0, 0])
    return np.r_[m[:3, 3], r, p, a]


def _inertial(link, source, scale):
    original = source.find("inertial")
    inertial = _add(link, "inertial")
    _add(inertial, "pose", _text(_origin(original)))
    _add(inertial, "mass", float(original.find("mass").get("value"))*scale)
    inertia = _add(inertial, "inertia")
    for name in ("ixx", "ixy", "ixz", "iyy", "iyz", "izz"):
        _add(inertia, name, float(original.find("inertia").get(name))*scale)


def _visual(link, source, assets):
    for i, source_visual in enumerate(source.findall("visual")):
        visual = _add(link, "visual", name=f"manufacturer_mesh_{i}")
        _add(visual, "pose", _text(_origin(source_visual)))
        geometry = _add(visual, "geometry")
        source_mesh = source_visual.find("geometry/mesh")
        if source_mesh is None:
            raise ValueError("A1 제조사 URDF에 예상하지 않은 비메시 형상이 있습니다.")
        package_uri = source_mesh.get("filename", "")
        prefix = "package://yahboomcar_description/"
        if not package_uri.startswith(prefix):
            raise ValueError(f"알 수 없는 차량 메시 경로: {package_uri}")
        path = (assets/package_uri[len(prefix):]).resolve()
        if not path.is_relative_to(assets.resolve()) or not path.is_file():
            raise FileNotFoundError(f"차량 메시를 찾지 못했습니다: {path}")
        mesh = _add(geometry, "mesh")
        _add(mesh, "uri", path.as_uri())
        if source_mesh.get("scale"):
            _add(mesh, "scale", source_mesh.get("scale"))
        color = source_visual.find("material/color")
        if color is not None:
            material = _add(visual, "material")
            _add(material, "ambient", color.get("rgba"))
            _add(material, "diffuse", color.get("rgba"))
            _add(material, "specular", "0.08 0.08 0.08 1")
        _add(visual, "cast_shadows", "false")


def _collision(link, name, v):
    if name == "base_link":
        collision = _add(link, "collision", name="chassis_collision")
        # Bounding volume of the manufacturer's chassis mesh. This is not a visual.
        _add(collision, "pose", "0.01017 0 0.06825 0 0 0")
        box = _add(_add(collision, "geometry"), "box")
        _add(box, "size", "0.27454 0.161 0.1445")
    elif name.endswith("_wheel"):
        collision = _add(link, "collision", name="tire_collision")
        _add(collision, "pose", f"0 0 0 {math.pi/2} 0 0")
        cylinder = _add(_add(collision, "geometry"), "cylinder")
        _add(cylinder, "radius", v["wheel_radius_m"])
        _add(cylinder, "length", v["wheel_width_m"])
        ode = _add(_add(_add(collision, "surface"), "friction"), "ode")
        _add(ode, "mu", v["friction_mu1"])
        _add(ode, "mu2", v["friction_mu2"])
        # 첫 번째 방향은 타이어 구름 방향, 두 번째는 그에 수직인 옆 방향입니다.
        # 바퀴 자체의 프레임은 구르면서 회전하므로 조향 링크/차체를 참조합니다.
        # Fortress DART의 공식 ignition:expressed_in 확장으로 방향을 지정합니다.
        direction_frame = (name.replace("_wheel", "_steering_link")
                           if name.startswith("front_") else "base_link")
        _add(ode, "fdir1", "1 0 0", **{"ignition:expressed_in": direction_frame})


def _camera(link, v):
    sensor = _add(link, "sensor", name="rgb", type="camera")
    # Camera housing extends to x=27.65 mm. Place the optical center ahead of
    # that face to avoid self-occlusion. This mounting offset is an estimate.
    _add(sensor, "pose", "0.029 0 0.015 0 0 0")
    _add(sensor, "always_on", "true")
    _add(sensor, "update_rate", v["camera_fps"])
    _add(sensor, "topic", "/lane_lab/camera")
    camera = _add(sensor, "camera")
    _add(camera, "horizontal_fov", math.radians(v["camera_hfov_deg"]))
    image = _add(camera, "image")
    _add(image, "width", 640)
    _add(image, "height", 480)
    _add(image, "format", "R8G8B8")
    clip = _add(camera, "clip")
    _add(clip, "near", 0.02)
    _add(clip, "far", 20)


def vehicle_sdf(root, v, spawn, config):
    assets = Path(root)/"assets/vehicle"
    urdf = ET.parse(assets/"urdf/yahboomcar_A1.src.urdf").getroot()
    source_links = {link.get("name"): link for link in urdf.findall("link")}
    source_joints = {joint.find("child").get("link"): joint for joint in urdf.findall("joint")}
    original_mass = sum(float(link.find("inertial/mass").get("value"))
                        for link in source_links.values() if link.find("inertial") is not None)
    mass_scale = v["mass_kg"]/original_mass
    kingpin = float(v.get("kingpin_width_m", 0.11))
    if not 0 < kingpin <= v["wheel_track_m"]:
        raise ValueError("조향축 간격은 0보다 크고 바퀴 간격 이하여야 합니다.")
    rear_z = _origin(source_joints["left_rear_wheel_hinge"])[2]
    # Keep the model's x/y origin at the wheelbase midpoint, as used by rewards.
    # Its z origin lies at the rear axle; joint-to-link geometry is unchanged.
    poses = {"base_link": _transform([0, 0, -rear_z, 0, 0, 0])}
    joint_origins = {}
    for child, joint in source_joints.items():
        pose = _origin(joint)
        if child in ("left_steering_hinge_joint", "right_steering_hinge_joint"):
            side = 1 if child.startswith("left") else -1
            pose[:2] = v["wheelbase_m"]/2, side*kingpin/2
        elif child in ("left_front_wheel_joint", "right_front_wheel_joint"):
            side = 1 if child.startswith("left") else -1
            pose[1] = side*(v["wheel_track_m"]-kingpin)/2
        elif child in ("left_rear_wheel_hinge", "right_rear_wheel_hinge"):
            side = 1 if child.startswith("left") else -1
            pose[:2] = -v["wheelbase_m"]/2, side*v["wheel_track_m"]/2
        elif child == "camera_link":
            pose[0] = v.get("camera_x_m", pose[0])
            pose[2] = v.get("camera_height_m", v["wheel_radius_m"]-rear_z+pose[2])-v["wheel_radius_m"]+rear_z
            pose[4] = math.radians(float(config.get("camera_pitch_deg", v["camera_pitch_deg"])))
        joint_origins[child] = pose
    pending = {name for name in source_links if name not in poses and name != "base_footprint"}
    while pending:
        ready = [child for child in pending if source_joints[child].find("parent").get("link") in poses]
        if not ready:
            raise ValueError("A1 URDF 연결 구조를 해석할 수 없습니다.")
        for child in ready:
            parent = source_joints[child].find("parent").get("link")
            poses[child] = poses[parent] @ _transform(joint_origins[child])
            pending.remove(child)
    model = ET.Element("model", name="a1", canonical_link="base_link",
                       **{"xmlns:ignition": "http://gazebosim.org/schemas"})
    _add(model, "pose", _text([spawn[0], spawn[1], v["wheel_radius_m"]+0.002, 0, 0, spawn[2]]))
    _add(model, "self_collide", "false")
    for name, source in source_links.items():
        if source.find("inertial") is None:
            # Keep unused manufacturer TF nodes as frames, not massless bodies.
            if name == "base_footprint":
                pose = -_origin(source_joints["base_link"])
            else:
                pose = joint_origins[name]
            frame = _add(model, "frame", name=name, attached_to="base_link")
            _add(frame, "pose", _text(pose), relative_to="base_link")
            continue
        out_name = LINK_NAMES.get(name, name)
        link = _add(model, "link", name=out_name)
        _add(link, "pose", _text(_pose(poses[name])))
        _inertial(link, source, mass_scale)
        _visual(link, source, assets)
        _collision(link, out_name, v)
        if name == "camera_link":
            _camera(link, v)
        if name == "base_link":
            continue
        original_joint = source_joints[name]
        parent = original_joint.find("parent").get("link")
        joint_name = JOINT_NAMES.get(original_joint.get("name"), original_joint.get("name")+"_joint")
        wheel = out_name.endswith("_wheel")
        steering = out_name.endswith("_steering_link")
        joint = _add(model, "joint", name=joint_name, type="revolute" if wheel or steering else "fixed")
        _add(joint, "parent", LINK_NAMES.get(parent, parent))
        _add(joint, "child", out_name)
        # SDF joint frame defaults to child frame: this retains the URDF pivot.
        _add(joint, "pose", "0 0 0 0 0 0")
        if wheel or steering:
            axis = _add(joint, "axis")
            _add(axis, "xyz", "0 1 0" if wheel else "0 0 1")
            limit = _add(axis, "limit")
            angle = 1e16 if wheel else math.radians(v["max_steer_deg"])
            _add(limit, "lower", -angle)
            _add(limit, "upper", angle)
            rear_motor = out_name.startswith("rear_") and wheel
            # Motor limits belong only to driven rear wheels. Front tires roll
            # passively; steering uses a shared kinematic actuator approximation.
            _add(limit, "effort", v["motor_torque_limit_nm"] if rear_motor else -1)
            if rear_motor:
                _add(limit, "velocity", v["motor_max_rpm"]*2*math.pi/60)
            elif steering:
                _add(limit, "velocity", v["steering_joint_rate_rad_s"])
            else:
                _add(limit, "velocity", -1)
            dynamics = _add(axis, "dynamics")
            _add(dynamics, "damping", 0.0001 if wheel else 0.02)
    plugin = _add(model, "plugin", filename=str((Path(root)/"build/native/liblane_lab_a1_controller.so").resolve()),
                  name="lane_lab::A1Controller")
    # max_steer_deg is the INNER KNUCKLE limit. Convert it to a virtual
    # center-wheel limit instead of assigning it to the servo shaft.
    center_limit = math.atan(v["wheelbase_m"] / (
        v["wheelbase_m"]/math.tan(math.radians(v["max_steer_deg"])) + kingpin/2))
    values = {"left_joint": "rear_left_wheel_joint", "right_joint": "rear_right_wheel_joint",
              "left_steering_joint": "front_left_steering_joint", "right_steering_joint": "front_right_steering_joint",
              "wheel_separation": v["wheel_track_m"], "kingpin_width": kingpin,
              "wheel_base": v["wheelbase_m"], "wheel_radius": v["wheel_radius_m"],
              "max_center_angle": min(center_limit, math.radians(v["max_center_steer_deg"])),
              "topic": "/lane_lab/cmd_vel", "motor_max_rpm": v["motor_max_rpm"],
              "motor_torque_limit": v["motor_torque_limit_nm"],
              "motor_kp": v["motor_kp_nm_per_rad_s"], "motor_ki": v["motor_ki_nm_per_rad"],
              "linear_acceleration": v["linear_acceleration_m_s2"],
              "yaw_acceleration": v["yaw_acceleration_rad_s2"],
              "steering_response_time": v["steering_response_time_s"],
              "steering_joint_rate": v["steering_joint_rate_rad_s"]}
    for name, value in values.items():
        _add(plugin, name, value)
    plugin = _add(model, "plugin", filename="ignition-gazebo-pose-publisher-system",
                  name="ignition::gazebo::systems::PosePublisher")
    for name, value in {"publish_nested_model_pose": "true", "publish_model_pose": "true",
                        "publish_link_pose": "false", "use_pose_vector_msg": "true", "update_frequency": -1}.items():
        _add(plugin, name, value)
    plugin = _add(model, "plugin", filename="ignition-gazebo-joint-state-publisher-system",
                  name="ignition::gazebo::systems::JointStatePublisher")
    _add(plugin, "topic", "/world/lane_lab/model/a1/joint_state")
    _add(plugin, "joint_name", "front_left_steering_joint")
    _add(plugin, "joint_name", "front_right_steering_joint")
    _add(plugin, "joint_name", "rear_left_wheel_joint")
    _add(plugin, "joint_name", "rear_right_wheel_joint")
    _add(plugin, "update_rate", 0)
    return ET.tostring(model, encoding="unicode")
