"""Periodic selection using one Gazebo server, between complete PPO updates."""
from __future__ import annotations

import copy
import hashlib
import io
import json
import math
from pathlib import Path
import random
import shutil
import time
import uuid
from dataclasses import dataclass

import numpy as np

from .checkpoints import atomic_save_model
from .configuration import atomic_json, sha256
from .environment import LaneEnv, StopRequested
from .policy_io import export_actor

DEFAULTS = {'eval_every_steps': 10000, 'eval_episodes': 1,
            'criterion': 'success_progress_reward'}


def read_options(root):
    path = Path(root) / 'config' / 'best_last.json'
    values = {**DEFAULTS, **(json.loads(path.read_text()) if path.exists() else {})}
    if set(values) != set(DEFAULTS):
        raise ValueError('config/best_last.json의 항목 이름을 확인하세요.')
    for key, low, high in (('eval_every_steps', 512, 1000000), ('eval_episodes', 1, 20)):
        value = values[key]
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ValueError(f'{key}: {low}~{high} 사이의 정수를 입력하세요.')
    if values['criterion'] not in ('success_progress_reward', 'mean_reward'):
        raise ValueError('criterion은 success_progress_reward 또는 mean_reward입니다.')
    return values


def _selection(run):
    path = Path(run) / 'model_selection.json'
    return json.loads(path.read_text()) if path.exists() else {}


def load_choice(run, choice):
    """Resolve a fully published model/actor pair; never relabel last as best."""
    run = Path(run).resolve()
    if choice not in ('best', 'last'):
        raise ValueError('모델 선택은 best 또는 last입니다.')
    record = _selection(run).get(choice)
    if record is None:
        if choice == 'last' and (run / 'actor.npz').is_file() and (run / 'model.zip').is_file():
            metadata = json.loads((run / 'training.json').read_text())
            if metadata.get('failed') or metadata.get('ppo_updates', 0) <= 0:
                raise ValueError('정상적으로 저장된 마지막 모델이 없습니다.')
            return run, {'timesteps': metadata['timesteps'], 'ppo_updates': metadata['ppo_updates'],
                         'legacy_last': True, 'metrics': None}
        raise ValueError(f'{choice} 모델이 없습니다. best는 패치 적용 후 평가를 완료한 학습부터 생깁니다. 기존 모델은 --choice last로 내보내세요.')
    folder = (run / record['directory']).resolve()
    if not folder.is_relative_to(run):
        raise ValueError('모델 저장 경로가 실험 폴더 밖을 가리킵니다.')
    for name in ('model.zip', 'actor.npz'):
        if sha256(folder / name) != record['sha256'][name]:
            raise ValueError(f'{choice} {name}의 무결성 검사가 실패했습니다.')
    return folder, record


def _publish(run, choice, folder, record):
    record = {**record, 'directory': str(folder.relative_to(run)),
              'sha256': {name: sha256(folder / name) for name in ('model.zip', 'actor.npz')}}
    data = _selection(run)
    data[choice] = record
    atomic_json(run / 'model_selection.json', data)
    return record


def save_snapshot(model, run, choice, observation_size, *, metrics=None, protocol=None):
    run = Path(run)
    folder = run / 'models' / f'{choice}_{int(model.num_timesteps):09d}_{uuid.uuid4().hex[:8]}'
    folder.mkdir(parents=True)
    try:
        atomic_save_model(model, folder / 'model.zip')
        export_actor(model, folder / 'actor.npz', observation_size=observation_size)
        record = {'timesteps': int(model.num_timesteps), 'ppo_updates': int(model._n_updates),
                  'metrics': metrics, 'protocol': protocol}
        atomic_json(folder / 'metadata.json', record)
        return _publish(run, choice, folder, record)
    except BaseException:
        # Previously selected versions are untouched until the final JSON commit.
        shutil.rmtree(folder, ignore_errors=True)
        raise


def save_last_snapshot(model, run, observation_size):
    return save_snapshot(model, run, 'last', observation_size)


@dataclass(frozen=True)
class CandidateSnapshot:
    """An independent PPO checkpoint in RAM, never a candidate file on disk."""
    payload: bytes
    timesteps: int
    ppo_updates: int


def capture_candidate(model):
    # SB3 excludes the simulator and rollout buffer and includes the policy,
    # critic and Adam state. Immutable bytes cannot follow later tensor updates.
    # Keep these snapshots on the selector, never on model.__dict__: model.save
    # serializes arbitrary model attributes and would recursively copy the queue.
    stream = io.BytesIO()
    model.save(stream, exclude=['lane_random_state'])
    return CandidateSnapshot(stream.getvalue(), int(model.num_timesteps), int(model._n_updates))


def load_candidate(snapshot):
    from stable_baselines3 import PPO
    model = PPO.load(io.BytesIO(snapshot.payload), device='cpu')
    if (int(model.num_timesteps), int(model._n_updates)) != (snapshot.timesteps, snapshot.ppo_updates):
        raise ValueError('메모리에 보관한 후보 모델의 학습 정보가 일치하지 않습니다.')
    return model


def metric_summary(episodes, criterion):
    success = float(np.mean([bool(e['successful_lap']) for e in episodes]))
    progress = float(np.mean([np.clip(float(e['progress_m']) / float(e['track_length_m']), 0, 1)
                              for e in episodes]))
    reward = float(np.mean([float(e['episode_return']) for e in episodes]))
    if not all(math.isfinite(value) for value in (success, progress, reward)):
        raise ValueError('평가 결과에 유한하지 않은 수가 있습니다.')
    rank = [success, progress, reward] if criterion == 'success_progress_reward' else [reward]
    return {'success_rate': success, 'mean_progress_fraction': progress,
            'mean_reward': reward, 'rank': rank, 'episodes': len(episodes)}


def scenario_fingerprint(app, run):
    """Scores are comparable only for the same task, track and vehicle dynamics."""
    run=Path(run)
    settings={k:v for k,v in app.cfg.items() if k not in
              ('train_steps','speed_mode','speed_factor','preview_hz','torch_threads','real')}
    track=json.loads((run/'world/track.json').read_text())
    files={'lesson':sha256(run/'lesson.py'),
           'vision':sha256(run/'shared_code/vision.py'),
           'vehicle':sha256(run/'vehicle_base.json')}
    for name in ('lane_lab/vehicle.py','lane_lab/geometry.py','lane_lab/reward_state.py',
                 'lane_lab/evaluation_geometry.py','lane_lab/environment.py',
                 'native/a1_controller.cc','native/a1_dynamics.hh','lane_lab/worlds.py'):
        path=app.root/name
        if path.is_file():files[name]=sha256(path)
    # World metadata includes filesystem paths; only the geometric scenario is hashed.
    payload={'settings':settings,'cells':track['cells'],'spawn':track['spawn'],'files':files}
    raw=json.dumps(payload,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


class BestLastSelector:
    def __init__(self, app, run, training_env, lesson, observation_size, options, parent=None, start_steps=0):
        import stable_baselines3
        if stable_baselines3.__version__ != '2.4.1':
            raise ValueError('이 패치는 패키지 기본 Stable-Baselines3 2.4.1용입니다.')
        self.app, self.run, self.training_env = app, Path(run), training_env
        self.lesson, self.size = lesson, observation_size
        self.options = dict(options)
        self.last_evaluated_update = -1
        self.last_captured_update = -1
        self.next_eval_step = (int(start_steps) // options['eval_every_steps'] + 1) * options['eval_every_steps']
        self.pending = []
        self.pending_bytes = 0
        self.peak_pending_bytes = 0
        self.captured_candidates = 0
        self.evaluated_candidates = 0
        self.discarded_candidates = 0
        self.batches = 0
        self.protocol = {'version': 2, 'episodes': options['eval_episodes'],
                         'criterion': options['criterion'],
                         'max_episode_seconds': float(app.cfg['max_episode_seconds']),
                         'deterministic': True, 'spawn': 'saved_world_default',
                         'seed_start': 0,'scenario_sha256':scenario_fingerprint(app,self.run)}
        atomic_json(self.run / 'best_last_config.json', self.options)
        self.best = None
        if parent is not None and _selection(parent).get('best') is not None:
            source, record = load_choice(parent, 'best')
            if record.get('protocol') == self.protocol:
                folder = self.run / 'models' / ('inherited_best_' + uuid.uuid4().hex[:8])
                shutil.copytree(source, folder)
                record = {**record, 'inherited_from': str(Path(parent).resolve())}
                self.best = _publish(self.run, 'best', folder, record)

    def write_buffer_status(self, **extra):
        record = {'storage': 'ram', 'captured_candidates': self.captured_candidates,
                  'evaluated_candidates': self.evaluated_candidates,
                  'discarded_candidates': self.discarded_candidates,
                  'pending_candidates': len(self.pending), 'pending_bytes': self.pending_bytes,
                  'peak_pending_bytes': self.peak_pending_bytes, 'batches': self.batches, **extra}
        atomic_json(self.run / 'ram_evaluation.json', record)
        self.app.write_status(buffered_candidates=len(self.pending), candidate_buffer_bytes=self.pending_bytes,
                              candidate_buffer_peak_bytes=self.peak_pending_bytes)

    def capture(self, model):
        updates = int(model._n_updates)
        if updates <= 0 or updates == self.last_captured_update:
            return False
        if updates < self.last_captured_update:
            raise ValueError('후보 모델의 PPO 업데이트 순서가 역전되었습니다.')
        snapshot = capture_candidate(model)
        self.pending.append(snapshot)
        self.pending_bytes += len(snapshot.payload)
        self.peak_pending_bytes = max(self.peak_pending_bytes, self.pending_bytes)
        self.captured_candidates += 1
        self.last_captured_update = updates
        self.write_buffer_status(last_captured_steps=snapshot.timesteps)
        return True

    def discard_pending(self, reason):
        self.discarded_candidates += len(self.pending)
        self.pending.clear()
        self.pending_bytes = 0
        self.write_buffer_status(discard_reason=reason)

    def maybe_evaluate(self, model, *, final=False):
        updates, step = int(model._n_updates), int(model.num_timesteps)
        if updates <= 0 or not self.pending or self.app.stop_event.is_set():
            return
        if not final and step < self.next_eval_step:
            return
        self.evaluate(model, restore_training=not final)
        self.last_evaluated_update = updates
        interval = self.options['eval_every_steps']
        self.next_eval_step = (step // interval + 1) * interval

    def evaluate(self, model, *, restore_training):
        import torch
        if not self.pending or self.app.stop_event.is_set():
            return
        # Last is always the latest live learner, never a historical candidate.
        prior_mode = model.policy.training
        try:
            save_last_snapshot(model, self.run, self.size)
        finally:
            # Actor export validates predict(), which switches policy to eval.
            model.policy.set_training_mode(prior_mode)
        # PPO.load seeds global RNGs; preserve them BEFORE loading any candidate.
        state = (random.getstate(), np.random.get_state(), torch.get_rng_state())
        step = int(model.num_timesteps)
        count = len(self.pending)
        self.batches += 1
        batch_id = self.batches
        candidate_index = 0
        candidate_step = 0
        evaluation_steps = 0
        last_report = 0.0
        episodes = []
        winner = None
        winner_metrics = None
        best_rank = tuple(self.best['metrics']['rank']) if self.best else None
        evaluation_env = None
        completed = False
        completed_count = 0
        candidate = None
        candidate_active = False

        def report(result, features, info, evaluation_env):
            nonlocal evaluation_steps, last_report
            evaluation_steps += 1
            self.app.update_image(result['image'], features, evaluation_env.grid)
            if time.monotonic() - last_report > .25:
                self.app.write_status(status='training', steps=step,
                    evaluation_steps=evaluation_steps, best_evaluation=True,
                    evaluation_candidate_index=candidate_index, evaluation_candidate_count=count,
                    evaluation_candidate_steps=candidate_step,
                    message=f'후보 평가 {candidate_index}/{count} · 후보 {candidate_step:,}스텝 · 주행 {len(episodes)+1}/{self.options["eval_episodes"]} · 학습 {step:,}스텝')
                last_report = time.monotonic()

        try:
            while self.pending:
                if self.app.stop_event.is_set():
                    raise StopRequested()
                candidate_index += 1
                snapshot = self.pending[0]
                candidate_step = snapshot.timesteps
                episodes = []
                candidate_active = True
                # Loading a separate model preserves the live policy AND optimizer.
                candidate = load_candidate(snapshot)
                evaluation_env = LaneEnv(self.training_env.sim, copy.deepcopy(self.training_env.settings),
                    self.lesson, self.size, self.app.stop_event, report,
                    training_step_context=candidate_step)
                for index in range(self.options['eval_episodes']):
                    observation, _ = evaluation_env.reset(seed=index)
                    while True:
                        action, _ = candidate.predict(observation, deterministic=True)
                        observation, _, terminated, truncated, info = evaluation_env.step(action)
                        if terminated or truncated:
                            episodes.append(info)
                            break
                metrics = metric_summary(episodes, self.options['criterion'])
                improved = best_rank is None or tuple(metrics['rank']) > best_rank
                if improved:
                    winner, winner_metrics = snapshot, metrics
                    best_rank = tuple(metrics['rank'])
                with (self.run / 'best_evaluations.jsonl').open('a') as stream:
                    stream.write(json.dumps({'training_steps': candidate_step,
                        'ppo_updates': snapshot.ppo_updates, 'batch_training_steps': step,
                        'batch_id': batch_id, 'candidate_index': candidate_index, 'candidate_count': count,
                        'complete': True, 'improved': improved, 'metrics': metrics,
                        'episodes': episodes}, ensure_ascii=False) + '\n')
                self.pending.pop(0)
                self.pending_bytes -= len(snapshot.payload)
                self.evaluated_candidates += 1
                completed_count += 1
                candidate_active = False
                evaluation_env.close()
                evaluation_env = None
                candidate = None
                self.write_buffer_status()
            completed = True
        except StopRequested:
            if candidate_active:
                with (self.run / 'best_evaluations.jsonl').open('a') as stream:
                    stream.write(json.dumps({'training_steps': candidate_step,
                        'batch_training_steps': step, 'batch_id': batch_id,
                        'candidate_index': candidate_index, 'candidate_count': count,
                        'complete': False, 'completed_episodes': len(episodes)}) + '\n')
            raise
        finally:
            try:
                if evaluation_env is not None:
                    evaluation_env.close()
            finally:
                try:
                    # Save only the best completed candidate of this batch. This
                    # also preserves a completed winner when a later trial stops.
                    candidate = None
                    if winner is not None:
                        selected = load_candidate(winner)
                        self.best = save_snapshot(selected, self.run, 'best', self.size,
                                                  metrics=winner_metrics, protocol=self.protocol)
                        del selected
                    atomic_json(self.run / f'evaluation_batch_{batch_id:04d}.json', {
                        'batch_id': batch_id, 'training_steps': step, 'candidates': count,
                        'completed_candidates': completed_count, 'complete': completed,
                        'selected_best_steps': self.best['timesteps'] if self.best else None,
                        'best_changed': winner is not None})
                    # One training reset per batch, not per historical candidate.
                    if completed and restore_training and not self.app.stop_event.is_set():
                        vector_env = model.get_env()
                        model._last_obs = vector_env.reset()
                        model._last_episode_starts = np.ones(vector_env.num_envs, dtype=bool)
                finally:
                    random.setstate(state[0])
                    np.random.set_state(state[1])
                    torch.set_rng_state(state[2])
                    self.write_buffer_status()
                    self.app.write_status(status='training', steps=step, best_evaluation=False,
                        best_steps=self.best['timesteps'] if self.best else 0,
                        message=f'학습 {step:,}스텝 · 베스트 {self.best["timesteps"]:,}스텝' if self.best else f'학습 {step:,}스텝')
