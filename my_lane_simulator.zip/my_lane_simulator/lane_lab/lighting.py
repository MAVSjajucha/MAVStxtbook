"""Validate student light variables and emit native Fortress SDF values.

Numeric ranges follow sdformat12 Light setters, not arbitrary lesson limits:
constant/linear [0, 1]; range/quadratic/spot angles/falloff >= 0; intensity and
position are finite doubles.  A zero direction is rejected because it cannot
define a spotlight axis.  Inner <= outer is a cone consistency requirement.
"""
from __future__ import annotations

import ast
import copy
import math
from numbers import Real
from pathlib import Path
from xml.sax.saxutils import escape


COMMON_VARIABLES = {
    "intensity": "INTENSITY", "diffuse": "DIFFUSE", "specular": "SPECULAR",
    "range": "RANGE_M", "constant": "CONSTANT", "linear": "LINEAR",
    "quadratic": "QUADRATIC",
}
SPOT_VARIABLES = {
    "direction": "DIRECTION", "inner_angle": "INNER_ANGLE_RAD",
    "outer_angle": "OUTER_ANGLE_RAD", "falloff": "FALLOFF",
}


def _number(value, name, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name}: 숫자를 입력하세요.")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name}: 유한한 숫자를 입력하세요.")
    if low is not None and number < low or high is not None and number > high:
        interval = f"{low} 이상" if high is None else f"{low}~{high}"
        raise ValueError(f"{name}: {interval}이어야 합니다.")
    return number


def _vector(value, size, name, low=None, high=None):
    if not isinstance(value, (list, tuple)) or len(value) != size:
        raise ValueError(f"{name}: 숫자 {size}개를 괄호 안에 입력하세요.")
    return [_number(item, f"{name}[{i}]", low, high) for i, item in enumerate(value)]


def load_lighting(path):
    """Read literal assignments without executing arbitrary configuration code."""
    path = Path(path)
    if path.is_dir():
        path = path / "design" / "lighting.py"
    values = {}
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in tree.body:
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                continue
            if not isinstance(node, ast.Assign) or len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                raise ValueError("변수에 숫자 또는 숫자 튜플을 대입하는 줄만 사용하세요.")
            name = node.targets[0].id
            if name in values:
                raise ValueError(f"{name} 변수가 두 번 작성되어 있습니다.")
            values[name] = ast.literal_eval(node.value)
    except (SyntaxError, ValueError) as exc:
        raise ValueError(f"{path.name}: {exc}") from exc
    result = {}
    scene_names = {"light1", "light2", "light3", "light4", "TRACK_SPECULAR",
                   "SUN_INTENSITY", "SUN_SPECULAR", "SUN_AZIMUTH_DEG", "SUN_ELEVATION_DEG"}
    expected = set(scene_names)
    missing_scene = scene_names - values.keys()
    if missing_scene:
        raise ValueError(f"{path.name}: 필요한 변수 {', '.join(sorted(missing_scene))}가 없습니다.")
    result.update(
        positions=[values[f"light{i}"] for i in range(1, 5)],
        track_specular=values["TRACK_SPECULAR"],
        directional={"intensity": values["SUN_INTENSITY"],
                     "diffuse": [1.0, 1.0, 1.0, 1.0],
                     "specular": values["SUN_SPECULAR"],
                     "azimuth_deg": values["SUN_AZIMUTH_DEG"],
                     "elevation_deg": values["SUN_ELEVATION_DEG"]})
    for kind in ("point", "spot"):
        fields = dict(COMMON_VARIABLES)
        if kind == "spot":
            fields.update(SPOT_VARIABLES)
        names = {key: f"{kind.upper()}_{suffix}" for key, suffix in fields.items()}
        expected.update(names.values())
        missing = [name for name in names.values() if name not in values]
        if missing:
            raise ValueError(f"{path.name}: 필요한 변수 {', '.join(missing)}가 없습니다.")
        result[kind] = {key: values[name] for key, name in names.items()}
    unknown = set(values) - expected
    if unknown:
        raise ValueError(f"{path.name}: 알 수 없는 변수 {', '.join(sorted(unknown))}")
    return validate_lighting(result)


def directional_vector(azimuth_deg, elevation_deg):
    """Unit ray direction, opposite the source position given by two angles.

    Azimuth is counterclockwise from +X towards +Y; elevation is above the XY
    plane. Angles are degrees. Equivalent angles outside one turn are allowed.
    """
    azimuth = math.radians(_number(azimuth_deg, "sun.azimuth_deg") % 360.0)
    elevation = math.radians(_number(elevation_deg, "sun.elevation_deg") % 360.0)
    values = (-math.cos(elevation) * math.cos(azimuth),
              -math.cos(elevation) * math.sin(azimuth), -math.sin(elevation))
    return [0.0 if abs(value) < 1e-15 else value for value in values]


def _directional(settings):
    if not isinstance(settings, dict):
        raise ValueError("lighting.directional 설정이 필요합니다.")
    try:
        return {"intensity": _number(settings["intensity"], "sun.intensity"),
                # Legacy snapshots allowed diffuse > 1. Keep the old SDF exactly
                # when replaying those snapshots; new design always uses white.
                "diffuse": _vector(settings.get("diffuse", [1., 1., 1., 1.]), 4, "sun.diffuse", 0),
                "specular": _vector(settings["specular"], 4, "sun.specular", 0, 1),
                "azimuth_deg": _number(settings["azimuth_deg"], "sun.azimuth_deg"),
                "elevation_deg": _number(settings["elevation_deg"], "sun.elevation_deg")}
    except KeyError as exc:
        raise ValueError(f"lighting.directional: {exc.args[0]} 값이 없습니다.") from exc


def validate_lighting(settings):
    if not isinstance(settings, dict):
        raise ValueError("lighting은 point와 spot 설정을 포함해야 합니다.")
    result = {}
    # Optional only for backwards-compatible saved worlds. New design files
    # always supply all three fields, and environment validation fills old ones.
    if "positions" in settings:
        if not isinstance(settings["positions"], (list, tuple)) or len(settings["positions"]) != 4:
            raise ValueError("lighting.positions: 광원 위치 4개가 필요합니다.")
        result["positions"] = [_vector(position, 3, f"light{i}")
                               for i, position in enumerate(settings["positions"], 1)]
    if "track_specular" in settings:
        result["track_specular"] = _number(settings["track_specular"], "TRACK_SPECULAR", 0, 1)
    if "directional" in settings:
        result["directional"] = _directional(settings["directional"])
    for kind in ("point", "spot"):
        group = settings.get(kind)
        if not isinstance(group, dict):
            raise ValueError(f"lighting.{kind} 설정이 없습니다.")
        try:
            result[kind] = {
                "intensity": _number(group["intensity"], f"{kind}.intensity"),
                "diffuse": _vector(group["diffuse"], 4, f"{kind}.diffuse", 0, 1),
                "specular": _vector(group["specular"], 4, f"{kind}.specular", 0, 1),
                "range": _number(group["range"], f"{kind}.range", 0),
                "constant": _number(group["constant"], f"{kind}.constant", 0, 1),
                "linear": _number(group["linear"], f"{kind}.linear", 0, 1),
                "quadratic": _number(group["quadratic"], f"{kind}.quadratic", 0),
            }
            if kind == "spot":
                direction = _vector(group["direction"], 3, "spot.direction")
                if math.hypot(*direction) == 0:
                    raise ValueError("spot.direction: (0, 0, 0)은 방향을 나타낼 수 없습니다.")
                inner = _number(group["inner_angle"], "spot.inner_angle", 0)
                outer = _number(group["outer_angle"], "spot.outer_angle", 0)
                if inner > outer:
                    raise ValueError("스포트라이트 안쪽 각도는 바깥쪽 각도보다 클 수 없습니다.")
                result[kind].update(direction=direction, inner_angle=inner, outer_angle=outer,
                                    falloff=_number(group["falloff"], "spot.falloff", 0))
        except KeyError as exc:
            raise ValueError(f"lighting.{kind}: {exc.args[0]} 값이 없습니다.") from exc
    return result


def migrate_friction_settings(settings):
    """Retire the static/sliding model without inventing directional behavior.

    A legacy snapshot was isotropic: seed BOTH directions from its static
    coefficient (or older single coefficient), never assign kinetic to mu2.
    Explicit directional values always win, including a partial new pair.
    Empty/other partial updates stay partial so they cannot reset a live scene.
    """
    settings = copy.deepcopy(settings)
    legacy_keys = ("static_friction", "kinetic_friction", "friction")
    if any(key in settings for key in legacy_keys):
        legacy = settings.get("static_friction", settings.get("friction", 0.5))
        settings.setdefault("friction_mu1", legacy)
        settings.setdefault("friction_mu2", legacy)
    for key in legacy_keys:
        settings.pop(key, None)
    return settings


def validate_environment_settings(settings):
    """Return canonical scene values with two independent friction directions."""
    settings = migrate_friction_settings(settings)
    # Legacy snapshots may still contain removed actuator-error and independent
    # floor-friction settings. Ignore them rather than re-enable old behavior.
    for key in ("rear_random_enabled", "servo_random_enabled", "motor_randomization",
                "track_friction", "tire_friction"):
        settings.pop(key, None)
    for key, label in (("friction_mu1", "마찰 계수(mu1)"),
                       ("friction_mu2", "마찰 계수(mu2)")):
        value = settings.get(key, 0.5)
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ValueError(f"{key} ({label}): 0 이상의 유한한 숫자를 입력하세요.")
        settings[key] = _number(float(value), f"{key} ({label})", 0)
    kind = settings.get("extra_light_type", "point")
    if kind not in ("point", "spot"):
        raise ValueError("추가 광원 종류는 point 또는 spot이어야 합니다.")
    settings["extra_light_type"] = kind
    lights = settings.get("extra_lights", [{"enabled": False, "x": 0.0, "y": 0.0, "z": 2.0} for _ in range(4)])
    if not isinstance(lights, list) or len(lights) != 4:
        raise ValueError("추가 광원은 활성화 여부를 선택할 수 있는 4개 항목으로 구성해야 합니다.")
    lighting = validate_lighting(settings["lighting"]) if "lighting" in settings else None
    positions = lighting.get("positions") if lighting else None
    canonical = []
    for i, light in enumerate(lights, 1):
        if not isinstance(light, dict) or not isinstance(light.get("enabled"), bool):
            raise ValueError(f"광원 {i}: enabled 값은 True 또는 False여야 합니다.")
        position = (positions[i - 1] if positions is not None else
                    [_number(light.get(axis), f"광원 {i}.{axis}") for axis in ("x", "y", "z")])
        canonical.append({"enabled": light["enabled"], **dict(zip(("x", "y", "z"), position))})
    settings["extra_lights"] = canonical
    specular = lighting.get("track_specular", settings.get("track_specular", 0.0)) if lighting else settings.get("track_specular", 0.0)
    settings["track_specular"] = _number(specular, "TRACK_SPECULAR", 0, 1)
    if lighting is not None:
        lighting.setdefault("positions", [[light[axis] for axis in ("x", "y", "z")] for light in canonical])
        lighting.setdefault("track_specular", settings["track_specular"])
        if "directional" not in lighting:
            # Preserve old saved-world brightness semantics: light_level used to
            # scale diffuse RGB, not the native intensity or scene ambient.
            level = _number(settings.get("light_level", settings.get("light_brightness", 1.0)), "light_level", 0)
            lighting["directional"] = _directional({"intensity": 1.0, "diffuse": [level, level, level, 1.0],
                "specular": [.1, .1, .1, 1.0], "azimuth_deg": 315.0,
                "elevation_deg": 67.01023222639115})
        settings["lighting"] = lighting
    # Retain the old key only as inert snapshot metadata. All current rendering
    # reads lighting.directional; a stale GUI value cannot override the code.
    return settings


def renderer_warnings(settings):
    """Report backend limitations rather than silently claim a setting was applied."""
    if settings.get("render_engine", "ogre") != "ogre2" or not any(
            light["enabled"] for light in settings.get("extra_lights", [])):
        return []
    group = settings.get("lighting", {}).get(settings.get("extra_light_type", "point"), {})
    if group and group["constant"] != 0.5:
        return ["Ogre2는 상수 감쇠를 0.5로 고정합니다. 입력한 constant를 그대로 적용하려면 Ogre 렌더러가 필요합니다."]
    return []


def lights_sdf(settings, center_x, center_y, surface_z=0.001):
    """Positions are relative to the generated track rectangle's surface center."""
    kind = settings["extra_light_type"]
    group = settings["lighting"][kind]
    vector = lambda values: " ".join(format(float(value), ".17g") for value in values)
    result = []
    for index, light in enumerate(settings["extra_lights"], 1):
        if not light["enabled"]:
            continue
        pose = vector((center_x + light["x"], center_y + light["y"], surface_z + light["z"], 0, 0, 0))
        cone = ""
        if kind == "spot":
            cone = (f'<direction>{vector(group["direction"])}</direction><spot>'
                    f'<inner_angle>{group["inner_angle"]}</inner_angle>'
                    f'<outer_angle>{group["outer_angle"]}</outer_angle>'
                    f'<falloff>{group["falloff"]}</falloff></spot>')
        result.append(f'''<light name="extra_light_{index}" type="{escape(kind)}"><pose>{pose}</pose>
<cast_shadows>false</cast_shadows><intensity>{group['intensity']}</intensity>
<diffuse>{vector(group['diffuse'])}</diffuse><specular>{vector(group['specular'])}</specular>
<attenuation><range>{group['range']}</range><constant>{group['constant']}</constant><linear>{group['linear']}</linear><quadratic>{group['quadratic']}</quadratic></attenuation>{cone}</light>''')
    return "\n".join(result)


def directional_sdf(settings):
    """Render a validated directional-light snapshot without rereading source."""
    group = settings["lighting"]["directional"]
    vector = lambda values: " ".join(format(float(value), ".17g") for value in values)
    direction = directional_vector(group["azimuth_deg"], group["elevation_deg"])
    return (f'<light name="sun" type="directional"><pose>0 0 10 0 0 0</pose>'
            f'<cast_shadows>false</cast_shadows><intensity>{group["intensity"]}</intensity>'
            f'<diffuse>{vector(group["diffuse"])}</diffuse><specular>{vector(group["specular"])}</specular>'
            f'<direction>{vector(direction)}</direction></light>')
