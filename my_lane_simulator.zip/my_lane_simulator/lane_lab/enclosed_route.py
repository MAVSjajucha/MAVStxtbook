"""Deterministic reference paths inside enclosed road artwork.

An enclosed area need not have a unique centreline.  Its inset boundaries give
useful closed references without requiring a degree-two tile graph.  These are
reward/evaluation references, never an additional painted or physical boundary.
"""
from __future__ import annotations

import math

import cv2
import numpy as np


def _resample(points, spacing=.005):
    points = np.asarray(points, dtype=float)
    points = points[np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1) > 1e-10]]
    if len(points) > 1 and np.linalg.norm(points[-1] - points[0]) < 1e-10:
        points = points[:-1]
    ends = np.vstack((points, points[0]))
    distances = np.r_[0., np.cumsum(np.linalg.norm(np.diff(ends, axis=0), axis=1))]
    if len(points) < 3 or distances[-1] < .001:
        return None
    samples = np.linspace(0., distances[-1], max(12, math.ceil(distances[-1] / spacing)), endpoint=False)
    return np.column_stack([np.interp(samples, distances, ends[:, axis]) for axis in (0, 1)])


def _area(points):
    return float(np.sum(points[:, 0] * np.roll(points[:, 1], -1) -
                        points[:, 1] * np.roll(points[:, 0], -1)) / 2)


def _smooth(points, sigma):
    if not sigma:
        return points
    length = np.linalg.norm(np.roll(points, -1, axis=0) - points, axis=1).sum()
    frequencies = np.fft.rfftfreq(len(points), d=length / len(points))
    weights = np.exp(-.5 * (2 * math.pi * sigma * frequencies) ** 2)
    return np.fft.irfft(np.fft.rfft(points, axis=0) * weights[:, None], n=len(points), axis=0)


def _curvature(points):
    # A 5 cm chord suppresses raster stair steps while still detecting narrow
    # dead-end U turns. Candidate curves have already been sampled at 5 mm.
    k = max(1, min(5, len(points) // 8))
    a = points - np.roll(points, k, axis=0)
    b = np.roll(points, -k, axis=0) - points
    denominator = np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1) * np.linalg.norm(a + b, axis=1)
    cross = np.abs(a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0])
    return np.divide(2 * cross, denominator, out=np.full(len(points), np.inf), where=denominator > 1e-12)


def _round_corners(points, sigma, minimum_radius):
    """Round square K-style corners without shrinking every curved lane."""
    seed = _smooth(points, .06)
    sharp = _curvature(seed) > max(8., 2 / minimum_radius)
    if not sharp.any():
        return seed
    count = len(seed)
    indices = np.arange(3 * count)
    marks = np.tile(sharp, 3)
    previous = np.maximum.accumulate(np.where(marks, indices, -3 * count))
    following = np.minimum.accumulate(np.where(marks, indices, 6 * count)[::-1])[::-1]
    distance = np.minimum(indices - previous, following - indices)[count:2 * count]
    step = np.linalg.norm(np.roll(seed, -1, axis=0) - seed, axis=1).sum() / count
    weight = np.exp(-.5 * (distance * step / (sigma * .8)) ** 4)
    return seed + (_smooth(seed, sigma) - seed) * weight[:, None]


def _vehicle_dimensions(vehicle):
    base = float(vehicle['wheelbase_m'])
    track = float(vehicle['wheel_track_m'])
    width = float(vehicle['wheel_width_m'])
    contact = float(vehicle['wheel_contact_length_m'])
    kingpin = float(vehicle.get('kingpin_width_m', track))
    if not all(math.isfinite(v) and v > 0 for v in (base, track, width, contact, kingpin)):
        raise ValueError('차량 접지 치수는 양의 유한한 값이어야 합니다.')
    # This disk contains all four tire patches at every body heading and every
    # front-wheel steering angle, including the outboard steering-pivot offset.
    rear_radius = math.hypot(base / 2 + contact / 2, (track + width) / 2)
    front_radius = math.hypot(base / 2, kingpin / 2) + abs(track - kingpin) / 2 + math.hypot(contact / 2, width / 2)
    radius = max(rear_radius, front_radius) + .002
    if 'max_center_steer_deg' in vehicle:
        steering = math.radians(float(vehicle['max_center_steer_deg']))
    else:
        inner = math.radians(float(vehicle.get('max_steer_deg', 45.)))
        steering = math.atan(base / (base / math.tan(inner) + kingpin / 2))
    steering = min(math.radians(80), max(math.radians(1), steering))
    minimum_radius = math.hypot(base / math.tan(steering), base / 2)
    return radius, minimum_radius


class _Road:
    def __init__(self, mask, resolution):
        self.mask = mask
        self.resolution = resolution
        self.height = len(mask) * resolution
        self.stride = min(min(mask.shape), max(1, int(round(.005 / resolution))))
        self.step = self.stride * resolution
        rows, cols = np.asarray(mask.shape) // self.stride
        # Min-pooling, not interpolating/resizing, preserves even a one-pixel
        # white line or hole. Crop incomplete border blocks conservatively.
        block = mask[:rows * self.stride, :cols * self.stride]
        coarse = block.reshape(rows, self.stride, cols, self.stride).min(axis=(1, 3))
        self.distance = cv2.distanceTransform(np.pad((coarse != 0).astype(np.uint8), 1),
                                             cv2.DIST_L2, cv2.DIST_MASK_PRECISE)[1:-1, 1:-1]
        self.distance *= self.step

    def clearance(self, points):
        col = np.floor(points[:, 0] / self.step).astype(int)
        row = np.floor((self.height - points[:, 1]) / self.step).astype(int)
        inside = ((row >= 0) & (col >= 0) & (row < self.distance.shape[0]) & (col < self.distance.shape[1]))
        result = np.full(len(points), -1.)
        # Distance is measured between coarse pixel centres. Subtracting a
        # complete pixel diagonal bounds both the query position and an actual
        # blocked full-resolution pixel anywhere within its pooled block.
        result[inside] = self.distance[row[inside], col[inside]] - math.sqrt(2) * self.step
        return result

    def contains(self, points):
        col = np.floor(points[:, 0] / self.resolution).astype(int)
        row = np.floor((self.height - points[:, 1]) / self.resolution).astype(int)
        inside = ((row >= 0) & (col >= 0) & (row < self.mask.shape[0]) & (col < self.mask.shape[1]))
        if not inside.all():
            return False
        return bool(np.all(self.mask[row, col]))


def _footprint(vehicle, steer_rad=0.):
    xx = np.linspace(-float(vehicle['wheel_contact_length_m']) / 2,
                     float(vehicle['wheel_contact_length_m']) / 2,
                     math.ceil(float(vehicle['wheel_contact_length_m']) / .002) + 1)
    yy = np.linspace(-float(vehicle['wheel_width_m']) / 2,
                     float(vehicle['wheel_width_m']) / 2,
                     math.ceil(float(vehicle['wheel_width_m']) / .002) + 1)
    patch = np.stack(np.meshgrid(xx, yy), -1).reshape(-1, 2)
    base, track = float(vehicle['wheelbase_m']), float(vehicle['wheel_track_m'])
    kingpin = float(vehicle.get('kingpin_width_m', track))
    result = []
    for front in (-1, 1):
        for left in (-1, 1):
            if front < 0:
                result.append(patch + (-base / 2, left * track / 2))
            else:
                angle = math.atan(base / (base / math.tan(steer_rad) - left * kingpin / 2)) if steer_rad else 0.
                c, s = math.cos(angle), math.sin(angle)
                rotation = np.array([[c, s], [-s, c]])
                result.append((patch + (0., left * (track - kingpin) / 2)) @ rotation +
                              (base / 2, left * kingpin / 2))
    return np.concatenate(result)


def _full_resolution_check(road, route, vehicle, steering_extremes=True):
    dense = _resample(route, min(.002, road.resolution * 2))
    if dense is None or not road.contains(dense):
        return False
    vectors = np.roll(dense, -1, axis=0) - np.roll(dense, 1, axis=0)
    cusp = np.linalg.norm(vectors, axis=1) < 1e-10
    vectors[cusp] = (np.roll(dense, -1, axis=0) - dense)[cusp]
    yaw = np.arctan2(vectors[:, 1], vectors[:, 0])
    base = float(vehicle['wheelbase_m'])
    kingpin = float(vehicle.get('kingpin_width_m', vehicle['wheel_track_m']))
    inner = math.radians(float(vehicle.get('max_steer_deg', 45.)))
    steering = math.radians(float(vehicle['max_center_steer_deg'])) if 'max_center_steer_deg' in vehicle else math.atan(base / (base / math.tan(inner) + kingpin / 2))
    # Verify neutral and both full-lock front tire patches against the supplied
    # full-resolution mask. The conservative disk handles intermediate angles
    # for the usual contour candidates; locally rounded corners get this exact
    # footprint check rather than an unnecessarily large all-heading disk.
    angles = (-steering, 0., steering) if steering_extremes else (0.,)
    patch = np.concatenate([_footprint(vehicle, angle) for angle in angles])
    for start in range(0, len(dense), 128):
        p, angle = dense[start:start + 128], yaw[start:start + 128]
        c, s = np.cos(angle)[:, None], np.sin(angle)[:, None]
        points = np.stack((p[:, 0, None] + c * patch[:, 0] - s * patch[:, 1],
                           p[:, 1, None] + s * patch[:, 0] + c * patch[:, 1]), axis=-1)
        if not road.contains(points.reshape(-1, 2)):
            return False
    return True


def _canonical(route):
    if _area(route) < 0:
        route = route[::-1]
    curvature = _curvature(route)
    # Prefer a straight spawn; break ties at the lowest/leftmost world point.
    candidates = np.flatnonzero(curvature <= max(.02, float(np.min(curvature)) + .02))
    best = min(candidates, key=lambda i: (round(float(route[i, 1]), 4), round(float(route[i, 0]), 4), int(i)))
    return np.roll(route, -int(best), axis=0)


def _stationary_reference(road, vehicle, safe_radius):
    row, col = np.unravel_index(int(np.argmax(road.distance)), road.distance.shape)
    center = np.array([(col + .5) * road.step, road.height - (row + .5) * road.step])
    clearance = float(road.clearance(center[None])[0])
    radius = min(.05, (clearance - safe_radius - .004) / 2)
    if radius > .005:
        angles = np.linspace(0., 2 * math.pi, 64, endpoint=False)
        return _resample(center + radius * np.column_stack((np.cos(angles), np.sin(angles))))
    # A narrow region may fit the aligned car despite not containing its
    # heading-independent safety disk. A short out-and-back reference remains
    # useful to projection consumers; it is explicitly never a lap circuit.
    patch = _footprint(vehicle)
    candidates = np.argwhere(road.distance >= max(float(road.distance.max()) - .01, .001))
    if len(candidates) > 64:
        candidates = candidates[np.linspace(0, len(candidates) - 1, 64).astype(int)]
    for row, col in candidates:
        center = np.array([(col + .5) * road.step, road.height - (row + .5) * road.step])
        for yaw in np.linspace(0., math.pi, 72, endpoint=False):
            u = np.array([math.cos(yaw), math.sin(yaw)])
            rotation = np.array([[u[0], u[1]], [-u[1], u[0]]])
            if all(road.contains(patch @ rotation + center + shift * u) for shift in (-.012, 0., .012)):
                route = _resample(np.array([center - .012 * u, center, center + .012 * u]), .002)
                if road.contains(route):
                    return route
    raise ValueError('닫힌 주행 영역 안에서 차량의 네 바퀴를 안전하게 놓을 출발 위치를 찾지 못했습니다.')


def generate_reference(mask, vehicle, resolution=.001):
    """Return ``(closed_world_xy_route, metadata)`` for an enclosed road mask.

    Every reference has at least three finite points. ``completion_enabled``
    is true only for a collision-safe circuit with plausible turning radii.
    Geometry creation remains available when only a diagnostic reference fits.
    A false completion flag MUST be respected by lap/progress consumers.
    """
    mask = np.asarray(mask)
    resolution = float(resolution)
    if (mask.ndim != 2 or min(mask.shape, default=0) < 1 or
            not math.isfinite(resolution) or resolution <= 0):
        raise ValueError('주행 영역은 비어 있지 않은 2차원 마스크와 양의 해상도가 필요합니다.')
    safe_radius, minimum_radius = _vehicle_dimensions(vehicle)
    road = _Road(mask, resolution)
    if not road.distance.size or not np.any(road.distance):
        raise ValueError('차량을 배치할 닫힌 주행 영역이 없습니다.')
    best = fallback = None
    best_score = fallback_score = -1.
    inset_minimum = safe_radius + math.sqrt(2) * road.step + .004
    insets = sorted(set((inset_minimum, max(.185, inset_minimum), max(.215, inset_minimum))))
    for inset in insets:
        binary = (road.distance >= inset).astype(np.uint8)
        contours, _ = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=lambda contour: (-abs(cv2.contourArea(contour)),
                                            int(contour[:, 0, 1].max()), int(contour[:, 0, 0].min())))
        for contour in contours:
            if len(contour) < 3 or abs(cv2.contourArea(contour)) * road.step ** 2 < .0001:
                continue
            coordinates = contour[:, 0].astype(float)
            bbox_area = float(np.ptp(coordinates[:, 0]) * np.ptp(coordinates[:, 1]) * road.step ** 2)
            if bbox_area < best_score:
                continue
            points = np.column_stack(((coordinates[:, 0] + .5) * road.step,
                                      road.height - (coordinates[:, 1] + .5) * road.step))
            base = _resample(points)
            if base is None:
                continue
            variants = [(False, _smooth(base, sigma)) for sigma in (0., .015, .03, .06, .12, .20, .32, .48)]
            variants += [(True, _round_corners(base, sigma, minimum_radius)) for sigma in (.24, .32, .40)]
            for local_rounding, points in variants:
                route = _resample(points)
                if route is None:
                    continue
                # The distance field is a conservative bound on the original
                # 1 mm mask. An extra half-segment margin covers every point
                # between the dense samples, including the closing segment.
                clearance = road.clearance(route)
                disk_safe = float(clearance.min()) >= safe_radius + .0025
                if not disk_safe and not local_rounding:
                    continue
                if not disk_safe and float(clearance.min()) < .01:
                    continue
                score = abs(_area(route))
                if disk_safe and score > fallback_score:
                    fallback, fallback_score = route, score
                if float(np.max(_curvature(route))) > 1.08 / minimum_radius:
                    continue
                if not disk_safe and (score <= best_score or not _full_resolution_check(road, route, vehicle)):
                    continue
                if score > best_score:
                    best, best_score = route, score
    enabled = best is not None
    route = best if enabled else fallback
    if route is None:
        route = _stationary_reference(road, vehicle, safe_radius)
    route = _canonical(route)
    if not _full_resolution_check(road, route, vehicle, steering_extremes=enabled):
        # No unverified contour can silently become a completion circuit.
        route = _canonical(_stationary_reference(road, vehicle, safe_radius))
        enabled = False
        if not _full_resolution_check(road, route, vehicle, steering_extremes=False):
            raise ValueError('닫힌 주행 영역 안에서 안전한 차량 출발 위치를 찾지 못했습니다.')
    maximum_curvature = float(np.max(_curvature(route)))
    info = {
        'reference_route_kind': 'generated_circuit' if enabled else 'enclosure_reference',
        'completion_enabled': bool(enabled),
        'spawn_index': 0,
        'reference_path_definition': 'deterministic inset boundary of the enclosed drivable region',
        'reference_minimum_turn_radius_m': float(minimum_radius),
        'reference_clearance_disk_radius_m': float(safe_radius),
        'reference_max_curvature_per_m': maximum_curvature if math.isfinite(maximum_curvature) else None,
        'reference_enclosed_area_m2': abs(_area(route)),
    }
    return route, info
