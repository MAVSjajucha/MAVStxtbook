"""Small stdlib-only parent which survives native crashes in the learner.

Gazebo's server, bridge, and GUI run in separate sessions. Their ownership is
registered explicitly so a failed learner cannot leave a moving simulation or a
panel that still says 'training'. No process is selected by executable name.
"""
from __future__ import annotations

import fcntl
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
import uuid


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    temporary.replace(path)


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def process_identity(pid):
    """Return Linux process start ticks, plus process group; reject zombies."""
    try:
        stat = Path(f'/proc/{int(pid)}/stat').read_text()
        fields = stat[stat.rfind(')') + 2:].split()
        if fields[0] == 'Z':
            return None
        return {'pid': int(pid), 'start_ticks': fields[19], 'pgid': int(fields[2])}
    except (OSError, ValueError, IndexError):
        return None


def register_process(role, pid):
    """Called just after each owned start_new_session=True Popen."""
    token = os.environ.get('LANE_LAB_SUPERVISOR_TOKEN')
    directory = os.environ.get('LANE_LAB_SUPERVISOR_RUNTIME')
    if not token or not directory:
        return  # Direct developer / doctor runs do not belong to a supervisor.
    if role not in ('server', 'bridge', 'gui'):
        raise ValueError('Unknown managed process role')
    identity = process_identity(pid)
    if identity is None:
        return  # An immediately failed process is handled by its Popen owner.
    atomic_json(Path(directory) / 'processes' / f'{role}_{pid}.json',
                {'role': role, 'token': token, **identity})


def owned_groups(runtime, token, roles):
    """Check token-bearing members even if the ign launcher has already exited."""
    records = [read_json(path) for path in (Path(runtime) / 'processes').glob('*.json')]
    candidates = {record.get('pgid') for record in records
                  if record.get('token') == token and record.get('role') in roles
                  and record.get('pgid') == record.get('pid')}
    candidates.discard(None)
    result = set()
    if not candidates:
        return result
    marker = ('LANE_LAB_SUPERVISOR_TOKEN=' + token).encode()
    for path in Path('/proc').glob('[0-9]*'):
        identity = process_identity(path.name)
        if identity is None or identity['pgid'] not in candidates:
            continue
        try:
            environment = (path / 'environ').read_bytes().split(b'\0')
        except OSError:
            continue
        if marker in environment:
            result.add(identity['pgid'])
    return result


def stop_owned(runtime, token, roles, timeout=4.0):
    groups = owned_groups(runtime, token, roles)
    for group in groups:
        try:
            os.killpg(group, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + timeout
    while groups and time.monotonic() < deadline:
        groups &= owned_groups(runtime, token, roles)
        if groups:
            time.sleep(.05)
    # Re-check ownership immediately before SIGKILL; never signal a reused PID.
    for group in groups & owned_groups(runtime, token, roles):
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass


def failure_status(runtime, returncode):
    value = read_json(Path(runtime) / 'status.json')
    if returncode < 0:
        try:
            reason = signal.Signals(-returncode).name
        except ValueError:
            reason = f'signal {-returncode}'
    else:
        reason = f'exit {returncode}'
    message = (f'학습 프로그램이 종료됐습니다 ({reason}). 시뮬레이션을 멈췄습니다. '
               '‘프로그램 복구’를 누른 뒤 ‘자동 저장 체크포인트 복구’ 버튼을 확인하세요. '
               '첫 PPO 업데이트 전에는 복구할 체크포인트가 없을 수 있습니다. '
               '오류 기록: runtime/app.log')
    value.update(status='error', backend_dead=True, backend_exit_code=returncode,
                 message=message, rtf=0)
    atomic_json(Path(runtime) / 'status.json', value)
    return message


def run_supervised(root, command=None, headless=False):
    root = Path(root).resolve()
    runtime = root / 'runtime'
    runtime.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    metadata = runtime / 'supervisor.json'
    recovery = runtime / 'recover.json'
    recovery.unlink(missing_ok=True)
    env = os.environ.copy()
    env.update(LANE_LAB_SUPERVISOR_TOKEN=token,
               LANE_LAB_SUPERVISOR_RUNTIME=str(runtime), PYTHONFAULTHANDLER='1',
               PYTHONUNBUFFERED='1')
    command = command or [sys.executable, '-X', 'faulthandler', '-m', 'lane_lab',
                          'app', *sys.argv[1:]]
    interrupted = False
    process = None
    def interrupt(signum, frame):
        nonlocal interrupted
        interrupted = True
        if process is not None and process.poll() is None:
            process.send_signal(signal.SIGTERM)
    old_handlers = {sig: signal.signal(sig, interrupt)
                    for sig in (signal.SIGINT, signal.SIGTERM)}
    result = 0
    try:
        while not interrupted:
            with open(runtime / 'app.log', 'ab', buffering=0) as log:
                log.write(f'\n=== Backend start {time.strftime("%Y-%m-%d %H:%M:%S")} ===\n'.encode())
                process = subprocess.Popen(command, cwd=root, env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    bufsize=0, start_new_session=True)
                atomic_json(metadata, {'token': token, 'supervisor_pid': os.getpid(),
                            'backend_pid': process.pid, 'backend_running': True})
                interrupt_since = None
                while process.poll() is None:
                    ready, _, _ = select.select([process.stdout], [], [], .2)
                    if ready:
                        data = os.read(process.stdout.fileno(), 65536)
                        if data:
                            log.write(data)
                            try:
                                os.write(sys.stdout.fileno(), data)
                            except (OSError, ValueError):
                                pass
                    if interrupted:
                        interrupt_since = interrupt_since or time.monotonic()
                        if time.monotonic() - interrupt_since > 65:
                            process.kill()
                # The backend's own stdout descriptor has closed. Registered
                # Gazebo processes write separate logs, not this pipe.
                while select.select([process.stdout], [], [], 0)[0]:
                    data = os.read(process.stdout.fileno(), 65536)
                    if not data:
                        break
                    log.write(data)
                    try:
                        os.write(sys.stdout.fileno(), data)
                    except (OSError, ValueError):
                        pass
                process.stdout.close()
                result = process.returncode
                atomic_json(metadata, {'token': token, 'supervisor_pid': os.getpid(),
                            'backend_pid': process.pid, 'backend_running': False,
                            'backend_exit_code': result})
            if interrupted or result == 0:
                break
            # Publish the failure before waiting for child-process shutdown.
            message = failure_status(runtime, result)
            print(message, flush=True)
            stop_owned(runtime, token, ('server', 'bridge'))
            if headless:
                break
            # Keep the Gazebo panel alive to display the error and recovery action.
            while not interrupted and owned_groups(runtime, token, ('gui',)):
                request = read_json(recovery)
                if request.get('token') == token and request.get('action') == 'recover':
                    recovery.unlink(missing_ok=True)
                    stop_owned(runtime, token, ('gui',))
                    break
                time.sleep(.2)
            else:
                break
            if interrupted:
                break
            # Only an explicit button request restarts the learner; training is
            # resumed separately using the recorded checkpoint and lesson.
    finally:
        stop_owned(runtime, token, ('server', 'bridge', 'gui'))
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        value = read_json(metadata)
        if value.get('token') == token:
            value.update(supervisor_running=False, backend_running=False)
            atomic_json(metadata, value)
    return result


def main():
    root = Path(__file__).resolve().parents[1]
    (root / 'runtime').mkdir(exist_ok=True)
    with open(root / 'runtime/supervisor.lock', 'a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('이 폴더의 실습이 이미 실행 중입니다. Gazebo 패널의 상태를 확인하세요.', file=sys.stderr)
            return 2
        # Also respect direct developer launches which use only app.lock.
        with open(root / 'runtime/app.lock', 'a') as app_lock:
            try:
                fcntl.flock(app_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                print('이 폴더의 실습이 이미 실행 중입니다.', file=sys.stderr)
                return 2
        return run_supervised(root, headless='--headless' in sys.argv[1:])


if __name__ == '__main__':
    sys.exit(main())
