"""평가용 매 제어 스텝 원자료. 학습 입력이나 보상에는 영향을 주지 않는다."""
from __future__ import annotations

import csv
import math
import time
from pathlib import Path

import numpy as np

from .configuration import atomic_json
from .evaluation_geometry import RearAxleProjection


def angle_difference(a, b):
    return math.atan2(math.sin(a-b), math.cos(a-b))


class EvaluationCSV:
    """한 행 = 행동 전 관측/입력 + 명령 + 행동 후 위치/보상.

    실제 속도는 연속된 Gazebo pose의 유한 차분이다. odom 센서나 명령 속도가
    아니다. 격자는 학생 observe()의 임의 변경을 존중하여, 원본 V/L/R와 정확한
    신경망 입력 배열을 각각 저장한다. reward 내부 지역변수가 없으면 빈칸이다.
    """
    def __init__(self, folder, env, model_metadata, clock=time.monotonic):
        self.folder=Path(folder)
        self.clock=clock
        self.projection=RearAxleProjection(env.track.route,env.track.wheelbase)
        self.reward_capture=env.lesson
        self.episode=0
        self.rows=0
        self.episodes=[]
        self.columns={}

        def fields(items):
            for name,unit,description in items:
                self.columns[name]={'unit':unit,'description':description}

        fields([
            ('episode','count','주행 번호 1, 2, 3'),('step','count','이번 주행의 제어 스텝'),
            ('sim_time_before_s','s','행동 전 Gazebo 시각'),('sim_time_s','s','행동 후 Gazebo 시각'),
            ('elapsed_s','s','중립 초기화 이후 이번 주행의 시뮬레이션 경과 시간'),
            ('wall_elapsed_s','s','이번 주행의 PC 실제 경과 시간; 기록 시점 기준'),
            ('dt_s','s','이번 제어 스텝의 시뮬레이션 시간 차이'),
            ('image_time_before_s','s','입력 특징점에 대응한 영상 생성 시각'),
            ('image_time_after_s','s','행동 후 특징점에 대응한 영상 생성 시각'),
            ('before_x_m','m','행동 전 앞뒤 차축 사이 중앙 x'),
            ('before_y_m','m','행동 전 앞뒤 차축 사이 중앙 y'),
            ('before_yaw_rad','rad','행동 전 차체 방향'),
            ('x_m','m','행동 후 앞뒤 차축 사이 중앙 x'),('y_m','m','행동 후 앞뒤 차축 사이 중앙 y'),
            ('yaw_rad','rad','행동 후 차체 방향'),
            ('rear_x_m','m','행동 후 뒤차축 중앙 x'),('rear_y_m','m','행동 후 뒤차축 중앙 y'),
            ('path_x_m','m','뒤차축 중앙에 가장 가까운 경로점 M의 x'),
            ('path_y_m','m','뒤차축 중앙에 가장 가까운 경로점 M의 y'),
            ('path_heading_rad','rad','M에서 경로 주행 순서를 따르는 접선 방향; 모호한 꼭짓점은 선택된 선분 방향'),
            ('lateral_error_m','m','뒤차축 중앙 O와 M의 부호 있는 최단 거리; 경로 왼쪽 +'),
            ('heading_error_rad','rad','차체 방향 - M의 경로 접선 방향, [-pi,pi]'),
            ('projection_distance_m','m','뒤차축 중앙과 경로 사이 최단 거리의 크기'),
            ('path_segment','index','가장 가까운 경로 선분 인덱스, 0부터'),
            ('projection_vertex','bool','투영점이 저장된 경로의 꼭짓점이면 1'),
            ('projection_ambiguous','bool','동일 최단 거리점/접선이 유일하지 않으면 1'),
            ('projection_normal_valid','bool','유일한 접선에 수직인 투영으로 해석 가능하면 1'),
            ('projection_tangential_residual_m','m','O-M의 선택된 접선 성분; 정상 법선 투영이면 0'),
            ('actual_speed_m_s','m/s','뒤차축 중앙의 두 위치 사이 거리/dt; 유한 차분 근사'),
            ('actual_longitudinal_speed_m_s','m/s','뒤차축 변위를 구간 중간 차체 방향으로 투영/dt'),
            ('actual_yaw_rate_rad_s','rad/s','차체 방향의 래핑 보정 차이/dt'),
            ('distance_step_m','m','이번 스텝 뒤차축 중앙 이동 거리'),
            ('distance_total_m','m','이번 주행 뒤차축 중앙 누적 이동 거리'),
            ('center_distance_step_m','m','이번 스텝 앞뒤 차축 사이 중앙 이동 거리'),
            ('center_distance_total_m','m','이번 주행 앞뒤 차축 사이 중앙 누적 이동 거리'),
            ('previous_steering_command_normalized','1','observe에 전달한 직전 정규화 조향 명령'),
            ('policy_action','1','정책의 실제 출력, act 호출 전'),
            ('steering_command_normalized','1','act가 반환한 정규화 조향 명령'),
            ('target_steering_rad','rad','목표 가상 중앙 조향각'),
            ('cmd_linear_x','m/s','발행한 전진 속도 명령'),
            ('cmd_angular_z','rad/s','발행한 yaw 명령, v*tan(delta)/wheelbase'),
            ('actual_front_left_rad','rad','Gazebo가 보고한 왼쪽 앞바퀴 조향 관절각'),
            ('actual_front_right_rad','rad','Gazebo가 보고한 오른쪽 앞바퀴 조향 관절각'),
            ('rear_left_wheel_rad_s','rad/s','Gazebo 왼쪽 뒷바퀴 회전 속도'),
            ('rear_right_wheel_rad_s','rad/s','Gazebo 오른쪽 뒷바퀴 회전 속도'),
            ('new_progress_m','m','기존 보상용 진행 추적기가 산출한 이번 추가 전진량'),
            ('progress_m','m','기존 보상용 추적기의 누적 최고 진행량; 차량 중앙 기준'),
            ('track_length_m','m','평가 경로 길이'),
            ('wheel_clearance_m','m','이번 이동 중 네 타이어 접지 영역의 최소 차선 여유'),
            ('physical_touched_line','bool','wheel_clearance_m <= 0'),
            ('ever_touched_line','bool','이번 주행 중 물리 차선 접촉이 한 번이라도 있었으면 1'),
            ('lap_completed','bool','기존 진행 추적기의 완주 판정'),
            ('successful_lap','bool','물리 차선 접촉 없는 완주'),
            ('progress','student-defined','실제로 실행한 calculate_reward의 지역변수; 없으면 빈칸'),
            ('near_line','student-defined','실제 보상 지역변수; 없으면 빈칸'),
            ('touched_line','student-defined','실제 보상 지역변수; 학생 기준이 물리 접촉 기준과 다를 수 있음'),
            ('finished','student-defined','실제 보상 지역변수; 없으면 빈칸'),
            ('reward','score','이번 스텝의 최종 보상'),('return_total','score','이번 주행 누적 보상'),
            ('terminated','bool','학생 보상 함수가 종료를 요청했으면 1'),
            ('truncated','bool','설정된 주행 시간 제한에 도달했으면 1'),
            ('end_reason','text','종료 신호와 동시 발생 조건. 임의 학생 코드의 종료 원인을 추정하지 않음'),
        ])
        self.feature_names=([f'v{i+1}' for i in range(env.grid.cols)]+
                            [f'l{i+1}' for i in range(env.grid.rows)]+
                            [f'r{i+1}' for i in range(env.grid.rows)])
        for prefix in ('before','after'):
            for name in self.feature_names:
                fields([(f'{prefix}_{name}_raw_px','px',f'{prefix} 원본 {name.upper()} 특징점 값; 미검출 sentinel 포함')])
        for i in range(env.observation_size):
            fields([(f'input_{i+1:03d}','student-defined',f'정책에 실제 전달한 입력 배열의 {i}번 값 (정규화 이후)')])
        self.metadata={
            'schema_version':1,'status':'running','expected_episodes':3,'rows_written':0,
            'csv':'driving.csv','row_definition':'before observation -> action -> after pose and reward',
            'model':model_metadata,'settings':env.settings,
            'coordinate_definition':{
                'vehicle_pose':'저장 x/y는 앞뒤 차축 사이 중앙점의 Gazebo 월드 좌표. yaw는 월드 +x 기준 반시계 +. 차체 좌표계에서만 +x 전진, +y 왼쪽.',
                'rear_axle':'O=(x-L/2*cos(yaw),y-L/2*sin(yaw))',
                'reference_point':'M = argmin over closed path C of ||O-M||. 차량 횡축과 경로의 교점이 아님.',
                'lateral_error':'유일한 법선 투영일 때 sign(tangent_x*(O_y-M_y)-tangent_y*(O_x-M_x))*||O-M||. 모호한 꼭짓점은 선택된 선분, 그 선분의 부호가 0이면 같은 점의 인접 후보 접선으로 부호 결정. 부호도 결정 불가하면 +거리와 모호성 플래그 저장.',
                'heading_error':'atan2(sin(yaw-path_heading),cos(yaw-path_heading))',
                'route_representation':'world/track.json이 지정한 약 5mm 간격의 폐곡선 polyline. 일반 코스는 기존 차선 중앙 경로, 광장·분기 코스는 자동 생성 기준 경로. 모든 유효 선분의 최단 투영을 비교. 매끄럽지 않은 꼭짓점/동거리 후보는 별도 플래그로 표시.',
                'reference_route_kind':getattr(env.track,'reference_route_kind','legacy_centerline'),
                'completion_enabled':getattr(env.track,'completion_enabled',True),
                'reward_progress':'기존 학습과 동일하게 차량 중앙의 지역 진행 추적기를 사용; 뒤차축 평가 오차와 별개',
            },
            'references':[
                'https://www-sop.inria.fr/members/Philippe.Martinet/publis/2002/AR02Benoit.pdf',
                'https://www-sop.inria.fr/members/Philippe.Martinet/publis/2016/ITSC16salvador.pdf'],
            'input_order':'input_001부터 실제 observe 반환 순서. 복사한 lesson.py의 observe를 참고. 원본 격자는 V(왼쪽부터), L/R(아래부터).',
            'missing_reward_terms':'해당 이름의 유한한 숫자/참거짓 지역변수가 없으면 빈칸. 0으로 추정하지 않음.',
            'columns':self.columns,'episodes':[],
        }
        atomic_json(self.folder/'metadata.json',self.metadata)
        self.file=open(self.folder/'driving.csv','w',newline='',encoding='utf-8-sig')
        self.writer=csv.DictWriter(self.file,fieldnames=list(self.columns))
        self.writer.writeheader();self.file.flush()

    def begin_episode(self, env):
        self.episode=env.episodes
        self.sim_start=float(env.last_result['sim_time'])
        self.wall_start=self.clock()
        self.distance=0.;self.center_distance=0.

    def record_step(self,env,before,observation,action,command,after,state,info,terminated,truncated):
        if self.episode!=env.episodes:
            raise RuntimeError('평가 CSV: 주행 시작 기록이 없습니다.')
        pose=np.asarray(after['pose'],dtype=float)
        old=np.asarray(before['pose'],dtype=float)
        geometry=self.projection.measure(pose)
        old_rear=old[:2]-.5*env.track.wheelbase*np.array([math.cos(old[2]),math.sin(old[2])])
        delta=np.array([geometry['rear_x_m'],geometry['rear_y_m']])-old_rear
        distance=float(np.linalg.norm(delta))
        center_distance=float(np.linalg.norm(pose[:2]-old[:2]))
        self.distance+=distance;self.center_distance+=center_distance
        dyaw=angle_difference(pose[2],old[2]);mid_yaw=old[2]+dyaw/2
        reasons=[]
        if terminated:reasons.append('lesson_termination')
        if truncated:reasons.append('time_limit')
        if terminated or truncated:
            if info['touched_line']:reasons.append('line_contact_present')
            if info['lap_completed']:reasons.append('lap_completed_present')
        front=after['front_angles'];rear=after.get('rear_wheel_rad_s',[None,None])
        row={
            'episode':self.episode,'step':env.step_count,
            'sim_time_before_s':before['sim_time'],'sim_time_s':after['sim_time'],
            'elapsed_s':float(after['sim_time'])-self.sim_start,'wall_elapsed_s':self.clock()-self.wall_start,
            'dt_s':state.dt,'image_time_before_s':before.get('image_time'),
            'image_time_after_s':after.get('image_time'),
            'before_x_m':old[0],'before_y_m':old[1],'before_yaw_rad':old[2],
            'x_m':pose[0],'y_m':pose[1],'yaw_rad':pose[2],**geometry,
            'actual_speed_m_s':distance/state.dt,
            'actual_longitudinal_speed_m_s':float(np.dot(delta,[math.cos(mid_yaw),math.sin(mid_yaw)]))/state.dt,
            'actual_yaw_rate_rad_s':dyaw/state.dt,
            'distance_step_m':distance,'distance_total_m':self.distance,
            'center_distance_step_m':center_distance,'center_distance_total_m':self.center_distance,
            'previous_steering_command_normalized':state.previous_steer,
            'policy_action':float(np.asarray(action).reshape(-1)[0]),
            'steering_command_normalized':command['normalized_steer'],
            'target_steering_rad':command['steering_rad'],'cmd_linear_x':command['speed_m_s'],
            'cmd_angular_z':command['speed_m_s']*math.tan(command['steering_rad'])/env.track.wheelbase,
            'actual_front_left_rad':front[0],'actual_front_right_rad':front[1],
            'rear_left_wheel_rad_s':rear[0],'rear_right_wheel_rad_s':rear[1],
            'new_progress_m':state.new_progress_m,'progress_m':info['progress_m'],
            'track_length_m':info['track_length_m'],'wheel_clearance_m':info['wheel_clearance_m'],
            'physical_touched_line':info['touched_line'],'ever_touched_line':info['ever_touched_line'],
            'lap_completed':info['lap_completed'],'successful_lap':info['successful_lap'],
            **self.reward_capture.last_terms,
            'reward':info['reward'],'return_total':info['episode_return'],
            'terminated':terminated,'truncated':truncated,'end_reason':';'.join(reasons),
        }
        for prefix,result in (('before',before),('after',after)):
            features=result['features']
            values=np.concatenate((features.V,features.L,features.R))
            row.update({f'{prefix}_{name}_raw_px':int(value) for name,value in zip(self.feature_names,values)})
        row.update({f'input_{i+1:03d}':float(value) for i,value in enumerate(observation)})
        # 참/거짓은 0/1, 없는 값은 빈칸으로 저장한다. 알 수 없는 열은 오류로 알린다.
        row={k:int(v) if isinstance(v,(bool,np.bool_)) else v for k,v in row.items()}
        self.writer.writerow(row)
        self.file.flush()  # 중단해도 완료된 스텝은 파일에 남긴다.
        self.rows+=1
        if terminated or truncated:
            self.episodes.append({'episode':self.episode,'steps':env.step_count,
                'elapsed_s':row['elapsed_s'],'return_total':info['episode_return'],
                'successful_lap':bool(info['successful_lap']),'end_reason':row['end_reason']})
            self._save_metadata('running')

    def _save_metadata(self,status,error=None):
        self.metadata.update(status=status,rows_written=self.rows,episodes=self.episodes)
        if error:self.metadata['error']=error
        atomic_json(self.folder/'metadata.json',self.metadata)

    def finish(self,status,error=None):
        try:self.file.close()
        finally:self._save_metadata(status,error)
