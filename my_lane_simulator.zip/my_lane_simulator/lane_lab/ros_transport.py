"""Gazebo ↔ ROS bridge and timestamp-matched training observations.

Training lives in the process that owns DRL_node. Gym calls command(), advances
the paused physics through the native world-control adapter, then requests the
features for that exact camera stamp. A newer/older frame is never substituted.
"""
from collections import OrderedDict
import json
import math
import os
from pathlib import Path
import shlex
import subprocess
import sys
import threading
import time

from .ros_nodes import CAMERA_TOPIC, FEATURES_TOPIC, features_from_message, stamp_ns
from .vision import GridConfig


class SimulationRosPipeline:
    _domains = set()
    _domain_lock = threading.Lock()

    def __init__(self, root, runtime, settings, process_env=None):
        self.root, self.runtime = Path(root), Path(runtime)
        self.settings = settings
        self.config = GridConfig.from_mapping(settings['vision'])
        self.env = dict(process_env or os.environ)
        # Private, local-only ROS domain: simulation /cmd_vel cannot reach a car.
        preferred_domain = int(self.env.get('LANE_SIM_ROS_DOMAIN_ID', 130 + os.getpid() % 70))
        if not 0 <= preferred_domain <= 232:
            raise ValueError('LANE_SIM_ROS_DOMAIN_ID는 0~232여야 합니다.')
        # A preview is prepared before replacing its old world. Give concurrent
        # candidate worlds different domains so their identical topic names and
        # clock stamps cannot cross during this handover.
        with self._domain_lock:
            available = [(preferred_domain + offset) % 233 for offset in range(233)
                         if (preferred_domain + offset) % 233 not in self._domains]
            if not available:
                raise RuntimeError('사용 가능한 시뮬레이터 ROS 도메인이 없습니다.')
            self.domain_id = available[0]
            self._domains.add(self.domain_id)
        self.env.update(ROS_DOMAIN_ID=str(self.domain_id), ROS_LOCALHOST_ONLY='1',
                        LANE_SIMULATOR_ROOT=str(self.root), PYTHONNOUSERSITE='1')
        self.env.pop('ROS_NAMESPACE', None)
        self.features = OrderedDict()
        self.condition = threading.Condition()
        self.failure = None
        self.node = self.context = self.executor = self.thread = None
        self.bridge = self.grid = None
        self.logs = []
        self.closed = False

    def _spawn(self, command, name):
        setup = self.root / 'ros_ws/install/setup.bash'
        if not setup.is_file():
            raise RuntimeError('ROS 메시지 빌드가 필요합니다. bash install.sh를 실행하세요.')
        # All paths are shell-quoted. The shell only performs required ROS setup.
        script = ('source /opt/ros/humble/setup.bash && source ' + shlex.quote(str(setup))
                  + ' && exec ' + shlex.join(command))
        log = open(self.runtime / (name + '.log'), 'a', buffering=1)
        self.logs.append(log)
        process = subprocess.Popen(['/bin/bash', '-c', script], env=self.env, cwd=self.root,
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        from .supervisor import register_process
        register_process('bridge', process.pid)
        return process

    def _grid_start(self):
        settings_path = self.runtime / 'ros_grid_settings.json'
        temporary = settings_path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'vision': self.settings['vision']}, indent=2), encoding='utf-8')
        temporary.replace(settings_path)
        # Use the learner's OpenCV/NumPy versions so splitting the node cannot
        # silently change the preprocessing implementation on this PC.
        interpreter = self.root / '.venv/bin/python'
        executable = str(interpreter) if interpreter.is_file() else sys.executable
        self.grid = self._spawn([executable, '-m', 'lane_lab.ros_nodes',
                                 '--settings', str(settings_path), '--use-sim-time'], 'grid_node')

    def start(self):
        import rclpy
        from rclpy.context import Context
        from rclpy.executors import SingleThreadedExecutor
        from rclpy.node import Node
        from rclpy.parameter import Parameter
        from geometry_msgs.msg import Twist
        from my_lane_simulator_interfaces.msg import LaneFeatures

        self.runtime.mkdir(parents=True, exist_ok=True)
        self.env['PYTHONPATH'] = str(self.root) + os.pathsep + self.env.get('PYTHONPATH', '')
        self.context = Context()
        # rclpy reads this at context creation, whereas subprocesses use self.env.
        # Only this simulator process is affected; vehicle launch is independent.
        os.environ['ROS_LOCALHOST_ONLY'] = '1'
        # context-specific domain avoids changing a caller's ROS environment.
        rclpy.init(args=[], context=self.context, domain_id=self.domain_id)
        self.node = Node('DRL_node', context=self.context, use_global_arguments=False,
                         parameter_overrides=[Parameter('use_sim_time', value=True)])
        self.publisher = self.node.create_publisher(Twist, '/cmd_vel', 10)
        self.subscription = self.node.create_subscription(LaneFeatures, FEATURES_TOPIC,
                                                          self._on_features, 128)
        self.executor = SingleThreadedExecutor(context=self.context)
        self.executor.add_node(self.node)
        self.thread = threading.Thread(target=self._spin, name='DRL_node-executor', daemon=True)
        self.thread.start()
        bridge_settings = [
            {'ros_topic_name': CAMERA_TOPIC, 'gz_topic_name': '/lane_lab/camera',
             'ros_type_name': 'sensor_msgs/msg/Image', 'gz_type_name': 'ignition.msgs.Image',
             'direction': 'GZ_TO_ROS', 'subscriber_queue': 8, 'publisher_queue': 8},
            {'ros_topic_name': '/cmd_vel', 'gz_topic_name': '/lane_lab/cmd_vel',
             'ros_type_name': 'geometry_msgs/msg/Twist', 'gz_type_name': 'ignition.msgs.Twist',
             'direction': 'ROS_TO_GZ', 'subscriber_queue': 10, 'publisher_queue': 10},
            {'ros_topic_name': '/clock', 'gz_topic_name': '/world/lane_lab/clock',
             'ros_type_name': 'rosgraph_msgs/msg/Clock', 'gz_type_name': 'ignition.msgs.Clock',
             'direction': 'GZ_TO_ROS'},
        ]
        path = self.runtime / 'ros_bridge.yaml'
        # JSON is valid YAML and avoids a runtime PyYAML dependency.
        path.write_text(json.dumps(bridge_settings, indent=2), encoding='utf-8')
        try:
            self.bridge = self._spawn(['ros2', 'run', 'ros_gz_bridge', 'parameter_bridge',
                                      '--ros-args', '-p', 'config_file:=' + str(path)], 'ros_gz_bridge')
            self._grid_start()
            self._ready()
        except Exception:
            self.close()
            raise

    def _ready(self, timeout=20):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self._healthy()
            if (self.publisher.get_subscription_count() > 0
                    and self.node.count_publishers(FEATURES_TOPIC) > 0
                    and self.node.count_subscribers(CAMERA_TOPIC) > 0):
                return
            time.sleep(.05)
        raise TimeoutError('ROS 브리지/격자 노드 준비 시간 초과. runtime/ros_gz_bridge.log와 grid_node.log를 확인하세요.')

    def _spin(self):
        try:
            while not self.closed and self.context.ok():
                self.executor.spin_once(timeout_sec=.1)
        except Exception as error:
            if not self.closed:
                with self.condition:
                    self.failure = str(error)
                    self.condition.notify_all()

    def _on_features(self, message):
        try:
            stamp = stamp_ns(message.header)
            features = features_from_message(message, self.config)
            with self.condition:
                self.features[stamp] = features
                while len(self.features) > 128:
                    self.features.popitem(last=False)
                self.condition.notify_all()
        except Exception as error:
            with self.condition:
                self.failure = str(error)
                self.condition.notify_all()

    def _healthy(self):
        if self.closed:
            raise RuntimeError('시뮬레이터 ROS 연결이 종료되었습니다.')
        if self.node is None or self.context is None or not self.context.ok():
            raise RuntimeError('시뮬레이터 ROS 연결이 준비되지 않았습니다.')
        if self.failure:
            raise RuntimeError('DRL_node 통신 실패: ' + self.failure)
        for name, process in (('ros_gz_bridge', self.bridge), ('grid_node', self.grid)):
            if process is not None and process.poll() is not None:
                raise RuntimeError(f'{name} 종료: runtime/{name}.log를 확인하세요.')

    def command(self, speed, steering, wheelbase):
        from geometry_msgs.msg import Twist
        self._healthy()
        speed, steering, wheelbase = float(speed), float(steering), float(wheelbase)
        if not all(math.isfinite(v) for v in (speed, steering, wheelbase)) or wheelbase <= 0:
            raise ValueError('속도/조향/축간거리 명령을 확인하세요.')
        yawrate = speed * math.tan(steering) / wheelbase
        command = Twist()
        command.linear.x, command.angular.z = speed, yawrate
        # A1 linear.y is intentionally zero: nonzero selects direct steering mode.
        self.publisher.publish(command)
        return yawrate

    def features_for(self, image_time, timeout=15):
        target = int(round(float(image_time) * 1_000_000_000))
        deadline = time.monotonic() + timeout
        with self.condition:
            while True:
                self._healthy()
                if target in self.features:
                    return self.features[target]
                # JSON float conversion can differ by <1 microsecond at long
                # simulation runtimes. This is far below a 50 ms camera period.
                close = [key for key in self.features if abs(key - target) <= 1000]
                if close:
                    return self.features[min(close, key=lambda key: abs(key-target))]
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    latest = max(self.features, default=-1) / 1e9
                    raise TimeoutError(f'촬영 시각이 일치하는 격자 대기 실패: 요청 {image_time:.6f}s, 최신 {latest:.6f}s')
                self.condition.wait(min(.1, remaining))

    def update_settings(self, settings):
        new_config = GridConfig.from_mapping(settings['vision'])
        self.settings = settings
        if new_config == self.config:
            return
        from .transport import stop_process_group
        stop_process_group(self.grid)
        # Only frames after reconfiguration can feed the new observation shape.
        with self.condition:
            self.config = new_config
            self.features.clear()
            self.failure = None
        self._grid_start()
        self._ready()

    def stop(self):
        if self.node is not None and self.context.ok():
            from geometry_msgs.msg import Twist
            self.publisher.publish(Twist())

    def close(self):
        if self.closed:
            return
        try:
            self.stop()
        finally:
            self.closed = True
            with self.condition:
                self.condition.notify_all()
            from .transport import stop_process_group
            for process in (self.grid, self.bridge):
                stop_process_group(process)
            if self.thread is not None:
                self.thread.join(timeout=2)
            if self.executor is not None:
                self.executor.shutdown(timeout_sec=2)
            if self.node is not None:
                self.node.destroy_node()
            if self.context is not None and self.context.ok():
                self.context.shutdown()
            for log in self.logs:
                log.close()
            with self._domain_lock:
                self._domains.discard(self.domain_id)
