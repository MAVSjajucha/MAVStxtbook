"""Gazebo panel command loop and managed training/evaluation workers."""
from __future__ import annotations
import csv
import copy
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
import uuid

import cv2
import numpy as np

# Set this once, before starting any application workers. The crash core from
# 2026-09-21 ended inside OpenCV's pthread pool while processing a camera image.
# 640x480 images do not need that additional pool alongside Gazebo and PPO.
# Keep vision.py unchanged: saved experiments retain identical ROI/features.
cv2.setNumThreads(1)
cv2.ocl.setUseOpenCL(False)

from .configuration import (atomic_json,read_settings,check_lesson,sha256,
                            lesson_gamma,load_lesson,checked_gamma)
from .lighting import migrate_friction_settings
from .settings_store import SettingsStore
from .environment import LaneEnv,StopRequested
from .checkpoints import atomic_save_model,save_checkpoint,resume_candidate,resume_settings,resume_status
from .transport import Simulator,stop_process_group
from .vision import GridConfig,extract_features,draw_grid
from .worlds import generate
# BEST_LAST_PATCH_V1
from .best_last import BestLastSelector,save_last_snapshot,read_options,load_choice
from .model_selection import prepare_evaluation,prepare_resume,validate_resume_selection
from .best_last_export import prepare_export,export_selected_model
from .evaluation_csv import EvaluationCSV
from .evaluation_reward import RewardCapture


class App:
    def __init__(self,root,headless=False):
        os.environ['ROS_DOMAIN_ID']=str(100+(os.getpid()%100))
        os.environ['ROS_LOCALHOST_ONLY']='1'
        self.root=Path(root).resolve(); self.runtime=self.root/'runtime'
        self.runtime.mkdir(exist_ok=True); (self.runtime/'commands').mkdir(exist_ok=True)
        # Discard stale requests from a previous launch, never replay a train action.
        for path in (self.runtime/'commands').glob('*.json'): path.unlink()
        self.settings_store=SettingsStore(self.root)
        self.cfg=self.settings_store.load()
        self.status={'status':'starting','message':'Gazebo 준비 중','steps':0,'episodes':0,'rtf':0.,'preview_seq':0,
                     'settings_warning':self.settings_store.warning}
        self.lock=threading.Lock(); self.write_status(**resume_status(self.root),**self.model_status())
        self.stop_event=threading.Event();self.quit_event=threading.Event()
        self.worker=None;self.sim=None;self.gui=None;self.headless=headless
        self.last_preview=0.; self.last_status=0.
        self.scene_reloading=False
        self.lifecycle_lock=threading.RLock()
        self.sim_settings=None;self.scene_key=None;self.gui_log=None
        self.gui_restart_attempts=0
        os.environ['LANE_LAB_ROOT']=str(self.root);os.environ['LANE_LAB_RUNTIME']=str(self.runtime)
        # Different packages/instances cannot accidentally command each other's cars.
        os.environ['IGN_PARTITION']='lane_lab_'+uuid.uuid4().hex[:12]
        os.environ['IGN_GUI_PLUGIN_PATH']=str(self.root/'build/gui')+os.pathsep+os.environ.get('IGN_GUI_PLUGIN_PATH','')
        os.environ['IGN_GAZEBO_RESOURCE_PATH']=str(self.root/'assets')+os.pathsep+os.environ.get('IGN_GAZEBO_RESOURCE_PATH','')

    def write_status(self,*,clear_error=False,error_generation=None,**values):
        with self.lock:
            if clear_error and self.status.get('status')=='error':
                # Keep a new runtime error raised while preflight was running.
                if error_generation!=getattr(self,'error_generation',0):return
                # A passed code check clears its error label without hiding a
                # still-running training/evaluation worker or an ongoing stop.
                worker=getattr(self,'worker',None)
                previous=getattr(self,'last_non_error_status','ready')
                active=('preview','training','evaluating','exporting','starting','stopping')
                if worker is not None and worker.is_alive():
                    values['status']='stopping' if self.stop_event.is_set() else previous if previous in active else 'ready'
                else:values['status']='ready'
            if values.get('status')=='error':
                self.error_generation=getattr(self,'error_generation',0)+1
            if values.get('status') and values['status']!='error':
                self.last_non_error_status=values['status']
            elif self.status.get('status')!='error':
                self.last_non_error_status=self.status.get('status','ready')
            self.status.update(values)
            atomic_json(self.runtime/'status.json',self.status)

    def error(self,exc):
        details=''.join(traceback.format_exception(type(exc),exc,exc.__traceback__))
        with open(self.runtime/'backend.log','a') as f:f.write(details+'\n')
        # Include source filename and line for student code mistakes.
        tb=traceback.extract_tb(exc.__traceback__)
        loc=next((f'{Path(t.filename).name}:{t.lineno}: ' for t in reversed(tb) if Path(t.filename).name in ('agent.py','lesson.py','lighting.py')),'')
        if isinstance(exc,SyntaxError):loc=f'{Path(exc.filename).name if exc.filename else "agent.py"}:{exc.lineno}: '
        self.write_status(status='error',message=loc+str(exc))

    # Only these values affect the generated physical / rendered world. Other
    # settings (ROI, reward code, PPO steps and wall-time speed) need no restart.
    world_setting_keys=('track','custom_tiles','vehicle','camera_pitch_deg',
                        'camera_hfov_deg','light_level','light_brightness','lighting',
                        'track_specular','extra_light_type','extra_lights','mass_kg',
                        'friction_mu1','friction_mu2','render_engine','world_plugins')

    def world_key(self,settings):
        settings=migrate_friction_settings(settings)
        values={key:settings[key] for key in self.world_setting_keys if key in settings}
        # Editing vehicle/track JSON by hand must also invalidate the live scene.
        paths=[self.root/'config/vehicle.json']
        if settings.get('track')!='custom':
            paths.append(self.root/'config/tracks'/(settings.get('track','track1')+'.json'))
        values['source_hashes']={str(p.relative_to(self.root)):sha256(p) for p in paths}
        def normalize(value):
            # QJson writes whole-valued doubles as integers (20.0 -> 20).
            # Preserve numeric equality through nested settings, while keeping
            # booleans distinct and avoiding int -> float precision loss.
            if isinstance(value,dict):return {k:normalize(v) for k,v in value.items()}
            if isinstance(value,(list,tuple)):return [normalize(v) for v in value]
            if isinstance(value,float) and value.is_integer():return int(value)
            return value
        return json.dumps(normalize(values),sort_keys=True,ensure_ascii=False)

    def lifecycle_event(self,event,**values):
        with open(self.runtime/'lifecycle.log','a') as stream:
            stream.write(json.dumps({'time':time.strftime('%Y-%m-%d %H:%M:%S'),
                         'event':event,**values},ensure_ascii=False)+'\n')

    def close_gui(self):
        # The lifecycle lock prevents the main loop from observing a deliberately
        # terminated GUI as if the student had closed the entire application.
        process=self.gui;self.gui=None
        if process is not None:
            self.lifecycle_event('gui_stop_requested',pid=process.pid,exit_code=process.poll())
            stop_process_group(process)
            self.lifecycle_event('gui_stopped',pid=process.pid,exit_code=process.returncode)
        if self.gui_log and not self.gui_log.closed:self.gui_log.close()
        self.gui_log=None

    def start_scene(self,settings,info):
        # Isolate discovery on every full reload; never start two renderers at once.
        os.environ['IGN_PARTITION']='lane_lab_'+uuid.uuid4().hex[:12]
        self.lifecycle_event('scene_start',partition=os.environ['IGN_PARTITION'],world=info['world_path'])
        candidate=Simulator(self.root,self.runtime,info,settings)
        try:
            candidate.start()
            # Read an actual settled camera frame before replacing the GUI. A
            # ready transport service alone does not prove the renderer works.
            candidate.reset()
            if not self.headless:self.start_gui(settings)
        except Exception:
            self.close_gui()
            candidate.close()
            raise
        self.sim=candidate
        self.sim_settings=copy.deepcopy(settings)
        self.scene_key=self.world_key(settings)
        self.gui_restart_attempts=0
        self.lifecycle_event('scene_ready',world=info['world_path'])
        return candidate

    def configure_sim(self,settings,output=None):
        # Do not advance the recovery snapshot until a rendered scene is ready.
        # The marker lets the next launch recover even after a hard interruption.
        self.settings_store.begin_apply(self.cfg)
        try:
            sim=self._configure_sim(settings,output)
        except Exception as exc:
            # Scene-start failures already restore the snapshot before opening
            # the rollback GUI. Generation failures are restored here instead.
            if self.settings_store.pending.exists():
                self.cfg=self.settings_store.reject(exc)
            self.write_status(settings_warning=self.settings_store.warning)
            raise
        self.settings_store.accept(self.cfg)
        return sim

    def _configure_sim(self,settings,output=None):
        key=self.world_key(settings)
        reusable=(self.sim is not None and self.scene_key==key and
                  getattr(self.sim,'is_alive',lambda:True)())
        if reusable:
            # Training/evaluation still get an immutable world + truth snapshot.
            # Only the live renderer is reused, never the experiment record.
            if output is not None:
                self.sim.info=generate(self.root,settings,output)
            self.sim.update_settings(settings)
            self.sim_settings=copy.deepcopy(settings)
            self.lifecycle_event('scene_reused',world=self.sim.info['world_path'])
            return self.sim
        # Invalid track/settings or file errors leave the current window intact.
        # Unique directories also preserve the last good world for rollback.
        target=output or self.runtime/'worlds'/uuid.uuid4().hex[:12]
        self.write_status(status='starting',message='환경을 준비합니다. 기존 화면은 준비가 끝날 때까지 유지됩니다.')
        info=generate(self.root,settings,target)
        with self.lifecycle_lock:
            self.scene_reloading=True
            previous_info=copy.deepcopy(self.sim.info) if self.sim else None
            previous_settings=copy.deepcopy(self.sim_settings)
            try:
                self.write_status(status='starting',message='변경한 환경을 적용합니다. Gazebo 화면이 한 번 다시 열립니다.')
                self.close_gui()
                if self.sim:self.sim.close();self.sim=None
                try:
                    return self.start_scene(settings,info)
                except Exception as exc:
                    self.lifecycle_event('scene_failed',error=str(exc))
                    self.sim=None;self.scene_key=None
                    # The new GUI reads settings.json in its constructor. Restore
                    # the controls BEFORE reopening the previous scene, not after.
                    self.cfg=self.settings_store.reject(exc)
                    self.write_status(settings_warning=self.settings_store.warning)
                    if previous_info is not None and previous_settings is not None:
                        self.write_status(status='starting',message='새 환경을 열지 못해 이전 환경을 복구합니다.')
                        try:
                            self.start_scene(previous_settings,previous_info)
                        except Exception as rollback_error:
                            self.lifecycle_event('rollback_failed',error=str(rollback_error))
                            raise RuntimeError(f'환경 적용 및 이전 환경 복구 실패: {exc}; {rollback_error}. runtime 로그를 확인하세요.') from exc
                        raise RuntimeError(f'환경 적용 실패. 이전 화면을 복구했습니다. {exc}') from exc
                    raise
            finally:self.scene_reloading=False

    def start_gui(self,settings=None):
        settings=settings or self.cfg
        cfg=(self.root/'config/gui.config.in').read_text().replace('@WORLD_NAME@','lane_lab')
        cfg=cfg.replace('<engine>ogre2</engine>','<engine>'+settings['render_engine']+'</engine>')
        (self.runtime/'gui.config').write_text(cfg)
        self.gui_log=open(self.runtime/'gui.log','a')
        self.gui_log.write('\n=== Starting Gazebo GUI ===\n');self.gui_log.flush()
        self.gui=subprocess.Popen(['ign','gazebo','-g','--gui-config',str(self.runtime/'gui.config'),'-v','2'],
                    stdout=self.gui_log,stderr=subprocess.STDOUT,start_new_session=True)
        from .supervisor import register_process
        register_process('gui',self.gui.pid)
        self.lifecycle_event('gui_started',pid=self.gui.pid)
        try:
            code=self.gui.wait(timeout=.5)
        except subprocess.TimeoutExpired:
            return
        raise RuntimeError(f'Gazebo 화면이 시작 중 종료됐습니다 (종료 코드 {code}). runtime/gui.log 확인.')

    def gui_closed(self):
        """Inspect/recover a GUI exit without racing scene replacement."""
        with self.lifecycle_lock:
            if self.scene_reloading or self.gui is None:return False
            code=self.gui.poll()
            if code is None:return False
            self.lifecycle_event('gui_exited',pid=self.gui.pid,exit_code=code)
            if code==0:return True  # normal window close
            # Preserve the server and current lesson if only the renderer crashed.
            if self.gui_restart_attempts<1 and self.sim is not None:
                self.gui_restart_attempts+=1
                try:
                    self.close_gui()
                    self.start_gui(self.sim_settings)
                    self.write_status(message=f'Gazebo 화면을 복구했습니다 (이전 종료 코드 {code}). runtime/gui.log에 원인이 기록됩니다.')
                    return False
                except Exception as exc:self.error(exc)
            else:
                self.error(RuntimeError(f'Gazebo 화면이 다시 종료됐습니다 (종료 코드 {code}). runtime/gui.log와 lifecycle.log를 확인하세요.'))
            return True

    def preview(self):
        sim=self.configure_sim(self.cfg)
        result=sim.reset()
        message='설정 적용 완료. 학습 진행을 누르면 시작합니다.'
        if not sim.info.get('completion_enabled',True):
            message='주행 구역 생성 완료. 순환 주행 기준 경로가 없어 완주 판정은 사용하지 않습니다.'
        elif sim.info.get('reference_route_kind')=='generated_circuit':
            message='주행 구역 생성 완료. 자동 생성한 기준 경로로 진행량과 완주를 판단합니다.'
        self.write_status(status='preview',message=message,steps=0,episodes=0,rtf=0.,**resume_status(self.root),**self.model_status())
        grid=GridConfig.from_mapping(self.cfg['vision'])
        while not self.stop_event.is_set():
            features=result['features']
            self.update_image(result['image'],features,grid,force=True)
            if self.stop_event.wait(.25):break
            result=sim.step(0,0)
        sim.stop()

    def update_image(self,image,features,grid,force=False):
        now=time.monotonic()
        if not force and now-self.last_preview < 1/float(self.cfg['preview_hz']):return
        overlay=draw_grid(image,features,grid)
        success,data=cv2.imencode('.jpg',overlay,[cv2.IMWRITE_JPEG_QUALITY,85])
        if success:
            tmp=self.runtime/'preview.tmp';tmp.write_bytes(data.tobytes());tmp.replace(self.runtime/'preview.jpg')
            self.last_preview=now
            self.write_status(preview_seq=self.status['preview_seq']+1)

    def report(self,result,features,info,env):
        self.report_progress(result,features,info,env)
        if env.step_count%10==0 or info['touched_line'] or info['lap_completed']:
            self.metrics.writerow({k:info[k] for k in self.metric_fields})
            self.metric_file.flush()

    def report_progress(self,result,features,info,env):
        self.update_image(result['image'],features,env.grid)
        now=time.monotonic()
        if now-self.last_status>.25:
            self.write_status(steps=env.total_steps,episodes=env.episodes,rtf=info['rtf'],
                 message=f"전진 {info['progress_m']:.2f}/{info['track_length_m']:.2f} m · 바퀴 여유 {info['wheel_clearance_m']*1000:.0f} mm · 보상 {info['reward']:.3f}")
            self.last_status=now

    metric_fields=['progress_m','wheel_clearance_m','touched_line','ever_touched_line',
                   'lap_completed','successful_lap','reward','episode_return','episode_steps','rtf']

    def open_metrics(self,path):
        self.metric_file=open(path,'w',newline='')
        self.metrics=csv.DictWriter(self.metric_file,fieldnames=self.metric_fields);self.metrics.writeheader()

    def resume(self,prepared=None):
        if prepared is None:
            candidate=resume_candidate(self.root)
            settings=resume_settings(self.root,candidate,self.cfg)
        else:
            validate_resume_selection(prepared)
            candidate=prepared.candidate
            settings=prepared.settings
        self.write_status(status='starting',message=f"선택한 {candidate['timesteps']:,}스텝의 PPO 학습 상태를 확인합니다.")
        # Deserialize policy, value network and optimizer before saving settings
        # or changing the live scene. A bad archive cannot create a child run.
        from stable_baselines3 import PPO
        model=PPO.load(candidate['path'],device='cpu',force_reset=True)
        if checked_gamma(model.gamma)!=lesson_gamma(load_lesson(self.root/'design/agent.py')):
            raise ValueError('선택한 model.zip과 agent.py의 gamma가 다릅니다. 새 학습을 시작하세요.')
        if (int(model.num_timesteps)!=candidate['timesteps'] or
                int(model._n_updates)!=candidate['ppo_updates']):
            raise ValueError('선택한 체크포인트의 학습 상태가 저장 정보와 다릅니다.')
        if prepared is not None:validate_resume_selection(prepared)
        self.cfg=self.settings_store.save(settings)
        self.settings_store.confirm_edit()
        self.train(candidate,loaded_model=model)

    def train(self,resume=None,loaded_model=None):
        import torch
        from stable_baselines3 import PPO
        from stable_baselines3.common.callbacks import BaseCallback
        from .policy_io import export_actor
        torch.set_num_threads(int(self.cfg['torch_threads']))
        best_last_options=read_options(self.root)
        source=resume['run'] if resume else self.root/'design'
        source_code=source/('lesson.py' if resume else 'agent.py')
        lesson,size=check_lesson(source_code,self.cfg)
        gamma=lesson_gamma(lesson)
        if resume:
            if loaded_model is None:
                loaded_model=PPO.load(resume['path'],device='cpu',force_reset=True)
            if checked_gamma(loaded_model.gamma)!=gamma:
                raise ValueError('선택한 model.zip과 저장된 학습 코드의 gamma가 다릅니다.')
        run=self.root/'runs'/time.strftime('%Y%m%d_%H%M%S')
        if run.exists():run=run.with_name(run.name+'_'+uuid.uuid4().hex[:6])
        run.mkdir(parents=True)
        shutil.copy2(source_code,run/'lesson.py')
        (run/'shared_code').mkdir()
        for name in ('vision.py','policy_io.py'):
            shutil.copy2((source/'shared_code' if resume else self.root/'lane_lab')/name,run/'shared_code'/name)
        atomic_json(run/'settings.json',self.cfg)
        shutil.copy2(self.root/'config/vehicle.json',run/'vehicle_base.json')
        (run/'environment_code').mkdir()
        for name in ('lighting.py',):
            shutil.copy2(self.root/'design'/name,run/'environment_code'/name)
        sim=self.configure_sim(self.cfg,run/'world')
        env=LaneEnv(sim,self.cfg,lesson,size,self.stop_event,self.report)
        self.open_metrics(run/'training.csv')
        start_steps=0
        try:
            if resume:
                # SB3 restores both the neural network and Adam optimizer. The old
                # rollout was not saved: start a fresh episode/rollout deliberately.
                model=loaded_model
                model.set_env(env,force_reset=True)
                start_steps=int(model.num_timesteps)
                # The policy counter remains authoritative when a legacy model
                # contains obsolete actuator randomization state.
                env.total_steps=start_steps
                if hasattr(model, 'lane_random_state'):
                    delattr(model, 'lane_random_state')
                atomic_json(run/'resume.json',{'parent_run':str(source.relative_to(self.root)),
                    'checkpoint':resume['path'].relative_to(source).as_posix(),'checkpoint_sha256':sha256(resume['path']),
                    'selected_actor':str(resume.get('actor','')),
                    'selected_actor_sha256':resume.get('actor_sha256'),
                    'model_choice':resume.get('label'),
                    'gamma':float(model.gamma),
                    'start_timesteps':start_steps,'target_timesteps':int(self.cfg['train_steps']),
                    'reset_episode':True,'track':self.cfg['track'],
                    'vehicle_sha256':sha256(run/'vehicle_base.json'),
                    'parent_vehicle_sha256':sha256(source/'vehicle_base.json') if (source/'vehicle_base.json').exists() else None})
                # The child has a usable recovery point before any new simulation.
                save_checkpoint(model,run)
            else:
                # Student observe/reward/act define the task; PPO optimizes a small
                # deep neural policy with two hidden layers on the CPU.
                model=PPO('MlpPolicy',env,learning_rate=3e-4,n_steps=512,batch_size=64,n_epochs=10,
                          gamma=gamma,gae_lambda=.95,clip_range=.2,ent_coef=.005,
                          policy_kwargs={'net_arch':{'pi':[64,64],'vf':[64,64]},'activation_fn':torch.nn.Tanh},
                          device='cpu',seed=self.cfg['seed'],verbose=0)
        except BaseException:
            env.close();self.metric_file.close()
            raise
        env.total_steps=start_steps
        self.write_status(status='training',run_dir=str(run),target_steps=self.cfg['train_steps'],
            steps=start_steps,episodes=0,rtf=0.,**resume_status(self.root),
            message=f'{start_steps:,}스텝 체크포인트부터 이어 학습합니다.' if resume else '새 PPO 신경망을 학습합니다.')
        app=self
        try:
            selector=BestLastSelector(self,run,env,lesson,size,best_last_options,
                                      parent=source if resume else None,start_steps=start_steps)
        except BaseException:
            env.close();self.metric_file.close();raise
        class Checkpoints(BaseCallback):
            def __init__(self):
                super().__init__()
                self.saved_updates=int(model._n_updates)
            def _on_step(self):
                return not app.stop_event.is_set()
            def save_updated(self):
                updates=int(self.model._n_updates)
                if updates>self.saved_updates:
                    # _on_rollout_start runs AFTER the preceding optimizer update.
                    # Never overwrite a recovery ZIP from inside an unfinished update.
                    save_checkpoint(self.model,run)
                    selector.capture(self.model)
                    self.saved_updates=updates
                    app.write_status(**resume_status(app.root))
            def _on_rollout_start(self):
                self.save_updated()
                selector.maybe_evaluate(self.model)
            def _on_training_end(self):
                self.save_updated()
                selector.maybe_evaluate(self.model,final=True)
        failed=None
        try:
            model.learn(total_timesteps=int(self.cfg['train_steps'])-start_steps,
                        reset_num_timesteps=resume is None,callback=Checkpoints())
        except StopRequested:
            pass
        except Exception as exc:
            failed=exc
        finally:
            # A transport/lesson error does not erase the last completed update.
            # A failed optimizer could have partially changed weights: keep its
            # checkpoint and never publish that in-memory model for evaluation.
            try:env.close()
            except Exception as exc:
                if failed is None:failed=exc
            self.metric_file.close()
            selector.discard_pending('stopped' if self.stop_event.is_set() else 'failed' if failed else 'finished')
            if failed is None:
                atomic_save_model(model,run/'model.zip')
                if model._n_updates>0:
                    actor_tmp=run/'actor.tmp.npz'
                    export_actor(model,actor_tmp,observation_size=size)
                    actor_tmp.replace(run/'actor.npz')
                    save_last_snapshot(model,run,size)
            record={'observation_size':size,'timesteps':int(model.num_timesteps),
                    'gamma':float(model.gamma),'gae_lambda':float(model.gae_lambda),
                    'start_timesteps':start_steps,'target_timesteps':int(self.cfg['train_steps']),
                    'resumed_from':str(source.relative_to(self.root)) if resume else None,
                    'ppo_updates':int(model._n_updates),'stopped':self.stop_event.is_set(),
                    'failed':str(failed) if failed else None,'lesson_sha256':sha256(run/'lesson.py'),
                    'settings_sha256':sha256(run/'settings.json'),'algorithm':'PPO MLP [64,64] Tanh',
                    'packages':{'torch':torch.__version__}}
            atomic_json(run/'training.json',record)
            if failed is None and model._n_updates>0:
                atomic_json(self.runtime/'latest_run.json',{'run':str(run.relative_to(self.root))})
            self.write_status(**resume_status(self.root),**self.model_status())
        if failed:raise failed
        self.write_status(best_evaluation=False)
        detail='중지 시점 모델을 저장했습니다.' if self.stop_event.is_set() else '학습을 마쳤습니다. 평가 버튼으로 실제 완주와 접촉 여부를 확인하세요.'
        if model._n_updates==0:detail+=' 아직 PPO 업데이트 전입니다. 학습을 더 진행해야 합니다.'
        self.write_status(status='stopped' if self.stop_event.is_set() else 'complete',steps=int(model.num_timesteps),message=detail)

    def latest_run(self):
        p=self.runtime/'latest_run.json'
        if not p.exists():raise ValueError('먼저 새 학습을 실행해 모델을 저장하세요.')
        run=(self.root/json.loads(p.read_text())['run']).resolve()
        if not run.is_relative_to(self.root/'runs'):raise ValueError('잘못된 모델 경로입니다.')
        return run

    def model_status(self):
        values={'best_available':False,'last_available':False,'evaluation_run':''}
        try:run=self.latest_run()
        except (OSError,ValueError,KeyError):return values
        values['evaluation_run']=str(run)
        for choice in ('best','last'):
            try:
                _,record=load_choice(run,choice)
                values[choice+'_available']=int(record.get('ppo_updates',0))>0
            except (OSError,ValueError,KeyError,TypeError):pass
        return values

    def evaluate(self,choice='last',prepared=None):
        # CLI/older command clients retain best/last selection. The file picker
        # supplies a fully checked, in-memory policy for the exact chosen file.
        if prepared is None:
            snapshot,_=load_choice(self.latest_run(),choice)
            prepared=prepare_evaluation(self.root,snapshot/'actor.npz',self.cfg)
        run,actor=prepared.run,prepared.actor
        selection,settings=prepared.record,copy.deepcopy(prepared.settings)
        settings['evaluation_episodes']=1
        lesson,size,policy=prepared.lesson,prepared.size,prepared.policy
        choice=prepared.label
        label=f'{run.name} / {actor.parent.name}'
        stamp=time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:4]
        out=self.root/'evaluation'/stamp;out.mkdir(parents=True)
        atomic_json(out/'settings.json',settings)
        shutil.copy2(run/'lesson.py',out/'lesson.py')
        sim=self.configure_sim(settings,out/'world')
        env=LaneEnv(sim,settings,RewardCapture(lesson),size,self.stop_event,self.report_progress,
                    training_step_context=int(selection['timesteps']))
        recorder=EvaluationCSV(out,env,{'path':str(actor),'sha256':prepared.actor_sha256,
            'run':str(run),'choice':choice,'timesteps':selection['timesteps'],
            'lesson_sha256':sha256(out/'lesson.py'),'observation_size':size})
        env.transition_report=recorder.record_step
        self.write_status(status='evaluating',target_steps=0,steps=0,episodes=0,rtf=0.,run_dir=str(run),
                          model_choice=choice,evaluation_run=str(run),evaluated_model_path=str(actor),
                          evaluated_model_timesteps=selection['timesteps'],
                          evaluation_directory=str(out),evaluation_csv=str(out/'driving.csv'),
                          message=f'{label} ({selection["timesteps"]:,}스텝, 저장된 입력 {size}개)을 평가합니다.')
        episodes=[];outcome='complete';failure=None
        try:
            for i in range(settings['evaluation_episodes']):
                obs,_=env.reset(seed=int(settings['seed']))
                recorder.begin_episode(env)
                done=False
                while not done:
                    obs,_,terminated,truncated,info=env.step(policy.predict(obs))
                    done=terminated or truncated
                episodes.append(info)
        except StopRequested:outcome='stopped'
        except Exception as exc:
            outcome='error';failure=str(exc);raise
        finally:
            try:env.close()
            finally:
                recorder.finish(outcome,failure)
                atomic_json(out/'result.json',{'episodes':episodes,'stopped':outcome=='stopped',
                    'status':outcome,'error':failure,'rows_written':recorder.rows,'csv':'driving.csv',
                    'clean_laps':sum(bool(e['successful_lap']) for e in episodes),
                    'total_episodes':len(episodes),'model_sha256':prepared.actor_sha256,
                    'model_choice':choice,'model_timesteps':selection['timesteps'],
                    'model_path':str(actor),'model_directory':str(actor.parent.relative_to(run))})
        self.write_status(status='complete',**{**self.model_status(),'evaluation_run':str(run)},
                          message=f"{label} 평가 {'중지 · ' if outcome=='stopped' else ''}{len(episodes)}회 완료. CSV {recorder.rows:,}행: {out.relative_to(self.root)}/driving.csv")

    def export(self,prepared=None):
        if prepared is not None:
            self.write_status(status='exporting',message=f'{prepared.run.name} / {prepared.actor.parent.name} 선택 모델을 내보냅니다.')
            target=export_selected_model(self.root,prepared.actor,prepared=prepared)
            self.write_status(status='complete',export_directory=str(target),
                              exported_model_path=str(prepared.actor),
                              message=f'선택 모델 폴더와 ZIP 저장 완료: {target.relative_to(self.root)}')
            return
        from .best_last_export import export_models
        available=self.model_status()
        choices=tuple(c for c in ('best','last') if available[c+'_available'])
        if not choices:raise ValueError('내보낼 학습 모델이 없습니다. 학습 후 일시 중지 및 저장을 누르세요.')
        label=' / '.join(choices)
        self.write_status(status='exporting',message=f'{label} 실차 모델을 만듭니다.')
        target=export_models(self.root,self.latest_run(),choices)
        self.write_status(status='complete',message=f'{label} 폴더와 ZIP 저장 완료: {target.relative_to(self.root)}')

    def launch_work(self,method):
        if self.worker and self.worker.is_alive():
            self.stop_event.set();self.write_status(status='stopping',message='현재 동작을 멈추고 저장합니다.')
            self.worker.join(50)
            if self.worker.is_alive():raise TimeoutError('중지 응답이 지연됩니다. runtime 로그를 확인하세요.')
        self.stop_event=threading.Event()
        def execute():
            try:method()
            except StopRequested:pass
            except Exception as exc:
                if self.sim:self.sim.stop()
                self.error(exc)
            finally:
                if self.stop_event.is_set() and self.status['status']=='stopping':
                    self.write_status(status='stopped',message='중지했습니다.')
        self.worker=threading.Thread(target=execute,daemon=True);self.worker.start()

    def preflight(self,settings):
        # Isolate mistakes such as an accidental endless loop from the GUI IPC loop.
        atomic_json(self.runtime/'check_settings.json',settings)
        script=("import json,sys; from lane_lab.configuration import check_lesson; "
                "_,n=check_lesson(sys.argv[1],json.load(open(sys.argv[2]))); print(n)")
        try:
            result=subprocess.run([sys.executable,'-c',script,str(self.root/'design/agent.py'),
                    str(self.runtime/'check_settings.json')],cwd=self.root,capture_output=True,text=True,timeout=8)
        except subprocess.TimeoutExpired:
            raise ValueError('코드 검사가 8초 안에 끝나지 않았습니다. agent.py의 반복문을 확인하세요.')
        if result.returncode:
            raise ValueError(result.stderr[-2200:])
        return int(result.stdout.strip().splitlines()[-1])

    def command(self,data):
        action=data.get('action')
        if action=='stop':
            self.stop_event.set()
            active=self.worker is not None and self.worker.is_alive()
            self.write_status(status='stopping' if active else 'stopped',message='현재 단계가 끝나면 중지·저장합니다.' if active else '중지했습니다.')
            return
        if action not in ('check','preview','train','resume','resume_file','evaluate','evaluate_best','evaluate_last','evaluate_file','export','export_file','apply','save_track'):
            raise ValueError(f'알 수 없는 명령: {action}')
        if action in ('export','export_file'):
            if self.worker and self.worker.is_alive() and self.status['status'] not in ('preview','error'):
                raise ValueError('학습/평가가 끝난 뒤 내보내기를 실행하세요.')
            if action=='export_file':
                prepared=prepare_export(self.root,data.get('model_path'))
                self.launch_work(lambda:self.export(prepared=prepared))
            else:self.launch_work(self.export)
            return
        requested={**self.cfg,**migrate_friction_settings(data.get('settings',{}))}
        if action=='save_track':requested['track']='custom'
        settings=read_settings(self.root,requested)
        if action=='resume_file':
            if self.worker and self.worker.is_alive() and self.status['status'] not in ('preview','error'):
                raise ValueError('현재 학습/평가를 중지한 뒤 이어 학습할 모델을 선택하세요.')
            prepared=prepare_resume(self.root,data.get('model_path'),settings)
            self.launch_work(lambda:self.resume(prepared=prepared))
            return
        if action=='check':
            error_generation=getattr(self,'error_generation',0)
            size=self.preflight(settings)
            self.cfg=self.settings_store.save(settings)
            self.settings_store.confirm_edit()
            self.write_status(clear_error=True,error_generation=error_generation,settings_warning='',**resume_status(self.root),message=f'코드 검사 통과: 입력 {size}개 / 액션 1개. 저장한 코드는 새 학습부터 적용됩니다.')
            return
        if action=='train':
            self.preflight(settings)
        prepared=None
        if action in ('evaluate','evaluate_best','evaluate_last','evaluate_file'):
            if action=='evaluate_file':
                model_path=data.get('model_path')
            else:
                choice='best' if action=='evaluate_best' else 'last'
                snapshot,_=load_choice(self.latest_run(),choice)
                model_path=snapshot/'actor.npz'
            # Recheck on click, before saving GUI settings or stopping a worker.
            # The actor in memory cannot silently become a newer best/last later.
            prepared=prepare_evaluation(self.root,model_path,settings)
        self.cfg=self.settings_store.save(settings)
        self.settings_store.confirm_edit()
        self.write_status(settings_warning='')
        if action=='train':
            self.launch_work(self.train)
        elif action=='resume':self.launch_work(self.resume)
        elif action in ('evaluate','evaluate_best','evaluate_last','evaluate_file'):
            self.launch_work(lambda:self.evaluate(prepared=prepared))
        else:self.launch_work(self.preview)

    def run(self):
        self.launch_work(self.preview)
        try:
            while not self.quit_event.wait(.1):
                if self.gui_closed():break
                if not self.headless and self.gui is None and self.worker and not self.worker.is_alive() and self.status['status']=='error':
                    print(self.status['message'],flush=True);break
                for path in sorted((self.runtime/'commands').glob('*.json')):
                    try:
                        data=json.loads(path.read_text());path.unlink();self.command(data)
                    except Exception as exc:self.error(exc)
        finally:
            self.stop_event.set()
            if self.worker:self.worker.join(50)
            if self.worker and self.worker.is_alive() and self.sim:
                self.sim.abort();self.worker.join(5)
            elif self.sim:self.sim.close()
            with self.lifecycle_lock:self.close_gui()
            if self.status['status']!='error':
                self.write_status(status='stopped',message='프로그램을 종료했습니다.')
            else:print(self.status['message'],flush=True)
