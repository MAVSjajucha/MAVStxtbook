"""Generate portable Gazebo Fortress worlds from 0.9 m printed track tiles.

Only generated run directories contain absolute paths. Input package files are
relocatable. GUI edits call generate again; ROS/colcon rebuild is unnecessary.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np
from PIL import Image

from .lighting import load_lighting, lights_sdf, directional_sdf, validate_environment_settings
from .enclosure import analyze_layout, tile_mask as _tile_mask
from .enclosed_route import generate_reference
from .tunnels import tunnel_sdf

TILE_M = 0.9
PIXELS = 900
OPPOSITE = {"N": "S", "E": "W", "S": "N", "W": "E"}
STEP = {"N": (-1, 0), "E": (0, 1), "S": (1, 0), "W": (0, -1)}


def parse_tile(token):
    if token in (None, "", "Background"):
        return "Background", 0
    if isinstance(token, dict):
        token = f"{token['tile']}{token.get('rotation', 0)}"
    m = re.fullmatch(r"(TS|TC|[A-P])(0|90|180|270)?", str(token))
    if not m:
        raise ValueError(f"잘못된 타일 {token!r}: A0, I90, TS0(직선 터널), TC90(곡선 터널), Background 형식으로 입력하세요.")
    return m.group(1), int(m.group(2) or 0)//90


def _ports(letter, turns):
    if letter == "Background":
        return ()
    if letter in "ABCDE" or letter == 'TS':
        base = ("W", "E")
    elif letter in "FGHIJK" or letter == 'TC':
        base = ("N", "E")
    elif letter in "LMNO":
        base = ("N", "E", "W")
    elif letter == "P":
        base = ("N", "E")
    else:
        raise ValueError(f"알 수 없는 패널: {letter}")
    order = "NESW"
    return tuple(order[(order.index(p)+turns) % 4] for p in base)


def _analyze(cells, root=None):
    if not cells or not cells[0] or any(len(row) != len(cells[0]) for row in cells):
        raise ValueError("트랙은 같은 길이의 행으로 이루어진 직사각형 격자여야 합니다.")
    if len(cells) > 8 or len(cells[0]) > 8:
        raise ValueError("저사양 PC 보호를 위해 트랙은 최대 8×8칸으로 설정하세요.")
    root = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    return analyze_layout(cells, parse_tile, root)


def _legacy_path(analysis):
    """Keep the exact historical centreline only for a single narrow circuit.

    Failure to form that particular route does not invalidate an enclosure.
    Wider panels and junctions use a separately generated reference circuit.
    """
    tiles = analysis['tiles']
    roads = {p: t for p, t in tiles.items() if t[0] != 'Background'}
    if any(t[0] in 'LMNOP' for t in roads.values()) or len(analysis['components']) != 1:
        return []
    ports = {p: _ports(*tile) for p, tile in roads.items()}
    if any(len(edges) != 2 for edges in ports.values()):
        return []
    start = sorted(ports, key=lambda p: (-p[0], p[1]))[0]
    outgoing = next(p for p in ("E", "N", "W", "S") if p in ports[start])
    incoming = next(p for p in ports[start] if p != outgoing)
    path, seen, position = [], set(), start
    for _ in range(len(ports) + 1):
        if position == start and path:
            return path if len(path) == len(ports) else []
        if position in seen or incoming not in ports.get(position, ()):
            return []
        seen.add(position)
        letter, rotation = tiles[position]
        outgoing = next(p for p in ports[position] if p != incoming)
        path.append((*position, letter, rotation, incoming, outgoing))
        dr, dc = STEP[outgoing]
        position = (position[0]+dr, position[1]+dc)
        incoming = OPPOSITE[outgoing]
    return []


def validate_layout(cells, root=None):
    """Validate enclosure boundaries, independently of its centreline topology.

    Return the legacy ordered tile path when applicable; [] denotes a valid
    enclosure whose reference path is generated from its drivable mask later.
    """
    return _legacy_path(_analyze(cells, root))


def _canonical_points(mask, letter):
    if letter in "ABCDE" or letter == "TS":
        xs = np.linspace(0, PIXELS, 181)
        ys = []
        for x in xs:
            rows = np.flatnonzero(mask[:, min(PIXELS-1, int(x))])
            ys.append((rows[0]+rows[-1]+1)/2)
        points = np.column_stack((xs, ys))
        points[0], points[-1] = (0, 450), (900, 450)
        return points
    # Median of the connected lane's radial cross-section supports both round
    # corners F~J and the visibly different square corner K.
    angles = np.linspace(0, math.pi/2, 181)
    result = []
    for a in angles:
        rr = np.arange(100, 1100, 0.5)
        xx, yy = 900-rr*np.cos(a), rr*np.sin(a)
        cc = np.clip(xx.astype(int), 0, PIXELS-1)
        row = np.clip(yy.astype(int), 0, PIXELS-1)
        valid = (xx >= 0) & (xx <= 900) & (yy >= 0) & (yy <= 900)
        road = rr[valid & (mask[row, cc] > 0)]
        r = float((road[0]+road[-1])/2)
        result.append((900-r*math.cos(a), r*math.sin(a)))
    result[0], result[-1] = (450, 0), (900, 450)
    return np.asarray(result)


def _resample_closed(points, spacing=0.005):
    points = np.asarray(points, float)
    keep = np.concatenate([[True], np.linalg.norm(np.diff(points, axis=0), axis=1) > 1e-7])
    points = points[keep]
    if np.linalg.norm(points[-1]-points[0]) < 1e-7:
        points = points[:-1]
    ends = np.vstack((points, points[0]))
    distances = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(ends, axis=0), axis=1))])
    samples = np.linspace(0, distances[-1], int(math.ceil(distances[-1]/spacing)), endpoint=False)
    return np.column_stack([np.interp(samples, distances, ends[:, a]) for a in (0, 1)])


def build_track(root, cells, vehicle, output_dir):
    import cv2
    root, output_dir = Path(root), Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    analysis = _analyze(cells, root)
    path = _legacy_path(analysis)
    rows, cols = len(cells), len(cells[0])
    masks, images = analysis["canonical_masks"], {}
    for row in cells:
        for token in row:
            letter, _ = parse_tile(token)
            if letter not in images:
                images[letter] = (np.full((PIXELS, PIXELS, 3), 33, dtype=np.uint8) if letter in ("TS", "TC") else
                                  np.asarray(Image.open(root/"track_img"/f"Track-{letter}.png").convert("RGB")))
    mask = np.zeros((rows*PIXELS, cols*PIXELS), np.uint8)
    mosaic = np.zeros((*mask.shape, 3), np.uint8)
    for r, row in enumerate(cells):
        for c, token in enumerate(row):
            letter, k = parse_tile(token)
            mask[r*PIXELS:(r+1)*PIXELS, c*PIXELS:(c+1)*PIXELS] = np.rot90(masks[letter], -k)
            mosaic[r*PIXELS:(r+1)*PIXELS, c*PIXELS:(c+1)*PIXELS] = np.rot90(images[letter], -k)
    route = []
    order = "NESW"
    for row, col, letter, k, entry, _ in path:
        pts = _canonical_points(masks[letter], letter)
        canon_entry = order[(order.index(entry)-k) % 4]
        if canon_entry == "E":
            pts = pts[::-1]
        for _ in range(k):
            pts = np.column_stack((900-pts[:, 1], pts[:, 0]))
        pts = np.column_stack(((col*900+pts[:, 0])*0.001,
                               (rows*900-(row*900+pts[:, 1]))*0.001))
        route.extend(pts)
    route_info = {"reference_route_kind": "legacy_centerline", "completion_enabled": True}
    if path:
        route = _resample_closed(route)
    else:
        route, route_info = generate_reference(mask, vehicle, resolution=0.001)
    # Start mid-straight where possible, away from white-line boundaries and corners.
    curvature = np.linalg.norm(np.roll(route, -8, axis=0)-2*route+np.roll(route, 8, axis=0), axis=1)
    straight = curvature < 1e-5
    doubled = np.concatenate((straight, straight))
    edges = np.diff(np.pad(doubled.astype(np.int8), (1, 1)))
    starts, stops = np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)
    if len(starts) and np.max(stops-starts) > 15:
        best = int(np.argmax(stops-starts))
        spawn_i = int((starts[best]+min(stops[best]-starts[best], len(route))//2) % len(route))
    else:
        spawn_i = int(np.argmin(curvature))
    if not path and "spawn_index" in route_info:
        spawn_i = int(route_info.pop("spawn_index")) % len(route)
    tunnel_cells = [[r, c] for r, row in enumerate(cells) for c, token in enumerate(row)
                    if parse_tile(token)[0] in ("TS", "TC")]
    if tunnel_cells:
        def outside_tunnel(i):
            row = min(rows - 1, max(0, int((rows*TILE_M - route[i, 1])/TILE_M)))
            col = min(cols - 1, max(0, int(route[i, 0]/TILE_M)))
            return [row, col] not in tunnel_cells
        if not outside_tunnel(spawn_i):
            candidates = [i for i in range(len(route)) if straight[i] and outside_tunnel(i)]
            if candidates:
                spawn_i = candidates[len(candidates)//2]
    route = np.roll(route, -spawn_i, axis=0)
    tangent = route[6]-route[0]
    spawn = [float(route[0, 0]), float(route[0, 1]), math.atan2(tangent[1], tangent[0])]
    # Release the RGB mosaic before allocating the full-resolution distance fields.
    Image.fromarray(mosaic).save(output_dir/"track_preview.png")
    del mosaic
    # Include a zero border so distance at outer world edges is finite and safe.
    inside = cv2.distanceTransform(np.pad(mask, 1), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)[1:-1, 1:-1]
    outside = cv2.distanceTransform(1-mask, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    signed = (inside-outside).astype(np.float32)*0.001
    np.savez_compressed(output_dir/"track_geometry.npz", signed_distance_m=signed, route=route)
    Image.fromarray(mask*255).save(output_dir/"track_drivable_mask.png")
    metadata = {"schema_version": 1, "resolution_m": 0.001, "tile_size_m": TILE_M,
                "width_m": cols*TILE_M, "height_m": rows*TILE_M, "cells": cells,
                "spawn": spawn, "vehicle": vehicle, "geometry_file": "track_geometry.npz",
                "coordinate_convention": "world +x right, +y up; JSON rows top to bottom",
                "enclosure_components": len(analysis["components"]),
                "tunnel_cells": tunnel_cells, **route_info}
    (output_dir/"track.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+"\n")
    return metadata


def _inertia_box(mass, x, y, z):
    return f"<inertial><mass>{mass}</mass><inertia><ixx>{mass*(y*y+z*z)/12}</ixx><iyy>{mass*(x*x+z*z)/12}</iyy><izz>{mass*(x*x+y*y)/12}</izz></inertia></inertial>"


def _material(color):
    return f"<material><ambient>{color}</ambient><diffuse>{color}</diffuse></material>"


def _vehicle(v, spawn, config, root=None):
    # The shipped manufacturer URDF supplies link geometry and joint origins.
    from .vehicle import vehicle_sdf
    return vehicle_sdf(Path(root) if root is not None else Path(__file__).resolve().parents[1],
                       v, spawn, config)


def _tile_dae(texture, specular=0.0):
    # Texture coordinates put the PNG's top row at world +y.
    return f'''<?xml version="1.0" encoding="utf-8"?>
<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1">
<asset><created>2026-09-21T00:00:00</created><modified>2026-09-21T00:00:00</modified><unit meter="1" name="meter"/><up_axis>Z_UP</up_axis></asset>
<library_images><image id="image"><init_from>{escape(str(texture.resolve()))}</init_from></image></library_images>
<library_effects><effect id="effect"><profile_COMMON><newparam sid="surface"><surface type="2D"><init_from>image</init_from></surface></newparam><newparam sid="sampler"><sampler2D><source>surface</source></sampler2D></newparam><technique sid="common"><phong><diffuse><texture texture="sampler" texcoord="UVSET0"/></diffuse><specular><color>{specular} {specular} {specular} 1</color></specular><shininess><float>32</float></shininess></phong></technique></profile_COMMON></effect></library_effects>
<library_materials><material id="material"><instance_effect url="#effect"/></material></library_materials>
<library_geometries><geometry id="tile"><mesh>
<source id="positions"><float_array id="positions-array" count="12">-.45 -.45 0 .45 -.45 0 .45 .45 0 -.45 .45 0</float_array><technique_common><accessor source="#positions-array" count="4" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>
<source id="uv"><float_array id="uv-array" count="8">0 0 1 0 1 1 0 1</float_array><technique_common><accessor source="#uv-array" count="4" stride="2"><param name="S" type="float"/><param name="T" type="float"/></accessor></technique_common></source>
<source id="normals"><float_array id="normals-array" count="3">0 0 1</float_array><technique_common><accessor source="#normals-array" count="1" stride="3"><param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/></accessor></technique_common></source>
<vertices id="vertices"><input semantic="POSITION" source="#positions"/></vertices><triangles count="2" material="mat"><input semantic="VERTEX" source="#vertices" offset="0"/><input semantic="TEXCOORD" source="#uv" offset="1" set="0"/><input semantic="NORMAL" source="#normals" offset="2"/><p>0 0 0 1 1 0 2 2 0 0 0 0 2 2 0 3 3 0</p></triangles></mesh></geometry></library_geometries>
<library_visual_scenes><visual_scene id="scene"><node><instance_geometry url="#tile"><bind_material><technique_common><instance_material symbol="mat" target="#material"><bind_vertex_input semantic="UVSET0" input_semantic="TEXCOORD" input_set="0"/></instance_material></technique_common></bind_material></instance_geometry></node></visual_scene></library_visual_scenes><scene><instance_visual_scene url="#scene"/></scene></COLLADA>'''


def _track_material(texture, specular):
    # An explicit SDF material replaces the embedded COLLADA material. Preserve
    # its image by also supplying albedo_map (mapped to SetTexture in Fortress).
    # Ogre2 supports the metal PBR workflow. Keep the track non-metallic and its
    # roughness fixed so the GUI changes specular strength, not the road artwork.
    texture = escape(str(Path(texture).resolve()))
    return f'''<material><ambient>1 1 1 1</ambient><diffuse>1 1 1 1</diffuse>
<specular>{specular} {specular} {specular} 1</specular>
<pbr><metal><albedo_map>{texture}</albedo_map><roughness>0.35</roughness><metalness>0</metalness></metal></pbr></material>'''


def generate(root, config, output_dir):
    """Return world_path, track_metadata_path, spawn=[x,y,yaw] and dimensions.

    config keys: track, custom_tiles (optional), camera_pitch_deg, light_level,
    track_specular, extra_light_type, extra_lights, lighting, mass_kg,
    camera_hfov_deg, render_engine; vehicle:{} overrides also work.
    friction_mu1 and friction_mu2 are independent tangential contact coefficients.
    Stock DART uses them for both sticking and sliding; there is no speed switch.
    An optional world_plugins string is inserted by the runtime for its RPC system.
    """
    root, output_dir = Path(root).resolve(), Path(output_dir).resolve()
    # A supplied lighting dictionary is a saved snapshot: never replace it with
    # the currently edited design file during evaluation or replay.
    config = dict(config)
    if "lighting" not in config:
        config["lighting"] = load_lighting(root)
    config = validate_environment_settings(config)
    output_dir.mkdir(parents=True, exist_ok=True)
    v = json.loads((root/"config/vehicle.json").read_text())
    v.update(config.get("vehicle", {}))
    for key in ("mass_kg", "camera_pitch_deg", "camera_hfov_deg"):
        if key in config:
            v[key] = float(config[key])
    v["friction_mu1"] = config["friction_mu1"]
    v["friction_mu2"] = config["friction_mu2"]
    for legacy in ("static_friction", "kinetic_friction", "tire_friction"):
        v.pop(legacy, None)
    positive = ("wheelbase_m", "wheel_track_m", "wheel_radius_m", "wheel_width_m", "wheel_contact_length_m", "mass_kg")
    if any(not math.isfinite(float(v[k])) or float(v[k]) <= 0 for k in positive):
        raise ValueError("차량 길이·질량은 유한한 양수여야 합니다.")
    if not 1 <= float(v["max_steer_deg"]) <= 45 or not 20 <= float(v["camera_hfov_deg"]) <= 120:
        raise ValueError("조향 한계는 1~45°, 카메라 수평 시야각은 20~120°로 설정하세요.")
    if not -45 <= float(v["camera_pitch_deg"]) <= 45:
        raise ValueError("카메라 힌지 각도는 -45~45°로 설정하세요.")
    minimum_radius = v["wheelbase_m"]/math.tan(math.radians(v["max_steer_deg"])) + v.get("kingpin_width_m", v["wheel_track_m"])/2
    v["max_center_steer_deg"] = math.degrees(math.atan(v["wheelbase_m"]/minimum_radius))
    # DART combines each pair with min(). Matching floor/tire values prevent
    # a hidden floor coefficient from capping either student setting.
    mu1, mu2 = config["friction_mu1"], config["friction_mu2"]
    if v["mass_kg"] < 0.5:
        raise ValueError("차량 질량은 0.5kg 이상으로 설정하세요.")
    name = config.get("track", "track1")
    if name not in ("track1", "track2", "track3", "custom"):
        raise ValueError("track은 track1 / track2 / track3 / custom 중 하나여야 합니다.")
    cells = config.get("custom_tiles") if name == "custom" else None
    if not cells:
        cells = json.loads((root/"config/tracks"/f"{name}.json").read_text())["cells"]
    metadata = build_track(root, cells, v, output_dir)
    tiles = []
    written_meshes = set()
    for row, line in enumerate(cells):
        for col, token in enumerate(line):
            letter, k = parse_tile(token)
            mesh = output_dir/f"tile_{letter}.dae"
            texture = root/"track_img"/f"Track-{letter}.png"
            if letter in ("TS", "TC"):
                texture = output_dir/"tunnel_floor.png"
                if not texture.exists():
                    Image.new("RGB", (PIXELS, PIXELS), (33, 33, 33)).save(texture)
            if letter not in written_meshes:
                mesh.write_text(_tile_dae(texture, config["track_specular"]))
                written_meshes.add(letter)
            x, y = (col+.5)*TILE_M, (len(cells)-row-.5)*TILE_M
            material = _track_material(texture, config["track_specular"])
            tiles.append(f'''<model name="tile_{row}_{col}_{letter}"><static>true</static><pose>{x} {y} 0.001 0 0 {-k*math.pi/2}</pose><link name="tile"><visual name="track"><geometry><mesh><uri>{escape(mesh.as_uri())}</uri></mesh></geometry>{material}<cast_shadows>false</cast_shadows></visual></link></model>''')
            if letter in ("TS", "TC"):
                tiles.append(tunnel_sdf(row, col, letter, k, len(cells), mu1, mu2, output_dir))
    render_engine = config.get("render_engine", "ogre")
    if render_engine not in ("ogre", "ogre2"):
        raise ValueError("render_engine은 ogre 또는 ogre2로 설정하세요.")
    physics_engine = "ignition-physics-dartsim-plugin"
    systems = (f'<plugin filename="ignition-gazebo-physics-system" name="ignition::gazebo::systems::Physics">'
               f'<engine><filename>{escape(physics_engine)}</filename></engine></plugin>')
    systems += "".join(f'<plugin filename="ignition-gazebo-{file}-system" name="ignition::gazebo::systems::{klass}"/>'
                      for file, klass in (("user-commands", "UserCommands"), ("scene-broadcaster", "SceneBroadcaster")))
    world = f'''<?xml version="1.0"?>
<sdf version="1.8"><world name="lane_lab">
<gravity>0 0 -9.81</gravity><physics name="physics" type="ignored"><max_step_size>0.001</max_step_size><real_time_factor>0</real_time_factor></physics>
{systems}<plugin filename="ignition-gazebo-sensors-system" name="ignition::gazebo::systems::Sensors"><render_engine>{render_engine}</render_engine></plugin>
{config.get('world_plugins', '')}
<scene><ambient>0.35 0.35 0.35 1</ambient><background>0.7 0.75 0.8 1</background><shadows>false</shadows><grid>false</grid></scene>
{directional_sdf(config)}
{lights_sdf(config, metadata['width_m']/2, metadata['height_m']/2)}
<model name="floor"><static>true</static><link name="floor"><collision name="floor"><geometry><plane><normal>0 0 1</normal><size>50 50</size></plane></geometry><surface><friction><ode><mu>{mu1}</mu><mu2>{mu2}</mu2><fdir1>0 0 0</fdir1></ode></friction></surface></collision><visual name="floor"><geometry><plane><normal>0 0 1</normal><size>50 50</size></plane></geometry>{_material('0.35 0.35 0.35 1')}</visual></link></model>
{''.join(tiles)}{_vehicle(v, metadata['spawn'], config, root)}
</world></sdf>'''
    world_path = output_dir/"lane_lab.sdf"
    world_path.write_text(world)
    return {"world_path": str(world_path), "physics_engine": physics_engine,
            "pose_topic": "/world/lane_lab/model/a1/pose", "joint_topic": "/world/lane_lab/model/a1/joint_state", "track_metadata_path": str(output_dir/"track.json"),
            "spawn": metadata["spawn"], "spawn_z": v["wheel_radius_m"]+0.002,
            "reference_route_kind": metadata.get("reference_route_kind", "legacy_centerline"),
            "completion_enabled": metadata.get("completion_enabled", True),
            "wheelbase_m": v["wheelbase_m"], "vehicle": v,
            "friction_mu1": mu1, "friction_mu2": mu2,
            "track_specular": config["track_specular"], "lighting": config["lighting"],
            "extra_light_type": config["extra_light_type"], "extra_lights": config["extra_lights"],
            "light_origin": [metadata["width_m"]/2, metadata["height_m"]/2, 0.001],
            "width_m": metadata["width_m"], "height_m": metadata["height_m"]}
