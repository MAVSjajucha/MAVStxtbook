import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import sys

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description='야붐 차선 주행 Gazebo 실습')
    sub=parser.add_subparsers(dest='command',required=True)
    app_parser=sub.add_parser('app');app_parser.add_argument('--headless',action='store_true')
    sub.add_parser('check')
    doctor=sub.add_parser('doctor');doctor.add_argument('--smoke',action='store_true')
    send=sub.add_parser('send');send.add_argument('action',choices=['preview','train','resume','stop','evaluate','evaluate_best','evaluate_last','export','check','apply'])
    send.add_argument('--settings',help='JSON 설정 파일 경로')
    args=parser.parse_args()
    if args.command=='app':
        (ROOT/'runtime').mkdir(exist_ok=True)
        with open(ROOT/'runtime/app.lock','w') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:parser.error('이 폴더의 실습이 이미 실행 중입니다.')
            from .runner import App
            app=App(ROOT,headless=args.headless)
            def stop(signum,frame):app.quit_event.set()
            signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
            app.run()
    elif args.command=='check':
        from .configuration import check_lesson,read_settings
        _,size=check_lesson(ROOT/'design/agent.py',read_settings(ROOT))
        print(f'학생 코드 검사 통과: 관측 {size}개 / 조향 액션 1개')
    elif args.command=='doctor':
        from .doctor import diagnose
        return diagnose(ROOT,args.smoke)
    else:
        import time,uuid
        from .configuration import atomic_json
        settings=json.loads(Path(args.settings).read_text()) if args.settings else {}
        directory=ROOT/'runtime/commands';directory.mkdir(parents=True,exist_ok=True)
        atomic_json(directory/f'{int(time.time()*1000)}_{uuid.uuid4().hex}.json',{'action':args.action,'settings':settings})
        print('Gazebo 패널과 같은 명령을 전달했습니다:',args.action)
    return 0

if __name__=='__main__':
    sys.exit(main())
