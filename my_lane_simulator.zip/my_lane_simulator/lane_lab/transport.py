"""Managed Fortress and ROS processes with synchronous image/action barriers."""
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import time
import threading

import cv2
import numpy as np
from .supervisor import register_process


def stop_process_group(process, timeout=5):
    """Stop our own session, including children spawned by the `ign` launcher.

    Every caller creates the process with start_new_session=True. Its group ID
    remains the launcher's PID even if the launcher has already exited.
    """
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        pass
    # A launcher may exit before its renderer child. Clean up that session too.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=timeout)


class Simulator:
    def __init__(self,root,runtime,world_info,settings=None):
        self.root,self.runtime=Path(root),Path(runtime)
        self.info=world_info
        self.settings=settings
        self.pipeline=None
        self.server=None
        self.bridge=None
        self.log=None
        self.bridge_log=None
        self.reply_buffer=b""
        self.rpc_lock=threading.Lock()
        self.process_env=os.environ.copy()
        self.protocol_failed=False

    def start(self):
        self.log=open(self.runtime/'server.log','a',buffering=1)
        self.log.write('\n=== Starting Gazebo world: '+str(self.info['world_path'])+' ===\n')
        try:
            command=['ign','gazebo','-s','-v','2']
            if self.info.get('physics_engine'):
                # Use Fortress's installed public DART plugin. A library name
                # is resolved by Gazebo; it is not a package-local file path.
                command.extend(['--physics-engine', self.info['physics_engine']])
            command.append(str(self.info['world_path']))
            self.server=subprocess.Popen(command,
                    stdout=self.log,stderr=subprocess.STDOUT,env=self.process_env,start_new_session=True)
            register_process('server', self.server.pid)
            # Discover only this scene's partition; a departed server's stale
            # service advertisements cannot satisfy the new scene's readiness.
            deadline=time.monotonic()+30
            while time.monotonic()<deadline:
                if self.server.poll() is not None:
                    raise RuntimeError(f'Gazebo 서버가 종료됐습니다 (종료 코드 {self.server.returncode}). runtime/server.log를 확인하세요.')
                p=subprocess.run(['ign','service','-l'],capture_output=True,text=True,
                                 timeout=8,env=self.process_env)
                if '/world/lane_lab/control' in p.stdout:
                    break
                time.sleep(.25)
            else:
                raise TimeoutError('Gazebo 월드 서비스가 준비되지 않았습니다. runtime/server.log 확인.')
            executable=self.root/'build/native/lane_lab_bridge'
            self.bridge_log=open(self.runtime/'bridge.log','a',buffering=1)
            self.bridge=subprocess.Popen([str(executable),str(self.runtime/'frame.rgb')],stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,stderr=self.bridge_log,bufsize=0,
                    env=self.process_env,start_new_session=True)
            register_process('bridge', self.bridge.pid)
            if self.settings is not None:
                from .ros_transport import SimulationRosPipeline
                self.pipeline=SimulationRosPipeline(self.root,self.runtime,self.settings,self.process_env)
                self.pipeline.start()
        except Exception:
            self.close(graceful=False)
            raise

    def is_alive(self):
        return (not self.protocol_failed and self.server is not None and self.server.poll() is None and
                self.bridge is not None and self.bridge.poll() is None)

    def request(self,cmd,timeout=45):
        with self.rpc_lock:
            if self.protocol_failed:
                raise RuntimeError('이전 응답이 시간 초과되어 연결을 다시 열어야 합니다. 미리 보기를 다시 누르세요.')
            try:
                return self._request(cmd,timeout)
            except (TimeoutError,OSError):
                # Never confuse a late reply with the response to the next RPC.
                self.protocol_failed=True
                raise

    def _request(self,cmd,timeout=45):
        if self.bridge is None or self.bridge.poll() is not None:
            code=self.bridge.poll() if self.bridge is not None else None
            raise RuntimeError(f'Gazebo 연결 프로세스가 종료됐습니다 (종료 코드 {code}). runtime/bridge.log 확인.')
        self.bridge.stdin.write((json.dumps(cmd)+'\n').encode()); self.bridge.stdin.flush()
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            if b'\n' not in self.reply_buffer:
                ready,_,_=select.select([self.bridge.stdout],[],[],.2)
                if not ready:
                    if self.server.poll() is not None:
                        raise RuntimeError(f'Gazebo 서버가 종료됐습니다 (종료 코드 {self.server.returncode}). runtime/server.log 확인.')
                    continue
                data=os.read(self.bridge.stdout.fileno(),65536)
                if not data:
                    raise RuntimeError('Gazebo 연결이 끊겼습니다.')
                self.reply_buffer+=data
                continue
            line,self.reply_buffer=self.reply_buffer.split(b'\n',1)
            line=line.decode('utf-8',errors='replace')
            try:
                result=json.loads(line)
            except json.JSONDecodeError:
                # Gazebo may print library diagnostics to stdout.
                self.bridge_log.write(line); continue
            if not result.get('ok'):
                raise RuntimeError(result.get('error','Gazebo 오류'))
            if 'frame' in result:
                rgb=np.fromfile(result['frame'],dtype=np.uint8).reshape(480,640,3)
                result['image']=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
            return result
        raise TimeoutError('Gazebo 응답 시간 초과. Gazebo를 재실행하세요.')

    def step(self,speed=0.,steering=0.):
        import math
        yawrate=float(speed)*math.tan(float(steering))/float(self.info['wheelbase_m'])
        if self.pipeline:self.pipeline.command(float(speed),float(steering),float(self.info['wheelbase_m']))
        result=self.request({'action':'ros_step' if self.pipeline else 'step','steps':100,'speed':float(speed),'yawrate':yawrate})
        return self.with_features(result)

    def reset(self):
        x,y,yaw=self.info['spawn']
        if self.pipeline:self.pipeline.command(0.,0.,float(self.info['wheelbase_m']))
        result=self.request({'action':'reset','x':x,'y':y,'yaw':yaw,'z':self.info['spawn_z']})
        return self.with_features(result)

    def with_features(self,result):
        if self.pipeline:result['features']=self.pipeline.features_for(result['image_time'])
        else:
            from .vision import GridConfig,extract_features
            if self.settings:result['features']=extract_features(result['image'],GridConfig.from_mapping(self.settings['vision']))
        return result

    def update_settings(self,settings):
        self.settings=settings
        if self.pipeline:self.pipeline.update_settings(settings)

    def stop(self):
        if self.pipeline:
            try:self.pipeline.command(0.,0.,float(self.info['wheelbase_m']))
            except Exception:pass
        if self.is_alive():
            try: self.request({'action':'stop'},timeout=3)
            except Exception: pass

    def abort(self):
        self.close(graceful=False)

    def close(self,graceful=True):
        if graceful:self.stop()
        if self.pipeline:
            self.pipeline.close();self.pipeline=None
        for process in (self.bridge,self.server):
            stop_process_group(process)
        for process in (self.bridge,):
            if process:
                for stream in (process.stdin,process.stdout):
                    if stream and not stream.closed:stream.close()
        for f in (self.log,self.bridge_log):
            if f and not f.closed: f.close()
