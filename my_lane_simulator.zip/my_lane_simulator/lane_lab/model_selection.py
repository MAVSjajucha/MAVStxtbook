"""Resolve a student's chosen actor and its saved input/control configuration.

File selection never changes latest_run.json.  A policy and its checked settings
are loaded into memory before the application changes settings or a Gazebo scene.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import json
from pathlib import Path
from types import ModuleType
import zipfile

import numpy as np

from .checkpoints import checkpoint_info, resume_settings
from .configuration import check_lesson, read_settings, sha256
from .policy_io import NumpyPolicy


@dataclass
class EvaluationModel:
    run: Path
    actor: Path
    label: str
    record: dict
    settings: dict
    lesson: ModuleType
    size: int
    policy: NumpyPolicy
    actor_sha256: str


@dataclass
class ResumeModel(EvaluationModel):
    """A checked selection whose candidate always names its sibling PPO ZIP."""
    candidate: dict


def _json(path):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise ValueError(f'모델에 필요한 {path.name}을 읽을 수 없습니다. 학습 실험 폴더 전체를 사용하세요.') from exc
    if not isinstance(value, dict):
        raise ValueError(f'{path.name}: 저장 정보는 JSON 객체여야 합니다.')
    return value


def _require_file(path, run):
    if not path.is_file() or not path.resolve().is_relative_to(run):
        raise ValueError(f'모델에 필요한 {path.relative_to(run)} 파일이 없거나 실험 폴더 밖을 가리킵니다. 학습 실험 폴더 전체를 사용하세요.')


def _steps(record):
    for key in ('timesteps', 'ppo_updates'):
        value = record.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f'모델의 {key} 저장 정보가 올바르지 않습니다. 정상적으로 저장한 모델을 선택하세요.')


def _resolve(root, model_path):
    if not isinstance(model_path, (str, Path)) or not str(model_path).strip():
        raise ValueError('평가할 actor.npz 파일을 선택하세요.')
    actor = Path(model_path).expanduser().resolve()
    if actor.name != 'actor.npz' or not actor.is_file():
        raise ValueError('저장된 모델의 actor.npz 파일을 선택하세요. model.zip이나 폴더는 선택할 수 없습니다.')
    runs = (root / 'runs').resolve()
    if not actor.is_relative_to(runs):
        raise ValueError('이 패키지의 runs 안에 있는 학습 모델을 선택하세요. exports는 실차 실행용입니다. 다른 실험은 폴더 전체를 runs로 복사하세요.')
    relative = actor.relative_to(runs)
    if len(relative.parts) == 2:
        run, folder = actor.parent, actor.parent
    elif len(relative.parts) == 4 and relative.parts[1] == 'models':
        run, folder = runs / relative.parts[0], actor.parent
    else:
        raise ValueError('runs/실험명/models/저장모델/actor.npz를 선택하세요. actor.npz만 따로 복사하면 평가할 수 없습니다.')
    # Check symlinked dependencies too: keep one complete, traceable experiment.
    for name in ('settings.json', 'lesson.py', 'training.json', 'vehicle_base.json',
                 'shared_code/vision.py', 'shared_code/policy_io.py'):
        _require_file(run / name, run)
    _require_file(folder / 'model.zip', run)
    training = _json(run / 'training.json')
    for name, key in (('settings.json', 'settings_sha256'), ('lesson.py', 'lesson_sha256')):
        if training.get(key) and sha256(run / name) != training[key]:
            raise ValueError(f'{name}이 학습 후 변경되어 저장된 모델과 일치하지 않습니다. 원래 실험 파일을 복구하세요.')
    record, label = None, folder.name
    index_path = run / 'model_selection.json'
    if index_path.exists():
        index = _json(index_path)
        for choice in ('best', 'last'):
            candidate = index.get(choice)
            if not isinstance(candidate, dict) or not isinstance(candidate.get('directory'), str):
                continue
            if (run / candidate['directory']).resolve() != folder:
                continue
            record, label = copy.deepcopy(candidate), choice
            for name in ('actor.npz', 'model.zip'):
                if sha256(folder / name) != record.get('sha256', {}).get(name):
                    raise ValueError(f'선택한 {choice}의 {name} 무결성 검사가 실패했습니다. 원래 모델을 복구하세요.')
            break
    if record is None:
        if folder == run:
            if training.get('failed'):
                raise ValueError('오류로 끝난 실험의 마지막 모델입니다. models 안의 정상 저장 모델을 선택하세요.')
            record, label = copy.deepcopy(training), 'last'
        else:
            _require_file(folder / 'metadata.json', run)
            record = _json(folder / 'metadata.json')
    _steps(record)
    try:
        checkpoint = checkpoint_info(folder / 'model.zip')
    except Exception as exc:
        raise ValueError('선택한 모델의 model.zip이 손상되었거나 PPO 저장 파일이 아닙니다.') from exc
    if any(checkpoint[key] != record[key] for key in ('timesteps', 'ppo_updates')):
        raise ValueError('선택한 모델의 스텝 정보가 model.zip과 일치하지 않습니다. 원래 모델을 복구하세요.')
    return actor, run, record, label, training


# Environment exploration stays on the current GUI settings.  These fields
# instead define the observations/actions that this particular policy learned.
POLICY_SETTING_KEYS = ('vision', 'grid_rows', 'grid_cols', 'roi_min', 'roi_max',
                       'camera_pitch_deg', 'camera_hfov_deg', 'speed_m_s',
                       'steer_max_rad', 'control_hz')


def prepare_evaluation(root, model_path, current):
    """Validate everything needed for evaluation without writing or starting work."""
    root = Path(root).resolve()
    actor, run, record, label, training = _resolve(root, model_path)
    saved = _json(run / 'settings.json')
    for name in ('vision.py', 'policy_io.py'):
        if sha256(run / 'shared_code' / name) != sha256(root / 'lane_lab' / name):
            raise ValueError(f'{name}이 학습 당시와 다릅니다. 해당 실험의 패키지 버전에서 평가하거나 새로 학습하세요.')
    missing = [key for key in POLICY_SETTING_KEYS if key not in saved]
    if missing:
        raise ValueError('학습 당시 입력·제어 설정이 없습니다: ' + ', '.join(missing))
    settings = copy.deepcopy(current)
    for key in POLICY_SETTING_KEYS:
        settings[key] = copy.deepcopy(saved[key])
    settings['observation_format'] = saved.get('observation_format', 'grid_distances_mask_v1')
    # Camera mounting and Ackermann geometry belong to the saved policy context;
    # GUI mass/friction still override their matching vehicle fields in worlds.py.
    vehicle = _json(run / 'vehicle_base.json')
    vehicle.update(copy.deepcopy(saved.get('vehicle', {})))
    settings['vehicle'] = vehicle
    try:
        settings = read_settings(root, settings, read_design=False)
    except Exception as exc:
        raise ValueError(f'선택한 모델의 저장 설정·학습 코드·정책 검사를 통과하지 못했습니다: {exc}') from exc
    lesson, size, policy = _checked_policy(run, actor, settings, training)
    return EvaluationModel(run, actor, label, record, settings, lesson, size, policy, sha256(actor))


def _checked_policy(run, actor, settings, training):
    try:
        lesson, size = check_lesson(run / 'lesson.py', settings)
        policy = NumpyPolicy(actor)
    except Exception as exc:
        raise ValueError(f'선택한 모델의 저장 설정·학습 코드·정책 검사를 통과하지 못했습니다: {exc}') from exc
    if policy.observation_size != size or (training.get('observation_size') is not None and training['observation_size'] != size):
        raise ValueError('선택한 모델의 입력 개수와 저장된 격자·학습 코드의 입력 개수가 다릅니다.')
    # A finite parameter array can still overflow at inference. Exercise a normal
    # missing-feature observation before changing the live simulator.
    policy.predict(np.zeros(size, dtype=np.float32))
    return lesson, size, policy


def _check_resume_checkpoint(path, size, policy):
    """Check SB3's readable architecture metadata without Torch or unpickling.

    The worker still loads the optimizer and tensor state with PPO.load on CPU.
    This gate rejects a wrong observation/action space or actor architecture
    before the application saves settings or changes its current simulation.
    """
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read('data'))
    for key in ('num_timesteps', '_n_updates', 'n_steps', 'n_envs'):
        value = data.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f'선택한 model.zip의 {key} 저장 정보가 올바르지 않습니다.')
    if data['n_envs'] != 1 or data.get('use_sde', False):
        raise ValueError('선택한 model.zip은 이 패키지의 단일 환경 PPO 정책이 아닙니다.')
    for key, shape in (('observation_space', [size]), ('action_space', [1])):
        space = data.get(key)
        if (not isinstance(space, dict) or space.get('_shape') != shape or
                space.get(':type:') != "<class 'gymnasium.spaces.box.Box'>"):
            raise ValueError(f'선택한 model.zip의 {key} 입력·액션 크기가 저장 정책과 다릅니다.')
    action = data['action_space']
    try:
        action_range = (float(action['low_repr']), float(action['high_repr']))
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('선택한 model.zip의 조향 액션 범위를 확인할 수 없습니다.') from exc
    if action_range != (-1., 1.):
        raise ValueError('선택한 model.zip의 조향 액션 범위는 [-1, +1]이어야 합니다.')
    kwargs = data.get('policy_kwargs')
    if not isinstance(kwargs, dict):
        raise ValueError('선택한 model.zip의 PPO 정책 구조를 확인할 수 없습니다.')
    architecture = kwargs.get('net_arch')
    # SB3 accepts a shared list as well as separate actor/critic layer lists.
    actor_layers = architecture.get('pi') if isinstance(architecture, dict) else architecture
    critic_layers = architecture.get('vf') if isinstance(architecture, dict) else architecture
    hidden_sizes = [int(weight.shape[0]) for weight, _ in policy.layers[:-1]]
    if (actor_layers != hidden_sizes or not isinstance(critic_layers, list) or
            any(isinstance(n, bool) or not isinstance(n, int) or n <= 0 for n in critic_layers) or
            kwargs.get('activation_fn') != "<class 'torch.nn.modules.activation.Tanh'>" or
            kwargs.get('squash_output', False)):
        raise ValueError('선택한 model.zip의 PPO 정책 구조가 actor.npz와 일치하지 않습니다.')
    return data['n_steps']


def validate_resume_selection(prepared):
    """Fail before execution if a prepared file selection changed while waiting."""
    candidate = prepared.candidate
    hashes = {**candidate['source_sha256'],
              str(candidate['actor']): candidate['actor_sha256'],
              str(candidate['path']): candidate['checkpoint_sha256']}
    for name, expected in hashes.items():
        path = Path(name)
        if not path.is_file() or path.resolve() != path or sha256(path) != expected:
            raise ValueError(f'선택한 모델의 {path.name}이 검사 후 변경되었습니다. 모델을 다시 선택하세요.')


def prepare_resume(root, model_path, current):
    """Prepare the exact selected PPO state without writes or simulator changes.

    ``candidate['path']`` is always ``actor.parent / 'model.zip'``: no latest-run
    lookup or checkpoint fallback is allowed. As in legacy resume, the target
    is max(saved train_steps, current train_steps), and must exceed this chosen
    snapshot's timesteps. Current environment fields follow resume_settings.
    Call validate_resume_selection again immediately before starting the worker.
    """
    root = Path(root).resolve()
    actor, run, record, label, training = _resolve(root, model_path)
    checkpoint = actor.parent / 'model.zip'
    candidate = {'run': run, 'path': checkpoint, 'actor': actor, 'label': label,
                 'timesteps': record['timesteps'], 'ppo_updates': record['ppo_updates'],
                 'gamma': checkpoint_info(checkpoint)['gamma'],
                 'actor_sha256': sha256(actor), 'checkpoint_sha256': sha256(checkpoint)}
    paths = [run / name for name in ('settings.json', 'lesson.py', 'training.json',
             'vehicle_base.json', 'shared_code/vision.py', 'shared_code/policy_io.py')]
    paths.extend(path for path in (run / 'model_selection.json', actor.parent / 'metadata.json')
                 if path.is_file())
    # Guard both the saved context and compatibility inputs during worker handoff.
    paths.extend(root / name for name in ('config/defaults.json', 'config/vehicle.json',
                 'design/agent.py', 'lane_lab/vision.py', 'lane_lab/policy_io.py'))
    candidate['source_sha256'] = {str(path): sha256(path) for path in paths}
    settings = resume_settings(root, candidate, current)
    lesson, size, policy = _checked_policy(run, actor, settings, training)
    candidate['n_steps'] = _check_resume_checkpoint(checkpoint, size, policy)
    prepared = ResumeModel(run, actor, label, record, settings, lesson, size, policy,
                           candidate['actor_sha256'], candidate)
    validate_resume_selection(prepared)
    return prepared
