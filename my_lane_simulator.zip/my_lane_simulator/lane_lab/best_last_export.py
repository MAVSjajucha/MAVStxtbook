"""Export selected PPO actors as independent, small Jetson deployment folders.

Usage from the PC package:
    python -m lane_lab.best_last_export --choice both --print-path

Default selection belongs to best_last; explicit file selection also supports
historical snapshots. No current student code or preprocessing is substituted
for a saved experiment.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
from dataclasses import dataclass
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import zipfile


_CHOICES = ('best', 'last')
_MANIFEST_FILES = ('lesson.py', 'settings.json', 'actor.npz',
                   'lane_lab/vision.py', 'lane_lab/policy_io.py', 'lane_lab/ros_nodes.py',
                   'drive_real.py', 'run_real.sh', 'build_real.sh', 'vehicle_launcher.py')


@dataclass(frozen=True)
class SelectedExport:
    root: Path
    run: Path
    actor: Path
    label: str
    record: dict
    actor_sha256: str
    source_sha256: dict


# A separate interpreter keeps saved lane_lab imports out of the running
# simulator. -B also prevents preflight from creating bytecode in the run.
_VALIDATE_SAVED_MODEL = r'''
import json, math, sys, types
from contextlib import redirect_stdout
from pathlib import Path
import numpy as np
run, actor = map(Path, sys.argv[1:])
package = types.ModuleType('lane_lab')
package.__path__ = [str(run / 'shared_code')]
sys.modules['lane_lab'] = package
with redirect_stdout(sys.stderr):
    from lane_lab.vision import GridConfig, extract_features
    from lane_lab.policy_io import NumpyPolicy
    settings = json.loads((run / 'settings.json').read_text(encoding='utf-8'))
    training = json.loads((run / 'training.json').read_text(encoding='utf-8'))
    grid = GridConfig.from_mapping(settings['vision'])
    for setting, attribute in (('grid_rows', 'rows'), ('grid_cols', 'cols'),
                               ('roi_min', 'roi_bottom_px'), ('roi_max', 'roi_top_px')):
        if settings[setting] != getattr(grid, attribute):
            raise ValueError('저장된 격자 설정이 서로 다릅니다: ' + setting)
    lesson = types.ModuleType('exported_lesson')
    lesson.__file__ = str(run / 'lesson.py')
    exec(compile((run / 'lesson.py').read_text(encoding='utf-8'), lesson.__file__, 'exec'), lesson.__dict__)
    for name in ('observe', 'act', 'calculate_reward'):
        if not callable(getattr(lesson, name, None)):
            raise ValueError('저장된 lesson.py에 ' + name + '()이 없습니다.')
    features = extract_features(np.zeros((grid.height, grid.width, 3), np.uint8), grid)
    observation = np.asarray(lesson.observe(features, 0.), dtype=np.float32)
    if observation.ndim != 1 or not 1 <= observation.size <= 1024 or not np.all(np.isfinite(observation)):
        raise ValueError('저장된 observe() 입력은 유한한 1차원 배열이어야 합니다.')
    policy = NumpyPolicy(actor)
    if policy.observation_size != observation.size or training.get('observation_size', observation.size) != observation.size:
        raise ValueError('모델의 입력 개수와 저장된 격자·학습 코드의 입력 개수가 다릅니다.')
    action = policy.predict(observation)
    for value in (action, np.array([-1.], np.float32), np.array([1.], np.float32)):
        command = lesson.act(value, settings)
        for name in ('normalized_steer', 'steering_rad', 'speed_m_s'):
            if not math.isfinite(float(command[name])):
                raise ValueError('저장된 act()에 유한한 숫자가 필요합니다: ' + name)
        if abs(command['normalized_steer']) > 1.000001 or abs(command['steering_rad']) > settings['steer_max_rad'] + 1e-6:
            raise ValueError('저장된 act()가 모델의 조향 범위를 넘었습니다.')
        if not 0 <= command['speed_m_s'] <= .2:
            raise ValueError('저장된 act()의 전진 속도는 0~0.2 m/s 범위여야 합니다.')
'''


def _read_object(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, ValueError) as exc:
        raise ValueError(f'실험 기록을 읽을 수 없습니다: {path}: {exc}') from exc
    if not isinstance(value, dict):
        raise ValueError(f'실험 기록은 JSON 객체여야 합니다: {path}')
    return value


def _write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n',
                    encoding='utf-8')


def _atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        _write_json(temporary, value)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _resolve_run(root: Path, run: str | Path | None) -> Path:
    runs = (root / 'runs').resolve()
    if run is None:
        record = _read_object(root / 'runtime' / 'latest_run.json')
        run = record.get('run')
        if not isinstance(run, str) or not run:
            raise ValueError('runtime/latest_run.json에 유효한 run 경로가 없습니다.')
    if not isinstance(run, (str, Path)):
        raise ValueError('run은 실험 폴더 경로여야 합니다.')
    supplied = Path(run)
    candidate = (supplied if supplied.is_absolute() else root / supplied).resolve()
    if candidate == runs or not candidate.is_relative_to(runs):
        raise ValueError('내보낼 실험은 이 패키지의 runs 폴더 안에 있어야 합니다.')
    if not candidate.is_dir():
        raise ValueError(f'실험 폴더가 없습니다: {candidate}')
    return candidate


def _required_file(path: Path, within: Path | None = None) -> Path:
    resolved = path.resolve()
    if within is not None and not resolved.is_relative_to(within.resolve()):
        raise ValueError(f'실험 폴더 밖을 가리키는 파일은 사용할 수 없습니다: {path}')
    if not resolved.is_file():
        raise ValueError(f'저장된 학습 파일이 없습니다: {path}')
    return resolved


def _nonnegative_int(value, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f'선택된 모델의 {field}는 0 이상의 정수여야 합니다.')
    return value


def _verify_selected(selected: SelectedExport) -> None:
    for relative, expected in selected.source_sha256.items():
        source = _required_file(selected.run / relative, selected.run)
        if _sha256(source) != expected:
            raise ValueError(f'선택한 모델 파일이 검사 후 변경되었습니다: {source}. 파일을 다시 선택하세요.')


def prepare_export(root: str | Path, model_path: str | Path) -> SelectedExport:
    """Validate an exact actor and saved context without creating export files."""
    from .model_selection import _resolve

    root = Path(root).resolve()
    actor, run, record, label, _ = _resolve(root, model_path)
    names = ['lesson.py', 'settings.json', 'training.json', 'vehicle_base.json',
             'shared_code/vision.py', 'shared_code/policy_io.py',
             actor.relative_to(run).as_posix(),
             (actor.parent / 'model.zip').relative_to(run).as_posix()]
    metadata = actor.parent / 'metadata.json'
    if metadata.is_file():
        names.append(metadata.relative_to(run).as_posix())
    hashes = {name: _sha256(_required_file(run / name, run)) for name in names}
    actor_hash = hashes[actor.relative_to(run).as_posix()]
    # A historical folder called best/last may no longer be that live choice.
    # Preserve its identity instead of presenting it as the current pointer.
    if actor.parent != run and label in _CHOICES and 'directory' not in record:
        label = f'snapshot_{label}_{record["timesteps"]}_{actor_hash[:8]}'
    for name in ('actor.npz', 'model.zip'):
        expected = record.get('sha256', {}).get(name)
        if expected and _sha256(actor.parent / name) != expected:
            raise ValueError(f'선택한 모델의 {name} 무결성 검사가 실패했습니다.')
    for name in ('drive_real.py', 'run_real.sh', 'build_real.sh', 'vehicle_launcher.py'):
        _required_file(root / 'deploy' / name)
    _required_file(root / 'lane_lab/ros_nodes.py')
    if not (root / 'ros_ws/src').is_dir():
        raise ValueError('실차 ROS 소스가 없습니다: ros_ws/src')
    try:
        result = subprocess.run([sys.executable, '-B', '-c', _VALIDATE_SAVED_MODEL,
                                 str(run), str(actor)], capture_output=True, text=True,
                                check=False, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError(f'선택한 모델의 저장 코드·정책 검사를 실행할 수 없습니다: {exc}') from exc
    if result.returncode:
        detail = result.stderr.strip().splitlines()
        raise ValueError('선택한 모델의 저장 설정·학습 코드·정책 검사를 통과하지 못했습니다: '
                         + (detail[-1] if detail else '검사 실행 실패'))
    selected = SelectedExport(root, run, actor, label, record, actor_hash, hashes)
    _verify_selected(selected)
    return selected


def _bundle(root: Path, run: Path, destination: Path,
            choice: str, snapshot: Path, selection: dict,
            prepared: SelectedExport | None = None) -> None:
    if not isinstance(selection, dict):
        raise ValueError(f'{choice} 모델의 선택 기록이 JSON 객체가 아닙니다.')
    steps = _nonnegative_int(selection.get('timesteps'), 'timesteps')
    updates = _nonnegative_int(selection.get('ppo_updates'), 'ppo_updates')
    if updates == 0:
        raise ValueError(f'{choice} 모델은 아직 PPO 업데이트 전입니다. 학습 후 내보내세요.')
    source_training = _read_object(_required_file(run / 'training.json', run))
    _required_file(snapshot / 'model.zip', run)
    actor = _required_file(snapshot / 'actor.npz', run)
    saved = {
        'lesson.py': _required_file(run / 'lesson.py', run),
        'settings.json': _required_file(run / 'settings.json', run),
        'lane_lab/vision.py': _required_file(run / 'shared_code' / 'vision.py', run),
        'lane_lab/policy_io.py': _required_file(run / 'shared_code' / 'policy_io.py', run),
    }
    if prepared is not None:
        _verify_selected(prepared)
        saved['vehicle_base.json'] = _required_file(run / 'vehicle_base.json', run)
    deploy = root / 'deploy'
    if not deploy.is_dir():
        raise ValueError(f'실차 실행 파일 폴더가 없습니다: {deploy}')
    # Copy the runnable deployment scripts and any supplied calibration first.
    # Saved experiment files below replace similarly named sample files.
    shutil.copytree(deploy, destination,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for relative, source in saved.items():
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    # Copy ROS source only. The first run builds these small packages for the
    # vehicle's own architecture; no PC build/install paths enter the bundle.
    shutil.copy2(_required_file(root / 'lane_lab/ros_nodes.py'), destination / 'lane_lab/ros_nodes.py')
    ros_source = root / 'ros_ws/src'
    if not ros_source.is_dir():
        raise ValueError('실차 ROS 소스가 없습니다: ros_ws/src')
    shutil.copytree(ros_source, destination / 'ros_ws/src',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.egg-info'))
    package_init = root / 'lane_lab' / '__init__.py'
    if package_init.is_file():
        shutil.copy2(package_init, destination / 'lane_lab' / '__init__.py')
    else:
        (destination / 'lane_lab' / '__init__.py').write_text('', encoding='utf-8')
    shutil.copy2(actor, destination / 'actor.npz')
    if prepared is not None:
        # Verify the bytes copied, including files changed during copy2 itself.
        for relative, source in {**saved, 'actor.npz': actor}.items():
            source_name = {'lane_lab/vision.py': 'shared_code/vision.py',
                           'lane_lab/policy_io.py': 'shared_code/policy_io.py',
                           'actor.npz': actor.relative_to(run).as_posix()}.get(relative, relative)
            expected = prepared.source_sha256[source_name]
            if _sha256(destination / relative) != expected:
                raise ValueError(f'내보내는 동안 선택한 모델 파일이 변경되었습니다: {source}')
        _verify_selected(prepared)
    calibration = destination / 'real_calibration.json'
    example = destination / 'real_calibration.example.json'
    if not calibration.exists() and example.is_file():
        shutil.copy2(example, calibration)
    training = dict(source_training)
    training.update(source_run_last_timesteps=source_training.get('timesteps'),
                    timesteps=steps, ppo_updates=updates, model_choice=choice)
    _write_json(destination / 'training.json', training)
    choice_record = {
        'choice': choice, 'run': run.relative_to(root).as_posix(),
        'step': steps, 'timesteps': steps, 'ppo_updates': updates,
    }
    if 'metrics' in selection:
        choice_record['metrics'] = selection['metrics']
    if prepared is not None:
        choice_record.update(
            model_path=str(prepared.actor), model_sha256=prepared.actor_sha256,
            checkpoint_path=str(snapshot / 'model.zip'),
            checkpoint_sha256=prepared.source_sha256[(snapshot / 'model.zip').relative_to(run).as_posix()],
            source_sha256=prepared.source_sha256)
    _write_json(destination / 'model_selection.json', choice_record)
    if (root / 'THIRD_PARTY.md').is_file():
        shutil.copy2(root / 'THIRD_PARTY.md', destination / 'THIRD_PARTY.md')
    if (root / 'licenses').is_dir():
        shutil.copytree(root / 'licenses', destination / 'licenses', dirs_exist_ok=True)
    manifest_files = list(_MANIFEST_FILES) + [
        path.relative_to(destination).as_posix()
        for path in sorted((destination / 'ros_ws/src').rglob('*')) if path.is_file()]
    if prepared is not None:
        manifest_files += ['vehicle_base.json', 'training.json', 'model_selection.json']
    _write_json(destination / 'manifest.json', {
        'ros_pipeline': 1,
        'sha256': {name: _sha256(destination / name) for name in manifest_files},
    })


def export_models(root: str | Path, run: str | Path | None = None,
                  choices: tuple[str, ...] = _CHOICES) -> Path:
    """Publish one ZIP and a group folder containing independent selected models.

    Existing exports are preserved. A failing build leaves no partial published
    group and does not change latest_models.json.
    """
    root = Path(root).resolve()
    run = _resolve_run(root, run)
    if not choices or len(set(choices)) != len(choices) or any(c not in _CHOICES for c in choices):
        raise ValueError('모델 선택은 best, last 또는 둘 다여야 합니다.')
    from .best_last import load_choice
    selected = {}
    for choice in choices:
        try:
            snapshot, record = load_choice(run, choice)
        except Exception as exc:
            hint = ('이 실험에 best 저장 기록이 있는지 확인하세요. '
                    'best를 저장하지 않은 이전 실험은 last만 내보내거나 새로 학습해야 합니다.'
                    if choice == 'best' else '이 실험의 last 모델 저장 여부를 확인하세요.')
            raise ValueError(f'{choice} 모델을 내보낼 수 없습니다: {exc}. {hint}') from exc
        snapshot = Path(snapshot).resolve()
        if not snapshot.is_relative_to(run):
            raise ValueError(f'{choice} 모델 저장 경로가 실험 폴더 밖입니다: {snapshot}')
        selected[choice] = (snapshot, record)
    return _publish_exports(root, run, selected)


def export_selected_model(root: str | Path, model_path: str | Path, *,
                          prepared: SelectedExport | None = None) -> Path:
    """Export exactly one chosen actor, even when it is no longer best/last."""
    root = Path(root).resolve()
    if prepared is None:
        prepared = prepare_export(root, model_path)
    if (prepared.root != root or not isinstance(model_path, (str, Path))
            or Path(model_path).expanduser().resolve() != prepared.actor):
        raise ValueError('검사한 모델 경로와 내보낼 모델 경로가 다릅니다. 파일을 다시 선택하세요.')
    _verify_selected(prepared)
    selected = {prepared.label: (prepared.actor.parent, prepared.record)}
    return _publish_exports(root, prepared.run, selected, prepared=prepared)


def _publish_exports(root: Path, run: Path, selected: dict, *,
                     prepared: SelectedExport | None = None) -> Path:
    exports = root / 'exports'
    exports.mkdir(parents=True, exist_ok=True)
    name = 'jetson_models_' + run.name + '_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:12]
    destination = exports / name
    archive = exports / (name + '.zip')
    staging = exports / ('.' + name + '.staging')
    temporary_zip = exports / ('.' + name + '.zip.tmp')
    if any(path.exists() for path in (destination, archive, staging, temporary_zip)):
        raise FileExistsError('내보내기 경로가 이미 존재합니다. 다시 실행하세요.')
    staging.mkdir()
    published_folder = False
    published_zip = False
    try:
        for choice, (snapshot, record) in selected.items():
            _bundle(root, run, staging / choice, choice, snapshot, record, prepared)
        with zipfile.ZipFile(temporary_zip, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
            for path in sorted(staging.rglob('*')):
                if path.is_file():
                    bundle.write(path, (Path(name) / path.relative_to(staging)).as_posix())
        staging.rename(destination)
        published_folder = True
        temporary_zip.rename(archive)
        published_zip = True
        _atomic_json(exports / 'latest_models.json', {
            'path': destination.relative_to(root).as_posix(),
            'run': run.relative_to(root).as_posix(),
        })
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        temporary_zip.unlink(missing_ok=True)
        if published_folder:
            shutil.rmtree(destination, ignore_errors=True)
        if published_zip:
            archive.unlink(missing_ok=True)
        raise
    return destination


def export_both(root: str | Path, run: str | Path | None = None) -> Path:
    """Export best and last as separate independent folders plus one ZIP."""
    return export_models(root, run, _CHOICES)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='best / last 모델을 독립된 Jetson 폴더로 내보내기')
    parser.add_argument('--choice', choices=('best', 'last', 'both'), default='both')
    parser.add_argument('--run', help='패키지 기준 runs/실험이름 또는 실험의 절대 경로')
    parser.add_argument('--print-path', action='store_true', help='표준 출력에는 생성된 그룹 폴더 경로만 표시')
    args = parser.parse_args(argv)
    choices = _CHOICES if args.choice == 'both' else (args.choice,)
    try:
        # Keep stdout machine-readable even if the selection implementation logs.
        with redirect_stdout(sys.stderr):
            result = export_models(Path(__file__).resolve().parents[1], args.run, choices)
    except Exception as exc:
        print(f'내보내기 실패: {exc}', file=sys.stderr)
        return 1
    if args.print_path:
        print(result)
    else:
        print('실차용 모델 폴더:', result)
        print('압축 파일:', Path(str(result) + '.zip'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
