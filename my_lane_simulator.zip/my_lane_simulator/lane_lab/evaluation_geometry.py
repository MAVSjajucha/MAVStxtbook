"""Rear-axle path errors for evaluation only; never alters reward or physics.

O is the rear axle midpoint and M is the *global closest point* on the closed
ordered route. This is the closest-point model used in Automatic Guidance of a
Farm Tractor Relying on a Single CP-DGPS and Comparison of lateral controllers
for autonomous vehicle: experimental results. It does not intersect the route
with the vehicle's lateral axis, nor pick only the nearest sampled vertex.

The simulator stores a dense (~5 mm) polyline rather than an analytic curve.
Segment projection is exact for that polyline; it approximates the underlying
printed centreline. On a segment interior O-M is normal to the segment. At a
non-collinear vertex no unique tangent exists, and equally near branches can
also make the reference ambiguous. Such rows are flagged rather than silently
reported as unique smooth-curve normal projections. The original segment with
the smallest index is selected deterministically in a distance tie; its tangent
is used for heading. Signed distance is left-positive in route order.
"""
from __future__ import annotations

import math

import numpy as np


class RearAxleProjection:
    """Measure a pose (vehicle midpoint x, y, yaw) against a closed XY route.

    wheelbase_m is the front/rear axle separation. The input vehicle midpoint
    lies midway between the axles, so O = (x,y) - L/2 * (cos(yaw),sin(yaw)).
    Repeated neighbouring route points are ignored. Segment indices refer to
    the original route, including its final-to-first closing segment.
    """

    _DISTANCE_TOL_M = 1e-9
    _TANGENT_TOL = 1e-8

    def __init__(self, route, wheelbase_m):
        points = np.asarray(route, dtype=np.float64)
        wheelbase_m = float(wheelbase_m)
        if (points.ndim != 2 or points.shape[1] != 2 or len(points) < 3
                or not np.isfinite(points).all()):
            raise ValueError("route must contain at least three finite XY points")
        if not math.isfinite(wheelbase_m) or wheelbase_m <= 0:
            raise ValueError("wheelbase_m must be finite and positive")
        vectors = np.roll(points, -1, axis=0) - points
        lengths = np.linalg.norm(vectors, axis=1)
        valid = lengths > 1e-12
        if np.count_nonzero(valid) < 3:
            raise ValueError("closed route needs at least three nonzero segments")
        self.wheelbase_m = wheelbase_m
        self.starts = points[valid].copy()
        self.vectors = vectors[valid].copy()
        self.lengths = lengths[valid].copy()
        self.lengths_squared = self.lengths ** 2
        self.tangents = self.vectors / self.lengths[:, None]
        self.segment_indices = np.flatnonzero(valid)

    def measure(self, pose):
        """Return finite distances in metres, heading angles in radians.

        ``lateral_error_m`` has the *magnitude of the shortest distance*, even
        at a polyline corner; it is not merely O-M dotted with a normal. At a
        degenerate corner, other tied segment directions help determine its
        side. If no side can be defined, positive distance is a deterministic
        fallback and ``projection_ambiguous`` is true. On-route distance is 0.
        ``projection_tangential_residual_m`` = (O-M) dot selected unit tangent.
        A valid unique normal projection has negligible tangential residual.
        """
        p = np.asarray(pose, dtype=np.float64)
        if p.ndim != 1 or len(p) < 3 or not np.isfinite(p[:3]).all():
            raise ValueError("pose must contain finite x, y, yaw")
        yaw = float(p[2])
        rear = p[:2] - self.wheelbase_m / 2 * np.array(
            [math.cos(yaw), math.sin(yaw)])
        fractions = np.clip(np.sum((rear - self.starts) * self.vectors, axis=1)
                            / self.lengths_squared, 0.0, 1.0)
        projected = self.starts + fractions[:, None] * self.vectors
        offsets = rear - projected
        distances = np.linalg.norm(offsets, axis=1)
        closest = float(np.min(distances))
        tied = np.flatnonzero(distances <= closest + self._DISTANCE_TOL_M)
        # Keep the true minimum, using route order only for numerically exact
        # ties. A merely near-tied branch must not replace the nearest point.
        best = int(np.argmin(distances))
        tangent = self.tangents[best]
        point = projected[best]
        offset = offsets[best]
        at_vertex = bool(fractions[best] <= 1e-12 or fractions[best] >= 1 - 1e-12)
        different_points = np.any(np.linalg.norm(projected[tied] - point, axis=1)
                                  > self._DISTANCE_TOL_M)
        different_tangents = np.any(np.linalg.norm(self.tangents[tied] - tangent,
                                                  axis=1) > self._TANGENT_TOL)
        ambiguous = bool(different_points or different_tangents)

        side = float(tangent[0] * offset[1] - tangent[1] * offset[0])
        if closest <= 1e-12:
            signed_distance = 0.0
        else:
            if abs(side) <= 1e-12:
                # At a corner O-M can be collinear with the selected segment.
                # Consider adjacent tied tangents rather than returning 0 for
                # an off-path point. Conflicting sides are already ambiguous.
                same_point = tied[np.linalg.norm(projected[tied] - point, axis=1)
                                  <= self._DISTANCE_TOL_M]
                sides = (self.tangents[same_point, 0] * offset[1]
                         - self.tangents[same_point, 1] * offset[0])
                nonzero = sides[np.abs(sides) > 1e-12]
                if len(nonzero):
                    side = float(nonzero[0])
                else:
                    ambiguous = True
                    side = 1.0
            signed_distance = math.copysign(closest, side)

        path_heading = math.atan2(float(tangent[1]), float(tangent[0]))
        delta = yaw - path_heading
        heading_error = math.atan2(math.sin(delta), math.cos(delta))
        tangential_residual = float(np.dot(offset, tangent))
        return {
            "rear_x_m": float(rear[0]),
            "rear_y_m": float(rear[1]),
            "path_x_m": float(point[0]),
            "path_y_m": float(point[1]),
            "path_heading_rad": path_heading,
            "lateral_error_m": signed_distance,
            "heading_error_rad": heading_error,
            "projection_distance_m": closest,
            "projection_ambiguous": ambiguous,
            "projection_vertex": at_vertex,
            "projection_normal_valid": (not ambiguous and
                abs(tangential_residual) <= self._DISTANCE_TOL_M),
            "path_segment": int(self.segment_indices[best]),
            "projection_tangential_residual_m": tangential_residual,
        }
