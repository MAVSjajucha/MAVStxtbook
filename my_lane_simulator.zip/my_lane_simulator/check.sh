#!/usr/bin/env bash
export PYTHONNOUSERSITE=1
set -euo pipefail
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$LAB_ROOT"
source "$LAB_ROOT/ros_env.sh"
if [[ ! -x .venv/bin/python ]]; then echo '먼저 bash install.sh를 실행하세요.'; exit 1; fi
.venv/bin/python -m lane_lab check
if [[ "${1:-}" == --gazebo ]]; then
  .venv/bin/python -m lane_lab doctor --smoke
else
  .venv/bin/python -m lane_lab doctor
fi
