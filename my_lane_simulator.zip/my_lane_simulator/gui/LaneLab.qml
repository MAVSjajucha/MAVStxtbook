// SPDX-License-Identifier: Apache-2.0
import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Controls.Material 2.12
import QtQuick.Layouts 1.12
// Fortress loads the root component with a file:: URL; resolve helper types
// through the resource URL explicitly rather than that synthetic base URL.
import "qrc:/LaneLab"

Item {
  id: panel
  anchors.fill: parent
  implicitWidth: 420
  implicitHeight: 760
  Layout.minimumWidth: 380
  Layout.minimumHeight: 540
  readonly property color brandColor: "#76364F"
  readonly property color warningColor: Material.theme === Material.Dark ? "#ffb86b" : "#a44700"
  Material.primary: brandColor
  Material.accent: brandColor

  property var customTiles: [["I90", "C180", "I180"], ["I0", "C0", "I270"]]
  property int tileRows: 2
  property int tileCols: 3
  property int selectedRow: 0
  property int selectedCol: 0
  property bool initialized: false
  property string validationMessage: ""
  readonly property var trackNames: ["track1", "track2", "track3", "custom"]
  readonly property var tileNames: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "TS", "TC", "Background"]

  readonly property var tileLabels: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "직선 터널", "곡선 터널", "빈칸"]

  function numberOr(value, fallback) {
    return value !== undefined && isFinite(Number(value)) ? Number(value) : fallback
  }
  property var extraLights: [
    {enabled:false,x:-0.9,y:-0.9,z:2}, {enabled:false,x:0.9,y:-0.9,z:2},
    {enabled:false,x:-0.9,y:0.9,z:2}, {enabled:false,x:0.9,y:0.9,z:2}]
  function lightSettings() {
    var result=[]
    for(var i=0;i<4;++i) {
      var row=lightRepeater.itemAt(i)
      result.push({enabled:row.checked, x:extraLights[i].x, y:extraLights[i].y, z:extraLights[i].z})
    }
    return result
  }
  function settings() {
    return {
      track: trackNames[trackChoice.currentIndex],
      train_steps: trainSteps.value, seed: seedValue.value,
      speed_mode: speedMode.currentIndex === 0 ? "auto" : "manual",
      speed_factor: speedFactor.value / 4,
      camera_pitch_deg: cameraPitch.value,
      mass_kg: massValue.value / 1000,
      friction_mu1: Number(mu1FrictionValue.text),
      friction_mu2: Number(mu2FrictionValue.text),
      extra_light_type: extraLightType.currentIndex === 0 ? "point" : "spot",
      extra_lights: lightSettings(),
      roi_min: roiMin.value, roi_max: roiMax.value,
      grid_rows: roiRows.value, grid_cols: roiCols.value,
      custom_tiles: customTiles
    }
  }
  function send(action) {
    if (action !== "stop" && action !== "recover") {
      if (!mu1FrictionValue.commit()) {
        validationMessage="마찰 계수(mu1)는 0 이상의 유한한 숫자로 입력하세요.";return false
      }
      if (!mu2FrictionValue.commit()) {
        validationMessage="마찰 계수(mu2)는 0 이상의 유한한 숫자로 입력하세요.";return false
      }

    }
    validationMessage = ""
    if (action === "choose_evaluation") return LaneLabController.ChooseEvaluationModel(settings())
    if (action === "choose_export") return LaneLabController.ChooseExportModel(settings())
    if (action === "choose_resume") return LaneLabController.ChooseResumeModel(settings())
    return LaneLabController.Send(action, settings())
  }
  function loadTiles(tiles) {
    if (!tiles || !tiles.length || !tiles[0].length) return
    var result = []
    for (var r = 0; r < tiles.length; ++r) {
      var row = []
      for (var c = 0; c < tiles[0].length; ++c) row.push(String(tiles[r][c] || "Background"))
      result.push(row)
    }
    tileRows = result.length
    tileCols = result[0].length
    customTiles = result
    selectedRow = 0
    selectedCol = 0
    editorRows.value = tileRows
    editorCols.value = tileCols
    tileChoice.currentIndex = tileNames.indexOf(tileName(result[0][0]))
    rotationChoice.currentIndex = tileRotation(result[0][0]) / 90
  }
  function preset(which) {
    if (which === 1) loadTiles([["I90", "C180", "I180"], ["I0", "C0", "I270"]])
    if (which === 2) loadTiles([["F90", "F180", "Background"], ["A90", "F0", "F180"], ["F0", "A180", "F270"]])
    if (which === 3) loadTiles([
      ["F90", "A180", "A180", "A180", "I180", "Background", "Background"],
      ["F0", "A180", "I180", "Background", "J0", "I180", "Background"],
      ["I90", "A180", "I270", "Background", "Background", "J0", "G180"],
      ["I0", "D0", "E180", "E180", "D0", "D0", "I270"]])
  }
  function resizedTiles() {
    var result = []
    for (var r = 0; r < editorRows.value; ++r) {
      var row = []
      for (var c = 0; c < editorCols.value; ++c)
        row.push(r < tileRows && c < tileCols ? customTiles[r][c] : "Background")
      result.push(row)
    }
    loadTiles(result)
  }
  function putTile() {
    var result = []
    for (var r = 0; r < tileRows; ++r) result.push(customTiles[r].slice())
    var token = tileNames[tileChoice.currentIndex]
    if (token !== "Background") token += String(rotationChoice.currentIndex * 90)
    result[selectedRow][selectedCol] = token
    customTiles = result
  }
  function tokenAt(index) {
    var row = customTiles[Math.floor(index / tileCols)]
    return row && row[index % tileCols] ? row[index % tileCols] : "Background"
  }
  function tileName(token) { return token === "Background" ? token : token.replace(/[0-9]+$/, "") }
  function tileRotation(token) { return token === "Background" ? 0 : Number(token.slice(tileName(token).length)) }

  Component.onCompleted: {
    var s = LaneLabController.savedSettings
    var trackIndex = trackNames.indexOf(s.track)
    if (trackIndex >= 0) trackChoice.currentIndex = trackIndex
    trainSteps.value = numberOr(s.train_steps, 30000)
    seedValue.value = numberOr(s.seed, 0)
    speedMode.currentIndex = s.speed_mode === "manual" ? 1 : 0
    speedFactor.value = numberOr(s.speed_factor, 1) * 4
    cameraPitch.value = numberOr(s.camera_pitch_deg, 0)
    massValue.value = numberOr(s.mass_kg, 1.5) * 1000
    mu1FrictionValue.setCoefficient(numberOr(s.friction_mu1, numberOr(s.static_friction, numberOr(s.friction, 0.50))))
    mu2FrictionValue.setCoefficient(numberOr(s.friction_mu2, numberOr(s.static_friction, numberOr(s.friction, 0.50))))
    extraLightType.currentIndex=s.extra_light_type === "spot" ? 1 : 0
    if(s.extra_lights) extraLights=s.extra_lights
    roiMin.value = numberOr(s.roi_min, 0)
    roiMax.value = numberOr(s.roi_max, 150)
    roiRows.value = numberOr(s.grid_rows, 3)
    roiCols.value = numberOr(s.grid_cols, 7)
    if (s.custom_tiles) loadTiles(s.custom_tiles)
    else loadTiles(customTiles)
    initialized = true
  }


  ColumnLayout {
    anchors.fill: parent
    anchors.margins: 10
    spacing: 6
    Label { text: "실습 정보"; font.pixelSize: 19; font.bold: true }
    RowLayout {
      Layout.fillWidth: true
      Label { text: LaneLabController.statusText; font.bold: true; Layout.fillWidth: true }
      Label { text: "배속 " + LaneLabController.rtf.toFixed(2) + "×"; font.pixelSize: 12 }
    }
    Label {
      Layout.fillWidth: true
      text: LaneLabController.message
      wrapMode: Text.WordWrap
      maximumLineCount: 5
      elide: Text.ElideRight
      font.pixelSize: 12
      ToolTip.visible: messageHover.containsMouse
      ToolTip.text: LaneLabController.message
      MouseArea { id: messageHover; anchors.fill: parent; hoverEnabled: true; acceptedButtons: Qt.NoButton }
    }
    Label {
      Layout.fillWidth: true
      visible: text.length > 0
      text: LaneLabController.settingsWarning
      color: panel.warningColor
      wrapMode: Text.WordWrap
      font.pixelSize: 12
    }
    TabBar {
      id: tabs
      Layout.fillWidth: true
      TabButton { objectName: "learningTab"; text: "학습 진행" }
      TabButton { objectName: "environmentTab"; text: "환경 설정" }
      TabButton { objectName: "trackTab"; text: "트랙 재구성" }
    }
    StackLayout {
      Layout.fillWidth: true
      Layout.fillHeight: true
      currentIndex: tabs.currentIndex

      ScrollView {
        id: runScroll
        clip: true
        contentWidth: availableWidth
        ColumnLayout {
          width: runScroll.availableWidth
          spacing: 8
          Label { text: "학습 설정"; font.bold: true }
          ComboBox {
            id: trackChoice
            Layout.fillWidth: true
            model: ["트랙1", "트랙2", "트랙3", "내 트랙"]
            enabled: LaneLabController.backendAlive && !LaneLabController.busy
          }
          Label { text: "시뮬레이션 배속"; font.bold: true }
          GridLayout {
            columns: 2
            Layout.fillWidth: true
            Label { text: "모드 선택" }
            ComboBox { id: speedMode; model: ["자동", "수동"]; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "목표 배속" }
            SpinBox {
              id: speedFactor
              from: 1; to: 80; value: 4
              enabled: speedMode.currentIndex === 1 && !LaneLabController.busy
              Layout.fillWidth: true
              textFromValue: function(value, locale) { return (value / 4).toFixed(2) + "×" }
            }
          }
          Label {
            text: "자동 모드는 PC 사양을 고려하여 가능한 최대 속도로 자동 진행합니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          GridLayout {
            columns: 2
            Layout.fillWidth: true
            Label { text: "학습 스텝" }
            SpinBox { id: trainSteps; from: 1000; to: 10000000; stepSize: 10000; value: 30000; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "시드" }
            SpinBox { id: seedValue; from: 0; to: 999999; value: 0; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
          }
          Label { text: "실행"; font.bold: true; Layout.fillWidth: true; wrapMode: Text.WordWrap }
          GridLayout {
            columns: 2
            Layout.fillWidth: true
            Button { text: "학습 코드 수정"; Layout.fillWidth: true; onClicked: LaneLabController.EditLesson() }
            Button { text: "학습 코드 검사"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.send("check") }
            Button { text: "변경 설정 적용"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.send("preview") }
            Button {
              id: trainButton
              objectName: "trainButton"
              text: "학습 진행"; Layout.fillWidth: true; highlighted: true
              enabled: LaneLabController.backendAlive && !LaneLabController.busy
              contentItem: Text {
                text: trainButton.text; font: trainButton.font
                color: trainButton.enabled ? "white" : "#888888"
                horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
              }
              onClicked: panel.send("train")
            }
            Button { text: "일시 중지 및 저장"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive; onClicked: panel.send("stop") }
            Button { text: "학습된 모델 평가"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; objectName: "evaluateModelButton"; onClicked: panel.send("choose_evaluation") }
            Button { text: "Sim-to-Real 내보내기"; font.capitalization: Font.MixedCase; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; objectName: "exportModelButton"; onClicked: panel.send("choose_export") }
            Button { text: "워크스페이스 열기"; Layout.fillWidth: true; onClicked: LaneLabController.OpenRuns() }
          }
          Button {
            objectName: "resumeModelButton"
            text: "체크포인트 이어 학습"
            Layout.fillWidth: true
            enabled: LaneLabController.backendAlive && !LaneLabController.busy
            onClicked: panel.send("choose_resume")
          }
          Button {
            objectName: "recoverCheckpointButton"
            text: "자동 저장 체크포인트 복구"
            Layout.fillWidth: true
            visible: LaneLabController.backendAlive && !LaneLabController.busy && LaneLabController.resumeCheckpointOnly
            enabled: LaneLabController.resumeAvailable
            onClicked: panel.send("resume")
          }
          Label {
            visible: LaneLabController.backendAlive && !LaneLabController.busy && LaneLabController.resumeCheckpointOnly
            text: LaneLabController.resumeCheckpoint + " · " + LaneLabController.resumeSteps + "스텝\n"
              + (LaneLabController.resumeAvailable
                 ? "비정상 종료 전 자동 저장된 학습 상태로 새 실험을 시작합니다."
                 : LaneLabController.resumeReason + " 설정·코드를 수정한 뒤 학습 코드 검사를 누르세요.")
            Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; font.pixelSize: 12
          }
          Button {
            text: "프로그램 복구"
            Layout.fillWidth: true
            visible: !LaneLabController.backendAlive
            enabled: LaneLabController.recoveryAvailable
            highlighted: true
            Material.foreground: "white"
            onClicked: panel.send("recover")
          }
          Label {
            text: "이어서 학습은 현재 선택된 트랙에서 진행됩니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          Label {
            text: "변경한 코드는 학습 코드 검사 이후 적용됩니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          ProgressBar { Layout.fillWidth: true; from: 0; to: Math.max(1, LaneLabController.targetSteps || trainSteps.value); value: LaneLabController.steps }
          Label { text: "스텝 " + LaneLabController.steps + "  /  에피소드 " + LaneLabController.episodes; font.pixelSize: 12 }
          Frame {
            Layout.fillWidth: true
            Layout.preferredHeight: Math.max(180, runScroll.availableWidth * 0.75)
            padding: 0
            Image {
              id: previewImage
              anchors.fill: parent
              // A hidden StackLayout page is still alive. Avoid decoding every
              // new camera frame while the student edits settings or track cells.
              source: tabs.currentIndex === 0 ? LaneLabController.previewUrl : ""
              sourceSize.width: 640
              sourceSize.height: 480
              fillMode: Image.PreserveAspectFit
              cache: false
              asynchronous: true
            }
            Label {
              anchors.centerIn: parent
              visible: previewImage.status !== Image.Ready
              text: previewImage.status === Image.Error
                ? "영상을 읽지 못했습니다.\n상단 상태 메시지를 확인해 주세요."
                : "카메라 격자 미리 보기\n640 × 480"
              horizontalAlignment: Text.AlignHCenter
            }
          }
          Label { text: LaneLabController.runDirectory; Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; font.pixelSize: 11 }
          Item { Layout.preferredHeight: 6 }
        }
      }

      ScrollView {
        id: envScroll
        clip: true
        contentWidth: availableWidth
        ColumnLayout {
          width: envScroll.availableWidth
          spacing: 8
          Label { text: "카메라 각도"; font.bold: true }
          GridLayout {
            columns: 2; Layout.fillWidth: true
            Label { text: "카메라 각도 (°)" }
            SpinBox { id: cameraPitch; from: -15; to: 45; value: 0; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
          }
          Label { text: "카메라 +각도는 아래 방향입니다. 영상은 항상 640 × 480입니다."; Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12 }
          Label { text: "격자 및 ROI 설정"; font.bold: true }
          GridLayout {
            columns: 2; Layout.fillWidth: true
            Label { text: "하단(px)" }
            SpinBox { id: roiMin; from: 0; to: 479; value: 0; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "상단(px)" }
            SpinBox { id: roiMax; from: 1; to: 480; value: 150; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "가로선 수" }
            SpinBox { id: roiRows; from: 1; to: 10; value: 3; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "세로선 수" }
            SpinBox { id: roiCols; from: 1; to: 20; value: 7; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
          }
          Label {
            text: "신경망에 입력되는 값은 " + (2 * roiRows.value + roiCols.value + 1) + "개입니다. 격자별 특징점 값과 직전 조향 명령이 입력됩니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          Label { text: "광원 추가"; font.bold: true }
          ComboBox { id: extraLightType; objectName: "extraLightType"; model: ["점광원", "스포트라이트"]; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
          RowLayout {
            Layout.fillWidth: true
            Repeater {
              id: lightRepeater
              model: 4
              CheckBox {
                objectName: "lightEnabled" + (index + 1)
                text: "광원 " + (index + 1)
                checked: panel.extraLights[index].enabled
                enabled: LaneLabController.backendAlive && !LaneLabController.busy
                Layout.fillWidth: true
                leftPadding: 0
                rightPadding: 0
              }
            }
          }
          Button { text: "광원 설정 코드 수정"; Layout.fillWidth: true; onClicked: LaneLabController.EditSettings("lighting.py") }
          Label { text: "기타 항목"; font.bold: true }
          GridLayout {
            columns: 2; Layout.fillWidth: true
            Label { text: "차량 질량 (g)" }
            SpinBox { id: massValue; from: 500; to: 4000; value: 1500; stepSize: 50; editable: true; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "마찰 계수(mu1)"; Layout.maximumWidth: 170; wrapMode: Text.WordWrap }
            FrictionField { id: mu1FrictionValue; objectName: "mu1FrictionValue"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "마찰 계수(mu2)"; Layout.maximumWidth: 170; wrapMode: Text.WordWrap }
            FrictionField { id: mu2FrictionValue; objectName: "mu2FrictionValue"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
          }
          Button { text: "설정 적용 · 미리 보기 갱신"; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.send("apply") }
          Item { Layout.preferredHeight: 6 }
        }
      }

      ScrollView {
        id: trackScroll
        clip: true
        contentWidth: availableWidth
        ColumnLayout {
          width: trackScroll.availableWidth
          spacing: 8
          Label { text: "주행 트랙 수정 및 제작"; font.bold: true }
          Label {
            text: "기본 트랙을 불러온 뒤 칸을 눌러 패널과 회전을 바꾸세요. 위쪽 행부터 표시하며 회전은 시계 방향입니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          RowLayout {
            Layout.fillWidth: true
            Repeater {
              model: 3
              Button { text: "트랙" + (index + 1); Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.preset(index + 1) }
            }
          }
          RowLayout {
            Layout.fillWidth: true
            Label { text: "행" }
            SpinBox { id: editorRows; from: 1; to: 8; value: 2; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Label { text: "열" }
            SpinBox { id: editorCols; from: 1; to: 8; value: 3; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Button { text: "크기 적용"; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.resizedTiles() }
          }
          GridLayout {
            Layout.fillWidth: true
            columns: panel.tileCols
            rowSpacing: 2
            columnSpacing: 2
            Repeater {
              model: panel.tileRows * panel.tileCols
              Rectangle {
                readonly property string token: panel.tokenAt(index)
                readonly property bool selected: Math.floor(index / panel.tileCols) === panel.selectedRow && index % panel.tileCols === panel.selectedCol
                Layout.fillWidth: true
                Layout.preferredWidth: (trackScroll.availableWidth - 2 * (panel.tileCols - 1)) / panel.tileCols
                Layout.preferredHeight: width
                color: "#404040"
                border.color: selected ? panel.brandColor : "#cccccc"
                border.width: selected ? 3 : 1
                Image {
                  anchors.fill: parent
                  anchors.margins: 3
                  source: LaneLabController.TileUrl(panel.tileName(parent.token))
                  // These are small editor thumbnails, not Gazebo textures.
                  // Decode at a bounded size even for an 8 × 8 panel layout.
                  sourceSize.width: 256
                  sourceSize.height: 256
                  asynchronous: true
                  rotation: panel.tileRotation(parent.token)
                  fillMode: Image.PreserveAspectFit
                }
                Rectangle {
                  anchors.fill: parent
                  anchors.margins: 3
                  visible: parent.selected
                  color: "transparent"
                  border.color: "white"
                  border.width: 1
                }
                Rectangle {
                  anchors.left: parent.left; anchors.bottom: parent.bottom
                  width: tokenText.width + 4; height: tokenText.height + 2
                  color: "#bb000000"
                  Label { id: tokenText; text: parent.parent.token === "Background" ? "빈칸" : parent.parent.token; color: "white"; font.pixelSize: 10 }
                }
                MouseArea {
                  anchors.fill: parent
                  enabled: LaneLabController.backendAlive && !LaneLabController.busy
                  onClicked: {
                    panel.selectedRow = Math.floor(index / panel.tileCols)
                    panel.selectedCol = index % panel.tileCols
                    var token = panel.tokenAt(index)
                    tileChoice.currentIndex = panel.tileNames.indexOf(panel.tileName(token))
                    rotationChoice.currentIndex = panel.tileRotation(token) / 90
                  }
                }
              }
            }
          }
          Label { text: "선택: " + (panel.selectedRow + 1) + "행 " + (panel.selectedCol + 1) + "열"; font.bold: true }
          RowLayout {
            Layout.fillWidth: true
            ComboBox { id: tileChoice; model: panel.tileLabels; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            ComboBox { id: rotationChoice; model: ["0°", "90°", "180°", "270°"]; Layout.fillWidth: true; enabled: LaneLabController.backendAlive && !LaneLabController.busy }
            Button { text: "변경"; enabled: LaneLabController.backendAlive && !LaneLabController.busy; onClicked: panel.putTile() }
          }
          Label {
            text: "흰색 차선이나 터널 벽이 주행 영역을 둘러싸도록 배치하세요. 광장·분기 패널도 사용할 수 있으며, 외부로 열린 틈은 허용되지 않습니다."
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
          }
          Button {
            id: saveTrackButton
            objectName: "saveTrackButton"
            text: "내 트랙 저장·검사"
            Layout.fillWidth: true
            highlighted: true
            Material.foreground: "white"
            enabled: LaneLabController.backendAlive && !LaneLabController.busy
            contentItem: Text {
              text: saveTrackButton.text; font: saveTrackButton.font
              color: saveTrackButton.enabled ? "white" : "#888888"
              horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
              elide: Text.ElideRight
            }
            onClicked: { trackChoice.currentIndex = 3; panel.send("save_track") }
          }
          Item { Layout.preferredHeight: 6 }
        }
      }
    }
    Label { text: panel.validationMessage || LaneLabController.notice; color: panel.validationMessage ? panel.warningColor : palette.windowText; Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 11 }
  }
}
