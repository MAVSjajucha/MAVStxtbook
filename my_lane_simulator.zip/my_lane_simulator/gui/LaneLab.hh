// SPDX-License-Identifier: Apache-2.0
#ifndef YAHBOOM_LANE_LAB_GUI_HH
#define YAHBOOM_LANE_LAB_GUI_HH

#include <ignition/gui/qt.h>
#include <ignition/gui/Plugin.hh>
#include <QTimer>
#include <QVariantMap>
#include <QUrl>
#include <QPointer>

class QFileDialog;

/// Gazebo-native controls. Python owns experiments; the panel exchanges atomic
/// JSON files with it so the GUI never blocks on training or ROS calls.
class LaneLab final : public ignition::gui::Plugin
{
  Q_OBJECT
  Q_PROPERTY(QString statusText READ StatusText NOTIFY Updated)
  Q_PROPERTY(QString message READ Message NOTIFY Updated)
  Q_PROPERTY(QString settingsWarning READ SettingsWarning NOTIFY Updated)
  Q_PROPERTY(QString notice READ Notice NOTIFY Updated)
  Q_PROPERTY(QString runDirectory READ RunDirectory NOTIFY Updated)
  Q_PROPERTY(int steps READ Steps NOTIFY Updated)
  Q_PROPERTY(int targetSteps READ TargetSteps NOTIFY Updated)
  Q_PROPERTY(int episodes READ Episodes NOTIFY Updated)
  Q_PROPERTY(double rtf READ Rtf NOTIFY Updated)
  Q_PROPERTY(bool busy READ Busy NOTIFY Updated)
  Q_PROPERTY(bool backendAlive READ BackendAlive NOTIFY Updated)
  Q_PROPERTY(bool recoveryAvailable READ RecoveryAvailable NOTIFY Updated)
  Q_PROPERTY(bool resumeAvailable READ ResumeAvailable NOTIFY Updated)
  Q_PROPERTY(bool resumeCheckpointOnly READ ResumeCheckpointOnly NOTIFY Updated)
  Q_PROPERTY(QString resumeCheckpoint READ ResumeCheckpoint NOTIFY Updated)
  Q_PROPERTY(QString resumeReason READ ResumeReason NOTIFY Updated)
  Q_PROPERTY(bool bestAvailable READ BestAvailable NOTIFY Updated)
  Q_PROPERTY(bool lastAvailable READ LastAvailable NOTIFY Updated)
  Q_PROPERTY(int resumeSteps READ ResumeSteps NOTIFY Updated)
  Q_PROPERTY(QUrl previewUrl READ PreviewUrl NOTIFY Updated)
  Q_PROPERTY(QVariantMap savedSettings READ SavedSettings CONSTANT)

 public:
  LaneLab();
  ~LaneLab() override;
  void LoadConfig(const tinyxml2::XMLElement *) override;
  Q_INVOKABLE bool Send(const QString &action, const QVariantMap &settings);
  Q_INVOKABLE bool ChooseEvaluationModel(const QVariantMap &settings);
  Q_INVOKABLE bool ChooseExportModel(const QVariantMap &settings);
  Q_INVOKABLE bool ChooseResumeModel(const QVariantMap &settings);
  Q_INVOKABLE void EditLesson();
  Q_INVOKABLE void OpenRuns();
  Q_INVOKABLE void EditSettings(const QString &name);
  Q_INVOKABLE QUrl TileUrl(const QString &tile) const;

  QString StatusText() const;
  QString Message() const { return message_; }
  QString SettingsWarning() const { return settingsWarning_; }
  QString Notice() const { return notice_; }
  QString RunDirectory() const { return runDir_; }
  int Steps() const { return steps_; }
  int TargetSteps() const { return targetSteps_; }
  int Episodes() const { return episodes_; }
  double Rtf() const { return rtf_; }
  bool Busy() const;
  bool BackendAlive() const { return backendAlive_; }
  bool RecoveryAvailable() const { return recoveryAvailable_; }
  bool ResumeAvailable() const { return resumeAvailable_; }
  bool ResumeCheckpointOnly() const { return resumeCheckpointOnly_; }
  QString ResumeCheckpoint() const { return resumeCheckpoint_; }
  QString ResumeReason() const { return resumeReason_; }
  bool BestAvailable() const { return bestAvailable_; }
  bool LastAvailable() const { return lastAvailable_; }
  int ResumeSteps() const { return resumeSteps_; }
  QUrl PreviewUrl() const { return previewUrl_; }
  QVariantMap SavedSettings() const { return savedSettings_; }

 signals:
  void Updated();

 private:
  bool ChooseModel(const QString &action, const QVariantMap &settings);
  bool QueueCommand(const QString &action, const QVariantMap &settings,
                    const QString &modelPath = QString());
  void Refresh();
  QPointer<QFileDialog> modelDialog_;
  QString root_, runtime_, state_{"waiting"}, message_, notice_, runDir_;
  QString settingsWarning_;
  QString resumeCheckpoint_, resumeReason_;
  QString pendingCommand_;
  int steps_{0}, targetSteps_{0}, episodes_{0}, resumeSteps_{0};
  bool backendAlive_{true}, recoveryAvailable_{false}, resumeAvailable_{false};
  bool resumeCheckpointOnly_{false};
  bool bestAvailable_{false}, lastAvailable_{false}, menuConfigured_{false};
  double rtf_{0};
  QUrl previewUrl_;
  QVariantMap savedSettings_;
  QTimer timer_;
};
#endif
