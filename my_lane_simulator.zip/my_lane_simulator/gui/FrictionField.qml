// SPDX-License-Identifier: Apache-2.0
import QtQuick 2.12
import QtQuick.Controls 2.12

// Keep the coefficient as a decimal; no integer scaling or artificial maximum.
TextField {
  id: control
  text: "0.50"
  selectByMouse: true
  inputMethodHints: Qt.ImhFormattedNumbersOnly
  validator: DoubleValidator {
    bottom: 0
    // The default top is infinity. commit() also rejects non-finite values.
    notation: DoubleValidator.ScientificNotation
    locale: "C"
  }

  function setCoefficient(value) {
    // Show at least two decimals without rounding away an entered precision.
    var shown = String(value)
    if (shown.indexOf("e") < 0 && shown.indexOf("E") < 0) {
      var point = shown.indexOf(".")
      if (point < 0) shown += ".00"
      else if (shown.length - point === 2) shown += "0"
    }
    text = shown
  }

  function commit() {
    var entered = text.trim()
    var coefficient = Number(entered)
    if (!entered || !acceptableInput || !isFinite(coefficient) || coefficient < 0) {
      forceActiveFocus()
      return false
    }
    setCoefficient(coefficient)
    return true
  }
}
