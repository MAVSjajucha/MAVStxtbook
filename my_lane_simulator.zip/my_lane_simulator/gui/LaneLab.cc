// SPDX-License-Identifier: Apache-2.0
#include "LaneLab.hh"
#include <ignition/gui/Application.hh>
#include <ignition/gui/MainWindow.hh>
#include <ignition/plugin/Register.hh>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQmlExpression>
#include <QDateTime>
#include <QDebug>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMap>
#include <QSaveFile>
#include <QSet>
#include <QSettings>
#include <QUuid>
#include <QUrlQuery>
#include <cmath>
#include <cerrno>
#include <csignal>
#ifdef Q_OS_LINUX
#include <dlfcn.h>
#endif

namespace
{
bool ConfigureLaneLabMenu()
{
  // Fortress derives plugin menu labels from library filenames, truncating at
  // the first dot. A library named "1.LaneLab(PPO)" would therefore show "1".
  // Keep the normal load identifier and customize the existing native menu's
  // display delegate and sorting. Other entries keep their original behavior.
  auto *app = ignition::gui::App();
  auto *mainWindow = app ? app->findChild<ignition::gui::MainWindow *>() : nullptr;
  auto *window = mainWindow ? mainWindow->QuickWindow() : nullptr;
  auto *context = window ? QQmlEngine::contextForObject(window) : nullptr;
  QObject *menu = context ? context->contextProperty("pluginMenu").value<QObject *>() : nullptr;
  if (!menu && window)
  {
    // Some GUI 6 patch releases return the outer creation context for a
    // component root. The native component class is stable across those builds.
    for (auto *child : window->findChildren<QObject *>())
      if (QString::fromLatin1(child->metaObject()->className()).startsWith("PluginMenu_QMLTYPE"))
      {
        menu = child;
        break;
      }
  }
  if (!menu) return false;
  QObject *model = nullptr;
  for (auto *child : menu->findChildren<QObject *>())
  {
    if (child->metaObject()->indexOfProperty("lessThan") >= 0 &&
        child->metaObject()->indexOfProperty("filterAcceptsItem") >= 0)
    {
      model = child;
      break;
    }
  }
  if (!model) return false;
  if (model->property("laneLabMenuConfigured").toBool()) return true;
  auto *modelContext = QQmlEngine::contextForObject(model);
  if (!modelContext) return false;
  QQmlExpression expression(modelContext, model, QString::fromUtf8(R"QML(
    (function() {
      filteredModel.lessThan = function(left, right) {
        var a = left.modelData === "Lane Lab" ? "1. Lane Lab(DRL)" : left.modelData;
        var b = right.modelData === "Lane Lab" ? "1. Lane Lab(DRL)" : right.modelData;
        return a.toLowerCase() < b.toLowerCase();
      };
      filteredModel.filterAcceptsItem = function(item) {
        var label = item.modelData === "Lane Lab" ? "1. Lane Lab(DRL)" : item.modelData;
        return label.toLowerCase().indexOf(searchField.text.toLowerCase()) >= 0;
      };
      filteredModel.delegate = Qt.createQmlObject(
        'import QtQuick 2.12; import QtQuick.Controls 2.12; '
        + 'Component { ItemDelegate {'
        + ' property variant pluginModel: model; width: parent ? parent.width : implicitWidth;'
        + ' text: modelData === "Lane Lab" ? "1. Lane Lab(DRL)" : modelData;'
        + ' highlighted: ListView.isCurrentItem;'
        + ' onClicked: { MainWindow.OnAddPlugin(modelData); drawer.close(); pluginMenu.close(); }'
        + ' } }', filteredModel, 'LaneLabMenuDelegate');
      filteredModel.update();
      return true;
    })()
  )QML"));
  const auto result = expression.evaluate();
  if (expression.hasError())
  {
    qWarning() << "LaneLab: could not configure plugin menu:" << expression.error();
    return false;
  }
  const bool configured = result.toBool();
  if (configured) model->setProperty("laneLabMenuConfigured", true);
  return configured;
}

void KeepGridConfigMetadataMapped()
{
#ifdef Q_OS_LINUX
  // Fortress destroys plugin instances before clearing QQmlEngine caches.
  // On Ubuntu 22.04, the crash address from that teardown mapped to static
  // metadata in libGridConfig.so. Keep only that already-loaded library
  // resident; its objects and render resources are still destroyed normally.
  auto *app = ignition::gui::App();
  if (!app) return;
  for (auto *plugin : app->findChildren<ignition::gui::Plugin *>())
  {
    Dl_info info{};
    if (!dladdr(plugin->metaObject(), &info) || !info.dli_fname)
      continue;
    if (QFileInfo(QString::fromLocal8Bit(info.dli_fname)).fileName() !=
        QStringLiteral("libGridConfig.so"))
      continue;
    // NOLOAD avoids loading another copy. NODELETE remains set after dlclose.
    void *handle = dlopen(info.dli_fname,
        RTLD_LAZY | RTLD_NOLOAD | RTLD_NODELETE);
    if (handle)
      dlclose(handle);
    else
      qWarning() << "LaneLab: could not retain GridConfig metadata:" << dlerror();
    return;
  }
#endif
}
}

LaneLab::LaneLab() : ignition::gui::Plugin()
{
  // A stable explicit context name works across GUI 6 patch releases, whose
  // automatically generated plugin context names differ from later releases.
  ignition::gui::App()->Engine()->rootContext()->setContextProperty("LaneLabController", this);
  root_ = qEnvironmentVariable("LANE_LAB_ROOT");
  runtime_ = qEnvironmentVariable("LANE_LAB_RUNTIME");
  if (runtime_.isEmpty() && !root_.isEmpty())
    runtime_ = QDir(root_).filePath("runtime");
  if (!runtime_.isEmpty())
  {
    QFile file(QDir(runtime_).filePath("settings.json"));
    if (file.open(QIODevice::ReadOnly))
      savedSettings_ = QJsonDocument::fromJson(file.readAll()).object().toVariantMap();
  }
  connect(&timer_, &QTimer::timeout, this, &LaneLab::Refresh);
  timer_.start(500);
}

LaneLab::~LaneLab()
{
  // The dialog is a QWidget; the Gazebo plugin itself is a QObject.
  if (modelDialog_) delete modelDialog_;
}

void LaneLab::LoadConfig(const tinyxml2::XMLElement *)
{
  // LaneLab is loaded after GridConfig in the supplied GUI configuration.
  KeepGridConfigMetadataMapped();
  if (this->title.empty()) this->title = "차선 주행 실습";
  Refresh();
}

QString LaneLab::StatusText() const
{
  static const QMap<QString, QString> names{
    {"waiting", "연결 대기"}, {"starting", "준비 중"}, {"idle", "준비"}, {"ready", "준비"},
    {"preview", "미리 보기"}, {"training", "학습 중"},
    {"evaluating", "평가 중"}, {"exporting", "내보내는 중"},
    {"stopping", "중지·저장 중"}, {"stopped", "중지됨"},
    {"complete", "완료"}, {"done", "완료"}, {"error", "확인 필요"}};
  return names.value(state_, state_);
}

bool LaneLab::Busy() const
{
  return backendAlive_ && (!pendingCommand_.isEmpty() || state_ == "training" || state_ == "evaluating" ||
         state_ == "exporting" || state_ == "stopping" || state_ == "starting");
}

void LaneLab::Refresh()
{
  if (!menuConfigured_) menuConfigured_ = ConfigureLaneLabMenu();
  if (!pendingCommand_.isEmpty() && !QFileInfo::exists(pendingCommand_))
    pendingCommand_.clear();
  if (runtime_.isEmpty() || root_.isEmpty())
  {
    message_ = "start.sh로 실행해 주세요. LANE_LAB_ROOT / RUNTIME이 없습니다.";
    emit Updated();
    return;
  }
  QFile file(QDir(runtime_).filePath("status.json"));
  if (file.open(QIODevice::ReadOnly))
  {
    QJsonParseError error;
    const auto document = QJsonDocument::fromJson(file.readAll(), &error);
    if (error.error == QJsonParseError::NoError && document.isObject())
    {
      const auto value = document.object();
      state_ = value.value("status").toString("waiting");
      message_ = value.value("message").toString();
      settingsWarning_ = value.value("settings_warning").toString();
      runDir_ = value.value("run_dir").toString();
      steps_ = value.value("steps").toInt();
      targetSteps_ = value.value("target_steps").toInt();
      episodes_ = value.value("episodes").toInt();
      rtf_ = value.value("rtf").toDouble();
      resumeAvailable_ = value.value("resume_available").toBool();
      resumeCheckpointOnly_ = value.value("resume_checkpoint_only").toBool();
      resumeCheckpoint_ = value.value("resume_checkpoint").toString();
      resumeReason_ = value.value("resume_reason").toString();
      bestAvailable_ = value.value("best_available").toBool();
      lastAvailable_ = value.value("last_available").toBool();
      resumeSteps_ = value.value("resume_steps").toInt();
      if (!std::isfinite(rtf_)) rtf_ = 0;
      const QFileInfo preview(QDir(runtime_).filePath("preview.jpg"));
      if (preview.exists())
      {
        previewUrl_ = QUrl::fromLocalFile(preview.absoluteFilePath());
        QUrlQuery query;
        query.addQueryItem("v", QString::number(preview.lastModified().toMSecsSinceEpoch())
          + "-" + QString::number(value.value("preview_seq").toInt()));
        previewUrl_.setQuery(query);
      }
    }
  }
  // The supervising process stays independent of PyTorch / OpenCV. A dead
  // learner must never leave a stale "training" label or queued commands.
  QFile healthFile(QDir(runtime_).filePath("supervisor.json"));
  if (healthFile.open(QIODevice::ReadOnly))
  {
    const auto health = QJsonDocument::fromJson(healthFile.readAll()).object();
    const QString token = qEnvironmentVariable("LANE_LAB_SUPERVISOR_TOKEN");
    if (!token.isEmpty() && health.value("token").toString() == token)
    {
      const int backendPid = health.value("backend_pid").toInt();
      const int supervisorPid = health.value("supervisor_pid").toInt();
      const auto alive = [](int pid) {
        return pid > 1 && (::kill(pid, 0) == 0 || errno == EPERM);
      };
      backendAlive_ = health.value("backend_running").toBool() && alive(backendPid);
      recoveryAvailable_ = !backendAlive_ && alive(supervisorPid);
      if (!backendAlive_)
      {
        state_ = "error";
        pendingCommand_.clear();
        rtf_ = 0;
        if (message_.isEmpty() || !message_.contains("학습 프로그램이 종료"))
          message_ = recoveryAvailable_
              ? "학습 프로그램이 종료됐습니다. ‘프로그램 복구’를 누른 뒤 ‘자동 저장 체크포인트 복구’ 버튼을 확인하세요. 오류 기록: runtime/app.log"
              : "학습 프로그램 연결이 끊겼습니다. Gazebo를 닫고 bash start.sh로 다시 실행하세요. 오류 기록: runtime/app.log";
      }
    }
  }
  emit Updated();
}

bool LaneLab::Send(const QString &action, const QVariantMap &settings)
{
  return QueueCommand(action, settings);
}

bool LaneLab::ChooseEvaluationModel(const QVariantMap &settings)
{
  return ChooseModel("evaluate_file", settings);
}

bool LaneLab::ChooseExportModel(const QVariantMap &settings)
{
  return ChooseModel("export_file", settings);
}

bool LaneLab::ChooseResumeModel(const QVariantMap &settings)
{
  return ChooseModel("resume_file", settings);
}

bool LaneLab::ChooseModel(const QString &action, const QVariantMap &settings)
{
  Refresh();
  if (!backendAlive_ || Busy() || root_.isEmpty())
  {
    notice_ = "현재 동작이 끝나거나 중지된 뒤 사용할 모델을 선택하세요.";
    emit Updated();
    return false;
  }
  if (modelDialog_)
  {
    modelDialog_->raise();
    modelDialog_->activateWindow();
    return true;
  }
  QString title, acceptLabel, selectionNotice;
  if (action == "evaluate_file")
  {
    title = "평가할 모델 파일 선택";
    acceptLabel = "평가 시작";
    selectionNotice = "실험 폴더의 models에서 평가할 best 또는 last 폴더의 actor.npz를 선택하세요.";
  }
  else if (action == "export_file")
  {
    title = "내보낼 모델 파일 선택";
    acceptLabel = "내보내기 시작";
    selectionNotice = "실험 폴더의 models에서 내보낼 best 또는 last 폴더의 actor.npz를 선택하세요.";
  }
  else if (action == "resume_file")
  {
    title = "이어서 학습할 모델 파일 선택";
    acceptLabel = "이어 학습 시작";
    selectionNotice = "실험 폴더의 models에서 이어서 학습할 best 또는 last 폴더의 actor.npz를 선택하세요.";
  }
  else return false;

  QSettings preferences("LaneLab", "LaneLab");
  QString directory = preferences.value("modelPicker/lastDirectory").toString();
  if (directory.isEmpty() || !QDir(directory).exists())
    directory = QDir(root_).filePath("runs");
  // Qt Widgets already comes with Fortress and qtbase5-dev. This avoids
  // requiring another QML dialog module on a freshly installed Ubuntu PC.
  auto *dialog = new QFileDialog(nullptr, title, directory, "학습 모델 (actor.npz)");
  modelDialog_ = dialog;
  dialog->setObjectName("laneModelFileDialog");
  dialog->setAttribute(Qt::WA_DeleteOnClose);
  dialog->setOption(QFileDialog::DontUseNativeDialog, true);
  dialog->setFileMode(QFileDialog::ExistingFile);
  dialog->setAcceptMode(QFileDialog::AcceptOpen);
  dialog->setViewMode(QFileDialog::Detail);
  dialog->setLabelText(QFileDialog::Accept, acceptLabel);
  dialog->setLabelText(QFileDialog::Reject, "취소");
  dialog->setWindowModality(Qt::ApplicationModal);
  dialog->resize(820, 520);
  auto *app = ignition::gui::App();
  auto *main = app ? app->findChild<ignition::gui::MainWindow *>() : nullptr;
  if (main && main->QuickWindow())
  {
    dialog->winId();
    dialog->windowHandle()->setTransientParent(main->QuickWindow());
  }
  connect(dialog, &QFileDialog::fileSelected, this,
      [this, action, settings](const QString &path)
      {
        const QFileInfo model(path);
        QSettings preferences("LaneLab", "LaneLab");
        preferences.setValue("modelPicker/lastDirectory", model.absolutePath());
        preferences.sync();
        // Preserve the exact selected file. The backend locates and validates
        // its experiment settings; it must not resolve the newest model here.
        QueueCommand(action, settings, model.absoluteFilePath());
      });
  notice_ = selectionNotice;
  emit Updated();
  dialog->open();
  return true;
}

bool LaneLab::QueueCommand(const QString &action, const QVariantMap &settings,
                          const QString &modelPath)
{
  Refresh();
  if (action == "recover")
  {
    if (!recoveryAvailable_) return false;
    const QJsonObject recovery{{"action", "recover"},
      {"token", qEnvironmentVariable("LANE_LAB_SUPERVISOR_TOKEN")}};
    QSaveFile file(QDir(runtime_).filePath("recover.json"));
    const QByteArray bytes = QJsonDocument(recovery).toJson(QJsonDocument::Compact);
    if (!file.open(QIODevice::WriteOnly) || file.write(bytes) != bytes.size() || !file.commit())
    {
      notice_ = "복구 요청을 저장하지 못했습니다: " + file.errorString();
      emit Updated();
      return false;
    }
    notice_ = "프로그램을 복구합니다. Gazebo 화면이 다시 열립니다.";
    emit Updated();
    return true;
  }
  if (!backendAlive_)
  {
    notice_ = "학습 프로그램이 종료됐습니다. 먼저 프로그램 복구를 누르세요.";
    emit Updated();
    return false;
  }
  static const QSet<QString> allowed{
    "preview", "train", "resume", "resume_file", "stop", "evaluate", "evaluate_best", "evaluate_last", "evaluate_file", "export", "export_file", "check", "save_track", "apply"};
  if (!allowed.contains(action) || root_.isEmpty() || runtime_.isEmpty())
  {
    notice_ = "명령을 보낼 수 없습니다. start.sh 실행 상태를 확인해 주세요.";
    emit Updated();
    return false;
  }
  if (action != "stop" && Busy())
  {
    notice_ = "현재 요청을 처리하고 있습니다. 중지하거나 완료된 뒤 실행해 주세요.";
    emit Updated();
    return false;
  }
  const QString commands = QDir(runtime_).filePath("commands");
  if (!QDir().mkpath(commands))
  {
    notice_ = "runtime/commands 폴더에 쓸 수 없습니다.";
    emit Updated();
    return false;
  }
  const QString id = QString::number(QDateTime::currentMSecsSinceEpoch()) + "_" +
      QUuid::createUuid().toString(QUuid::WithoutBraces);
  QJsonObject object{{"action", action},
                          {"settings", QJsonObject::fromVariantMap(settings)},
                          {"id", id}};
  if (action == "evaluate_file" || action == "export_file" || action == "resume_file")
    object.insert("model_path", modelPath);
  const QString commandPath = QDir(commands).filePath(id + ".json");
  QSaveFile file(commandPath);
  const QByteArray bytes = QJsonDocument(object).toJson(QJsonDocument::Compact);
  if (!file.open(QIODevice::WriteOnly) || file.write(bytes) != bytes.size() || !file.commit())
  {
    notice_ = "명령 파일 저장 실패: " + file.errorString();
    emit Updated();
    return false;
  }
  if (action == "evaluate_file") notice_ = "선택한 모델을 확인하고 평가를 시작합니다.";
  else if (action == "export_file") notice_ = "선택한 모델을 확인하고 내보내기를 시작합니다.";
  else if (action == "resume_file") notice_ = "선택한 모델을 확인하고 이어 학습을 시작합니다.";
  else if (action == "resume") notice_ = "자동 저장 체크포인트의 호환성을 확인하고 복구합니다.";
  else notice_ = "요청 전달: " + action;
  pendingCommand_ = commandPath;
  emit Updated();
  return true;
}

void LaneLab::EditLesson()
{
  const auto path = QDir(root_).filePath("design/agent.py");
  if (!QDesktopServices::openUrl(QUrl::fromLocalFile(path)))
    notice_ = "편집기를 열 수 없습니다. 파일 앱에서 design/agent.py를 열어 주세요.";
  else
    notice_ = "agent.py를 저장한 뒤 ‘학습 코드 검사’를 누르세요. 학습 진행부터 반영됩니다.";
  emit Updated();
}

void LaneLab::EditSettings(const QString &name)
{
  if (name != "lighting.py") return;
  const auto path = QDir(root_).filePath("design/" + name);
  if (!QDesktopServices::openUrl(QUrl::fromLocalFile(path)))
    notice_ = "편집기를 열 수 없습니다: " + path;
  else notice_ = name + " 저장 후 변경 설정 적용 또는 이어 학습을 누르세요.";
  emit Updated();
}

void LaneLab::OpenRuns()
{
  QDesktopServices::openUrl(QUrl::fromLocalFile(root_));
}

QUrl LaneLab::TileUrl(const QString &tile) const
{
  static const QSet<QString> allowed{
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "TS", "TC", "Background"};
  if (!allowed.contains(tile)) return QUrl();
  return QUrl::fromLocalFile(QDir(root_).filePath("track_img/Track-" + tile + ".png"));
}

IGNITION_ADD_PLUGIN(LaneLab, ignition::gui::Plugin)
