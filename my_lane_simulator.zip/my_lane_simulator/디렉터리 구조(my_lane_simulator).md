**이 파일은 my_lane_simulator 패키지의 디렉터리 구조입니다.**  
**패키지 사용 설명은 `사용 가이드(my_lane_simulator).md`에서 확인할 수 있습니다.**  
**실습 관련 자료는 https://github.com/MAVSjajucha/MAVStxtbook 에서 다운로드할 수 있습니다.**

---

**직접 수정하거나 학습 결과를 확인하는 주요 파일·폴더는 `**`로 표시했습니다.**  

my_lane_simulator/                        # Ubuntu PC 작업 폴더: /home/사용자 이름/my_lane_simulator
├── design/                               # 학생이 수정하는 실습 코드
│   ├── **agent.py**                      # 할인율·신경망 입력·보상·조향 명령 계산
│   ├── **lighting.py**                   # 트랙 정반사·광원 위치·색·세기·감쇠·방향 설정
│   └── **보상 설계 방안.md**               # 보상 계산에 사용할 수 있는 state 항목 설명
├── **runs**/                             # 시뮬레이션 학습 결과와 저장 당시 설정
│   └── example_model/                    # 함께 제공하는 예시 학습 결과
│       ├── models/
│       │   ├── best/
│       │   │   ├── actor.npz             # 평가·이어 학습·내보내기에서 선택하는 정책 파일
│       │   │   └── model.zip             # 이어 학습에 필요한 PPO 저장 파일
│       │   └── last/                     # 마지막 저장 모델: actor.npz와 model.zip
│       ├── lesson.py                     # 학습 당시의 agent.py 사본
│       ├── settings.json                 # 학습 당시 격자·카메라·차량·환경 설정
│       ├── training.json                 # 입력 개수·학습 설정 정보
│       ├── model_selection.json          # best·last 모델 위치와 선정 결과
│       ├── best_last_config.json         # 자동 평가 주기·횟수·선정 기준
│       ├── vehicle_base.json             # 학습 당시 차량 제원
│       └── shared_code/                  # 학습 당시 특징점 처리·정책 실행 코드
├── **exports**/                          # 실제 차량으로 옮길 실행 폴더 저장 위치
│   └── **example_model**/                # 함께 제공하는 예시 실차 실행 폴더
│       ├── best/                         # 이 폴더 전체를 차량으로 복사하여 사용
│       │   ├── actor.npz                 # 차량에서 실행할 정책
│       │   ├── lesson.py                 # 저장 당시 신경망 입력·조향 명령 계산 코드
│       │   ├── settings.json             # 저장 당시 격자·카메라·제어 설정
│       │   ├── training.json             # 저장된 모델의 학습 정보
│       │   ├── model_selection.json      # 내보낸 모델의 식별 정보
│       │   ├── manifest.json             # 내보낸 파일 목록과 모델 정보
│       │   ├── run_real.sh               # 실차 실행: 필요한 ROS 패키지 빌드 후 노드 실행
│       │   ├── build_real.sh             # 차량용 ROS 인터페이스·노드 빌드
│       │   ├── drive_real.py             # 실차 정책 실행 진입점
│       │   ├── vehicle_launcher.py       # 차량 환경 확인·노드 실행 관리
│       │   ├── real_calibration.json     # 실차 제어 보정값
│       │   ├── real_calibration.example.json
│       │   ├── calibrate.py              # 실차 보정 설정 도구
│       │   ├── diagnose.py               # 카메라·제어·모델 진단
│       │   ├── stop_real.sh              # 실차 정지 명령 실행
│       │   ├── stop_real.py              # 정지 명령 발행 코드
│       │   ├── lane_lab/                 # 특징점 추출·정책 추론·ROS 노드 코드
│       │   ├── ros_ws/src/               # 차량에서 빌드할 ROS 2 패키지 소스
│       │   ├── licenses/                 # 포함된 외부 코드의 라이선스
│       │   └── THIRD_PARTY.md            # 외부 코드 출처
│       └── last/                         # last 실차 실행 폴더: best와 같은 구성
├── evaluation/                           # 모델 평가 결과 CSV와 평가 당시 설정 저장 위치
│   └── **평가 지표 CSV 가이드.md**         # 평가 지표 의미·단위·계산 방법
├── config/                               # 시뮬레이터 기본 설정
│   ├── defaults.json                     # GUI 초기값·격자·차량·주행 설정
│   ├── best_last.json                    # 자동 평가 주기·횟수·best 비교 기준
│   ├── vehicle.json                      # 축간 거리·바퀴 크기·조향 한계·구동 응답 제원
│   ├── gui.config.in                     # Gazebo GUI 구성 템플릿
│   └── tracks/
│       ├── track1.json                   # 기본 트랙1 패널 배치
│       ├── track2.json                   # 기본 트랙2 패널 배치
│       ├── track3.json                   # 기본 트랙3 패널 배치
│       └── custom.json                   # 저장한 내 트랙 패널 배치
├── assets/                               # 트랙·차량 시각 자료
│   ├── vehicle/
│   │   ├── urdf/yahboomcar_A1.src.urdf    # 제조사 A1 차량 원본 URDF
│   │   ├── meshes/A1Ackermann/            # 차체·바퀴·조향부·센서의 STL 파일
│   │   ├── VEHICLE_SOURCE.md             # 차량 자료 출처와 가공 내역
│   │   └── SHA256SUMS.json               # 차량 자료의 체크섬
│   ├── PROVENANCE.md                     # 트랙 이미지·코드 출처
│   └── SHA256SUMS                        # 트랙 자료의 체크섬
├── lane_lab/                             # 시뮬레이션 내부 Python 코드
│   ├── __main__.py                       # 실행 명령 진입점
│   ├── runner.py                         # 미리 보기·학습·평가·내보내기 작업 관리
│   ├── supervisor.py                     # 실행 프로세스와 작업 상태 관리
│   ├── environment.py                    # 1스텝 주행·환경 초기화·보상 호출
│   ├── reward_state.py                   # 보상 함수에 제공하는 좌표·속도·거리 상태
│   ├── vision.py                         # ROI·격자 기반 V·L·R 특징점 추출
│   ├── policy_io.py                      # NumPy 정책 저장·불러오기·추론
│   ├── ros_nodes.py                      # grid_node의 카메라 수신·특징점 발행
│   ├── ros_transport.py                  # 시뮬레이션 DRL_node의 특징점 수신·주행 명령 발행
│   ├── transport.py                      # Gazebo와의 제어·상태 통신
│   ├── vehicle.py                        # 원본 URDF를 바탕으로 차량 SDF 생성
│   ├── worlds.py                         # 트랙·차량·광원이 포함된 Gazebo 월드 생성
│   ├── geometry.py                       # 경로 진행량·타이어 여유 거리 계산
│   ├── enclosure.py                      # 흰색 차선·터널 벽으로 닫힌 주행 영역 검사
│   ├── enclosed_route.py                 # 닫힌 영역에서 중심 주행 경로 생성
│   ├── tunnels.py                        # 터널 패널과 벽 구성
│   ├── lighting.py                       # design/lighting.py 검증과 광원 설정 변환
│   ├── configuration.py                  # 설정값 구성·검증
│   ├── settings_store.py                 # GUI 설정 저장·복구
│   ├── checkpoints.py                    # 학습 체크포인트 저장·복구
│   ├── best_last.py                      # 중간 후보의 RAM 보관·자동 평가·best/last 저장
│   ├── model_selection.py                # 사용자가 선택한 저장 모델과 학습 설정 확인
│   ├── best_last_export.py               # 선택한 모델의 독립 실차 실행 폴더 생성
│   ├── evaluation_csv.py                 # 평가 주행의 스텝별 CSV 기록
│   ├── evaluation_geometry.py            # 최단 경로점·횡방향 오차·방향 오차 계산
│   ├── evaluation_reward.py              # 보상 계산에 사용한 항목 기록
│   ├── doctor.py                         # 실행 환경·통신·물리 상태 검사
│   └── __init__.py
├── gui/                                  # Gazebo 실습 패널
│   ├── LaneLab.qml                       # 화면 배치·버튼·입력 항목·표시 문구
│   ├── FrictionField.qml                 # 마찰 계수 입력 항목
│   ├── LaneLab.cc                        # GUI와 내부 실행 코드 연결
│   ├── LaneLab.hh                        # GUI 플러그인 선언
│   ├── lane_lab.qrc                      # GUI 리소스 등록
│   └── CMakeLists.txt                    # GUI 플러그인 빌드 설정
├── native/                               # Gazebo 연동 C++ 코드
│   ├── bridge.cc                         # 시뮬레이션 제어·상태 전달
│   ├── a1_controller.cc                  # 전륜 애커먼 조향·독립 후륜 구동 제어
│   ├── a1_dynamics.hh                    # 조향·후륜 구동 계산
│   ├── a1_dynamics_test.cc               # 차량 제어 계산 검사
│   ├── dart_friction_physics_test.cc     # DART 접촉 마찰 검사
│   └── CMakeLists.txt                    # C++ 연동 코드 빌드 설정
├── ros_ws/                               # PC용 ROS 2 작업 공간
│   └── src/
│       ├── my_lane_simulator_interfaces/ # 사용자 정의 메시지 패키지
│       │   ├── msg/LaneFeatures.msg      # 영상 시각과 v·l·r 특징점 배열
│       │   ├── package.xml
│       │   └── CMakeLists.txt
│       └── my_lane_simulator_nodes/      # ROS 2 실행 항목 등록 패키지
│           ├── my_lane_simulator_nodes/
│           │   ├── entry.py              # grid_node·DRL_node 실행 진입점
│           │   └── __init__.py
│           ├── resource/my_lane_simulator_nodes
│           ├── package.xml
│           ├── setup.py
│           └── setup.cfg
├── deploy/                               # 실차 내보내기 시 복사하는 실행 코드 원본
│   ├── **run_real.sh**                   # 실차 실행 스크립트
│   ├── build_real.sh                     # 차량용 ROS 패키지 빌드 스크립트
│   ├── drive_real.py                     # 실차 DRL_node의 정책 추론·주행 명령 발행
│   ├── vehicle_launcher.py               # 차량 실행 환경·노드 관리
│   ├── real_calibration.json             # 기본 실차 보정값
│   ├── real_calibration.example.json     # 보정값 작성 예시
│   ├── calibrate.py                      # 보정 설정 도구
│   ├── diagnose.py                       # 차량 실행 진단
│   ├── stop_real.sh                      # 정지 스크립트
│   └── stop_real.py                      # 정지 명령 발행 코드
├── tests/                                # 기능 검사 코드와 검사 자료
├── **track_img/**                        # 변경 가능한 트랙 패널 도안
├── licenses/                             # 외부 코드 라이선스
├── install.sh                            # 최초 설치·PC용 빌드
├── start.sh                              # Gazebo GUI와 실습 프로그램 실행
├── check.sh                              # 패키지·Gazebo 실행 점검
├── ros_env.sh                            # ROS 2·Gazebo 통신 환경 설정
├── requirements.txt                      # Python 패키지 의존성
├── system_packages.txt                   # Ubuntu 시스템 패키지 의존성
├── VERSION                               # 배포본 버전 정보
├── FILES.sha256                          # 배포 파일 체크섬 목록
├── **사용 가이드(my_lane_simulator).md**   # 설치·학습·평가·실차 실행 절차
└── **디렉터리 구조(my_lane_simulator).md**                    # 현재 파일


---

**주요 경로**

- **`design/agent.py`**: 할인율·보상 계산 등을 직접 수정하는 파일입니다.
- **`design/lighting.py`**: 광원의 성질과 위치, 트랙 정반사 값을 수정하는 파일입니다.
- **`runs/`**: 시뮬레이션에서 학습한 모델과 학습 당시의 설정이 저장됩니다.
- **`exports/`**: 실제 차량에 복사할 실행 폴더가 저장됩니다. 해당 모델 폴더의 파일을 모두 함께 옮깁니다.
- **`evaluation/`**: 평가할 때 생성되는 `driving.csv`와 평가 당시 설정·결과가 저장됩니다.
- **`gui/LaneLab.qml`**: 실습 패널의 문구와 화면 구성을 확인할 수 있습니다.

처음 빌드하거나 실행하면 `.venv/`, `build/`, `runtime/`, `ros_ws/build/`, `ros_ws/install/`, `ros_ws/log/` 등의 폴더가 추가로 만들어집니다. 위 구조는 이러한 생성물을 제외한 배포본 기준입니다.
