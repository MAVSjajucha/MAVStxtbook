#!/usr/bin/env python3
"""Reuse the A1 chassis driver and start the RGB camera, then run the policy."""
import fcntl
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
DRIVER = '/home/jetson/yahboomcar_ros2_ws/yahboomcar_ws/install/yahboomcar_bringup/lib/yahboomcar_bringup/Ackman_driver_A1'
JOY = '/home/jetson/yahboomcar_ros2_ws/yahboomcar_ws/install/yahboomcar_ctrl/lib/yahboomcar_ctrl/yahboom_joy_A1'
CAMERA = '/home/jetson/yahboomcar_ros2_ws/software/library_ws/install/ascamera/lib/ascamera/ascamera_node'


def processes(executable):
    found = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                continue
            argv = (entry / 'cmdline').read_bytes().split(b'\0')
            if os.fsencode(executable) in argv[:2]:
                found.append(entry)
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    return found


def ros_environment(process):
    env = {}
    for item in (process / 'environ').read_bytes().split(b'\0'):
        key, sep, value = item.partition(b'=')
        if sep and key in (b'ROS_DOMAIN_ID', b'RMW_IMPLEMENTATION', b'ROS_LOCALHOST_ONLY', b'CYCLONEDDS_URI', b'FASTRTPS_DEFAULT_PROFILES_FILE'):
            env[key.decode()] = value.decode()
    env.setdefault('ROS_DOMAIN_ID', '0')
    env.setdefault('RMW_IMPLEMENTATION', 'rmw_fastrtps_cpp')
    env.setdefault('ROS_LOCALHOST_ONLY', '0')
    return env


def background(command, name):
    (ROOT / 'logs').mkdir(exist_ok=True)
    with (ROOT / 'logs' / (name + '.log')).open('a') as log:
        proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, start_new_session=True)
    (ROOT / 'logs' / (name + '.pid')).write_text(str(proc.pid))
    print(f'{name} 시작 (PID {proc.pid})', flush=True)


def main():
    from drive_real import parse_arguments
    _, args = parse_arguments()
    # Preserve this lock across exec to avoid running this bundle twice.
    lock = os.open(ROOT.parent / '.lane_policy.lock', os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError('이 모델이 이미 실행 중입니다. 기존 터미널에서 Ctrl+C로 종료하세요.')
    os.set_inheritable(lock, True)
    os.ftruncate(lock, 0)
    os.write(lock, str(os.getpid()).encode())
    drivers = processes(DRIVER)
    if len(drivers) > 1:
        raise RuntimeError('차량 드라이버가 여러 개 실행 중입니다.')
    if drivers:
        device_env = ros_environment(drivers[0])
    else:
        device_env = {'ROS_DOMAIN_ID': '0', 'RMW_IMPLEMENTATION': 'rmw_fastrtps_cpp', 'ROS_LOCALHOST_ONLY': '0'}
    for name in ('CYCLONEDDS_URI', 'FASTRTPS_DEFAULT_PROFILES_FILE'):
        os.environ.pop(name, None)
    os.environ.update(device_env)
    os.environ['ROBOT_TYPE'] = 'A1'
    os.environ['CAMERA_TYPE'] = 'nuwa'
    print(f'차량 ROS_DOMAIN_ID={device_env["ROS_DOMAIN_ID"]}, RMW={device_env["RMW_IMPLEMENTATION"]}', flush=True)
    if not drivers:
        background(['ros2', 'run', 'yahboomcar_bringup', 'Ackman_driver_A1'], 'driver')
    cameras = processes(CAMERA)
    for camera in cameras:
        if ros_environment(camera)['ROS_DOMAIN_ID'] != device_env['ROS_DOMAIN_ID']:
            raise RuntimeError('기존 카메라와 차량의 ROS 도메인이 다릅니다. 기존 카메라를 종료하세요.')
    if not cameras:
        background(['ros2', 'launch', 'ascamera', 'hp60c.launch.py'], 'camera')
    if args.drive:
        for joy in processes(JOY):
            # pidfd prevents signalling a reused PID during handover.
            pidfd = os.pidfd_open(int(joy.name))
            try:
                if joy not in processes(JOY):
                    continue
                signal.pidfd_send_signal(pidfd, signal.SIGINT)
                print('기존 조이스틱 주행 노드를 종료했습니다. 차량 드라이버는 계속 사용합니다.', flush=True)
            finally:
                os.close(pidfd)
        deadline = time.monotonic() + 3
        while processes(JOY) and time.monotonic() < deadline:
            time.sleep(0.1)
        if processes(JOY):
            raise RuntimeError('조이스틱 주행 노드가 종료되지 않았습니다.')
    os.execv(sys.executable, [sys.executable, str(ROOT / 'drive_real.py'), '--bundle', str(ROOT), *sys.argv[1:]])


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError) as error:
        print(f'차량 실행 준비 실패: {error}', file=sys.stderr)
        raise SystemExit(1)
