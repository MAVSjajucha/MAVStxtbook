#!/usr/bin/env python3
"""Send a short manual calibration pulse. Requires explicit --drive; Ctrl+C stops."""
import argparse
import math
import signal
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--drive", action="store_true")
    parser.add_argument("--linear", type=float, default=0.0, help="cmd_vel.linear.x, 0~0.10")
    parser.add_argument("--angular", type=float, default=0.0, help="cmd_vel.angular.z, -0.5~0.5")
    parser.add_argument("--seconds", type=float, default=1.0, help="0 초과 3 초 이하")
    parser.add_argument("--cmd-topic", default="/cmd_vel")
    args = parser.parse_args()
    if not all(math.isfinite(x) for x in (args.linear, args.angular, args.seconds)):
        parser.error("값은 유한한 수여야 합니다.")
    if not 0 <= args.linear <= 0.1 or abs(args.angular) > 0.5 or not 0 < args.seconds <= 3:
        parser.error("linear 0~0.10, angular -0.5~0.5, seconds 0 초과~3 범위로 입력하세요.")
    if not args.drive:
        print(f"관찰 모드: {args.seconds}s 동안 linear={args.linear}, angular={args.angular}. 실행하려면 --drive.")
        return 0
    import rclpy
    from rclpy.node import Node
    from rclpy.signals import SignalHandlerOptions
    from geometry_msgs.msg import Twist
    def request_stop(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, request_stop)
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = Node("lane_lab_manual_calibration")
    publisher = node.create_publisher(Twist, args.cmd_topic, 1)
    # Let ROS discovery see competing command publishers before movement.
    try:
        start = time.monotonic()
        while time.monotonic() - start < 1:
            rclpy.spin_once(node, timeout_sec=0.1)
        start = time.monotonic()
        while rclpy.ok() and time.monotonic() - start < args.seconds:
            if node.count_publishers(args.cmd_topic) > 1:
                raise RuntimeError("다른 cmd_vel 발행기가 있습니다. 기존 주행 노드를 종료하세요.")
            message = Twist()
            message.linear.x = args.linear
            message.angular.z = args.angular
            publisher.publish(message)
            rclpy.spin_once(node, timeout_sec=0.05)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            for _ in range(3):
                publisher.publish(Twist())
                rclpy.spin_once(node, timeout_sec=0.05)
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
