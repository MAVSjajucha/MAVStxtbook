#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f /opt/ros/humble/setup.bash ]]; then
  echo 'ROS 2 Humble이 없습니다. 이 폴더는 야붐 차량의 /home/jetson 아래에서 실행하세요.' >&2
  exit 1
fi
source /opt/ros/humble/setup.bash
for lane_ws in /home/jetson/yahboomcar_ros2_ws/software/library_ws /home/jetson/yahboomcar_ros2_ws/yahboomcar_ws; do
  if [[ -f "$lane_ws/install/setup.bash" ]]; then source "$lane_ws/install/setup.bash"; fi
done
export PYTHONNOUSERSITE=1
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export LANE_SIMULATOR_ROOT="$SCRIPT_DIR"
# A copied x86 install tree is never reused on Jetson. Source builds are small;
# subsequent runs skip them unless the bundle location or message source changes.
if ! /usr/bin/python3 - "$SCRIPT_DIR" <<'PY'
import hashlib, json, platform, sys
from pathlib import Path
root = Path(sys.argv[1])
try:
    stamp = json.loads((root / 'ros_ws/.build_stamp.json').read_text())
    h = hashlib.sha256()
    for p in sorted((root / 'ros_ws/src').rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            h.update(p.relative_to(root).as_posix().encode())
            h.update(p.read_bytes())
    assert stamp == {'source_sha256': h.hexdigest(), 'machine': platform.machine(),
                     'python': list(sys.version_info[:2]), 'root': str(root.resolve())}
    assert (root / 'ros_ws/install/setup.bash').is_file()
except (OSError, ValueError, AssertionError):
    sys.exit(1)
PY
then
  bash "$SCRIPT_DIR/build_real.sh"
fi
source "$SCRIPT_DIR/ros_ws/install/setup.bash"
# System Python is required for apt-provided rclpy and cv_bridge on Jetson.
exec /usr/bin/python3 "$SCRIPT_DIR/vehicle_launcher.py" "$@"
