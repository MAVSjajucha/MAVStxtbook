#!/usr/bin/env python3
"""Read-only camera/ROS inspection; does not publish any motor commands."""
import argparse
import json
from pathlib import Path
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=5)
    parser.add_argument("--camera-topic", default="/ascamera_hp60c/camera_publisher/rgb0/image")
    parser.add_argument("--output", default="camera_report.json")
    args = parser.parse_args()
    if not 1 <= args.seconds <= 60:
        parser.error("--seconds는 1~60 사이여야 합니다.")
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import Image, CameraInfo

    class Probe(Node):
        def __init__(self):
            super().__init__("lane_lab_camera_probe")
            self.arrivals = []
            self.report = {"camera_topic": args.camera_topic, "camera_info": {}, "images": 0}
            self.image_sub = self.create_subscription(Image, args.camera_topic, self.image, qos_profile_sensor_data)
            self.info_subs = {}

        def image(self, message):
            self.arrivals.append(time.monotonic())
            self.report.update({"width": message.width, "height": message.height,
                                "encoding": message.encoding, "step": message.step,
                                "frame_id": message.header.frame_id})

        def discover(self):
            topics = self.get_topic_names_and_types()
            self.report["topics"] = {name: types for name, types in topics}
            for name, types in topics:
                if "sensor_msgs/msg/CameraInfo" in types and name not in self.info_subs:
                    def receive(message, topic=name):
                        self.report["camera_info"][topic] = {
                            "width": message.width, "height": message.height,
                            "frame_id": message.header.frame_id,
                            "distortion_model": message.distortion_model,
                            "K": list(message.k), "D": list(message.d),
                            "R": list(message.r), "P": list(message.p)}
                    self.info_subs[name] = self.create_subscription(CameraInfo, name, receive, qos_profile_sensor_data)

    rclpy.init()
    node = Probe()
    start = time.monotonic()
    last_discovery = 0
    try:
        while rclpy.ok() and time.monotonic() - start < args.seconds:
            if time.monotonic() - last_discovery > 0.5:
                node.discover()
                last_discovery = time.monotonic()
            rclpy.spin_once(node, timeout_sec=0.1)
        node.report["images"] = len(node.arrivals)
        node.report["observed_fps"] = ((len(node.arrivals) - 1) / (node.arrivals[-1] - node.arrivals[0])
                                       if len(node.arrivals) > 1 else 0)
        node.report["cmd_vel_publishers"] = [
            {"node_name": item.node_name, "node_namespace": item.node_namespace}
            for item in node.get_publishers_info_by_topic("/cmd_vel")]
        Path(args.output).write_text(json.dumps(node.report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({key: value for key, value in node.report.items() if key != "topics"}, ensure_ascii=False, indent=2))
        print(f"저장: {Path(args.output).resolve()}")
        return 0 if node.arrivals else 1
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())
