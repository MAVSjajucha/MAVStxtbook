#!/usr/bin/env python3
"""Stop lane-model processes in this deployment directory and send zero velocity."""
import os
from pathlib import Path
import signal
import time
from vehicle_launcher import ROOT, DRIVER, processes, ros_environment


def main():
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                continue
            argv = (entry / 'cmdline').read_bytes().split(b'\0')
            if len(argv) < 2:
                continue
            script = Path(os.fsdecode(argv[1]))
            if script.name != 'drive_real.py' or script.parent.parent != ROOT.parent:
                continue
            fd = os.pidfd_open(int(entry.name))
            try:
                signal.pidfd_send_signal(fd, signal.SIGINT)
            finally:
                os.close(fd)
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    drivers = processes(DRIVER)
    if not drivers:
        print('모델 정지 요청 완료. 실행 중인 차량 ROS 드라이버는 없습니다.')
        return
    device_env = ros_environment(drivers[0])
    for name in ('CYCLONEDDS_URI', 'FASTRTPS_DEFAULT_PROFILES_FILE'):
        os.environ.pop(name, None)
    os.environ.update(device_env)
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import Twist
    rclpy.init()
    node = Node('lane_lab_stop')
    pub = node.create_publisher(Twist, '/cmd_vel', 1)
    try:
        deadline = time.monotonic() + 5
        while not pub.get_subscription_count() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.05)
        if not pub.get_subscription_count():
            raise RuntimeError('차량 드라이버와 연결되지 않아 추가 정지 명령을 전달하지 못했습니다.')
        for _ in range(15):
            pub.publish(Twist())
            rclpy.spin_once(node, timeout_sec=0.05)
        print('모델 정지 요청 및 차량 속도 0 명령 전송 완료.')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
