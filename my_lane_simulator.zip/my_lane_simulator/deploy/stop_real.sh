#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source /opt/ros/humble/setup.bash
export PYTHONNOUSERSITE=1
exec /usr/bin/python3 "$SCRIPT_DIR/stop_real.py"
