#!/usr/bin/env bash
# Build only the small shared ROS interfaces/entry points on this computer.
# The vehicle does not install Gazebo, PyTorch, or Stable-Baselines3.
set -eo pipefail
MODEL_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f /opt/ros/humble/setup.bash ]]; then
  echo '차량에 ROS 2 Humble이 필요합니다.' >&2
  exit 1
fi
source /opt/ros/humble/setup.bash
if [[ ! -d "$MODEL_ROOT/ros_ws/src" ]]; then
  echo 'ros_ws/src가 없습니다. 새 버전의 sim to real 내보내기로 폴더 전체를 옮기세요.' >&2
  exit 1
fi
export PYTHONNOUSERSITE=1
MODEL_PACKAGES=(build-essential cmake python3-colcon-common-extensions python3-numpy python3-opencv
  ros-humble-ament-cmake ros-humble-ament-cmake-python ros-humble-rclpy ros-humble-cv-bridge
  ros-humble-geometry-msgs ros-humble-sensor-msgs ros-humble-std-msgs
  ros-humble-rosidl-default-generators ros-humble-rosidl-default-runtime)
MODEL_MISSING=()
for MODEL_PACKAGE in "${MODEL_PACKAGES[@]}"; do
  if [[ "$(dpkg-query -W -f='${Status}' "$MODEL_PACKAGE" 2>/dev/null || true)" != 'install ok installed' ]]; then
    MODEL_MISSING+=("$MODEL_PACKAGE")
  fi
done
if (( ${#MODEL_MISSING[@]} )); then
  echo '실차 ROS 노드 빌드에 필요한 패키지를 설치합니다.'
  sudo apt-get update
  sudo apt-get install -y "${MODEL_MISSING[@]}"
fi
cd "$MODEL_ROOT/ros_ws"
# These are generated files owned by this bundle. A previous PC build may have
# another CPU architecture or absolute prefix; rebuild it from source on Jetson.
rm -rf -- "$MODEL_ROOT/ros_ws/build" "$MODEL_ROOT/ros_ws/install" "$MODEL_ROOT/ros_ws/log"
/usr/bin/python3 -m colcon build --executor sequential \
  --packages-select my_lane_simulator_interfaces my_lane_simulator_nodes \
  --cmake-args -DCMAKE_BUILD_TYPE=Release -DPython3_EXECUTABLE=/usr/bin/python3 -DPYTHON_EXECUTABLE=/usr/bin/python3
source install/setup.bash
/usr/bin/python3 - <<'PY'
from my_lane_simulator_interfaces.msg import LaneFeatures
import rclpy
from cv_bridge import CvBridge
message = LaneFeatures()
message.v = [1.0]
message.l = [2.0]
message.r = [3.0]
print('LaneFeatures / rclpy / cv_bridge 확인 완료')
PY
/usr/bin/python3 - "$MODEL_ROOT" <<'PY'
import hashlib, json, platform, sys
from pathlib import Path
root = Path(sys.argv[1])
files = sorted((root / 'ros_ws/src').rglob('*'))
h = hashlib.sha256()
for p in files:
    if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
        h.update(p.relative_to(root).as_posix().encode())
        h.update(p.read_bytes())
(root / 'ros_ws/.build_stamp.json').write_text(json.dumps({
    'source_sha256': h.hexdigest(), 'machine': platform.machine(),
    'python': list(sys.version_info[:2]), 'root': str(root.resolve())}))
PY
echo '실차 ROS 노드 준비 완료. bash run_real.sh로 관찰, bash run_real.sh --drive로 주행합니다.'
