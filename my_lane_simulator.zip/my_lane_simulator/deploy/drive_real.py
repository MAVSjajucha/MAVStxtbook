#!/usr/bin/env python3
"""Exported PPO inference. Default is read-only dry-run; --drive enables commands."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import signal
import sys
import time

import numpy as np


def load_bundle(path):
    root = Path(path).expanduser().resolve()
    manifest_path = root / "manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for relative, expected in manifest.get("sha256", {}).items():
            target = (root / relative).resolve()
            if not target.is_relative_to(root):
                raise ValueError("manifest 경로가 모델 폴더 밖을 가리킵니다.")
            if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
                raise ValueError(f"내보낸 파일이 변경되었습니다: {relative}. PC에서 다시 내보내세요.")
    sys.path.insert(0, str(root))
    from lane_lab.policy_io import NumpyPolicy
    from lane_lab.vision import GridConfig
    settings = json.loads((root / "settings.json").read_text(encoding="utf-8"))
    # Runtime hardware calibration is deliberately separate from the frozen training settings.
    calibration = root / "real_calibration.json"
    if calibration.exists():
        overrides = json.loads(calibration.read_text(encoding="utf-8"))
        allowed = {"camera_topic", "cmd_topic", "control_hz", "image_timeout_s",
                   "calibration_confirmed", "angular_gain", "angular_offset", "angular_limit",
                   "max_speed_m_s", "angular_mode", "wheelbase_m"}
        unknown = set(overrides) - allowed
        if unknown:
            raise ValueError(f"실차 교정 파일의 알 수 없는 항목: {sorted(unknown)}")
        settings["real"] = {**settings.get("real", {}), **overrides}
    resolve_angular_limit(settings)
    spec = importlib.util.spec_from_file_location("exported_lesson", root / "lesson.py")
    lesson = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = lesson
    spec.loader.exec_module(lesson)
    return NumpyPolicy(root / "actor.npz"), lesson, settings, GridConfig.from_mapping(settings.get("vision", {}))


def finite_number(value, name, *, positive=False):
    value = float(value)
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f"{name}: 유한한 {'양수' if positive else '수'}가 필요합니다.")
    return value


def resolve_angular_limit(settings):
    """Resolve 'auto' from this model's saved action scale, not a new model's scale.

    Numeric hardware caps remain supported. This sets a command envelope only;
    it does not claim measured servo-to-wheel calibration.
    """
    real = settings.setdefault("real", {})
    if real.get("angular_limit") != "auto":
        return
    angle = finite_number(settings["steer_max_rad"], "steer_max_rad", positive=True)
    if angle >= math.pi/2:
        raise ValueError("steer_max_rad는 90°보다 작아야 합니다.")
    gain = finite_number(real.get("angular_gain", 1.0), "angular_gain")
    offset = finite_number(real.get("angular_offset", 0.0), "angular_offset")
    if real.get("angular_mode", "steering_rad") == "yaw_rate":
        speed = finite_number(real["max_speed_m_s"], "max_speed_m_s", positive=True)
        wheelbase = finite_number(real["wheelbase_m"], "wheelbase_m", positive=True)
        base_limit = speed * math.tan(angle) / wheelbase
    else:
        base_limit = angle
    real["angular_limit"] = abs(gain) * base_limit + abs(offset)


def convert_steering(speed, steering, normalized, real):
    """Map learned wheel angle to the calibrated chassis command contract."""
    gain = float(real.get("angular_gain", 1.0))
    offset = float(real.get("angular_offset", 0.0))
    limit = float(real.get("angular_limit", 1.0))
    mode = real.get("angular_mode", "steering_rad")
    if mode == "yaw_rate":
        base = speed * math.tan(steering) / float(real["wheelbase_m"])
    else:
        base = steering
    angular = float(np.clip(gain * base + offset, -limit, limit))
    base_applied = (angular - offset) / gain
    if mode == "yaw_rate":
        actual_steering = math.atan(base_applied * float(real["wheelbase_m"]) / speed) if speed > 0 else 0.0
    else:
        actual_steering = base_applied
    applied = normalized * actual_steering / steering if abs(steering) > 1e-10 else normalized
    return angular, float(np.clip(applied, -1, 1))


def parse_arguments(argv=None):
    """Validate command-line options before the launcher touches vehicle nodes."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--drive", action="store_true", help="실제 /cmd_vel 발행 (기본은 관찰만)")
    parser.add_argument("--duration", type=float, default=0, help="자동 종료 초, 0이면 Ctrl+C까지")
    parser.add_argument("--camera-topic", default=None)
    parser.add_argument("--cmd-topic", default=None)
    args = parser.parse_args(argv)
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error("duration은 0 이상의 유한한 수여야 합니다.")
    return parser, args


def main():
    parser, args = parse_arguments()
    policy, lesson, settings, grid = load_bundle(args.bundle)
    real = settings.get("real", {})
    if args.drive and real.get("calibration_confirmed") is not True:
        parser.error("실차 조향 변환이 확인되지 않았습니다. real_calibration.json을 교정하고 calibration_confirmed를 true로 바꾸세요.")
    gain = finite_number(real.get("angular_gain", 1.0), "angular_gain")
    offset = finite_number(real.get("angular_offset", 0.0), "angular_offset")
    limit = finite_number(real.get("angular_limit", 1.0), "angular_limit", positive=True)
    max_speed = finite_number(real.get("max_speed_m_s", 0.15), "max_speed_m_s", positive=True)
    # Old bundles may contain image_timeout_s. It is accepted by load_bundle
    # only for compatibility; latest-frame mode has no image-age timeout.
    frequency = finite_number(real.get("control_hz", 10), "control_hz", positive=True)
    mode = real.get("angular_mode", "steering_rad")
    if mode not in ("steering_rad", "yaw_rate"):
        parser.error("angular_mode는 steering_rad 또는 yaw_rate여야 합니다.")
    if mode == "yaw_rate":
        wheelbase = finite_number(real.get("wheelbase_m", 0), "wheelbase_m", positive=True)
        if not 0.05 <= wheelbase <= 1:
            parser.error("wheelbase_m 설정을 확인하세요.")
    if gain == 0 or abs(offset) >= limit or not 1 <= frequency <= 50 or not 0 < max_speed <= 0.5:
        parser.error("실차 gain/offset/limit, 제어 주기 또는 최대 속도 설정을 확인하세요.")
    import rclpy
    from rclpy.node import Node
    from rclpy.signals import SignalHandlerOptions
    from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
    from my_lane_simulator_interfaces.msg import LaneFeatures
    from geometry_msgs.msg import Twist
    from rclpy.executors import SingleThreadedExecutor
    from lane_lab.ros_nodes import make_grid_node, features_from_message, stamp_ns, FEATURES_TOPIC
    import cv2
    cv2.setNumThreads(1)
    cv2.ocl.setUseOpenCL(False)

    class Driver(Node):
        def __init__(self):
            super().__init__("DRL_node")
            self.pending_features = None
            self.feature_stamp = None
            self.previous_steer = 0.0
            self.failure = None
            self.last_report = 0.0
            self.started = time.monotonic()
            self.motion_started = None
            self.cmd_topic = args.cmd_topic or real.get("cmd_topic", "/cmd_vel")
            self.pub = self.create_publisher(Twist, self.cmd_topic, 1) if args.drive else None
            qos = QoSProfile(depth=1, history=HistoryPolicy.KEEP_LAST,
                             reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.VOLATILE)
            self.sub = self.create_subscription(LaneFeatures, FEATURES_TOPIC, self.on_features, qos)
            self.timer = self.create_timer(1.0 / frequency, self.tick)
            self.get_logger().info("실차 주행 모드" if args.drive else "관찰 모드: 모터 명령을 발행하지 않습니다.")

        def on_features(self, message):
            try:
                stamp = stamp_ns(message.header)
                # Header is used only for duplicate/out-of-order rejection.
                # Camera clocks need not match this computer's wall clock.
                if stamp > 0 and self.feature_stamp is not None and stamp <= self.feature_stamp:
                    return
                # Replace an unconsumed observation: never build a frame queue.
                self.pending_features = features_from_message(message, grid)
                if stamp > 0:
                    self.feature_stamp = stamp
            except Exception as error:
                self.failure = f"격자 수신 오류: {error}"
                self.stop()

        def stop(self):
            self.previous_steer = 0.0
            if self.pub is not None:
                self.pub.publish(Twist())

        def tick(self):
            try:
                now = time.monotonic()
                if self.pub is not None and self.count_publishers(self.cmd_topic) > 1:
                    raise RuntimeError("다른 /cmd_vel 발행기가 있습니다. 기존 주행 노드를 종료하세요.")
                if self.pending_features is None:
                    # No fresh observation: wait without repeating inference
                    # or publishing another driving command from an old frame.
                    return
                if self.pub is not None and self.pub.get_subscription_count() == 0:
                    self.stop()
                    if now - self.started > 10:
                        raise RuntimeError("차량 드라이버가 cmd_vel을 구독하지 않습니다.")
                    return
                features = self.pending_features
                self.pending_features = None
                observation = lesson.observe(features, self.previous_steer)
                action = policy.predict(observation)
                command = lesson.act(action, settings)
                speed = finite_number(command["speed_m_s"], "speed_m_s")
                steering = finite_number(command["steering_rad"], "steering_rad")
                normalized = finite_number(command["normalized_steer"], "normalized_steer")
                if not 0 <= speed <= max_speed or not -1 <= normalized <= 1:
                    raise ValueError("학생 액션 함수의 속도/조향이 실차 허용 범위를 벗어났습니다.")
                angular, self.previous_steer = convert_steering(speed, steering, normalized, real)
                if self.pub is not None:
                    message = Twist()
                    message.linear.x = speed
                    message.angular.z = angular
                    self.pub.publish(message)
                    if self.motion_started is None:
                        self.motion_started = now
                if now - self.last_report >= 1:
                    self.get_logger().info(f"v={speed:.3f} m/s, steer={steering:+.3f} rad, "
                                           f"cmd.angular.z={angular:+.3f}, 검출={int(features.valid_mask.sum())}/{len(features.valid_mask)}")
                    self.last_report = now
            except Exception as error:
                self.failure = f"정책 실행 중 정지: {error}"
                self.stop()

    # Keep the ROS context alive until the final zero commands have been sent.
    def request_stop(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGHUP, request_stop)
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = None
    grid_node = None
    executor = SingleThreadedExecutor()
    exit_code = 0
    try:
        grid_node = make_grid_node(grid, args.camera_topic or real.get("camera_topic",
                                    "/ascamera_hp60c/camera_publisher/rgb0/image"))
        node = Driver()
        executor.add_node(grid_node)
        executor.add_node(node)
        while rclpy.ok() and node.failure is None:
            executor.spin_once(timeout_sec=0.1)
            if grid_node.failure:
                node.failure = grid_node.failure
                node.stop()
            duration_start = node.motion_started if args.drive else node.started
            if args.duration and duration_start is not None and time.monotonic() - duration_start >= args.duration:
                break
        if node.failure:
            node.get_logger().error(node.failure)
            exit_code = 1
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.timer.cancel()
            if rclpy.ok():
                for _ in range(3):
                    node.stop()
                    executor.spin_once(timeout_sec=0.03)
            executor.remove_node(node)
            node.destroy_node()
        if grid_node is not None:
            executor.remove_node(grid_node)
            grid_node.destroy_node()
        executor.shutdown()
        if rclpy.ok():
            rclpy.shutdown()
    return exit_code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, ImportError, KeyError) as error:
        print(f"실차 실행 준비 실패: {error}", file=sys.stderr)
        raise SystemExit(1)
