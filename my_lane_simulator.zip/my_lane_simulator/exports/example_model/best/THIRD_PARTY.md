# 출처와 재사용

- `lane_lab/vision.py`: 사용자가 제공한 `my_rule_based_copy`의 `grid_core.py` 알고리즘과 영상 표시에 맞춰 구현. 원본 Apache License 2.0은 `licenses/grid_demo_APACHE2.txt`에 포함했습니다.
- `assets/tiles/`: 사용자가 제공한 Track-A~P, Track-Background 이미지. 원본 권리는 제공자에게 있습니다. 교재의 외부 재배포 시 제공자의 사용 범위를 따르세요. 파일 해시는 `assets/SHA256SUMS`를 확인하세요.
- `assets/vehicle/`: 사용자가 제공한 참고 패키지의 제조사 A1 원본 URDF와 CAD STL 9개. 원본을 보존하고 실행 시 URDF에서 상세 시각 형상과 조인트를 읽습니다. 충돌체만 간단한 도형을 사용합니다. 원본 권리·경량화 이력·하드웨어 버전 차이는 [차량 모델 출처](assets/vehicle/VEHICLE_SOURCE.md)를 참고하세요.
- Gazebo Fortress, Qt, OpenCV, NumPy, Gymnasium, Stable Baselines3, PyTorch는 설치 시 각각의 공식 배포처에서 내려받으며 해당 프로젝트 라이선스를 따릅니다.

## 구현 참고 문서

- [Gazebo Fortress Ubuntu 설치](https://gazebosim.org/docs/fortress/install_ubuntu/)
- [Gazebo GUI 플러그인](https://gazebosim.org/api/gui/6/plugins.html)
- [Gazebo 모델 이동·격자 맞춤](https://gazebosim.org/docs/fortress/manipulating_models/)
- [Fortress AckermannSteering](https://gazebosim.org/api/gazebo/6/classignition_1_1gazebo_1_1systems_1_1AckermannSteering.html)
- [Stable Baselines3 PPO](https://stable-baselines3.readthedocs.io/en/v2.4.1/modules/ppo.html)
- [ROSMASTER A1 제조사 제품](https://category.yahboom.net/products/rosmaster-a1)

카메라 초기 화각·외형은 제공된 YDLIDAR HP60C V1.5 데이터시트를 참고했습니다. 실제 640×480 스트림의 CameraInfo 값이 우선입니다. 자세한 근거와 근삿값은 `assets/PROVENANCE.md`, `config/vehicle.json`에 기록했습니다.
