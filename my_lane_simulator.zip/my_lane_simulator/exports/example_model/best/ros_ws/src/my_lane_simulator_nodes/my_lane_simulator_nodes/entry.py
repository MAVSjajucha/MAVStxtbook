import os
from pathlib import Path
import runpy
import sys


def root():
    """Resolve either an installed simulator or a copied, self-contained bundle."""
    candidates = []
    if os.environ.get('LANE_SIMULATOR_ROOT'):
        candidates.append(Path(os.environ['LANE_SIMULATOR_ROOT']).expanduser())
    candidates.extend(Path(__file__).resolve().parents)
    for candidate in candidates:
        if (candidate / 'lane_lab' / 'vision.py').is_file():
            sys.path.insert(0, str(candidate))
            return candidate
    raise RuntimeError('LANE_SIMULATOR_ROOT를 패키지 또는 내보낸 모델 폴더로 지정하세요.')


def grid_main():
    root()
    from lane_lab.ros_nodes import grid_main as run
    return run()


def policy_main():
    folder = root()
    script = folder / 'drive_real.py'
    if not script.is_file():
        script = folder / 'deploy' / 'drive_real.py'
    runpy.run_path(str(script), run_name='__main__')
