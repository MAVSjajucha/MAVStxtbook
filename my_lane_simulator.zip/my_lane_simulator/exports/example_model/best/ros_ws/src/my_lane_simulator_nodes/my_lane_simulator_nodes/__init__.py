"""ROS entry points; executable policy and vision stay beside the frozen bundle."""
