from setuptools import find_packages, setup

package_name = 'my_lane_simulator_nodes'
setup(
    name=package_name, version='1.0.0', packages=find_packages(),
    data_files=[('share/ament_index/resource_index/packages', ['resource/' + package_name]),
                ('share/' + package_name, ['package.xml'])],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='My Lane Simulator', maintainer_email='maintainer@example.invalid',
    description='Shared lane grid and policy ROS nodes', license='Apache-2.0',
    entry_points={'console_scripts': [
        'grid_node = my_lane_simulator_nodes.entry:grid_main',
        'DRL_node = my_lane_simulator_nodes.entry:policy_main',
    ]},
)
