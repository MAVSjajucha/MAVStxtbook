"""학생 격자 데모와 같은 영상 처리. 시뮬레이션과 실차가 이 파일을 함께 쓴다.

Original grid calculation/colours: my_rule_based_copy/grid_core.py (Apache-2.0).
Distances are pixels, ROI coordinates are measured upward from the image bottom.
No colour classifier or hidden road-position estimate is added here.
"""
from dataclasses import dataclass, fields
from typing import Mapping

import cv2
import numpy as np

VERTICAL_LINE_BGR = (0, 255, 255)
HORIZONTAL_LINE_BGR = (255, 246, 0)
V_POINT_BGR = (0, 0, 255)
L_POINT_BGR = (130, 160, 0)
R_POINT_BGR = (227, 110, 0)


@dataclass(frozen=True)
class GridConfig:
    width: int = 640
    height: int = 480
    rows: int = 3
    cols: int = 7
    roi_bottom_px: int = 50
    roi_top_px: int = 150
    canny_low: int = 100
    canny_high: int = 300
    blur_kernel: int = 5

    def __post_init__(self):
        for item in fields(self):
            value = getattr(self, item.name)
            if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
                raise ValueError(f"{item.name}: 정수를 입력하세요.")
        if self.width < 2 or self.height < 2:
            raise ValueError("영상 가로/세로 크기는 2 이상이어야 합니다.")
        if not 0 <= self.roi_bottom_px < self.roi_top_px <= self.height:
            raise ValueError("ROI: 0 <= roi_bottom_px < roi_top_px <= height")
        if not 1 <= self.cols < self.width or not 1 <= self.rows < self.roi_height:
            raise ValueError("격자 개수는 영상 너비/ROI 높이보다 작아야 합니다.")
        if not 0 <= self.canny_low < self.canny_high:
            raise ValueError("Canny: 0 <= canny_low < canny_high")
        if self.blur_kernel <= 0 or self.blur_kernel % 2 == 0:
            raise ValueError("blur_kernel은 양의 홀수여야 합니다.")

    @classmethod
    def from_mapping(cls, values: Mapping | None = None):
        aliases = {"processing_width": "width", "processing_height": "height",
                   "roi_b": "roi_bottom_px", "roi_t": "roi_top_px",
                   "ths1": "canny_low", "ths2": "canny_high", "ker_size": "blur_kernel"}
        normalized = {}
        for key, value in (values or {}).items():
            key = aliases.get(key, key)
            if key in normalized:
                raise ValueError(f"격자 설정이 중복되었습니다: {key}")
            normalized[key] = value
        return cls(**normalized)

    @property
    def roi_height(self):
        return self.roi_top_px - self.roi_bottom_px

    @property
    def cv_top(self):
        return self.height - self.roi_top_px

    @property
    def cv_bottom(self):
        return self.height - self.roi_bottom_px

    @property
    def center_x(self):
        return self.width // 2

    @property
    def horizontal_y(self):
        return [self.height - 1 - self.roi_bottom_px -
                round((i + 1) * self.roi_height / (self.rows + 1))
                for i in range(self.rows)]

    @property
    def vertical_x(self):
        return [round((i + 1) * self.width / (self.cols + 1))
                for i in range(self.cols)]


@dataclass
class GridFeatures:
    V: np.ndarray
    L: np.ndarray
    R: np.ndarray
    v_valid: np.ndarray
    l_valid: np.ndarray
    r_valid: np.ndarray
    config: GridConfig = GridConfig()
    edges: np.ndarray | None = None

    @property
    def valid_mask(self):
        return np.concatenate((self.v_valid, self.l_valid, self.r_valid)).astype(np.float32)


def prepare_image(image_bgr: np.ndarray, config: GridConfig = GridConfig()):
    image_bgr = np.asarray(image_bgr)
    if image_bgr.ndim != 3 or image_bgr.shape[2] != 3 or image_bgr.dtype != np.uint8:
        raise ValueError("카메라 영상은 uint8 BGR 3채널이어야 합니다.")
    if image_bgr.shape[0] == 0 or image_bgr.shape[1] == 0:
        raise ValueError("카메라 영상이 비어 있습니다.")
    if image_bgr.shape[:2] != (config.height, config.width):
        image_bgr = cv2.resize(image_bgr, (config.width, config.height))
    return image_bgr


def extract_features(image_bgr: np.ndarray, config: GridConfig = GridConfig()) -> GridFeatures:
    """V: 왼쪽→오른쪽, L/R: 아래→위. 검출 실패도 원본 sentinel을 유지한다."""
    image_bgr = prepare_image(image_bgr, config)
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (config.blur_kernel, config.blur_kernel), 0)
    edges = cv2.Canny(blurred, config.canny_low, config.canny_high)
    left, right, vertical = [], [], []
    for y in config.horizontal_y:
        left_hits = np.flatnonzero(edges[y, :config.center_x + 1])
        right_hits = np.flatnonzero(edges[y, config.center_x:])
        left.append(config.center_x - int(left_hits[-1]) if left_hits.size else config.center_x + 1)
        right.append(int(right_hits[0]) if right_hits.size else config.width - config.center_x)
    for x in config.vertical_x:
        hits = np.flatnonzero(edges[config.cv_top:config.cv_bottom, x])
        vertical.append(config.roi_height - 1 - int(hits[-1]) if hits.size else config.roi_height)
    v, l, r = (np.asarray(items, dtype=np.int32) for items in (vertical, left, right))
    return GridFeatures(v, l, r, v != config.roi_height, l != config.center_x + 1,
                        r != config.width - config.center_x, config, edges)


def normalized_distances(features: GridFeatures, config: GridConfig | None = None) -> np.ndarray:
    """V/100, L/320, R/320 (기본 설정). 미검출은 0, 별도 mask로 구별한다."""
    config = config or features.config
    return np.concatenate((
        np.where(features.v_valid, features.V / config.roi_height, 0),
        np.where(features.l_valid, features.L / config.center_x, 0),
        np.where(features.r_valid, features.R / (config.width - config.center_x), 0),
    )).astype(np.float32)


def draw_grid(image_bgr: np.ndarray, features: GridFeatures | None = None,
              config: GridConfig | None = None) -> np.ndarray:
    """원본 데모의 격자/특징점 위치와 BGR 색상을 그대로 표시한다."""
    config = config or (features.config if features is not None else GridConfig())
    image_bgr = prepare_image(image_bgr, config)
    features = features if features is not None else extract_features(image_bgr, config)
    debug = image_bgr.copy()
    edges = features.edges
    if edges is None:
        edges = extract_features(image_bgr, config).edges
    roi = debug[config.cv_top:config.cv_bottom]
    roi[edges[config.cv_top:config.cv_bottom] > 0] = (255, 255, 255)
    for x in config.vertical_x:
        cv2.line(debug, (x, config.cv_top), (x, config.cv_bottom - 1), VERTICAL_LINE_BGR, 1)
    for y in config.horizontal_y:
        cv2.line(debug, (0, y), (config.width - 1, y), HORIZONTAL_LINE_BGR, 1)
    for i, y in enumerate(config.horizontal_y):
        if features.l_valid[i]:
            cv2.circle(debug, (config.center_x - int(features.L[i]), y), 5, L_POINT_BGR, -1)
        if features.r_valid[i]:
            cv2.circle(debug, (config.center_x + int(features.R[i]), y), 5, R_POINT_BGR, -1)
    for i, x in enumerate(config.vertical_x):
        if features.v_valid[i]:
            cv2.circle(debug, (x, config.cv_bottom - 1 - int(features.V[i])), 5, V_POINT_BGR, -1)
    return debug
