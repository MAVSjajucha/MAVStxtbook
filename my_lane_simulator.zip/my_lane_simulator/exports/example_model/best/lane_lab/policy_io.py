"""Small PPO actor export: training uses SB3/Torch; Jetson inference needs NumPy only."""
from pathlib import Path

import numpy as np

FORMAT_VERSION = 1


def export_actor(model_or_policy, destination, observation_size=None):
    """Export SB3's deterministic unsquashed Tanh MLP actor (no value network)."""
    import torch

    policy = getattr(model_or_policy, "policy", model_or_policy)
    if getattr(policy, "squash_output", False):
        raise ValueError("squash_output 정책은 이 내보내기 형식에서 지원하지 않습니다.")
    if getattr(policy, "use_sde", False):
        raise ValueError("use_sde=False로 학습하세요.")
    observation_shape = tuple(policy.observation_space.shape)
    if len(observation_shape) != 1:
        raise ValueError("1차원 격자 관측만 내보낼 수 있습니다.")
    size = int(observation_shape[0])
    if observation_size is not None and size != observation_size:
        raise ValueError(f"관측 차원 불일치: 모델={size}, 설정={observation_size}")
    if policy.action_space.shape != (1,):
        raise ValueError("조향 액션 1개인 정책이어야 합니다.")
    low = np.asarray(policy.action_space.low, dtype=np.float32)
    high = np.asarray(policy.action_space.high, dtype=np.float32)
    if not np.array_equal(low, [-1.0]) or not np.array_equal(high, [1.0]):
        raise ValueError("액션 범위는 [-1, +1]이어야 합니다.")
    # Reject learned preprocessing: exported observation is passed directly to the MLP.
    extractor = policy.features_extractor
    if any(True for _ in extractor.parameters()) or extractor.__class__.__name__ != "FlattenExtractor":
        raise ValueError("FlattenExtractor를 사용하는 MlpPolicy만 내보낼 수 있습니다.")
    modules = list(policy.mlp_extractor.policy_net.children())
    if not modules or len(modules) % 2:
        raise ValueError("정책 은닉층은 Linear, Tanh 순서여야 합니다.")
    layers = []
    for i in range(0, len(modules), 2):
        if not isinstance(modules[i], torch.nn.Linear) or not isinstance(modules[i + 1], torch.nn.Tanh):
            raise ValueError("정책 은닉층은 Linear, Tanh 순서여야 합니다.")
        layers.append(modules[i])
    if not isinstance(policy.action_net, torch.nn.Linear):
        raise ValueError("액션 출력층은 Linear여야 합니다.")
    layers.append(policy.action_net)
    payload = {"format_version": np.array(FORMAT_VERSION, dtype=np.int32),
               "layer_count": np.array(len(layers), dtype=np.int32),
               "observation_size": np.array(size, dtype=np.int32),
               "action_low": low, "action_high": high}
    for index, layer in enumerate(layers):
        payload[f"W{index}"] = layer.weight.detach().cpu().numpy().astype(np.float32)
        payload[f"b{index}"] = layer.bias.detach().cpu().numpy().astype(np.float32)
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # A file object prevents NumPy from silently appending another '.npz'.
    with destination.open("wb") as handle:
        np.savez_compressed(handle, **payload)
    exported = NumpyPolicy(destination)
    # Compare exact exported preprocessing/action semantics before returning a bundle.
    rng = np.random.default_rng(104)
    observations = rng.uniform(-1, 1, (32, size)).astype(np.float32)
    expected, _ = policy.predict(observations, deterministic=True)
    actual = exported.predict(observations)
    if not np.allclose(actual, expected, rtol=2e-5, atol=2e-6):
        destination.unlink(missing_ok=True)
        raise RuntimeError("NumPy 내보내기와 학습 정책의 액션이 일치하지 않습니다.")
    return {"format_version": FORMAT_VERSION, "observation_size": size,
            "hidden_sizes": [int(layer.out_features) for layer in layers[:-1]],
            "max_action_error": float(np.max(np.abs(actual - expected)))}


class NumpyPolicy:
    def __init__(self, path):
        with np.load(path, allow_pickle=False) as data:
            if int(data["format_version"]) != FORMAT_VERSION:
                raise ValueError("지원하지 않는 정책 파일 버전입니다.")
            count = int(data["layer_count"])
            if not 2 <= count <= 20:
                raise ValueError("정책 층 수가 올바르지 않습니다.")
            self.observation_size = int(data["observation_size"])
            if self.observation_size < 1:
                raise ValueError("관측 차원이 올바르지 않습니다.")
            self.low = np.asarray(data["action_low"], dtype=np.float32)
            self.high = np.asarray(data["action_high"], dtype=np.float32)
            if not np.array_equal(self.low, [-1.0]) or not np.array_equal(self.high, [1.0]):
                raise ValueError("정책 액션 범위는 [-1, +1]이어야 합니다.")
            self.layers = []
            previous_size = self.observation_size
            for index in range(count):
                weight = np.asarray(data[f"W{index}"], dtype=np.float32)
                bias = np.asarray(data[f"b{index}"], dtype=np.float32)
                if weight.ndim != 2 or bias.ndim != 1 or weight.shape != (bias.size, previous_size):
                    raise ValueError(f"정책의 {index}번 층 크기가 맞지 않습니다.")
                if not np.isfinite(weight).all() or not np.isfinite(bias).all():
                    raise ValueError("정책 가중치에 NaN 또는 무한대가 있습니다.")
                self.layers.append((weight.copy(), bias.copy()))
                previous_size = bias.size
            if previous_size != 1:
                raise ValueError("출력 액션이 1개여야 합니다.")

    def predict(self, observation):
        """Return one normalized steering action, or a batch of actions."""
        value = np.asarray(observation, dtype=np.float32)
        if value.ndim not in (1, 2) or value.shape[-1] != self.observation_size:
            raise ValueError(f"관측 마지막 차원은 {self.observation_size}이어야 합니다.")
        if not np.isfinite(value).all():
            raise ValueError("관측에 NaN 또는 무한대가 있습니다.")
        for index, (weight, bias) in enumerate(self.layers):
            value = value @ weight.T + bias
            if index < len(self.layers) - 1:
                value = np.tanh(value)
        if not np.isfinite(value).all():
            raise ValueError("정책 출력이 유한한 수가 아닙니다.")
        return np.clip(value, self.low, self.high).astype(np.float32)
