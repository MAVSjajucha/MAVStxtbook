"""시뮬레이터와 실차가 공유하는 격자 ROS 노드.

격자 산출은 vision.extract_features 한 곳에서만 수행합니다. LaneFeatures는
픽셀 거리와 촬영 시각만 전달하며, 정규화/직전 조향 결합은 DRL_node의 역할입니다.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path

import numpy as np

from .vision import GridConfig, GridFeatures, extract_features

CAMERA_TOPIC = '/ascamera_hp60c/camera_publisher/rgb0/image'
FEATURES_TOPIC = '/lane_features_topic'


def stamp_ns(header):
    return int(header.stamp.sec) * 1_000_000_000 + int(header.stamp.nanosec)


def features_from_message(message, config):
    """원본 픽셀 값으로 원본 검출 여부를 복원합니다. 추가 입력은 없습니다."""
    arrays = []
    specs = ((message.v, config.cols, config.roi_height, 'v'),
             (message.l, config.rows, config.center_x + 1, 'l'),
             (message.r, config.rows, config.width - config.center_x, 'r'))
    for values, count, sentinel, name in specs:
        value = np.asarray(values, dtype=np.float32)
        if value.shape != (count,):
            raise ValueError(f'{name} 격자 수 불일치: {value.size}, 설정 {count}')
        if (not np.isfinite(value).all() or np.any(value < 0)
                or np.any(value > sentinel) or np.any(value != np.rint(value))):
            raise ValueError(f'{name}: 격자 픽셀 값이 올바르지 않습니다.')
        arrays.append(value.astype(np.int32))
    v, l, r = arrays
    return GridFeatures(v, l, r, v != config.roi_height,
                        l != config.center_x + 1,
                        r != config.width - config.center_x, config)


def message_from_features(features, header):
    from my_lane_simulator_interfaces.msg import LaneFeatures
    message = LaneFeatures()
    message.header = deepcopy(header)
    message.v = features.V.astype(float).tolist()
    message.l = features.L.astype(float).tolist()
    message.r = features.R.astype(float).tolist()
    return message


def make_grid_node(config, camera_topic=CAMERA_TOPIC, features_topic=FEATURES_TOPIC,
                   *, context=None, use_sim_time=False):
    """Lazy ROS imports also let dependency-free tests check the wire format."""
    import cv2
    from cv_bridge import CvBridge
    from rclpy.node import Node
    from rclpy.parameter import Parameter
    from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
    from sensor_msgs.msg import Image
    from my_lane_simulator_interfaces.msg import LaneFeatures

    class GridNode(Node):
        def __init__(self):
            super().__init__('grid_node', context=context, use_global_arguments=False,
                             parameter_overrides=[Parameter('use_sim_time', value=use_sim_time)])
            self.config = config
            self.bridge = CvBridge()
            self.failure = None
            self.frames = 0
            cv2.setNumThreads(1)
            cv2.ocl.setUseOpenCL(False)
            # The simulation bridge offers RELIABLE: do not lose its final
            # frame while physics is paused. Real camera producers may only
            # offer BEST_EFFORT, so retain the compatible sensor QoS there.
            # Keep simulation history for exact-stamp barriers. The real-car
            # path keeps only the latest queued image and feature message.
            camera_qos = QoSProfile(depth=8 if use_sim_time else 1, history=HistoryPolicy.KEEP_LAST,
                                    reliability=(ReliabilityPolicy.RELIABLE if use_sim_time
                                                 else ReliabilityPolicy.BEST_EFFORT),
                                    durability=DurabilityPolicy.VOLATILE)
            self.publisher = self.create_publisher(LaneFeatures, features_topic,
                                                  64 if use_sim_time else 1)
            self.subscription = self.create_subscription(Image, camera_topic, self.on_image, camera_qos)

        def on_image(self, message):
            try:
                image = self.bridge.imgmsg_to_cv2(message, desired_encoding='bgr8')
                features = extract_features(image, self.config)
                self.publisher.publish(message_from_features(features, message.header))
                self.frames += 1
            except Exception as error:
                # Do not emit fabricated observations. The real policy's main
                # loop observes this failure and issues its error-stop command.
                self.failure = f'격자 영상 처리 실패: {error}'
                self.get_logger().error(self.failure)

    return GridNode()


def grid_main(argv=None):
    parser = argparse.ArgumentParser(description='원본 카메라 격자를 LaneFeatures로 발행합니다.')
    parser.add_argument('--settings', required=True)
    parser.add_argument('--camera-topic', default=CAMERA_TOPIC)
    parser.add_argument('--features-topic', default=FEATURES_TOPIC)
    parser.add_argument('--use-sim-time', action='store_true')
    args = parser.parse_args(argv)
    settings = json.loads(Path(args.settings).read_text(encoding='utf-8'))
    config = GridConfig.from_mapping(settings.get('vision', {}))
    import rclpy
    from rclpy.executors import ExternalShutdownException
    rclpy.init(args=[])
    node = make_grid_node(config, args.camera_topic, args.features_topic,
                          use_sim_time=args.use_sim_time)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    except Exception:
        # SIGTERM can invalidate a wait set (RCLError), or clear rclpy's global
        # executor during spin() (AttributeError). Only ignore errors after the
        # context was shut down; live-context failures must still surface.
        if rclpy.ok():
            raise
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    grid_main()
