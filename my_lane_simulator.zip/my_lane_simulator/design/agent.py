'''차선 주행 실습을 위해 직접 수정하는 파일입니다. 수정 후 Gazebo GUI에서 '학습 코드 검사'를 진행합니다. 재빌드는 필요하지 않습니다.'''

import numpy as np
from lane_lab.vision import normalized_distances


'''
# 미래 보상의 할인율입니다. 0~1 사이의 숫자로 수정하세요.
# 0에 가까울수록 당장의 보상, 1에 가까울수록 먼 미래의 보상도 중요하게 봅니다.
# 저장 후 '학습 코드 검사' → '학습 진행'으로 새 학습에 적용합니다.
# 이어서 학습할 때는 저장된 모델과 같은 값이어야 합니다.
'''
gamma = 0.995


'''
============================================================================================================================================

① 입력: 신경망에 입력되는 값입니다.
--------------------------------------------------------------------------------------------------------------------------------------------
- 특징점 값과 직전 조향 정보가 입력됩니다.
- 격자 개수에 따라 특징점 값 개수는 달라집니다.
- 특징점 값은 0~1 사이의 값으로 정규화됩니다. 만약, 특징점 값이 미검출되면 1.1로 입력됩니다.
- 직전 조향 정보는 최대 조향 값을 기준으로 -1~+1로 정규화됩니다.
'''

def observe(features, previous_steer):
    missing_value = 1.1
    distances = normalized_distances(features)
    distances = np.where(features.valid_mask > 0, distances, missing_value)
    return np.concatenate([distances, [previous_steer]]).astype(np.float32)

'''
============================================================================================================================================

② 보상: 신경망은 여기서 설정한 보상이 최대가 되도록 업데이트를 진행합니다.
--------------------------------------------------------------------------------------------------------------------------------------------
- wheel_clearance_m: 네 바퀴의 접지면과 흰 선 사이의 최소 여유 거리(m)입니다. 차선과 접촉 시 0, 차선을 밟거나 이탈하면 음수가 산출됩니다.
- new_progress_m: 이전 시행보다 추가로 전진한 거리(m)입니다.
- lap_completed: 정해진 주행 코스를 한 바퀴 완주했는지 판단하는 변수입니다.
- steer / previous_steer: 현재 / 직전 조향 명령입니다.
- features: V/L/R 특징점 값.
- speed_m_s: 전진 속도(m/s).
'''

def calculate_reward(state):
    # near_line을 산출하는 기준 거리(m)입니다.
    safe_gap_m = 0.02       
    # touched_line을 산출하는 차선 접촉 기준 거리(m)입니다.
    touch_gap_m = 0.00
    # progress를 산출하는 기준 거리(m)입니다. 이 거리만큼 전진하면 progress가 1이 됩니다.
    progress_unit_m = 0.05

    # progress_unit_m을 이용하여 이전보다 더 전진했는지 계산합니다. 0~1 사이의 값으로 산출됩니다.
    progress = np.clip(state.new_progress_m / progress_unit_m, 0.0, 1.0)
    # safe_gap_m을 기준으로 차선과의 근접 정도를 계산합니다. 1 스텝 동안 최대로 근접한 순간을 기준으로 산출합니다.
    near_line = np.clip((safe_gap_m - state.wheel_clearance_m) / safe_gap_m, 0.0, 1.0)
    # touch_gap_m을 기준으로 차선 접촉을 계산합니다. 차선과 접촉하면 1(True), 접촉하지 않으면 0(False)이 됩니다.
    touched_line = state.wheel_clearance_m <= touch_gap_m
    # 차선을 완주하면 1(True), 완주하지 못하면 0(False)이 됩니다.
    finished = state.lap_completed and not touched_line

    # 보상을 계산하여 score로 저장합니다. 다양한 방식으로 수식을 재구성해 봅시다.
    score = (10.0 * progress + 10.0 * finished) - (10.0 * near_line + 10.0 * touched_line)
    
    end_episode = touched_line or finished
    return float(score), bool(end_episode)

'''
============================================================================================================================================

③ 액션: 신경망의 출력입니다.
--------------------------------------------------------------------------------------------------------------------------------------------
- 조향 값과 주행 속도(고정 값. 기본 값은 0.1m/s)를 출력합니다.
'''

def act(action, settings):
    steer = float(np.clip(np.asarray(action).reshape(-1)[0], -1.0, 1.0))
    steering_rad = steer * float(settings["steer_max_rad"])
    speed_m_s = float(settings.get("speed_m_s", 0.10))
    return {"normalized_steer": steer, "steering_rad": steering_rad, "speed_m_s": speed_m_s}
